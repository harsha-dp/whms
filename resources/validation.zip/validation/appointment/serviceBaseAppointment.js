/**
 * 
 */

function validate(from) {
	/* Start */
	var error = document.getElementById("sel1error");
	var sel1 = form["sel1"].value;

	error.innerHTML = "";

	if (sel1 == null || sel1 == "") {
		error.innerHTML = "Select Service";
		return false;
	}

	var error = document.getElementById("familerror");
	var family = form["family"].value;

	error.innerHTML = "";

	if (family == null || family == "") {
		error.innerHTML = "Select famly member name";
		return false;
	}

	var error = document.getElementById("dateerror");
	var datepicker = form["datepicker"].value;

	error.innerHTML = "";

	if (datepicker == null || datepicker == "") {
		error.innerHTML = "Please select appointment date";
		return false;
	}

	var error = document.getElementById("timeerror");
	var timee = form["timee"].value;

	error.innerHTML = "";

	if (timee == null || timee == "") {
		error.innerHTML = "Please select appointment Time";
		return false;
	}

}