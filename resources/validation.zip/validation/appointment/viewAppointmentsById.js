/**
 * 
 */

function validate(from) {
	var error = document.getElementById("docerror");
	var doc = form["doc"].value;

	error.innerHTML = "";

	if (doc == null || doc == "") {
		error.innerHTML = "Enter Document Name ";
		return false;
	}

	var error = document.getElementById("browseerror");
	var browse = form["browse"].value;

	error.innerHTML = "";

	if (browse == null || browse == "") {
		error.innerHTML = "Select File ";
		return false;
	}
}