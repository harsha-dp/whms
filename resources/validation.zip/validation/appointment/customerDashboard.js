/**
 * 
 */
function validate(from) {
	/* Start */var error = document.getElementById("contactError");
	var cardRPhnNumber = form["cardRPhnNumber"].value;

	error.innerHTML = "";

	if (cardRPhnNumber == null || cardRPhnNumber == "") {
		error.innerHTML = "Please enter customer card number";
		return false;
	}

	else if (isNaN(cardRPhnNumber)) {
		error.innerHTML = "Thank you for enter vaild number";
		return true;
	}
}