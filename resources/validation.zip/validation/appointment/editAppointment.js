/**
 * 
 */
function validate(from) {
	/* Start */

	var error = document.getElementById("dateerror");
	var datepicker = form["datepicker"].value;

	error.innerHTML = "";

	if (datepicker == null || datepicker == "") {
		error.innerHTML = "Please select Edit appointment date";
		return false;
	}

	var error = document.getElementById("timeerror");
	var timee = form["timee"].value;

	error.innerHTML = "";

	if (timee == null || timee == "") {
		error.innerHTML = "Please select Edit appointment Time";
		return false;
	}

	var error = document.getElementById("statuserror");
	var status = form["status"].value;

	error.innerHTML = "";

	if (status == null || status == "") {
		error.innerHTML = "Please select Status";
		return false;
	}

	var error = document.getElementById("Remarkerror");
	var remark = form["remark"].value;

	error.innerHTML = "";

	if (remark == null || remark == "") {
		error.innerHTML = "Please input Remark";
		return false;
	}

	if (remark.length < 3) {
		error.innerHTML = "Enter minimum 3 character";
		return false;
	}

	if (remark.length > 500) {
		error.innerHTML = "you entered more then 500 character please enter less then 500 character";
		return false;
	}
}

function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}