/**
 * 
 */

function validate(from) {

	/* start */
	var error = document.getElementById("nameerror");
	var name = form["name"].value;

	error.innerHTML = "";

	if (name == null || name == "") {
		error.innerHTML = "Input Your FirstName";
		return false;
	}

	else if (!isNaN(name)) {
		error.innerHTML = "Name Can Not be a number";
		return false;
	}

	if (name.length < 3) {
		error.innerHTML = "Name should be minimum 3 character";
		return false;
	}
	if (name.length > 25) {
		error.innerHTML = "Name should be in between 3 to 25 character";
		return false;
	}/* end */

	/* Start */
	var error = document.getElementById("contactErrorr");
	var Contactnumber = form["Contactnumber"].value;
	error.innerHTML = "";

	if (Contactnumber == null || Contactnumber == "")

	{
		error.innerHTML = "Please input mobile number";
		return false;
	}
	if (/^[0-9 ,+]*$/.test(Contactnumber) == false) {
		error.innerHTML = "Mobile Number Can Not be an alphabate  ";
		return false;
	}

	if (Contactnumber.length < 10) {
		error.innerHTML = "Mobile Number should be minimum 10 digits";
		return false;
	}

	if (Contactnumber.length > 12) {
		error.innerHTML = "You entered more then 12 digit please enter valid mobile number";
		return false;
	}

	/*
	 * if(isNAN(Contactnumber)){ error.innerHTML=" input digits only"; return
	 * false; }
	 */

	var error = document.getElementById("modeeerror");
	var modee = form["modee"].value;

	error.innerHTML = "";

	if (modee == null || modee == "") {
		error.innerHTML = "Please select Interaction mode ";
		return false;
	}

	var error = document.getElementById("purposeerror");
	var purposeee = form["purposeee"].value;

	error.innerHTML = "";

	if (purposeee == null || purposeee == "") {
		error.innerHTML = "Please select Interaction purpose";
		return false;
	}

	var error = document.getElementById("througheerror");
	var through = form["through"].value;

	error.innerHTML = "";

	if (through == null || through == "") {
		error.innerHTML = "Please select Interaction through";
		return false;
	}

	var error = document.getElementById("statusserror");
	var statuss = form["statuss"].value;

	error.innerHTML = "";

	if (statuss == null || statuss == "") {
		error.innerHTML = "Please select Status";
		return false;
	}
	var error = document.getElementById("detilserror");
	var details = form["details"].value;

	error.innerHTML = "";

	if (details == null || details == "") {
		error.innerHTML = "input Interaction details";
		return false;
	}

	if (details.length < 3) {
		error.innerHTML = "Input minimum 3 character";
		return false;
	}

	if (details.length > 500) {
		error.innerHTML = "You entered more then 500 charcater please enter less then 500 character";
		return false;
	}

}

function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
	s
}
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}