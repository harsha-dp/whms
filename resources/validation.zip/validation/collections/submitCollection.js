/**
 * 
 */
function validate(from) {

	/*
	 * var error = document.getElementById("applicationerror"); var
	 * aplicationno=form["aplicationno"].value; error.innerHTML="";
	 * 
	 * 
	 * if(aplicationno=null ||aplicationno=="" ) //for text use
	 * if(strUser1=="Select") { error.innerHTML="Please Select Application
	 * Number "; return false; }
	 */
	var error = document.getElementById("paymenterror");
	var purposes = form["payment"].value;
	error.innerHTML = "";

	if (purposes = null || purposes == "") // for text use
											// if(strUser1=="Select")
	{
		error.innerHTML = "Please Select Payment Mode ";
		return false;
	}

	var error = document.getElementById("checkerror");
	var datepicker1 = form["datepicker1"].value;

	error.innerHTML = "";

	if (payment.datepicker1) {
		error.innerHTML = "Cheque number has to be minmum 6 digits"
		return false;
	}
}

function disable_Online() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = true;

}
function disable_Cash() {
	document.getElementById("datepicker1").disabled = true;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = true;
}
function disable_Credit_debit() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = false;
}

function enable_Cheque() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = false;
	document.getElementById("datepicker-autoclose").disabled = false;
	document.getElementById("terminal").disabled = true;
}
function disable_Complimentary() {
	document.getElementById("datepicker1").disabled = true;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = true;
}
function disable_NEFT() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = false;
	document.getElementById("terminal").disabled = true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}