/**
 * 
 */
function validate(from) {

	var error = document.getElementById("taskstatuserror");
	var taskstatuss = form["taskstatuss"].value;

	error.innerHTML = "";
	if (taskstatuss == "" || taskstatuss == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("timespentederror");
	var timespented = form["timespented"].value;

	error.innerHTML = "";
	if (timespented == "" || timespented == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("percentageerror");
	var percentage = form["percentage"].value;

	error.innerHTML = "";
	if (percentage == "" || percentage == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("usernoteserror");
	var user = form["user"].value;

	error.innerHTML = "";

	if (user == null || user == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	if (user.length < 3) {
		error.innerHTML = "Enter minimum 3 character";
		return false;
	}
	if (user.length > 500) {
		error.innerHTML = "Enter in between 3 to 500 character";
		return false;
	}/* end */

	var error = document.getElementById("daterangeerror");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";
	if (datepickerautoclose == "" || datepickerautoclose == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("daterange1error");
	var datepickerautoclose1 = form["datepickerautoclose1"].value;

	error.innerHTML = "";
	if (datepickerautoclose1 == "" || datepickerautoclose1 == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("percentageerror");
	var percentage = form["percentage"].value;

	error.innerHTML = "";
	if (percentage == "" || percentage == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

}
