/**
 * 
 */

function validate(from) {

	var error = document.getElementById("error");
	var name = form["name"].value;

	error.innerHTML = "";
	if (name == "" || name == null) {
		document.getElementById("error").innerHTML = "This field cannot be empty!";
		document.getElementById("name").focus()
		return false;
	}

	var error = document.getElementById("Authorerror");
	var Author = form["Author"].value;

	error.innerHTML = "";
	if (Author == "" || Author == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("Assignerror");
	var Assign = form["Assign"].value;

	error.innerHTML = "";
	if (Assign == "" || Assign == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("tasktypeerror");
	var task = form["task"].value;

	error.innerHTML = "";
	if (task == "" || task == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("activityerror");
	var activity = form["activity"].value;

	error.innerHTML = "";
	if (activity == "" || activity == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("drop4error");
	var alloptions = form["alloptions"].value;

	error.innerHTML = "";

	if (alloptions == null || alloptions == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	if (alloptions.length < 3) {
		error.innerHTML = "Enter minimum 3 character";
		return false;
	}
	if (alloptions.length > 500) {
		error.innerHTML = "Enter in between 3 to 500 character";
		return false;
	}/* end */

	var error = document.getElementById("descriptionerror");
	var description = form["description"].value;

	error.innerHTML = "";

	if (description == null || description == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	if (description.length < 3) {
		error.innerHTML = "Enter minimum 3 character";
		return false;
	}

	var error = document.getElementById("daterangeerror");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("daterangeerror1");
	var datepickerautoclose1 = form["datepickerautoclose1"].value;

	error.innerHTML = "";

	if (datepickerautoclose1 == null || datepickerautoclose1 == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}
	var error = document.getElementById("droperror");
	var defaultconfig = form["defaultconfig"].value;

	error.innerHTML = "";
	if (defaultconfig == "" || defaultconfig == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	if (/^[0-9,:]*$/.test(defaultconfig) == false) {

		error.innerHTML = "Please enter only digits";
		return false;
	} else if (defaultconfig.length > 5) {
		error.innerHTML = "Enter maximum 5 digits only!";
		return false;
	}

	var error = document.getElementById("priorityerror");
	var priority = form["priority"].value;

	error.innerHTML = "";
	if (priority == "" || priority == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

}
