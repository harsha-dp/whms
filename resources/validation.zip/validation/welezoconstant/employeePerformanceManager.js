/**
 * 
 */

function validate(from) {

	var error = document.getElementById("employeerror");
	var employe = form["employe"].value;
	error.innerHTML = "";
	if (employe == null || employe == "") {
		error.innerHTML = "This field cannot be empty !";
		return false;
	}

	var error = document.getElementById("perioderror");
	var period = form["period"].value;
	error.innerHTML = "";
	if (period == null || period == "") {
		error.innerHTML = "This field cannot be empty !";
		return false;
	}

}