/**
 * 
 */
function validate(from) {

	var error = document.getElementById("error");
	var names = form["names"].value;
	error.innerHTML = "";
	if (names == null || names == "") {
		error.innerHTML = "This field cannot be empty !";
		return false;
	}

	var error = document.getElementById("perioderror");
	var period = form["period"].value;
	error.innerHTML = "";
	if (period == null || period == "") {
		error.innerHTML = "This field cannot be empty !";
		return false;
	}

}