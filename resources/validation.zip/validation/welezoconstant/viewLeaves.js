/**
 * 
 */

function validate(from) {
	var error = document.getElementById("errordatepickerautoclose");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "Select Empanelled Date!";
		return false;
	}

	var error = document.getElementById("errorlocations");
	var locations = form["locations"].value;

	error.innerHTML = "";

	if (locations == null || locations == "") {
		error.innerHTML = "Please enter location !";
		return false;
	}

	else if (locations.length < 3) {
		error.innerHTML = "Location name should be atleast 3 character !";
		return false;
	}

	else if (locations.length > 40) {
		error.innerHTML = "Location name should be inbetween 3 nto 40 character !";
		return false;
	}

	var error = document.getElementById("errortextarea");
	var textarea = form["textarea"].value;

	error.innerHTML = "";

	if (textarea == null || textarea == "") {
		error.innerHTML = "Enter hospital Address!";
		return false;
	}

	else if (textarea.length < 3) {
		error.innerHTML = "Address should be atleast 3 character !";
		return false;
	}

	else if (textarea.length > 400) {
		error.innerHTML = "Address should be in between 3 nto 400 character !";
		return false;
	}

	var error = document.getElementById("errorcity");
	var city = form["city"].value;

	error.innerHTML = "";

	if (city == null || city == "") {
		error.innerHTML = "Enter City Name!";
		return false;
	}

	else if (city.length < 3) {
		error.innerHTML = "City name should be atleast 3 character !";
		return false;
	}

	else if (city.length > 80) {
		error.innerHTML = "City name should be inbetween 3 nto 80 character !";
		return false;
	}

	var error = document.getElementById("errorpincode");
	var pincode = form["pincode"].value;

	error.innerHTML = "";

	if (pincode == null || pincode == "") {
		error.innerHTML = "Enter pincode!";
		return false;
	}

	else if (pincode.length < 6) {
		error.innerHTML = "Enter minimum 6 digits!";
		return false;
	}

	else if (pincode.length > 8) {
		error.innerHTML = "Pincode shoild be in between 6 to 8 digits!";
		return false;
	}

	var error = document.getElementById("errorlattitude");
	var lattitude = form["lattitude"].value;

	error.innerHTML = "";

	if (lattitude == null || lattitude == "") {
		error.innerHTML = "Enter lattitude!";
		return false;
	}

	else if (isNaN(lattitude)) {
		error.innerHTML = "Enter only digits !";
		return false;
	} else if (pincode.length < 3) {
		error.innerHTML = "Enter minimum 3 digits!";
		return false;
	}

	else if (pincode.length > 15) {
		error.innerHTML = "lattitude should be in between 3 to 15 digits!";
		return false;
	}

	var error = document.getElementById("errorlongitudee");
	var longitudee = form["longitudee"].value;

	error.innerHTML = "";

	if (longitudee == null || longitudee == "") {
		error.innerHTML = "Enter longitude!";
		return false;
	} else if (isNaN(longitudee)) {
		error.innerHTML = "Enter only digits !";
		return false;
	}

	else if (longitudee.length < 3) {
		error.innerHTML = "longitude should atleast 3 integer !";
		return false;
	} else if (longitudee.length > 10) {
		error.innerHTML = "longitude should be in between 3 to 15 digits!";
		return false;
	}

}/* end main line */

function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
		// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
		// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}

/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}

var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}

function isNumberKey(evt) {
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
		return false;

	return true;
}
