/**
 * 
 */

function validate(from) {
	var error = document.getElementById("errorgoalname");
	var goalname = form["goalname"].value;

	error.innerHTML = "";

	if (goalname == null || goalname == "") {
		error.innerHTML = "Enter plan title !";
		return false;
	}

	else if (!isNaN(goalname)) {
		error.innerHTML = "Enter Only characters !";
		return false;
	}

	else if (goalname.length < 3) {
		error.innerHTML = "Name should atleast 3 character !";
		return false;
	} else if (goalname.length > 80) {
		error.innerHTML = "Name should maximum 80 character !";
		return false;
	}

	var error = document.getElementById("errorassignto");
	var sel2 = form["sel2"].value;

	error.innerHTML = "";

	if (sel2 == null || sel2 == "") {
		error.innerHTML = "Select Assign To!";
		return false;
	}

	var error = document.getElementById("errorassigned");
	var assigned = form["assigned"].value;

	error.innerHTML = "";

	if (assigned == null || assigned == "") {
		error.innerHTML = "Select Assign By!";
		return false;
	}

	var error = document.getElementById("errorAppraisal");
	var Appraisal = form["Appraisal"].value;

	error.innerHTML = "";

	if (Appraisal == null || Appraisal == "") {
		error.innerHTML = "Select type!";
		return false;
	}

	var error = document.getElementById("errordatepickerautoclose");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "Select Start Date!";
		return false;
	}

	var error = document.getElementById("errordatepickerautoclose1");
	var datepickerautoclose1 = form["datepickerautoclose1"].value;

	error.innerHTML = "";

	if (datepickerautoclose1 == null || datepickerautoclose1 == "") {
		error.innerHTML = "Select End Date!";
		return false;
	}

	var error = document.getElementById("errordgoal");
	var goal = form["goal"].value;

	error.innerHTML = "";

	if (goal == null || goal == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	} else if (goal.length < 3) {
		error.innerHTML = "Goal should be atleast 3 character !";
		return false;
	} else if (goal.length > 400) {
		error.innerHTML = "Goal should be maximum 400 character !";
		return false;
	}
}
