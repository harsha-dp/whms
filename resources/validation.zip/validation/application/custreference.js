/**
 * 
 */
function validate(from) {

	var error = document.getElementById("errorrname");
	var rname = form["rname"].value;

	error.innerHTML = "";

	if (rname == null || rname == "") {
		error.innerHTML = "Pease fill in this field";
		return false;
	}

	if (rname.length < 3) {
		error.innerHTML = "Enter minimum 3 character";
		return false;
	} else if (rname.length >= 100) {
		error.innerHTML = "Enter maximum 100 character";
		return false;
	} else if (!isNaN(rname)) {
		error.innerHTML = "Name cannot be number";
		return false;
	}

	var error = document.getElementById("errorrcontact");
	var rcontact = form["rcontact"].value;

	error.innerHTML = "";

	if (rcontact == null || rcontact == "") {
		error.innerHTML = "Pease fill in this field";
		return false;
	}

	if (rcontact.length < 10) {
		error.innerHTML = "Invalid contact number";
		return false;
	} else if (rcontact.length >= 11) {
		error.innerHTML = "Enter 10 digit contact number";
		return false;
	} else if (isNaN(rcontact)) {
		error.innerHTML = "Contact number cannot be alphabets";
		return false;
	}

	else if (/^[0-9,(),]*$/.test(rcontact) == false) {
		error.innerHTML = "Invalid number";
		return false;
	}

	var error = document.getElementById("errorrfor");
	var rfor = form["rfor"].value;
	error.innerHTML = "";
	if (rfor == null || rfor == "") {
		error.innerHTML = "Please fill in this field";
		return false;
	}

	var error = document.getElementById("errorrref");
	var ref = form["ref"].value;

	error.innerHTML = "";

	if (ref == null || ref == "") {
		error.innerHTML = "Pease fill in this field";
		return false;
	}

	if (ref.length < 3) {
		error.innerHTML = "Enter minimum 3 character";
		return false;
	} else if (ref.length >= 100) {
		error.innerHTML = "Enter maximum 100 character";
		return false;
	} else if (!isNaN(ref)) {
		error.innerHTML = "Name cannot be number";
		return false;
	}

	var error = document.getElementById("errorrmobile");
	var rmobile = form["rmobile"].value;

	error.innerHTML = "";

	if (rmobile == null || rmobile == "") {
		error.innerHTML = "Pease fill in this field";
		return false;
	}

	if (rmobile.length < 10) {
		error.innerHTML = "Invalid contact number";
		return false;
	} else if (rmobile.length >= 11) {
		error.innerHTML = "Enter 10 digit contact number";
		return false;
	} else if (isNaN(rmobile)) {
		error.innerHTML = "Contact number cannot be alphabets";
		return false;
	}

	else if (/^[0-9,(),]*$/.test(rmobile) == false) {
		error.innerHTML = "Invalid number";
		return false;
	}

	/*
	 * var error = document.getElementById("errorrdatepickerautoclose"); var
	 * datepickerautoclose = form["datepickerautoclose"].value;
	 * error.innerHTML=""; if(datepickerautoclose== null ||
	 * datepickerautoclose==""){ error.innerHTML="Please fill in this field";
	 * return false; }
	 */

	var error = document.getElementById("errorrrelationship");
	var rrelationship = form["rrelationship"].value;
	error.innerHTML = "";
	if (rrelationship == null || rrelationship == "") {
		error.innerHTML = "Please fill in this field";
		return false;
	}
}