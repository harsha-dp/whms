/**
 * 
 */
function validate(from) {
	/* Start */var error = document.getElementById("executiveerror");
	var executive = form["executive"].value;

	error.innerHTML = "";

	if (executive == null || executive == "") {
		error.innerHTML = "Select Executive Name!";
		return false;
	}

	var error = document.getElementById("statusserror");
	var statuss = form["statuss"].value;

	error.innerHTML = "";

	if (statuss == null || statuss == "") {
		error.innerHTML = "Select Status!";
		return false;
	}
}
function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}