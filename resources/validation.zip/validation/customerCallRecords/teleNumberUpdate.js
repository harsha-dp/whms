/**
 * 
 */
function validate(from) {
	var error = document.getElementById("errordatepickerautoclose");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "Select Date !";
		return false;
	}

	var error = document.getElementById("errorcsr");
	var assign = form["assign"].value;

	error.innerHTML = "";

	if (assign == null || assign == "") {
		error.innerHTML = "Select CSR Name !";
		return false;
	}

	var error = document.getElementById("errorPhone");
	var phone = form["phone"].value;

	error.innerHTML = "";

	if (phone == null || phone == "") {
		error.innerHTML = "Enter Phone Number !";
		return false;
	} else if (isNaN(phone)) {
		error.innerHTML = "Enter Only Numbers !";
		return false;
	}

	else if (phone.length < 10) {
		error.innerHTML = "Enter valid phone number !";
		return false;
	} else if (phone.length > 12) {
		error.innerHTML = "Phone number should be 10 to 12 digits !";
		return false;
	}

	var error = document.getElementById("errorstatuss");
	var statuss = form["statuss"].value;

	error.innerHTML = "";

	if (statuss == null || statuss == "") {
		error.innerHTML = "Select status !";
		return false;
	}
}

function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
		// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
		// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}

/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}

var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}