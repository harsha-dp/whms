/**
 * 
 */
function validate(from) {

	var error = document.getElementById("extensionnoerror");
	var extensionno = form["extensionno"].value;

	error.innerHTML = "";

	if (extensionno == null || extensionno == "") {
		error.innerHTML = "Select Extension number!";
		return false;
	}

}