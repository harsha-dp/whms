/**
 * 
 */
function validate(from) {

	var error = document.getElementById("sourceerror");
	var source = form["source"].value;
	error.innerHTML = "";
	if (source == null || source == "") {
		error.innerHTML = "Please enter source deatils";
		return false;
	}
	if (source.length < 3) {
		error.innerHTML = "Source details should be minimum 3 character";
		return false;
	}

	if (source.length > 200) {
		error.innerHTML = "You entered more then 200 character please enter less then 200 character";
		return false;
	}

	var error = document.getElementById("proverror");
	var prov = form["prov"].value;

	error.innerHTML = "";

	if (prov == null || prov == "") {
		error.innerHTML = "Enter provided By name";
		return false;
	}

	if (prov.length < 3) {
		error.innerHTML = "Name should be minimum 3 character";
		return false;
	}
	if (prov.length > 80) {
		error.innerHTML = "Name should be in between 3 to 80 character";
		return false;
	}/* end */

	var error = document.getElementById("quanterror");
	var quant = form["quant"].value;

	error.innerHTML = "";

	if (quant == null || quant == "") {
		error.innerHTML = "Enter quantity of database";
		return false;
	}

	else if (isNaN(quant)) {
		error.innerHTML = "Quantity number Can Not be alphabate";
		return false;
	}

	if (quant.length < 1) {
		error.innerHTML = "Quantity has to be minmum 1 digits"
		return false;
	}
	if (quant.length > 10) {
		error.innerHTML = "you entered more than 10 digits"
		return false;
	}/* end */

	var error = document.getElementById("uploaderror");
	var upload = form["upload"].value;

	error.innerHTML = "";

	if (upload == null || upload == "") {
		error.innerHTML = "Select File!";
		return false;
	}

}

function validate1(from) {

	var error = document.getElementById("uploaderrors");
	var uploads = form1["uploads"].value;

	error.innerHTML = "";

	if (uploads == null || uploads == "") {
		error.innerHTML = "Select File!";
		return false;
	}

}
function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}