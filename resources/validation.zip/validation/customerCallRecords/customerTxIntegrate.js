/**
 * 
 */
function validate(from) {
	/* Start */var error = document.getElementById("contactError");
	var cardRPhnNumber = form["cardRPhnNumber"].value;

	error.innerHTML = "";

	if (cardRPhnNumber == null || cardRPhnNumber == "") {
		error.innerHTML = "Please enter customer card number";
		return false;
	}

	else if (isNaN(cardRPhnNumber)) {
		error.innerHTML = "Thank you for enter vaild number";
		return true;
	}

}

/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}