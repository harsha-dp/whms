/**
 * 
 */
 function validate(from)
     {
   /*Start */ var error=document.getElementById("contactError");
    	var contactnumber=form["contactnumber"].value;

        error.innerHTML="";
     
        if( contactnumber==null || contactnumber==""){
            error.innerHTML="Enter Contact Number";
            return false;
        }

        else if(isNaN(contactnumber)){
            error.innerHTML="Mobile Number Can Not be alphabate";
            return false;
        }

        if(contactnumber.length<10){
            error.innerHTML="Contact has to be minmum 10 digits"
            return false;
        } 
        if(contactnumber.length>11){
            error.innerHTML="Invalid mobile number you entered more than 11 digits"
            return false;
        }/*end */
        
        if(/^[0-9 ,+]*$/.test(contactnumber) == false){
        	  error.innerHTML="Invalid mobile number ";
                  return false;
        }


        /*start */ var error=document.getElementById("firstNameError");
    	var firstName=form["firstName"].value;

        error.innerHTML="";
     
        if( firstName==null || firstName==""){
            error.innerHTML="Input Your FirstName";
            return false;
        }

        else if(!isNaN(firstName)){
            error.innerHTML="Name Can Not be a number";
            return false;
        }

        if(firstName.length<3){
            error.innerHTML="Name should be minimum 3 character";
            return false;
        } 
        if(firstName.length>25){
            error.innerHTML="Name should be in between 3 to 25 character";
            return false;
        }/*end */


    	
        var error = document.getElementById("firstNameError2");
        var sources=form["sources"].value;
        error.innerHTML="";
        
      
        if(sources=null ||sources=="" ) //for text use if(strUser1=="Select")
        {
         error.innerHTML="Please Select Source ";
        return false;
        }

        var error = document.getElementById("firstNameError3");
        var purposes=form["purposes"].value;
        error.innerHTML="";
        
      
        if(purposes=null ||purposes=="" ) //for text use if(strUser1=="Select")
        {
         error.innerHTML="Please Select Purpose ";
        return false;
        }


       
        /*start */ var error=document.getElementById("Remarkserror");
    	var remarkss=form["remarkss"].value;

        error.innerHTML="";
     
        if( remarkss==null || remarkss==""){
            error.innerHTML="Input Your Remarks";
            return false;
        }
        
        

        if(remarkss.length<3){
            error.innerHTML="Remarks should be minimum 3 character";
            return false;
        } 
        if(remarkss.length>100){
            error.innerHTML="Remarks should be in between 3 to 100 character";
            return false;
        }/*end */
        
        
        /*pending vollection*/
        
       
        var error = document.getElementById("applicationerror");
        var aplicationno=form["aplicationno"].value;
        error.innerHTML="";
        
      
        if(aplicationno=null ||aplicationno=="" ) //for text use if(strUser1=="Select")
        {
         error.innerHTML="Please Select Application Number ";
        return false;
        }

       
     
        
        
        
        
     }/*end main line*/
         