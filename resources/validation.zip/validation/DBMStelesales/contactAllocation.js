/**
 * 
 */
function validate(from) {
	var error = document.getElementById("errordata");
	var data = form["data"].value;
	error.innerHTML = "";

	if (data == null || data == "") {
		error.innerHTML = "Enter No of data allocation to CSR";
		return false;
	} else if (/^[0-9,(),]*$/.test(data) == false) {
		error.innerHTML = "Invalid number";
		return false;
	}

	else if (isNaN(data)) {
		error.innerHTML = "Enter Numbers only";
		return false;
	} else if (data.length < 1) {
		error.innerHTML = "Enter minimum 1 digit";
		return false;
	}

	else if (data.length > 3) {
		error.innerHTML = "Maximim 3 digit";
		return false;
	}

}
