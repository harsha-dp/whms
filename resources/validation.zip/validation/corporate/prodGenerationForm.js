


	var products = JSON.parse('${object}');
	
	console.log(products);
	var checkedItemFinal2 = [];
	
	var chekLen, i;
	var testCheck;

	

	$(function(){
		
		
		var checkedItems = [];
		var checkedItemFinal = [];
		var serviceList = [];
		
		window.checkAjaxCall = function() {
			
			
			chekLen = checkedItems.length;
			

			var error2 = document.getElementById("proNameerror");

			var proNameIdd = form["proNameId"].value;
			var regExp = /^[0-9a-zA-Z]+$/;
			error2.innerHTML = " ";

			if (proNameIdd == null || proNameIdd == ""){
				error2.innerHTML = "Please Enter Product Name";
				document.form.proName.focus();
				return false;
			}

			
			if (!regExp.test(proNameIdd)){
			
				error2.innerHTML = "Only Alphanumeric Characters  Allowed ";
				document.form.proName.focus();
				return false;
			}
			
			var error3 = document.getElementById("preEmpIderror");
			var preEmpIdd = form["preEmpId"].value;

			error3.innerHTML = "";

			if (preEmpIdd == null || preEmpIdd == ""){
				error3.innerHTML = "Please select mode of Service ";
				
				return false;
			}
			
			var error4 = document.getElementById("servCouuntiderror");
			var servCouuntidd = form["serviceCountid"].value;

			error4.innerHTML = "";

			if (servCouuntidd == null || servCouuntidd == ""){
			
				error4.innerHTML = "Please Enter the Headcount ";
				document.form.serviceHeadCount.focus();
				return false;
			}
			

			for (var i = 0; i < checkedItems.length; i++) {
				var item = checkedItems[i];
				
				serviceList[i] = item.key;
			
			}
			
			
			
				
				var proName = $('#proNameId').val(); 
				var empCount = $('#serviceCountid').val();
				var healthMode= $("form input[type='radio']:Checked").val();
				/* var companyId = $('#companyId').val(); */
				var companyId = ${corporateById.corporateId};
				
				
				var json={"proName":proName,"empCount":empCount,"healthMode":healthMode,"companyId":companyId,"serviceList":serviceList};
				
				
				$.ajax({
			        url: "validateCaptchaThroughAJAX",
			        type: 'POST',
			        data: JSON.stringify(json),
			        cache:false,
			        beforeSend: function(xhr) {  
			            xhr.setRequestHeader("Accept", "application/json");  
			            xhr.setRequestHeader("Content-Type", "application/json");  
			        },
			        success:function(response){
			        	
			        	alert("Congrats!! The Product " + response.proName + " has been successfully created.");
			        	window.location.href = "viewcorporatebyId?corporateId="+${corporateId};
			        },
			        error:function(jqXhr, textStatus, errorThrown){
			        	
			        	alert(" Error!! The Product " + proName + " couldn't be created.Please try again.");
			        	window.location.href = "viewcorporatebyId?corporateId="+${corporateId};
			        }
			    });
				
		}//window.madeAjaxCall=function()	

		$("#selection-treeview").dxTreeView({

			items : products,
			width : 220,
			dataSource : products,
			showCheckBoxesMode : "normal",
			searchEnabled : true,
			dataStructure : 'plain',

			onItemSelectionChanged : function(e) {
				var item = e.node;

				if (isProduct(item)) {
					processProduct($.extend({
						category : item.parent.text
					}, item));
				} else {
					$.each(item.items, function(index, product) {
						processProduct($.extend({
							category : item.text
						}, product));
					});
				}
				checkedItemsList.option("items", checkedItems);
				

			},
			itemTemplate : function(data) {
				return "<div>" + data.text + "</div>";
				
			}
		});

		$("#searchMode").dxSelectBox({
			dataSource : [ "contains", "startswith" ],
			value : "contains",
			onValueChanged : function(data) {
				treeView.option("searchMode", data.value);
			}
		});

		var checkedItemsList = $("#checked-items").dxList(
				{

					width : 250,
					items : checkedItems,
					itemTemplate : function(data) {
						var a = new Array();
						a['key'] = data.key;


						return "<div>" + data.parent.text + " - " + data.text
								+ "-" + data.key + "</div>";

						
					}

				}).dxList("instance");

		function isProduct(data) {
			return !data.items.length;
		}

		function processProduct(product) {
			var itemIndex = -1;

			$.each(checkedItems, function(index, item) {
				if (item.key === product.key) {
					
					itemIndex = index;
					return false;
				}
			});

			if (product.selected && itemIndex === -1) {
				checkedItems.push(product);
				checkedItemFinal.push(product);
				

			} else if (!product.selected) {

				checkedItems.splice(itemIndex, 1);
				checkedItemFinal.splice(itemIndex, 1);
				
			}
			
			checkedItemFinal2 = checkedItems
			


		} //end of processProduct(product)

		

	}); //function close
