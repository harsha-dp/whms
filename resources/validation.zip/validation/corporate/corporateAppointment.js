/**
 * 
 */

function validate(from) {

	/* start */
	var error = document.getElementById("fnameerror");
	var namee = form["namee"].value;

	error.innerHTML = "";

	if (namee == null || namee == "") {
		error.innerHTML = "Enter contact name";
		return false;
	}

	if (namee.length < 3) {
		error.innerHTML = "Name should be minimum 3 character";
		return false;
	}
	if (namee.length > 50) {
		error.innerHTML = "Name should be in between 3 to 50 character";
		return false;
	}/* end */

	var error = document.getElementById("desinameerror");
	var desiname = form["desiname"].value;

	error.innerHTML = "";

	if (desiname == null || desiname == "") {
		error.innerHTML = "Please Enter designation ";
		return false;
	}

	if (desiname.length < 2) {
		error.innerHTML = " Designation name should be minimum 2 character";
		return false;
	}
	if (desiname.length > 50) {
		error.innerHTML = "Designation name should be in between 2 to 50 character";
		return false;
	}

	var error = document.getElementById("desinagmeerror");
	var number = form["number"].value;

	error.innerHTML = "";

	if (number.length < 10) {
		error.innerHTML = "Mobile number should be 10 digit";
		return false;
	}
	if (number.length > 12) {
		error.innerHTML = "You entered more then 12 digit mobile number please enter valid mobile number";
		return false;
	}

	if (/^[0-9 ,+]*$/.test(number) == false) {
		error.innerHTML = "Mobile Number Can Not be an alphabate  ";
		return false;
	}

	var error = document.getElementById("dateeerror");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "Please select date of appointment";
		return false;
	}

	var error = document.getElementById("timeeerror");
	var timee = form["timee"].value;

	error.innerHTML = "";

	if (timee == null || timee == "") {
		error.innerHTML = "Please select appointment time";
		return false;
	}

	var error = document.getElementById("exceutiveerror");
	var exceutive = form["exceutive"].value;

	error.innerHTML = "";

	if (exceutive == null || exceutive == "") {
		error.innerHTML = "Please select executive name";
		return false;
	}

	var error = document.getElementById("statusserror");
	var statuss = form["statuss"].value;

	error.innerHTML = "";

	if (statuss == null || statuss == "") {
		error.innerHTML = "Please select appointment status";
		return false;
	}

}

function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}