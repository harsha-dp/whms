/**
 * 
 */

function validate(from) {

	var error = document.getElementById("channellerror");
	var channele = form["channele"].value;

	error.innerHTML = "";

	if (channele == null || channele == "") {
		error.innerHTML = "Please select type of channel ";
		return false;
	}

	/* start */
	var error = document.getElementById("fnameerror");
	var names = form["names"].value;

	error.innerHTML = "";

	if(names == null || names == "") {
		error.innerHTML = "Enter corporate name";
		return false;
	}
		if(names.length < 3) {
		error.innerHTML = "Name should be minimum 3 character";
		return false;
	}
	if (names.length > 300) {
		error.innerHTML = "Name should be in between 3 to 300 character";
		return false;
	}/* end */

	
	
	var error = document.getElementById("strengthherror");
	var strengthh = form["strengthh"].value;

	error.innerHTML = "";

	if (strengthh == null || strengthh == "") {
		error.innerHTML = "Please enter total strength";
		return false;
	}

	if (strengthh.length < 1) {
		error.innerHTML = "Enter minimum 1 digit";
		return false;
	}
	if (strengthh.length > 7) {
		error.innerHTML = "you entered more then 5 digits please enter less then 7 didgits";
		return false;
	}

	var error = document.getElementById("textareaerror");
	var textarea = form["textarea"].value;

	error.innerHTML = "";

	if (textarea == null || textarea == "") {
		error.innerHTML = "Enter corporate address";
		return false;
	}

	if (textarea.length < 3) {
		error.innerHTML = "Address should be minimum 3 character";
		return false;
	}
	if (textarea.length > 400) {
		error.innerHTML = "Address should be in between 3 to 400 character";
		return false;
	}/* end */

	var error = document.getElementById("cityyerror");
	var cityy = form["cityy"].value;

	error.innerHTML = "";

	if (cityy == null || cityy == "") {
		error.innerHTML = "Enter corporate city name";
		return false;
	}

	if (cityy.length < 3) {
		error.innerHTML = "city should be minimum 3 character";
		return false;
	}
	if (cityy.length > 50) {
		error.innerHTML = "city should be in between 3 to 50 character";
		return false;
	}/* end */

	

	
	var error = document.getElementById("typeeerror");
	var typee = form["typee"].value;

	error.innerHTML = "";

	if (typee == null || typee == "") {
		error.innerHTML = "Please select entity type";
		return false;
	}

	var error = document.getElementById("exceeeerror");
	var exceee = form["exceee"].value;

	error.innerHTML = "";

	if (exceee == null || exceee == "") {
		error.innerHTML = "Please select executive name";
		return false;
	}

}

function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}