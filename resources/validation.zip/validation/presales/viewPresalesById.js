/**
 * 
 */

function validate(from) {
	var error = document.getElementById("custnameerror");
	var custname = form["custname"].value;

	error.innerHTML = "";

	if (custname == null || custname == "") {
		error.innerHTML = "Enter customer name";
		return false;
	}

	if (custname.length < 3) {
		error.innerHTML = "Customer name should be minimum 3 character";
		return false;
	}
	if (custname.length > 80) {
		error.innerHTML = "Customer name should be in between 3 to 80 character";
		return false;
	}/* end */

	var error = document.getElementById("contactError");
	var contactnumber = form["contactnumber"].value;

	error.innerHTML = "";

	if (contactnumber == null || contactnumber == "") {
		error.innerHTML = "Enter Contact Number";
		return false;
	}

	else if (isNaN(contactnumber)) {
		error.innerHTML = "Mobile Number Can Not be alphabate";
		return false;
	}

	if (contactnumber.length < 10) {
		error.innerHTML = "Contact has to be minmum 10 digits"
		return false;
	}
	if (contactnumber.length > 10) {
		error.innerHTML = "Invalid mobile number you entered more than 10 digits"
		return false;
	}/* end */

	var error = document.getElementById("addresserror");
	var addresss = form["addresss"].value;
	error.innerHTML = "";
	if (addresss == null || addresss == "") {
		error.innerHTML = "Please enter customer address";
		return false;
	}
	if (addresss.length < 3) {
		error.innerHTML = "Customer address should be minimum 3 character";
		return false;
	}

	if (addresss.length > 200) {
		error.innerHTML = "You entered more then 200 character please enter less then 200 character";
		return false;
	}

	var error = document.getElementById("cityerror");
	var cityy = form["cityy"].value;

	error.innerHTML = "";

	if (cityy == null || cityy == "") {
		error.innerHTML = "Enter city name";
		return false;
	}

	if (cityy.length < 3) {
		error.innerHTML = "City name should be minimum 3 character";
		return false;
	}
	if (cityy.length > 30) {
		error.innerHTML = "City name should be in between 3 to 30 character";
		return false;
	}

	var error = document.getElementById("producterror");
	var productt = form["productt"].value;

	error.innerHTML = "";

	if (productt == null || productt == "") {
		error.innerHTML = "Please select product ";
		return false;
	}

	var error = document.getElementById("teamerror");
	var team = form["team"].value;

	error.innerHTML = "";

	if (team == null || team == "") {
		error.innerHTML = "Please select Team name ";
		return false;
	}

	/*
	 * var error=document.getElementById("csrrterror"); var
	 * csrr=form["csrr"].value;
	 * 
	 * error.innerHTML="";
	 * 
	 * if( csrr==null || csrr==""){ error.innerHTML="Please select CSR name ";
	 * return false; }
	 */
	var error = document.getElementById("channelerror");
	var channell = form["channell"].value;

	error.innerHTML = "";

	if (channell == null || channell == "") {
		error.innerHTML = "Please select channel name ";
		return false;
	}

	var error = document.getElementById("dateerror");
	var datepicker = form["datepicker"].value;

	error.innerHTML = "";

	if (datepicker == null || datepicker == "") {
		error.innerHTML = "Please select date of appointment ";
		return false;
	}

	var error = document.getElementById("timeerror");
	var timee = form["timee"].value;

	error.innerHTML = "";

	if (timee == null || timee == "") {
		error.innerHTML = "Please select time of appointment ";
		return false;
	}

	/*
	 * var error=document.getElementById("executiveerror"); var
	 * executivee=form["executivee"].value;
	 * 
	 * error.innerHTML="";
	 * 
	 * if( executivee==null || executivee==""){ error.innerHTML="Please select
	 * executive name "; return false; }
	 */

}
function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}