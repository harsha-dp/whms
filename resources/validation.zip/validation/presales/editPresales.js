/**
 * 
 */

function validate(from) {
	var error = document.getElementById("custnameerror");
	var custname = form["custname"].value;

	error.innerHTML = "";

	if (custname == null || custname == "") {
		error.innerHTML = "Enter customer name";
		return false;
	}

	if (custname.length < 3) {
		error.innerHTML = "Customer name should be minimum 3 character";
		return false;
	}
	if (custname.length > 80) {
		error.innerHTML = "Customer name should be in between 3 to 80 character";
		return false;
	}/* end */

	var error = document.getElementById("contactError");
	var contactnumber = form["contactnumber"].value;

	error.innerHTML = "";

	if (contactnumber == null || contactnumber == "") {
		error.innerHTML = "Enter Contact Number";
		return false;
	}

	else if (isNaN(contactnumber)) {
		error.innerHTML = "Mobile Number Can Not be alphabate";
		return false;
	}

	if (contactnumber.length < 10) {
		error.innerHTML = "Contact has to be minmum 10 digits"
		return false;
	}
	if (contactnumber.length > 10) {
		error.innerHTML = "Invalid mobile number you entered more than 10 digits"
		return false;
	}/* end */

	var error = document.getElementById("addresserror");
	var addresss = form["addresss"].value;
	error.innerHTML = "";
	if (addresss == null || addresss == "") {
		error.innerHTML = "please enter customer address";
		return false;
	}
	if (addresss.length < 3) {
		error.innerHTML = "Customer addresss should be minimum 3 character";
		return false;
	}

	if (addresss.length > 200) {
		error.innerHTML = "You entered more then 200 character please enter less then 200 character";
		return false;
	}

	var error = document.getElementById("cityerror");
	var cityy = form["cityy"].value;

	error.innerHTML = "";

	if (cityy == null || cityy == "") {
		error.innerHTML = "Enter city name";
		return false;
	}

	if (cityy.length < 3) {
		error.innerHTML = "City name should be minimum 3 character";
		return false;
	}
	if (cityy.length > 30) {
		error.innerHTML = "City name should be in between 3 to 30 character";
		return false;
	}

	var error = document.getElementById("producterror");
	var productt = form["productt"].value;

	error.innerHTML = "";

	if (productt == null || productt == "") {
		error.innerHTML = "Please select product ";
		return false;
	}

	var error = document.getElementById("teamerror");
	var team = form["team"].value;

	error.innerHTML = "";

	if (team == null || team == "") {
		error.innerHTML = "Please select Team name ";
		return false;
	}

	var error = document.getElementById("channelerror");
	var channell = form["channell"].value;

	error.innerHTML = "";

	if (channell == null || channell == "") {
		error.innerHTML = "Please select channel name ";
		return false;
	}

	var error = document.getElementById("dateerror");
	var datepickerautoclose = form["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "Please select date of appointment ";
		return false;
	}

	var error = document.getElementById("timeerror");
	var timee = form["timee"].value;

	error.innerHTML = "";

	if (timee == null || timee == "") {
		error.innerHTML = "Please select time of appointment ";
		return false;
	}

	/*
	 * var error=document.etElementbyId("meetingeerror"); var
	 * cbxShowHide2=form["cbxShowHide2"].value;
	 * 
	 * error.innerHTML="";
	 * 
	 * 
	 * if( cbxShowHide2==true || cbxShowHide==true){
	 *  }
	 * 
	 * else if ( cbxShowHide2==false || cbxShowHide=="false"){ }
	 * 
	 * else{ error.innerHTML="Please select meeting status rr "; return false; }
	 */

	if (document.getElementById("chkYes").checked == false
			&& document.getElementById("chkNo").checked == false) {
		/* error.innerHTML="Please select Meeting status Met or Not Met"; */
		alert("Please select Meeting status Met or Not Met");
		return false;
	}

	/*
	 * if(document.getElementById("cbxShowHide2").checked==true) { } else
	 * if(document.getElementById("cbxShowHide").checked==true) { }
	 * 
	 * else{ alert(" Please select meeting status Met or Not Met"); return
	 * false; }
	 */

	if (document.getElementById("reschule").checked == false
			&& document.getElementById("coll").checked == false
			&& document.getElementById("not").checked == false) {
		alert(" Please select status (Collected or Rescheduled or Not Interested )");
		return false;
	} else if (document.getElementById("coll").checked == true) {
		// / alert("You selected Collected")
		var ddl = document.getElementById("payment");
		var selectedValue = document.getElementById("payment").options[ddl.selectedIndex].value;
		var dd2 = document.getElementById("apln");
		var selectedValue2 = document.getElementById("apln").options[dd2.selectedIndex].value;

		if (selectedValue == "payment") {
			alert("Select Payment Mode");
			return false;
		} else if (selectedValue2 == "application") {
			alert("Select Application Number");
			return false;
		}

	}

	var error = document.getElementById("remarksserror");
	var remarkss = form["remarkss"].value;
	error.innerHTML = "";
	if (remarkss == null || remarkss == "") {
		error.innerHTML = "please enter customer remarks";
		return false;
	}
	if (remarkss.length < 3) {
		error.innerHTML = "Customer remarks should be minimum 3 character";
		return false;
	}

	if (remarkss.length > 200) {
		error.innerHTML = "You entered more then 200 character please enter less then 200 character";
		return false;
	}

}
function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}