/**
 * 
 */

function validate(from) {
	var error = document.getElementById("droperror");
	var defaultconfig = form["defaultconfig"].value;

	error.innerHTML = "";
	if (defaultconfig == "" || defaultconfig == null) {
		error.innerHTML = "This field cannot be empty!";
		return false;
	} else if (isNaN(defaultconfig)) {
		error.innerHTML = "Enter digits only!";
		return false;
	} else if (defaultconfig.length > 6) {
		error.innerHTML = "Enter maximum 6 digits only!";
	}
	if (/^[0-9,.]*$/.test(defaultconfig) == false) {
		// error message
		error.innerHTML = "Please enter only digits and (dot) only ";
		return false;
	}

}

/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}

var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}