/**
 * 
 */
function validate(from) {
	var error = document.getElementById("dateerror");
	var datepickerautoclose = form["datepickerautoclose"].value;
	error.innerHTML = "";

	if (datepickerautoclose = null || datepickerautoclose == "") // for text
																	// use
																	// if(strUser1=="Select")
	{
		error.innerHTML = "Please select cheque presented date";
		return false;
	}

	var error = document.getElementById("dateerror1");
	var datepickerautoclose1 = form["datepickerautoclose1"].value;
	error.innerHTML = "";

	if (datepickerautoclose1 = null || datepickerautoclose1 == "") // for text
																	// use
																	// if(strUser1=="Select")
	{
		error.innerHTML = "Please Select cheque approval date ";
		return false;
	}

	var error = document.getElementById("assignerror");
	var assign = form["assign"].value;
	error.innerHTML = "";

	if (assign = null || assign == "") // for text use if(strUser1=="Select")
	{
		error.innerHTML = "Please Select Payment mode ";
		return false;
	}
}