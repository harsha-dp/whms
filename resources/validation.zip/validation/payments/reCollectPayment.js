/**
 * 
 */
function validate(from) {

	var error = document.getElementById("paymenterror");
	var purposes = form["payment"].value;
	error.innerHTML = "";

	if (purposes = null || purposes == "") // for text use
											// if(strUser1=="Select")
	{
		error.innerHTML = "Please Select Payment Mode ";
		return false;
	}

	var error = document.getElementById("csrerror");
	var assigns = form["assigns"].value;
	error.innerHTML = "";

	if (assigns = null || assigns == "") // for text use
											// if(strUser1=="Select")
	{
		error.innerHTML = "Please Select CSR Name ";
		return false;
	}

	var error = document.getElementById("teamerror");
	var teamer = form["teamer"].value;
	error.innerHTML = "";

	if (teamer = null || teamer == "") // for text use if(strUser1=="Select")
	{
		error.innerHTML = "Please select Channel Name ";
		return false;
	}

	var error = document.getElementById("collectederror");
	var datepickerautoclose1 = form["datepickerautoclose1"].value;
	error.innerHTML = "";

	if (datepickerautoclose1 = null || datepickerautoclose1 == "") // for text
																	// use
																	// if(strUser1=="Select")
	{
		error.innerHTML = "Please Select Collected date ";
		return false;
	}

	var error = document.getElementById("collectedbyerror");
	var collectedbyy = form["collectedbyy"].value;
	error.innerHTML = "";

	if (collectedbyy = null || collectedbyy == "") // for text use
													// if(strUser1=="Select")
	{
		error.innerHTML = "Please Select Collected By name ";
		return false;
	}

	var error = document.getElementById("remarkserror");
	var remarkse = form["remarkse"].value;
	error.innerHTML = "";

	if (remarkse = null || remarkse == "") // for text use
											// if(strUser1=="Select")
	{
		error.innerHTML = "Please enter remarks ";
		return false;
	}

}

function disable_Online() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = true;

}
function disable_Cash() {
	document.getElementById("datepicker1").disabled = true;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = true;
}
function disable_Credit_debit() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = false;
}

function enable_Cheque() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = false;
	document.getElementById("datepicker-autoclose").disabled = false;
	document.getElementById("terminal").disabled = true;
}
function disable_Complimentary() {
	document.getElementById("datepicker1").disabled = true;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = true;
	document.getElementById("terminal").disabled = true;
}
function disable_NEFT() {
	document.getElementById("datepicker1").disabled = false;
	document.getElementById("datepicker2").disabled = true;
	document.getElementById("datepicker-autoclose").disabled = false;
	document.getElementById("terminal").disabled = true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
										// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
										// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}

/* start */
function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
/* end */

/* start */
function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
/* end */
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}