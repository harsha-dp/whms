/**
 * 
 */
function validate(from) {
	var error = document.getElementById("approvalerror");
	var datepickerautoclose2 = form["datepickerautoclose2"].value;

	error.innerHTML = "";

	if (datepickerautoclose2 == null || datepickerautoclose2 == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("approvalerror1");
	var datepickerautoclose3 = form["datepickerautoclose3"].value;

	error.innerHTML = "";

	if (datepickerautoclose3 == null || datepickerautoclose3 == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}

	var error = document.getElementById("statuserror");
	var statuss = form["statuss"].value;

	error.innerHTML = "";

	if (statuss == null || statuss == "") {
		error.innerHTML = "This field cannot be empty!";
		return false;
	}
}
