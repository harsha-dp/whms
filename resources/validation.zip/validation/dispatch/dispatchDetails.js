/**
 * 
 */

function validate(from) {

	var error = document.getElementById("dateerror");
	var datepicker = form["datepicker"].value;

	error.innerHTML = "";

	if (datepicker == null || datepicker == "") {
		error.innerHTML = "Select Dispatch Received Date";
		return false;
	}

	var error = document.getElementById("statusserror");
	var statuss = form["statuss"].value;

	error.innerHTML = "";

	if (statuss == null || statuss == "") {
		error.innerHTML = "Select Your Dispatch Status";
		return false;
	}
}