/**
 * 
 */

function validate(from) {
	/* Start */
	var error = document.getElementById("statusserror");
	var status = form["status"].value;

	error.innerHTML = "";

	if (status == null || status == "") {
		error.innerHTML = "Select Your Dispatch Status";
		return false;
	}

	var error = document.getElementById("deliverystatusserror");
	var status = form["deliverystatus"].value;

	error.innerHTML = "";

	if (status == null || status == "") {
		error.innerHTML = "Select Your Delivery Status";
		return false;
	}

	var error = document.getElementById("dateerror");
	var datepicker = form["datepicker"].value;

	error.innerHTML = "";

	if (datepicker == null || datepicker == "") {
		error.innerHTML = "Please Select Date";
		return false;
	}

	var error = document.getElementById("througherror");
	var through = form["through"].value;

	error.innerHTML = "";

	if (through == null || through == "") {
		error.innerHTML = "Please select dispatch through";
		return false;
	}

	/*
	 * if(/^[a-zA-Z,() ,]*$/.test(through) == false){ //error message
	 * error.innerHTML="Please enter only character and special symbol like.. () ";
	 * return false; }
	 */
	/*
	 * else if( !isNaN(through)) { error.innerHTML="input character only";
	 * return false; }
	 */
	/*
	 * if(through.length<3)
	 *  { error.innerHTML="Enter minimum 3 character"; return false; }
	 * if(through.length>50)
	 *  { error.innerHTML="You entered more then 50 characetr please enter less
	 * than 50 character"; return false; }
	 */

	var error = document.getElementById("consignerror");
	var conthrough = form["conthrough"].value;

	error.innerHTML = "";

	if (conthrough == null || conthrough == "") {
		error.innerHTML = "Please input Consignment Reference number";
		return false;
	}

	if (conthrough.length < 2)

	{
		error.innerHTML = "Enter minimum 2 character ";
		return false;
	}
	if (conthrough.length > 9)

	{
		error.innerHTML = "You entered more then 9 characetr please enter less than 9 character";
		return false;
	}

}
function validate1(from) {

	var error = document.getElementById("uploaderrors");
	var uploads = form1["uploads"].value;

	error.innerHTML = "";

	if (uploads == null || uploads == "") {
		error.innerHTML = "Select File!";
		return false;
	}

}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
		// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
		// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}

/* start */
function isNumber(evt) {
	evt = (evt) ? evt : window.event;
	var charCode = (evt.which) ? evt.which : evt.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {
		return false;
	}
	return true;
}
/* end */

/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}

var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}