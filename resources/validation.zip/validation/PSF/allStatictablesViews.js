/**
 * 
 */
function validate(from) {
	var error = document.getElementById("errorteam");
	var team = form["team"].value;

	error.innerHTML = "";

	if (team == null || team == "") {
		error.innerHTML = "Enter Team Name !";
		return false;
	} else if (!isNaN(team)) {
		error.innerHTML = "Enter Only Character !";
		return false;
	} else if (team.length < 3) {
		error.innerHTML = "Name should atleast 3 character !";
		return false;
	} else if (team.length > 400) {
		error.innerHTML = "Name should maximum 400 character !";
		return false;
	}

	var error = document.getElementById("errorleader");
	var leader = form["leader"].value;

	error.innerHTML = "";

	if (leader == null || leader == "") {
		error.innerHTML = "Enter Team Leader Name !";
		return false;
	}

	else if (!isNaN(leader)) {
		error.innerHTML = "Enter Only Character !";
		return false;
	} else if (team.length < 3) {
		error.innerHTML = "Name should atleast 3 character !";
		return false;
	} else if (team.length > 400) {
		error.innerHTML = "Name should maximum 400 character !";
		return false;
	}
}

function validate1(from) {

	var error = document.getElementById("errorchannelss");
	var channelss = form1["channelss"].value;

	error.innerHTML = "";

	if (channelss == null || channelss == "") {
		error.innerHTML = "Enter Channel Name !";
		return false;
	} else if (!isNaN(channelss)) {
		error.innerHTML = "Enter Only Character !";
		return false;
	} else if (channelss.length < 3) {
		error.innerHTML = "Channel Name should atleast 3 character !";
		return false;
	} else if (channelss.length > 400) {
		error.innerHTML = "Channel Name should maximum 400 character !";
		return false;
	}
}

function validate3(from) {
	var error = document.getElementById("errorproduct");
	var product = form3["product"].value;

	error.innerHTML = "";

	if (product == null || product == "") {
		error.innerHTML = "Enter product Name !";
		return false;
	} else if (!isNaN(product)) {
		error.innerHTML = "Enter Only Character !";
		return false;
	} else if (product.length < 3) {
		error.innerHTML = "Product Name should atleast 3 character !";
		return false;
	} else if (product.length > 100) {
		error.innerHTML = "Product Name should maximum 100 character !";
		return false;
	}

	var error = document.getElementById("errorpricees");
	var pricees = form3["pricees"].value;

	error.innerHTML = "";

	if (pricees == null || pricees == "") {
		error.innerHTML = "Enter Product Price !";
		return false;
	} else if (isNaN(pricees)) {
		error.innerHTML = "Enter Only Digits !";
		return false;
	}

	else if (pricees.length < 2) {
		error.innerHTML = "Price should be atleast 2 digits !";
		return false;
	} else if (pricees.length > 6) {
		error.innerHTML = "Maximum 6 digits !";
		return false;
	}

	var error = document.getElementById("errordatepickerautoclose");
	var datepickerautoclose = form3["datepickerautoclose"].value;

	error.innerHTML = "";

	if (datepickerautoclose == null || datepickerautoclose == "") {
		error.innerHTML = "Select Service Start Date !";
		return false;
	}

	var error = document.getElementById("errordatepickerautoclose1");
	var datepickerautoclose1 = form3["datepickerautoclose1"].value;

	error.innerHTML = "";

	if (datepickerautoclose1 == null || datepickerautoclose1 == "") {
		error.innerHTML = "Select Service End Date !";
		return false;
	}
}

function validate2(from) {

	var error = document.getElementById("errorservices");
	var services = form2["services"].value;

	error.innerHTML = "";

	if (services == null || services == "") {
		error.innerHTML = "Select Service Category !";
		return false;
	}

	var error = document.getElementById("errorservice");
	var service = form2["service"].value;

	error.innerHTML = "";

	if (service == null || service == "") {
		error.innerHTML = "Enter Service Name !";
		return false;
	} else if (service.length < 3) {
		error.innerHTML = "Service Name should atleast 3 character !";
		return false;
	} else if (service.length > 100) {
		error.innerHTML = "Service Name should maximum 100 character !";
		return false;
	}

	var error = document.getElementById("errordescriptions");
	var descriptions = form2["descriptions"].value;

	error.innerHTML = "";

	if (descriptions == null || descriptions == "") {
		error.innerHTML = "Enter Service Description !";
		return false;
	} else if (!isNaN(descriptions)) {
		error.innerHTML = "Enter Only Character !";
		return false;
	}

	else if (descriptions.length < 3) {
		error.innerHTML = "Description should be atleast 3 digits !";
		return false;
	} else if (descriptions.length > 400) {
		error.innerHTML = "Maximum 400 Characters !";
		return false;
	}
}