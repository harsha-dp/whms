/**
 * 
 */
function validate(from) {

	var error = document.getElementById("custnameerror");
	var custname = form["custname"].value;

	error.innerHTML = "";

	if (custname == null || custname == "") {
		error.innerHTML = "Enter item name !!";
		return false;
	}

	if (custname.length < 3) {
		error.innerHTML = "Item name should be minimum 3 character";
		return false;
	}
	if (custname.length > 200) {
		error.innerHTML = "Item name should be in between 3 to 200 character";
		return false;
	}/* end */

	var error = document.getElementById("caterror");
	var category = form["category"].value;
	error.innerHTML = "";
	if (category == null || category == "") {
		error.innerHTML = "Please enter item category";
		return false;
	}
	if (category.length < 3) {
		error.innerHTML = "Category name should be minimum 3 character";
		return false;
	}

	if (category.length > 200) {
		error.innerHTML = "You entered more then 200 character please enter less then 200 character";
		return false;
	}

	var error = document.getElementById("companyerror");
	var company = form["company"].value;

	error.innerHTML = "";

	if (company == null || company == "") {
		error.innerHTML = "Enter item company name !!";
		return false;
	}

	if (company.length < 3) {
		error.innerHTML = "Company name should be minimum 3 character";
		return false;
	}
	if (company.length > 200) {
		error.innerHTML = "Company name should be in between 3 to 200 character";
		return false;
	}/* end */

	var error = document.getElementById("addresserror");
	var addresss = form["addresss"].value;

	error.innerHTML = "";

	if (addresss == null || addresss == "") {
		error.innerHTML = "Enter company addresss !!";
		return false;
	}

	if (addresss.length < 3) {
		error.innerHTML = "Address name should be minimum 3 character";
		return false;
	}
	if (addresss.length > 500) {
		error.innerHTML = "Address name should be in between 3 to 500 character";
		return false;
	}/* end */

}

function onlyNumbersAndPlus(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode == 43)
		return true;
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyNumbers(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // if IE
	else
		charCode = evt.which; // if firefox
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}

function onlyAlphabets(evt) {
	var charCode;
	if (window.event)
		charCode = window.event.keyCode; // for IE
	else
		charCode = evt.which; // for firefox
	if (charCode == 32) // for &lt;space&gt; symbol
		return true;
	if (charCode > 31 && charCode < 65) // for characters before 'A' in ASCII
		// Table
		return false;
	if (charCode > 90 && charCode < 97) // for characters between 'Z' and 'a' in
		// ASCII Table
		return false;
	if (charCode > 122) // for characters beyond 'z' in ASCII Table
		return false;
	return true;
}
/* WRITE THE VALIDATION SCRIPT IN THE HEAD TAG. */
function isNumber(evt) {
	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57))
		return false;

	return true;
}
var specialKeys = new Array();
specialKeys.push(8); // Backspace
function IsNumeric(e) {
	var keyCode = e.which ? e.which : e.keyCode
	var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
	document.getElementById("error").style.display = ret ? "none" : "inline";
	return ret;
}
function isNumberKey(evt) {
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57))
		return false;

	return true;
}
