/**
 * 
 */
function validate(from) {

	var error = document.getElementById("custnameerror");
	var custname = form["custname"].value;

	error.innerHTML = "";

	if (custname == null || custname == "") {
		error.innerHTML = "Enter Vender name !!";
		return false;
	}

	if (custname.length < 3) {
		error.innerHTML = "Vender name should be minimum 3 character";
		return false;
	}
	if (custname.length > 200) {
		error.innerHTML = "Vender name should be in between 3 to 200 character";
		return false;
	}/* end */

	var error = document.getElementById("caterror");
	var category = form["category"].value;
	error.innerHTML = "";
	if (category == null || category == "") {
		error.innerHTML = "Please enter item category";
		return false;
	}
	if (category.length < 3) {
		error.innerHTML = "Category name should be minimum 3 character";
		return false;
	}

	if (category.length > 200) {
		error.innerHTML = "You entered more then 200 character please enter less then 200 character";
		return false;
	}

	var error = document.getElementById("companyerror");
	var company = form["company"].value;

	error.innerHTML = "";

	if (company == null || company == "") {
		error.innerHTML = "Enter item company name !!";
		return false;
	}

	if (company.length < 3) {
		error.innerHTML = "Item Company name should be minimum 3 character";
		return false;
	}
	if (company.length > 200) {
		error.innerHTML = "Item Company name should be in between 3 to 200 character";
		return false;
	}/* end */

	var error = document.getElementById("addresserror");
	var addresss = form["addresss"].value;

	error.innerHTML = "";

	if (addresss == null || addresss == "") {
		error.innerHTML = "Enter company addresss !!";
		return false;
	}

	if (addresss.length < 3) {
		error.innerHTML = "Address name should be minimum 3 character";
		return false;
	}
	if (addresss.length > 500) {
		error.innerHTML = "Address name should be in between 3 to 500 character";
		return false;
	}/* end */

}