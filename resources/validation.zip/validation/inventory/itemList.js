/**
 * 
 */
function validate(from) {

	var error = document.getElementById("custnameerror");
	var custname = form["custname"].value;

	error.innerHTML = "";

	if (custname == null || custname == "") {
		error.innerHTML = "Enter item name !!";
		return false;
	}

	if (custname.length < 3) {
		error.innerHTML = "Item Name should be minimum 3 character";
		return false;
	}
	if (custname.length > 80) {
		error.innerHTML = "Item Name should be in between 3 to 80 character";
		return false;
	}/* end */

	var error = document.getElementById("uniterror");
	var unit = form["unit"].value;

	error.innerHTML = "";

	if (unit == null || unit == "") {
		error.innerHTML = "Please select type of measure !!";
		return false;
	}

	var error = document.getElementById("depterror");
	var department = form["department"].value;

	error.innerHTML = "";

	if (department == null || department == "") {
		error.innerHTML = "Select Department name";
		return false;
	}

}