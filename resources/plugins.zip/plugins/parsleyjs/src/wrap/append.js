	return window.Parsley;
//}));
