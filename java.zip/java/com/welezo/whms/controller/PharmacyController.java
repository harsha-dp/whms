package com.welezo.whms.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CallsUpload;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.CallRecordsService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.PharmacyService;

@Controller
public class PharmacyController {

	@Autowired
	PharmacyService pharamcyService;
	
	@Autowired
	HRService hrService;
	
	@Autowired
	CallRecordsService callrecordservice;
	@Autowired
	AdminService adminService;
	
	@RequestMapping(value = "/pharamacyDashBoard")
	public ModelAndView pharmacyDashBorad(ModelMap model) {

		
		
		return new ModelAndView("Admin/dashboards/pharmacyDashBoard");
	}
	
	@RequestMapping(value = "/viewPharamacy")
	public ModelAndView viewPharmacy(ModelMap model) {

		ArrayList<HashMap<String, String>> pharmacyList = pharamcyService.getPharmacyList("", "", "");
		model.addAttribute("pharmacyList", pharmacyList);
		
		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);
		
		return new ModelAndView("Admin/Pharmacy/viewPharamacy");
	}
	@RequestMapping(value = "/savePharamacy", method = RequestMethod.POST)
	public ModelAndView savePharmacyDetails(ModelMap model,@RequestParam String pharmacyName,String regnNo,String welezoCode,String primaryContact,String alternateNumber,
			String address,String location,String city,String primaryNumber,String email,String empanelDate,String expiryDate,Integer executive,Integer createdBy) {

		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(empanelDate));
			date1 = formatter.format(sdf.parse(expiryDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "INSERT INTO pharmacies(pharmacy_name,location,city,address,STATUS,regn_no,empanel_date,primary_contact,primary_number,alternate_number,email,"
				+ "welezo_code,executive,expiry_date,isActive,created_date,created_by)VALUES('"+pharmacyName+"','"+location+"','"+city+"','"+address+"','New',"
				+ "'"+regnNo+"','"+date+"','"+primaryContact+"','"+primaryNumber+"','"+alternateNumber+"','"+email+"','"+welezoCode+"','"+executive+"','"+date1+"',TRUE,CURRENT_TIMESTAMP,'"+createdBy+"')";
		hrService.upDateQuery(query);
		
		return new ModelAndView("redirect:viewPharamacy");
	}
	@RequestMapping(value = "/viewPharamacyById")
	public ModelAndView viewPharmacyById(ModelMap model,@RequestParam Integer pharmacyId) {

		HashMap<String,String> pharmacyDeatilsById = pharamcyService.getPharmacyDeatilsById(pharmacyId);
		model.addAttribute("pharmacyData", pharmacyDeatilsById);
		
		CallsUpload calls = new CallsUpload();
	String path = "/home/welezohealth/whms/Pharmacy/";
	// String path = "D:\\files\\doc\\";
		ArrayList<HashMap<String, String>> employeeDocuments = calls.getEmployeeDocuments(pharmacyId+"" ,path);
		model.addAttribute("documentList", employeeDocuments);
		
		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);
		
		return new ModelAndView("Admin/Pharmacy/pharmacyDetails");
	}
	
	@RequestMapping(value = "/pharmacyMOUFileUpload", method = RequestMethod.POST)
	public ModelAndView pharmacyMOUFileUpload(ModelMap model,@RequestParam CommonsMultipartFile file,
			@RequestParam String pharmacyName,@RequestParam Integer pharmacyId)
			throws Exception {
		String path = "/home/welezohealth/whms/Pharmacy";
	// String path = "D:\\files\\doc";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();
			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();
		} catch (Exception e) {
			// System.out.println(e);
		}
		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + pharmacyId + "_"+ pharmacyName.replaceAll(" ", "-")+ "_"+ filename));

		model.addAttribute("pharmacyId", pharmacyId);
		return new ModelAndView("redirect:viewPharamacyById");
	}
	@RequestMapping(value = "/updatePharamacy", method = RequestMethod.POST)
	public ModelAndView editPharmacyDetails(ModelMap model,@RequestParam String pharmacyName,String pharmacyId,String regnNo,String welezoCode,
			String primaryContact,String alternateNumber,String address,String location,String city,String primaryNumber,String email,String empanelDate,
			String expiryDate,Integer executive,Integer createdBy) {

		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(empanelDate));
			date1 = formatter.format(sdf.parse(expiryDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "UPDATE pharmacies SET pharmacy_name='"+pharmacyName+"',location='"+location+"',city='"+city+"',address='"+address+"',regn_no='"+regnNo+"',"
				+ "empanel_date='"+date+"',primary_contact='"+primaryContact+"',primary_number='"+primaryNumber+"',"
				+ " alternate_number ='"+alternateNumber+"', email='"+email+"',welezo_code='"+welezoCode+"',executive='"+executive+"',expiry_date='"+date1+"' WHERE `pharmacy_id`='"+pharmacyId+"'";
		hrService.upDateQuery(query);
		
		model.addAttribute("pharmacyId", pharmacyId);
		return new ModelAndView("redirect:viewPharamacyById");
	}
	@RequestMapping(value = "/viewDoctors")
	public ModelAndView viewDoctors(ModelMap model) {
		
		ArrayList<HashMap<String,String>> doctorsList = pharamcyService.getDoctorsList();
		model.addAttribute("doctorsList", doctorsList);
		
		return new ModelAndView("Admin/doctorLounge/viewDoctorsList");
	}
	
	@RequestMapping(value = "/saveDoctors", method = RequestMethod.POST)
	public ModelAndView saveDoctors(ModelMap model,@RequestParam String doctorName,String doctorNumber,String clinicName,String clinicNumber,String specializations
			,String timing,String address,String city,String location,String pincode,String registrationId,String joinedDate,String expiryDate,Integer createdBy) {

		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(joinedDate));
			date1 = formatter.format(sdf.parse(expiryDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "INSERT INTO doctors_lounge(doctor_name,specializations,clinic,address,clinic_number,doctor_number,city,location,pincode,registration_id,timing,joined_date,expiry_date,created_by,created_date)"
				+ "VALUES('"+doctorName+"','"+specializations+"','"+clinicName+"','"+address+"','"+clinicNumber+"','"+doctorNumber+"','"+city+"','"+location+"','"+pincode+"','"+registrationId+"','"+timing+"','"+date+"','"+date1+"','"+createdBy+"',CURRENT_TIMESTAMP);";
		hrService.upDateQuery(query);
		
		return new ModelAndView("redirect:viewDoctors");
	}
	@RequestMapping(value = "btlActivity")
	public ModelAndView searchCallDetails(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
	//	model.addAttribute("status", "");
		model.addAttribute("parkId", "");
		return new ModelAndView("redirect:btlActivity1");
	}
	
	@RequestMapping(value = "/btlActivity1")
	public ModelAndView viewBTLActivity(ModelMap model,@RequestParam String fromDate,String toDate,String parkId) {
		String status ="";
		ArrayList<HashMap<String,String>> allBTlLeads = callrecordservice.getAllBTlLeads(fromDate,toDate, status,parkId);
		model.addAttribute("allBTlLeads", allBTlLeads);
		ArrayList<HashMap<String, String>> allParkDetails = callrecordservice.getAllParkDetails();
		model.addAttribute("allParkDetails", allParkDetails);
		
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		//model.
		return new ModelAndView("Admin/btlActivity/viewBtlLeads");
	}
	@RequestMapping(value = "/saveBTLLeads" ,method = RequestMethod.POST)
	public ModelAndView saveBTLActivityLead(ModelMap model,@RequestParam String[] leadName,String[] contactNumber,String[] age,String[] gender,String[] bp,String[] sugar,
			String activityDate,Integer parkId,String executive,Integer createdBy) {
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(activityDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(int i = 0; i < leadName.length ;i++ ){
			if(contactNumber[i] != ""){
		String query = "INSERT INTO channel_leads(lead_name,contact_number,age,gender,entity_id,lead_status,executive,Channel,bp,sugar,acitivity_date,created_by,created_date)"
				+ " VALUES('"+leadName[i]+"','"+contactNumber[i]+"','"+age[i]+"','"+gender[i]+"','"+parkId+"','New','"+executive+"','13','"+bp[i]+"','"+sugar[i]+"','"+date+"','"+createdBy+"',CURRENT_TIMESTAMP)";
		hrService.upDateQuery(query);
			}
		}
		return new ModelAndView("redirect:btlActivity");
	}
	@RequestMapping(value = "/saveParkDetails")
	public ModelAndView saveParkDetails(ModelMap model,@RequestParam String parkName,String location,String city,String pincode,String address) {
		
		String query = "INSERT INTO park_details(park_name,location,city,address,pincode)"
				+ " VALUES('"+parkName+"','"+location+"','"+city+"','"+address+"','"+pincode+"')";
		hrService.upDateQuery(query);
		return new ModelAndView("redirect:btlActivity");
	}
	@RequestMapping(value = "/updatesBTlLeads")
	public ModelAndView leadsUpdate(ModelMap model,@RequestParam String leadStatus,String remarks,Integer btlId) {
		
		String query = "UPDATE channel_leads SET lead_status ='"+leadStatus+"', remarks = '"+remarks+"' WHERE id = '"+btlId+"'";
		hrService.upDateQuery(query);
		return new ModelAndView("redirect:btlActivity");
	}
	
	@RequestMapping(value = "/pharmacyLeads")
	public ModelAndView pharmacyLeads(ModelMap model) {
		
		ArrayList<HashMap<String,String>> pharmacyNameList = pharamcyService.getPharmacyNameList();
		model.addAttribute("pharmacyNameList", pharmacyNameList);
		
		ArrayList<HashMap<String,String>> pharmacyLeadList = pharamcyService.getPharmacyLeadList("", "", "");
		model.addAttribute("pharmacyLeadList", pharmacyLeadList);
		
		return new ModelAndView("Admin/Pharmacy/viewPharmacyLeads");
	}
	
	@RequestMapping(value = "/savePharmacyLeads" ,method = RequestMethod.POST)
	public ModelAndView savePharmacyLeads(ModelMap model,@RequestParam String[] leadName,String[] contactNumber,String[] age,String[] gender,String activityDate,String biometricId,Integer createdBy) {
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(activityDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(int i = 0; i < leadName.length ;i++ ){
			if(contactNumber[i] != ""){
		String query = "INSERT INTO channel_leads(lead_name,contact_number,age,gender,entity_id,lead_status,Channel,acitivity_date,created_by,created_date)"
				+ " VALUES('"+leadName[i]+"','"+contactNumber[i]+"','"+age[i]+"','"+gender[i]+"','"+biometricId+"','New','12','"+date+"','"+createdBy+"',CURRENT_TIMESTAMP)";
		hrService.upDateQuery(query);
		
	//	System.out.println(query);
			}
		}
		return new ModelAndView("redirect:pharmacyLeads");
	}
	
	
}
