package com.welezo.whms.controller;

import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;

import com.welezo.whms.service.HRService;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateExceptionHandler;

@Controller
public class MailReportController {

	@Autowired
	HRService hrService;
	@Autowired
	ReportController report;
	@Autowired
	private JavaMailSender mailSender;
	
		public void teleSalesDepartmentEmailReports() throws MessagingException {

			Date date = new Date();
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String todate = sdf.format(date);
			
			MimeMessage message = mailSender.createMimeMessage();

			try {
				MimeMessageHelper helper = new MimeMessageHelper(message, true);
				helper.setFrom("no-reply@welezohealth.com");
				//helper.setTo("lohith@welezohealth.com");
			//helper.setCc("lohith@welezohealth.com");
				String to = "shiv@welezohealth.com , dp.harsha@welezohealth.com , lohith@welezohealth.com";
				InternetAddress[] parse = InternetAddress.parse(to , true);
				message.setRecipients(javax.mail.Message.RecipientType.TO,  parse);
				helper.setSubject("CSR Month-To-Date report : "+todate);

				// Free marker Template
				Configuration cfg = new Configuration();
				// Assume that the template is available under
				// /src/main/resources/templates
				cfg.setClassForTemplateLoading(MailReportController.class, "/templates/");
				cfg.setDefaultEncoding("UTF-8");
				cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
				Template template = cfg.getTemplate("telesalesReports.ftl");
				
				Map<String,Object> root = new HashMap<String,Object>();
				
				
				//System.out.println("Today date :"+todate +" convertd "+formatter.format(sdf.parse(todate)));
				/*Today presales appointment */
				ArrayList<HashMap<String, String>> todayPresalesAppointment = report.getTodayPresalesAppointment(formatter.format(sdf.parse(todate)));
				root.put("apptList", todayPresalesAppointment);
				root.put("sizeOfTodayAppt", todayPresalesAppointment.size());
				Calendar calendar = Calendar.getInstance();
				calendar.add(Calendar.DATE, 1);
				Date tomorrowDate = calendar.getTime();
				root.put("TomorrowDate", sdf.format(tomorrowDate));
				root.put("ToDate", todate);
				
			//	System.out.println("Tomorrow Date : "+formatter.format(tomorrowDate));
				/*tomorrow presales appointment */
				ArrayList<HashMap<String, String>> tomorrowAppt = report.getTodayPresalesAppointment(formatter.format(tomorrowDate));
				root.put("tomorrowAppt", tomorrowAppt);
			
				calendar.set(Calendar.DATE, 1);
				Date firstDate = calendar.getTime();
				root.put("sizeOfTomorriwAppt", tomorrowAppt.size());
				ArrayList<HashMap<String,String>> csrDailyCallsReport = report.getCSRDailyCallsReport(formatter.format(sdf.parse(todate)));
				root.put("callsReport", csrDailyCallsReport);
				root.put("firstDate", sdf.format(firstDate));
				ArrayList<HashMap<String,String>> csrSummary = report.getCSRMonthlyReport(formatter.format(firstDate),formatter.format(sdf.parse(todate)));
				root.put("salesReport", csrSummary);
				
				ArrayList<HashMap<String,String>> todayHealthApptSummary = report.getHealthApptSummaryEmail(formatter.format(sdf.parse(todate)));
				root.put("todayHealthApptList", todayHealthApptSummary);
				root.put("sizeOfTodayHealthAppt", todayHealthApptSummary.size());
				ArrayList<HashMap<String,String>> tomorHealthApptSummary= report.getHealthApptSummaryEmail(formatter.format(tomorrowDate));
				root.put("tomorowHealthApptList", tomorHealthApptSummary);
				root.put("sizeOfTomorrowHealthAppt", tomorHealthApptSummary.size());
				
				// Write output on console example 1
				StringWriter out = new StringWriter();
				template.process(root, out);
				out.flush();

				BodyPart messageBodyPart = new MimeBodyPart();
				// Now set the actual message
				// messageBodyPart.setText("");

				// Create a multipar message
				Multipart multipart = new MimeMultipart();

				MimeBodyPart attachPart = new MimeBodyPart();
				// Part two is attachment
				messageBodyPart = new MimeBodyPart();
				BodyPart body = new MimeBodyPart();
				body.setContent(out.toString(), "text/html");
				multipart.addBodyPart(body);
				message.setContent(multipart);
				mailSender.send(message);
			//	System.out.println("Sent message successfully....");
				Thread.sleep(1000);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		public void hrDepartmentEmailReports() throws MessagingException {

			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyyy HH:mm:ss");
			Date date = new Date();
			MimeMessage message = mailSender.createMimeMessage();

			try {
				MimeMessageHelper helper = new MimeMessageHelper(message, true);
				helper.setFrom("no-reply@welezohealth.com");
				//helper.setTo("lohith@welezohealth.com");
				String to = "shiv@welezohealth.com , lohith@welezohealth.com , dp.harsha@welezohealth.com , himabindu@welezohealth.com, sushmitha@welezohealth.com";
				InternetAddress[] parse = InternetAddress.parse(to , true);
				message.setRecipients(javax.mail.Message.RecipientType.TO,  parse);
				//helper.setCc("lohith@welezohealth.com"+";"+"lohithvn245@gmail.com");
				helper.setSubject("Daily Employees Attendance Report : "+dateFormat.format(date));

				// Free marker Template
				Configuration cfg = new Configuration();
				// Assume that the template is available under
				// /src/main/resources/templates
				cfg.setClassForTemplateLoading(UserController.class, "/templates/");
				cfg.setDefaultEncoding("UTF-8");
				cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

				Template template = cfg.getTemplate("hrEmailReports.ftl");
				Map<String,Object> root = new HashMap<String,Object>();
				
				//ArrayList<HashMap<String,String>> csrSummary = report.getCSRMonthlyReport();
				ArrayList<HashMap<String, String>> employeeBirthdayList = report.employeeBirthdayList();
				root.put("empDOB", employeeBirthdayList);
				
				ArrayList<HashMap<String,String>> employeeAbsenties = report.getEmployeeAbsenties();
				root.put("employeeAbsenties", employeeAbsenties);
				// Write output on console example 1
				StringWriter out = new StringWriter();
				template.process(root, out);
				out.flush();

				BodyPart messageBodyPart = new MimeBodyPart();
				
				// Create a multipar message
				Multipart multipart = new MimeMultipart();

				MimeBodyPart attachPart = new MimeBodyPart();
				// Part two is attachment
				messageBodyPart = new MimeBodyPart();
				BodyPart body = new MimeBodyPart();
				body.setContent(out.toString(), "text/html");
				multipart.addBodyPart(body);
				message.setContent(multipart);
				mailSender.send(message);
			//	System.out.println("Sent HR message successfully....");
				Thread.sleep(500);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
}
