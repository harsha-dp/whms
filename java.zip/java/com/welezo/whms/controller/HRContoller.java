package com.welezo.whms.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import com.welezo.whms.commons.CallsUpload;
import com.welezo.whms.dto.AttendenceDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.EmployeeQualificationDTO;
import com.welezo.whms.dto.PerformanceMetricsDTO;
import com.welezo.whms.dto.SalaryCompDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;
import com.welezo.whms.to.AttendenceTO;
import com.welezo.whms.to.EmpEvaluationTO;
import com.welezo.whms.to.EmployeeDetailsTO;
import com.welezo.whms.to.EmployeeImagesTO;
import com.welezo.whms.to.EmployeeQualificationTO;
import com.welezo.whms.to.EmployeeRolesTO;
import com.welezo.whms.to.ExperienceDetailsTO;
import com.welezo.whms.to.GoalSettingTO;
import com.welezo.whms.to.HireCompanyTO;
import com.welezo.whms.to.JobOpeningsTO;
import com.welezo.whms.to.LeaveRequestTO;
import com.welezo.whms.to.QnResponsesTO;
import com.welezo.whms.to.QualificationMasterTO;
import com.welezo.whms.to.RecruitmentTO;
import com.welezo.whms.to.RoleMasterTO;
import com.welezo.whms.to.SalaryCompTO;
import com.welezo.whms.to.WelezoConstantsTO;
import com.welezo.whms.tracker.TrackerDaoImpl;

@Controller
public class HRContoller {

	HttpSession session = null;
	@Autowired
	UserService userService;
	@Autowired
	AdminService adminService;

	@Autowired
	TrackerDaoImpl service;
	@Autowired
	ReportController report;
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	HRService hrService;
	private String query;

	@RequestMapping(value = "/homeHr")
	public ModelAndView dashBoardHr(ModelMap model) {

		ArrayList<HashMap<String, String>> employeeAbsenties = report.getEmployeeAbsenties();
		model.addAttribute("employeeAbsenties", employeeAbsenties);
		
		ArrayList<HashMap<String,String>> totalEmployeeReport = report.getTotalEmployeeReport();
		model.addAttribute("totalEmployeeReport", totalEmployeeReport);
		
		ArrayList<HashMap<String, String>> employeeBirthdayList = report.employeeBirthdayList();
		model.addAttribute("employeeBirthdayList", employeeBirthdayList);
		
		ArrayList<HashMap<String,String>> attendanceMonthlyManualReport = report.getAttendanceMonthlyManualReport();
		model.addAttribute("monthlyAttendance", attendanceMonthlyManualReport);
		
		ArrayList<HashMap<String,String>> employeeLeavesList = report.employeeLeavesList();
		model.addAttribute("employeeLeavesList", employeeLeavesList);
		return new ModelAndView("HR/dashboard");
	}

	@RequestMapping(value = "/addEmployee")
	public ModelAndView addemployee(ModelMap model) {
		
		EmployeeDetailsTO emp = new EmployeeDetailsTO();
		//List<EmployeeDetailsDTO> joinedList = hrService.getAllEmployees("STATUS IN('Joined')");
		//model.addAttribute("joinedList", joinedList);
		
		List<EmployeeDetailsDTO> releavedList = hrService.getAllEmployees("STATUS IN('Releaved')");
		model.addAttribute("releavedList", releavedList);
		
		List<EmployeeDetailsDTO> terminatedList = hrService.getAllEmployees("STATUS IN('Terminated')");
		model.addAttribute("terminatedList", terminatedList);
		
		List<HashMap<String, String>> permanentEmployees = hrService.getEmployeesListOnEmpType("Permanent");
		model.addAttribute("permanentEmployees", permanentEmployees);
		
		List<HashMap<String, String>> contractEmployees = hrService.getEmployeesListOnEmpType("Contract");
		model.addAttribute("contractEmployees", contractEmployees);
		
		List<HashMap<String, String>> consultantEmployees = hrService.getEmployeesListOnEmpType("Consultant");
		model.addAttribute("consultantEmployees", consultantEmployees);
		
		return new ModelAndView("HR/hr/addemployee", "addemployee", emp);
	}

	@RequestMapping(value = "getEmployee")
	public ModelAndView getEmployee(ModelMap model, @RequestParam Integer empId) {
		EmployeeDetailsTO employee = new EmployeeDetailsTO();
		return new ModelAndView("HR/hr/viewemployeedetails", "employee",
				employee);
	}

	@RequestMapping(value = "saveEmployee", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveEmployee(ModelMap model,
			EmployeeDetailsTO employeeDetailsTO) {
		employeeDetailsTO.setEmpId(employeeDetailsTO.getEmpId());
		adminService.saveOrUpdate(employeeDetailsTO);
		return new ModelAndView("redirect:addemployee");
	}

	@RequestMapping(value = "/viewEmployees")
	public ModelAndView viewEmployees(ModelMap model) {
		List<EmployeeDetailsDTO> allEmployees = hrService.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);
		
		
		return new ModelAndView("HR/hr/viewemployeedetails");
	}

	@RequestMapping(value = "/empImg", method = RequestMethod.POST)
	public ModelAndView employeeImgUpload(ModelMap model,
			@RequestParam CommonsMultipartFile file, @RequestParam Integer empId)
			throws Exception {

		boolean imgs = hrService.updateEmployeeImage(empId);
		if (imgs == false) {
			String s2 = "INSERT INTO employee_images (emp_id)VALUES('" + empId
					+ "')";
			hrService.upDateQuery(s2);
		}

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				// Create the file on server
				report.updateEmpImg(bytes, empId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		model.addAttribute("empId", empId);

		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "personalDeatils")
	public @ResponseBody ModelAndView personalDetails(ModelMap model) {
		// EmployeeDetailsTO empDetails = new EmployeeDetailsTO();
		RecruitmentTO empDetails = new RecruitmentTO();
		ArrayList<HashMap<String, String>> allJobOpenings = hrService
				.getAllJobOpenings();
		model.addAttribute("allJobOpenings", allJobOpenings);
		List<HireCompanyTO> allHireCompany = hrService.getAllHireCompany();
		model.addAttribute("allHireCompany", allHireCompany);

		return new ModelAndView("HR/hr/personalEmpDetails", "empDetails",
				empDetails);
	}

	@RequestMapping(value = "savepersonal", method = RequestMethod.POST)
	public ModelAndView savePersonalDetails(ModelMap model,
			RecruitmentTO empDetails) {
		Calendar cal = Calendar.getInstance();
		empDetails.setCreatedDate(cal.getTime());
		empDetails.setInterviewStatus("For Interview");
		adminService.saveAdmin(empDetails);

		model.addAttribute("empId", empDetails.getCandidateId());
		return new ModelAndView("redirect:OtherEmployeeDetails");
	}

	@RequestMapping(value = "OtherEmployeeDetails")
	public @ResponseBody ModelAndView employeeOtherDeatils(ModelMap model,
			@RequestParam Integer empId) {

		/*
		 * EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		 * model.addAttribute("employeeById", employeeById);
		 */

		HashMap<String, String> candidateDetails = hrService
				.getCandidateDetails(empId);
		model.addAttribute("candidateDetails", candidateDetails);
		List<EmployeeQualificationDTO> empDeptWise = hrService
				.getEmpDeptWise(candidateDetails.get("department"));
		model.addAttribute("empDeptWise", empDeptWise);
		List<EmployeeQualificationDTO> empDeptWiseHR = hrService
				.getEmpDeptWise("HR");
		model.addAttribute("empDeptWiseHR", empDeptWiseHR);
		List<WelezoConstantsTO> welezoWorkFlow = report
				.getWelezoWorkFlow("Interview_status");
		model.addAttribute("welezoWorkFlow", welezoWorkFlow);
		List<WelezoConstantsTO> interViewRounds = report
				.getWelezoWorkFlow("Interview_rounds");
		model.addAttribute("interViewRounds", interViewRounds);
		ArrayList<HashMap<String, String>> interviewerFeedback = hrService
				.getInterviewerFeedback(empId);
		model.addAttribute("interviewerFeedback", interviewerFeedback);

		ArrayList<HashMap<String, String>> questionBank = hrService
				.getQuestionBank("Interview Feedback");
		model.addAttribute("questionBank", questionBank);
		ArrayList<HashMap<String, String>> candidateReviewDetails = hrService
				.getEmployeeACCDetails("Interview Feedback", empId);
		model.addAttribute("candidateReviewDetails", candidateReviewDetails);

		/*
		 * List<ExperienceDetailsTO> empExperience =
		 * hrService.getEmpExperience(empId);
		 * model.addAttribute("empExperience", empExperience);
		 * List<EmployeeQualificationDTO> empQualifiaction =
		 * hrService.getEmpQualifiaction(empId);
		 * model.addAttribute("empQualifiaction", empQualifiaction);
		 */
		List<RoleMasterTO> allRoles = hrService.getAllRoles();
		model.addAttribute("allRoles", allRoles);

		List<EmployeeQualificationDTO> empRoleDesignation = hrService
				.getEmpRoleDesignation(empId);
		model.addAttribute("empRoleDesignation", empRoleDesignation);

		ArrayList<HashMap<String, String>> allSalSlab = hrService
				.getAllSalSlab();
		model.addAttribute("allSalSlab", allSalSlab);

		CallsUpload calls = new CallsUpload();
		String path = "/home/welezohealth/whms/others/";
		// String path = "D:\\files\\doc\\";
		ArrayList<HashMap<String, String>> employeeDocuments = calls
				.getEmployeeDocuments(
						empId + "_" + candidateDetails.get("Name"), path);
		model.addAttribute("documentList", employeeDocuments);

		return new ModelAndView("HR/hr/addEmpOtherDetails", "employeeDetails",
				new EmployeeQualificationDTO());
	}

	@RequestMapping(value = "/viewEmployeeById")
	public ModelAndView viewEmployeeById(ModelMap model,
			@RequestParam Integer empId) {

		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		model.addAttribute("employeeById", employeeById);

		List<ExperienceDetailsTO> empExperience = hrService
				.getEmpExperience(empId);
		model.addAttribute("empExperience", empExperience);
		List<EmployeeQualificationDTO> empQualifiaction = hrService
				.getEmpQualifiaction(empId);
		model.addAttribute("empQualifiaction", empQualifiaction);

		List<RoleMasterTO> allRoles = hrService.getAllRoles();
		model.addAttribute("allRoles", allRoles);

		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		List<EmployeeQualificationDTO> empRoleDesignation = hrService
				.getEmpRoleDesignation(empId);
		model.addAttribute("empRoleDesignation", empRoleDesignation);

		ArrayList<HashMap<String, String>> questionBank = hrService
				.getQuestionBank("Employee A/c Info");
		model.addAttribute("questionBank", questionBank);
		ArrayList<HashMap<String, String>> employeeACCDetails = hrService
				.getEmployeeACCDetails("Employee A/c Info", empId);
		model.addAttribute("employeeACCDetails", employeeACCDetails);

		ArrayList<HashMap<String, String>> allSalSlab = hrService
				.getAllSalSlab();
		model.addAttribute("allSalSlab", allSalSlab);

		CallsUpload calls = new CallsUpload();
		 String path = "/home/welezohealth/whms/hr/";
		// String path = "D:\\files\\doc\\";
		ArrayList<HashMap<String, String>> employeeDocuments = calls.getEmployeeDocuments(empId + "_" + employeeById.getEmpName(),
						path);
		model.addAttribute("documentList", employeeDocuments);
		// String path1 = "D:\\files\\doc\\";
		EmployeeImagesTO employeeImage = report.getEmployeeImage(empId);
		String encode = Base64.encodeBase64String(employeeImage.getEmpImg());
		model.addAttribute("empImge", encode);

		ArrayList<HashMap<String, String>> salPayMonthsList = hrService
				.getSalPayMonthsList(empId);
		model.addAttribute("monthList", salPayMonthsList);

		return new ModelAndView("HR/hr/viewEmployeeById", "employeeDetails",
				new EmployeeQualificationDTO());
	}

	@RequestMapping(value = "saveCandidateOtherDetails")
	public @ResponseBody ModelAndView saveQualificationInIVlevel(
			ModelMap model, EmployeeQualificationDTO employeeDetails) {

		String recruitment = "UPDATE recruitment SET relavent_exp = '"
				+ employeeDetails.getQualification()
				+ "', prvious_cmpy_designation ='"
				+ employeeDetails.getDesignation() + "',location_contrain ='"
				+ employeeDetails.getInstitute() + "'," + " current_salary ='"
				+ employeeDetails.getBiometricId() + "',expected_salary ='"
				+ employeeDetails.getQualifiedYear()
				+ "'  WHERE candidate_id = '" + employeeDetails.getEmpId()
				+ "'";

		hrService.upDateQuery(recruitment);
		model.addAttribute("empId", employeeDetails.getEmpId());
		return new ModelAndView("redirect:OtherEmployeeDetails");
	}

	@RequestMapping(value = "saveEmpQulaiificationDetails")
	public @ResponseBody ModelAndView saveQualificationInProfile(
			ModelMap model, EmployeeQualificationDTO employeeDetails) {
		QualificationMasterTO master = new QualificationMasterTO();
		master.setQualification(employeeDetails.getQualification());
		master.setSpecialization(employeeDetails.getSpecialization());
		adminService.saveAdmin(master);

		EmployeeDetailsTO emp = new EmployeeDetailsTO();
		emp.setEmpId(employeeDetails.getEmpId());

		EmployeeQualificationTO qualification = new EmployeeQualificationTO();
		qualification.setInstitute(employeeDetails.getInstitute());
		qualification.setQualifiedYear(employeeDetails.getQualifiedYear());
		qualification.setPercentage(employeeDetails.getPercentage());
		qualification.setUniversity(employeeDetails.getUniversity());
		qualification.setEmployeeDetails(emp);
		qualification.setQualificationMaster(master);
		adminService.saveAdmin(qualification);
		model.addAttribute("empId", employeeDetails.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "saveRemarks")
	public @ResponseBody ModelAndView saveInterviewewRemarks(ModelMap model,
			EmployeeQualificationDTO employeeDetails) {

		/*
		 * EmployeeDetailsDTO employeeById =
		 * hrService.getEmployeeById(employeeDetails.getEmpId()); Calendar cal =
		 * Calendar.getInstance();
		 * employeeDetails.setRemarks(employeeById.getRemarks() + "\n" + " - ("+
		 * employeeDetails.getStatus() + ") " + employeeDetails.getRemarks() +
		 * " On " + cal.getTime());
		 * hrService.saveInterviewRemarks(employeeDetails);
		 */

		/*
		 * if(employeeDetails.getStatus().equalsIgnoreCase("Joined")){
		 * EmployeeImagesTO img = new EmployeeImagesTO();
		 * img.setEmpId(employeeById.getEmpId()); adminService.saveAdmin(img); }
		 */
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(employeeDetails.getDob()));
		} catch (Exception e) {
			e.printStackTrace();
		}
	//	System.out.println(date);
		String interViewer = "INSERT INTO interviews(interviewed_by,candidate_id,interview_date,remarks,interview_status,created_date,created_by,interview_round)"
				+ " VALUES('"
				+ employeeDetails.getExpId()
				+ "','"
				+ employeeDetails.getEmpId()
				+ "','"
				+ date
				+ "' ,'"
				+ employeeDetails.getRemarks()
				+ "','"
				+ employeeDetails.getStatus()
				+ "',CURRENT_TIMESTAMP,'"
				+ employeeDetails.getEmpQufnId()
				+ "','"
				+ employeeDetails.getLevel() + "')";

		hrService.upDateQuery(interViewer);

		String recruitment = "UPDATE recruitment SET interview_status = '"
				+ employeeDetails.getStatus() + "' WHERE candidate_id = '"
				+ employeeDetails.getEmpId() + "'";
		hrService.upDateQuery(recruitment);

		model.addAttribute("empId", employeeDetails.getEmpId());
		return new ModelAndView("redirect:OtherEmployeeDetails");
	}

	@RequestMapping(value = "saveExperience")
	public @ResponseBody ModelAndView saveExperience(ModelMap model,
			EmployeeQualificationDTO employeeDetails) {

		EmployeeDetailsTO emp = new EmployeeDetailsTO();
		emp.setEmpId(employeeDetails.getEmpId());

		ExperienceDetailsTO experience = new ExperienceDetailsTO();
		experience.setCompanyName(employeeDetails.getCompanyName());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String fromdate = employeeDetails.getQualification();
		String toDate = employeeDetails.getSpecialization();
		try {
			Date date = formatter.parse(fromdate);
			experience.setFromDate(date);
			Date date1 = formatter.parse(toDate);
			experience.setToDate(date1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		experience.setDesignation(employeeDetails.getDesignation());
		experience.setCtcAnnum(employeeDetails.getCtcAnnum());
		experience.setReasonLeaving(employeeDetails.getReasonLeaving());
		experience.setEmployeeDetails(emp);
		adminService.saveAdmin(experience);
		model.addAttribute("empId", employeeDetails.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/postEditEmployee")
	public ModelAndView postEditEmployeeDetails(ModelMap model,
			EmployeeQualificationDTO employee) {
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(employee
				.getEmpId());

		AttendenceTO attendence = new AttendenceTO();
		attendence.setBiometricId(employee.getBiometricId());

		EmployeeDetailsTO details = new EmployeeDetailsTO();
		details.setEmpId(employee.getEmpId());
		details.setEmployeeId(employee.getEmployeeId());
		details.setEmpName(employee.getEmpName());
		details.setFHName(employee.getFHName());
		details.setRelationship(employee.getRelationship());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String dateInString = employee.getDob();
		try {
			Date date = formatter.parse(dateInString);
			details.setDob(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		details.setGender(employee.getGender());
		details.setMaritalStatus(employee.getMaritalStatus());
		details.setEmergencyContact(employee.getEmergencyContact());
		details.setPersonalContact(employee.getPersonalContact());
		details.setBloodGroup(employee.getBloodGroup());
		details.setPermanentAddress(employee.getPermanentAddress());
		details.setCommunicationAddresss(employee.getCommunicationAddresss());
		details.setPersonalEmail(employee.getPersonalEmail());
		// details.setEmpImg(employeeById.getEmpImg());
		details.setStatus(employeeById.getStatus());
		details.setCorporateEmail(employee.getCorporateEmail());
		details.setIsActive(true);
		details.setAttendence(attendence);
		adminService.upDateAdmin(details);

		model.addAttribute("empId", employee.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/empRole")
	public ModelAndView saveEmployeeRole(ModelMap model,
			EmployeeQualificationDTO employee) {

		EmployeeDetailsTO emp = new EmployeeDetailsTO();
		emp.setEmpId(employee.getEmpId());

		RoleMasterTO role = new RoleMasterTO();
		role.setRoleId(employee.getBiometricId());
		EmployeeRolesTO roleTO = new EmployeeRolesTO();
		roleTO.setEmpType(employee.getDesignation());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String fromdate = employee.getStatus();
		String todate = employee.getFHName();
		try {
			Date date = formatter.parse(fromdate);
			roleTO.setFromDate(date);
			if (employee.getCompanyName().equalsIgnoreCase("OfferLetter")) {
				Calendar cal = Calendar.getInstance();
				// Date today = cal.getTime();
				cal.add(Calendar.YEAR, 1); // to get previous year add -1
				Date nextYear = cal.getTime();
				roleTO.setToDate(nextYear);
				// System.out.println(nextYear);
			} else {
				Date date1 = formatter.parse(todate);
				roleTO.setToDate(date1);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		roleTO.setRoleMaster(role);
		roleTO.setEmployeeDetails(emp);
		roleTO.setReportTo(employee.getExpId());
		roleTO.setSlabId(employee.getEmpQufnId());
		adminService.saveAdmin(roleTO);

		model.addAttribute("empId", employee.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/recuirmentlist")
	public ModelAndView searchAppointment(Model model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", (todate));
		model.addAttribute("status", "For Interview");

		return new ModelAndView("redirect:recuirmentlist1");
	}

	@RequestMapping(value = "/recuirmentlist1", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView recuirtmentList(ModelMap model,
			@RequestParam String fromDate, String toDate, String status) {

		ArrayList<HashMap<String, String>> interviewCandidatesList = hrService
				.getInterviewCandidatesList(fromDate, toDate, status);
		model.addAttribute("candidateList", interviewCandidatesList);
		ArrayList<HashMap<String, String>> allJobOpenings = hrService
				.getAllJobOpenings();
		model.addAttribute("allJobOpenings", allJobOpenings);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("status", status);
		return new ModelAndView("HR/hr/recuirtmentlist");
	}

	@RequestMapping(value = "/viewLeaves")
	public ModelAndView viewEmployeeLeavesInHR(ModelMap model) {
		Calendar calendar = Calendar.getInstance();
		String firstDate = new SimpleDateFormat("dd/MM/yyyy").format(calendar
				.getTime());
		String lastDate = new SimpleDateFormat("dd/MM/yyyy").format(calendar
				.getTime());
		model.addAttribute("fromDate", firstDate);
		model.addAttribute("toDate", lastDate);
		return new ModelAndView("redirect:viewLeaves1");
	}

	@RequestMapping(value = "/viewLeaves1")
	public ModelAndView viewLeavesInHR(ModelMap model, String fromDate,
			String toDate) {
		ArrayList<HashMap<String, String>> allLeaves = hrService.getAllLeaves(
				fromDate, toDate);
		model.addAttribute("allLeaves", allLeaves);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		return new ModelAndView("HR/hr/viewLeaves");
	}

	@RequestMapping(value = "/editleaves")
	public ModelAndView editLeaves(ModelMap model,
			@RequestParam Integer requestId) {
		HashMap<String, String> leavesById = hrService.getLeavesById(requestId);
		model.addAttribute("leavesById", leavesById);
		return new ModelAndView("HR/hr/editLeaves", "leaveRequest",
				new LeaveRequestTO());
	}

	@RequestMapping(value = "/postEditleaves")
	public ModelAndView postEditLeavesHR(ModelMap model,
			LeaveRequestTO leaveRequest) {
		saveEditLeaves(leaveRequest);
		return new ModelAndView("redirect:viewLeaves");
	}

	@RequestMapping(value = "/postEditleavesAdmin")
	public ModelAndView postEditLeavesAdmin(ModelMap model,
			LeaveRequestTO leaveRequest) {
		saveEditLeaves(leaveRequest);
		String toAddr1 = null;
		String fromAddr1 = null;
		String cc = null;
		String subject1 = null;
		String body1 = null;

		HashMap<String, String> reportBy = hrService.getReportIdthruUserId(leaveRequest.getApprovedBy());
		EmployeeDetailsDTO reportEmail = hrService.getEmployeeById(Integer.parseInt(reportBy.get("reportTo")));
		EmployeeDetailsDTO applyBy = hrService.getEmployeeById(leaveRequest
				.getEmpId());
		if (leaveRequest.getStatus().equalsIgnoreCase("Approved")) {
			toAddr1 = applyBy.getCorporateEmail();
			fromAddr1 = "no-reply@welezohealth.com";
			cc = "hr@welezohealth.com";
			subject1 = "Leave Request Approved  by " + reportEmail.getEmpName();
			body1 = "Hi " + applyBy.getEmpName() + ",\n"
					+ " Your leave request has been approved by "
					+ reportEmail.getEmpName() + "\n" + "\n" + "\n"
					+ "Thanks \n" + "Team Welezo \n";
			
			try {
				report.saveEmployeeLeaves(leaveRequest.getEmpId(), leaveRequest.getFromDate(), leaveRequest.getToDate());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			
			
		} else if (leaveRequest.getStatus().equalsIgnoreCase("Rejected")) {
			toAddr1 = applyBy.getCorporateEmail();
			fromAddr1 = "no-reply@welezohealth.com";
			cc = "hr@welezohealth.com";
			subject1 = "Leave Request Declined  by  "
					+ reportEmail.getEmpName();
			body1 = "Hi " + applyBy.getEmpName() + ",\n"
					+ " Your leave request has been declined by  "
					+ reportEmail.getEmpName() + "\n" + "\n" + "\n"
					+ "Thanks \n" + "Team Welezo \n";
		} else if (leaveRequest.getStatus().equalsIgnoreCase("Cancelled")) {
			toAddr1 = reportEmail.getCorporateEmail();
			fromAddr1 = "no-reply@welezohealth.com";
			cc = "hr@welezohealth.com";
			subject1 = "Leave Request Cancelled by  "
					+ reportEmail.getEmpName();
			body1 = "Hi " + reportEmail.getEmpName() + ",\n"
					+ applyBy.getEmpName()
					+ " has cancelled the leave request.  " + "\n" + "\n"
					+ "\n" + "Thanks \n" + "Team Welezo \n";
		}
		MimeMessage message = mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(fromAddr1);
			helper.setTo(toAddr1);
			helper.setCc(cc);
			helper.setSubject(subject1);
			helper.setText(body1);
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		model.addAttribute("userId", leaveRequest.getApprovedBy());
		return new ModelAndView("redirect:viewLeaveslist");
	}

	@RequestMapping(value = "/cancelLeaveReq")
	public ModelAndView CancelLeaveRequest(ModelMap model,
			@RequestParam Integer requestId, @RequestParam Integer userId) {
		String query = "UPDATE leave_request SET STATUS = 'Cancelled' WHERE request_id = '"
				+ requestId + "'";
		hrService.upDateQuery(query);
		model.addAttribute("userId", userId);
		return new ModelAndView("redirect:userProfile");
	}

	public void saveEditLeaves(LeaveRequestTO leaveRequest) {
		HashMap<String, String> leavesById = hrService
				.getLeavesById(leaveRequest.getRequestId());
		String fromDate = null;
		String toDate = null;
		String description = leavesById.get("description") + " -- "
				+ leaveRequest.getDescription();
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-dd");
			fromDate = sdf.format(leaveRequest.getFromDate());
			toDate = sdf.format(leaveRequest.getToDate());
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
		String query = "UPDATE leave_request SET from_date = '" + fromDate
				+ "',to_date = '" + toDate + "',total_days = '"
				+ leaveRequest.getTotalDays() + "' ,leave_type = '"
				+ leaveRequest.getLeaveType() + "',description = '"
				+ description + "'," + " STATUS='" + leaveRequest.getStatus()
				+ "',approved_by = '" + leaveRequest.getApprovedBy()
				+ "',approved_on=CURRENT_TIMESTAMP WHERE request_id = '"
				+ leaveRequest.getRequestId() + "'";
		hrService.upDateQuery(query);

	}

	@RequestMapping(value = "/leaveForm")
	public ModelAndView empLeaveRequest(ModelMap model) {
		LeaveRequestTO leaveRequest = new LeaveRequestTO();
		List<EmployeeDetailsDTO> allEmployees = hrService.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);
		return new ModelAndView("HR/hr/leaveRequest", "leaveRequest",
				leaveRequest);
	}

	@RequestMapping(value = "leaveRequestAdmin")
	public ModelAndView viewleaverequest(ModelMap model, Integer userId) {

		ArrayList<HashMap<String, String>> employeesListByReportId = hrService.getEmployeesListByReportId(userId);
		model.addAttribute("allEmployees", employeesListByReportId);
		return new ModelAndView("Admin/welezoconstant/leaveRequest","leaveRequest", new LeaveRequestTO());
	}

	@RequestMapping(value = "/saveLeaveAdmin")
	public ModelAndView saveLeaveFromAdmin(ModelMap model,LeaveRequestTO leaveRequest) {
		Calendar cal = Calendar.getInstance();
		leaveRequest.setReqCreation(cal.getTime());
		adminService.saveAdmin(leaveRequest);

		HashMap<String, String> reportBy = hrService.getReportIdthruUserId(leaveRequest.getRequestBy());
		EmployeeDetailsDTO reportEmail = hrService.getEmployeeById(Integer.parseInt(reportBy.get("reportTo")));
		//System.out.println(reportEmail.getCorporateEmail());
		EmployeeDetailsDTO applyBy = hrService.getEmployeeById(leaveRequest.getEmpId());
		System.out.println(applyBy.getCorporateEmail());

		String toAddr1 = reportEmail.getCorporateEmail();
		String fromAddr1 = "no-reply@welezohealth.com";
		String subject1 = "Need Action - Leave Request submitted by "	+ applyBy.getEmpName();
		String body1 = "Hi "
				+ reportEmail.getEmpName()
				+ ",\n"
				+ applyBy.getEmpName()
				+ " has applied for the leave through WHMS.Please take action to Approve / Reject."
				+ "\n" + "\n" + "\n" + "Thanks \n" + "Team Welezo \n";

		MimeMessage message = mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(fromAddr1);
			helper.setTo(toAddr1);
			helper.setSubject(subject1);
			helper.setText(body1);
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		model.addAttribute("userId", leaveRequest.getRequestBy());
		return new ModelAndView("redirect:userProfile");
	}

	@RequestMapping(value = "viewLeaveslist", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView viewLeaveRequestInAdmin(ModelMap model, Integer userId) {

		String query = "SELECT req.*, emp.`emp_name`,emp1.emp_name AS 'report' FROM leave_request req "
				+ " LEFT JOIN employee_details emp ON emp.emp_id = req.emp_id "
				+ " LEFT JOIN `employee_roles` roles ON roles.`emp_id` = req.`emp_id` "
				+ "LEFT JOIN `employee_details` emp1 ON emp1.`emp_id` = `report_to` "
				+ "WHERE CURRENT_DATE BETWEEN roles.from_date AND roles.to_date "
				+ "AND (roles.`report_to` = (SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON "
				+ " emp.corporate_email = mast.user_mail WHERE user_id = '"
				+ userId + "')) ";
		ArrayList<HashMap<String, String>> allLeavesAdmin = hrService
				.getAllLeavesAdmin(query);
		model.addAttribute("leavesList", allLeavesAdmin);
		return new ModelAndView("Admin/welezoconstant/viewLeaves");
	}

	@RequestMapping(value = "editLeaveslist")
	public ModelAndView editLeaveRequestInAdmin(ModelMap model,
			Integer requestId) {
		// System.out.println(requestId);
		HashMap<String, String> leavesById = hrService.getLeavesById(requestId);
		model.addAttribute("leavesById", leavesById);
		return new ModelAndView("Admin/welezoconstant/editLeaves",
				"leaveRequest", new LeaveRequestTO());
	}

	@RequestMapping(value = "/saveLeave")
	public ModelAndView saveLeaveRequest(ModelMap model,
			LeaveRequestTO leaveRequest) {
		adminService.saveAdmin(leaveRequest);
		return new ModelAndView("redirect:viewLeaves");
	}

	@RequestMapping(value = "/department")
	public ModelAndView department(ModelMap model) {
		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);
		return new ModelAndView("HR/hr/department");
	}

	@RequestMapping(value = "/empList")
	public ModelAndView teamMembers(ModelMap model,
			@RequestParam String departmentName) {
		List<EmployeeQualificationDTO> empDeptWise = hrService
				.getEmpDeptWise(departmentName);
		model.addAttribute("empDeptWise", empDeptWise);
		model.addAttribute("departmentName", departmentName);
		return new ModelAndView("HR/hr/teamMembers");
	}

	@RequestMapping(value = "/company")
	public ModelAndView company(ModelMap model) {
		return new ModelAndView("HR/hr/company");
	}

	@RequestMapping(value = "/PayRoll")
	public ModelAndView Payroll(ModelMap model) {
		return new ModelAndView("HR/hr/PayRoll");
	}

	@RequestMapping(value = "/editEmpRole")
	public ModelAndView editEmpRole(ModelMap model, Integer roleId) {
		EmployeeQualificationDTO empRoleById = hrService.getEmpRoleById(roleId);
		model.addAttribute("empRoleById", empRoleById);
		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		List<RoleMasterTO> allRoles = hrService.getAllRoles();
		model.addAttribute("allRoles", allRoles);
		return new ModelAndView("HR/hr/editEmpRole", "empRoleTO",
				new EmployeeQualificationDTO());
	}

	@RequestMapping(value = "/saveRoleDate")
	public ModelAndView savePostEdit(ModelMap model,
			EmployeeQualificationDTO employeeRole) {
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(employeeRole.getDob()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		// System.out.println("inside edit roles " + date);
		String query = "UPDATE employee_roles SET role_id= '"
				+ employeeRole.getEmpQufnId() + "',emp_type='"
				+ employeeRole.getDesignation() + "', to_date = '" + date
				+ "', " + "report_to  = '" + employeeRole.getBiometricId()
				+ "' WHERE emp_role_id = '" + employeeRole.getExpId() + "' ";
		hrService.upDateQuery(query);
		model.addAttribute("empId", employeeRole.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/empDocument", method = RequestMethod.POST)
	public ModelAndView uploadEmpDoc(ModelMap model,
			@RequestParam("name") String name,
			@RequestParam CommonsMultipartFile file, @RequestParam Integer empId)
			throws Exception {

		String path = "/home/welezohealth/whms/hr";
	//	 String path = "D:\\files\\doc";
		String filename = file.getOriginalFilename();
		// boolean renameTo = ((File)file).renameTo(new
		// File("D:\\files\\"+name));

		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			// multipartFile.transferTo(new File(saveDirectory + fileName));
			// fileNames.add(fileName);
			bout.write(barr);
			bout.flush();
			bout.close();

		} catch (Exception e) {
			// System.out.println(e);
		}

		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + empId + "_" + name + "_"
				+ filename));

		model.addAttribute("empId", empId);
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/empOfferletter")
	public ModelAndView OffrerLetterby(ModelMap model,
			@RequestParam Integer candidateId, @RequestParam Integer slabId) {

		// EmployeeDetailsDTO employeeById =
		// hrService.getEmployeeById(candidateId);
		HashMap<String, String> candidateDetails = hrService
				.getCandidateDetails(candidateId);
		model.addAttribute("employeeById", candidateDetails);
		HashMap<String, String> salarySlabDetails = hrService
				.getSalarySlabDetails(slabId);
		model.addAttribute("salaryDeatils", salarySlabDetails);
		HashMap<String, String> designation = hrService
				.getDesignation(candidateId);
		model.addAttribute("designation", designation);

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("todayDate", dateFormat.format(date));

		// the day from join date to minus 3 days
		String dt = candidateDetails.get("joiningDate");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(dt));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.add(Calendar.DATE, -3); // number of days to minus
		dt = sdf.format(c.getTime());
		System.out.println(dt);
		model.addAttribute("minus3Days", dt);
		return new ModelAndView("HR/hr/OfferLetterBy");
	}

	@RequestMapping(value = "/paycalc")
	public ModelAndView payCalculatorPage(ModelMap model) {

		return new ModelAndView("HR/hr/payCalculator");
	}

	@RequestMapping(value = "/goalSetting")
	public ModelAndView empGoalSetting(ModelMap model) {
		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);
		String query = "SELECT DISTINCT emp.emp_name,role.department,emp.emp_id FROM employee_roles empRole "
				+ " LEFT JOIN role_master role ON role.role_id = empRole.role_id  LEFT JOIN employee_details emp ON emp.emp_id = empRole.emp_id ";
		ArrayList<HashMap<String, String>> getemployeeListThruRole = hrService
				.getemployeeListThruRole(query);
		model.addAttribute("employeeList", getemployeeListThruRole);
		String query1 = "SELECT DISTINCT emp.emp_name,role.department,emp.emp_id,empRole.report_to FROM employee_roles empRole "
				+ "LEFT JOIN role_master role ON role.role_id = empRole.role_id LEFT JOIN employee_details emp ON emp.emp_id = empRole.report_to "
				+ " WHERE CURRENT_DATE BETWEEN  from_date AND to_date";
		ArrayList<HashMap<String, String>> getemployeeListThruRole2 = hrService
				.getemployeeListThruRole(query1);
		model.addAttribute("managersList", getemployeeListThruRole2);
		return new ModelAndView("HR/hr/goalSetting", "goalTO",
				new GoalSettingTO());
	}
	
	@RequestMapping(value = "/goalSettingOthers")
	public ModelAndView empGoalSettings(ModelMap model, Integer userId) {

		ArrayList<HashMap<String, String>> employeesListByReportId = hrService
				.getEmployeesListByReportId(userId);
		model.addAttribute("allEmployees", employeesListByReportId);
		HashMap<String, String> employee = hrService.getEmployeeIdFromUserId(userId);
		
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(Integer.parseInt(employee.get("empId")));
		model.addAttribute("employeeDetail", employeeById);

		ArrayList<HashMap<String, String>> metricsList = hrService.getMetricsList();
		model.addAttribute("metricsList", metricsList);
		
		return new ModelAndView("Admin/welezoconstant/goalSettingOthers");
	}
	@RequestMapping(value = "/goalSettingCSR")
	public ModelAndView empGoalSettingsCSR(ModelMap model, Integer userId) {

		ArrayList<HashMap<String, String>> metricsList = hrService.getMetricsList();
		model.addAttribute("metricsList", metricsList);
		
		List<EmployeeDTO> csrList = adminService.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("employeeList", csrList);
		return new ModelAndView("Admin/welezoconstant/goalSettings", "goalTO",	new GoalSettingTO());
	}
	@RequestMapping(value = "/goalSettingExecutive")
	public ModelAndView empGoalSettingExecutive(ModelMap model, Integer userId) {

		HashMap<String, String> employee = hrService.getEmployeeIdFromUserId(userId);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(Integer.parseInt(employee.get("empId")));
		
		ArrayList<HashMap<String, String>> metricsList = hrService.getMetricsList();
		model.addAttribute("metricsList", metricsList);
		
		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%' AND department ='Telesales'");
		model.addAttribute("employeeList", executiveList);
		
		model.addAttribute("employeeDetail", employeeById);

		
		return new ModelAndView("Admin/welezoconstant/goalSettings", "goalTO",	new GoalSettingTO());
	}

	@RequestMapping(value = "/savegoals")
	public ModelAndView saveGoalsFromManger(String goalName,String goalInfo,String metricId,String metricType,String goalFrom,
			String goalTo,String[] target,String[] goalSetFor) {
		String date = null;
		String date1 = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(goalFrom));
			date1 = formatter.format(sdf.parse(goalTo));
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(int i =0 ; i< goalSetFor.length;i++){
			if(!target.equals(null)){
		String query = "INSERT INTO goal_setting (goal_name,metric_id,metric_type,target,STATUS,goal_from,goal_to,goal_set_for,goal_info)"
				+ "VALUES('"+goalName+"','"+metricId+"','"+metricType+"','"+target[i]+"','Goal Set','"+date+"','"+date1+"','"+goalSetFor[i]+"','"+goalInfo+"')";
		hrService.upDateQuery(query);
			}
		}
		return new ModelAndView("redirect:welezouser_dashboard");
	}

	@RequestMapping(value = "/savegoal")
	public ModelAndView saveGoal(String goalName,String goalInfo,String metricId,String metricType,String goalFrom,
			String goalTo,String target,String goalSetFor) {
		
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(goalFrom));
			date1 = formatter.format(sdf.parse(goalTo));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "INSERT INTO goal_setting (goal_name,metric_id,metric_type,target,STATUS,goal_from,goal_to,goal_set_for,goal_info)"
				+ "VALUES('"+goalName+"','"+metricId+"','"+metricType+"','"+target+"','Goal Set','"+date+"','"+date1+"','"+goalSetFor+"','"+goalInfo+"')";
		hrService.upDateQuery(query);
		return new ModelAndView("redirect:welezouser_dashboard");
	}

	@RequestMapping(value = "/viewGoal")
	public ModelAndView viewGoals(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -10);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		model.addAttribute("status", "New");
		return new ModelAndView("redirect:viewAllGoal");
	}

	@RequestMapping(value = "/viewAllGoal")
	public ModelAndView viewAllGoals(ModelMap model, String fromDate,
			String toDate, String status) {
		ArrayList<HashMap<String, String>> allGoals = hrService.getAllGoals(fromDate, toDate, status);
		model.addAttribute("allGoals", allGoals);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("status", status);
		return new ModelAndView("HR/hr/viewGoals");
	}

	@RequestMapping(value = "/viewGoals")
	public ModelAndView viewAllGoalsInAdmin(ModelMap model, Integer userId) {
		HashMap<String, String> employeeById = hrService.getEmployeeIdFromUserId(userId);
		String query = "SELECT goal.*,emp.emp_name AS 'Set For' FROM goal_setting goal  "
				+ " LEFT JOIN employee_details emp ON emp.emp_id = goal.goal_set_for WHERE CURRENT_DATE BETWEEN goal_from AND (goal_to + 3)  ";
		ArrayList<HashMap<String, String>> goalsAdmin = hrService
				.getGoalsAdmin(query);
		model.addAttribute("goals", goalsAdmin);
		return new ModelAndView("Admin/user/viewGoalsAdmin");
	}

	@RequestMapping(value = "/jobopenings")
	public ModelAndView jobOpenings(ModelMap model) {
		ArrayList<HashMap<String, String>> allJobOpenings = hrService
				.getAllJobOpenings();
		model.addAttribute("allJobOpenings", allJobOpenings);
		List<RoleMasterTO> allRoles = hrService.getAllRoles();
		model.addAttribute("allRoles", allRoles);
		return new ModelAndView("HR/hr/jobOpenings", "jobOpenTO",
				new JobOpeningsTO());
	}

	@RequestMapping(value = "/saveOpenings")
	public ModelAndView saveJobOpenings(ModelMap model, JobOpeningsTO jobOpenTO) {
		adminService.saveAdmin(jobOpenTO);
		return new ModelAndView("redirect:jobopenings");
	}

	@RequestMapping(value = "/hireCompany")
	public ModelAndView hireCompany(ModelMap model) {
		List<HireCompanyTO> allHireCompany = hrService.getAllHireCompany();
		model.addAttribute("allHireCompany", allHireCompany);
		return new ModelAndView("HR/hr/hireCompany", "companyTO",
				new HireCompanyTO());
	}

	@RequestMapping(value = "/saveCompany")
	public ModelAndView saveHireCompany(ModelMap model, HireCompanyTO companyTO) {
		adminService.saveAdmin(companyTO);
		return new ModelAndView("redirect:hireCompany");
	}

	@RequestMapping(value = "/editJobOpenings")
	public ModelAndView editJobOpenings(ModelMap model,
			@RequestParam Integer jobOpenId) {
		ArrayList<HashMap<String, String>> allJobOpenings = hrService
				.getAllJobOpenings();
		model.addAttribute("allJobOpenings", allJobOpenings);

		HashMap<String, String> jobOpeninsById = hrService
				.getJobOpeninsById(jobOpenId);
		model.addAttribute("jobOpeninsById", jobOpeninsById);
		return new ModelAndView("HR/hr/editJobOpenings", "jobOpenTO",
				new JobOpeningsTO());
	}

	@RequestMapping(value = "/saveJobOpenings")
	public ModelAndView postEditJobOpenings(ModelMap model,
			JobOpeningsTO jobOpenTO) {
		jobOpenTO.setJobOpenId(jobOpenTO.getJobOpenId());
		adminService.upDateAdmin(jobOpenTO);
		return new ModelAndView("redirect:jobopenings");
	}

	@RequestMapping(value = "/updateAttendece")
	public ModelAndView updateAttendence(ModelMap model,
			AttendenceDTO attendenceDTO) {
		report.updateAttendence(attendenceDTO);
		return new ModelAndView("redirect:addAtendance");
	}

	@RequestMapping(value = "/editQunfn")
	public ModelAndView editQualification(ModelMap model,
			@RequestParam Integer empQufnId) {
		HashMap<String, String> qualificationById = hrService
				.getQualificationById(empQufnId);
		model.addAttribute("qualificationById", qualificationById);
		return new ModelAndView("HR/hr/editQualifications", "qualificationDTO",
				new EmployeeQualificationDTO());
	}

	@RequestMapping(value = "/editExp")
	public ModelAndView editExperience(ModelMap model,
			@RequestParam Integer expId) {
		HashMap<String, String> experienceById = hrService
				.getExperienceById(expId);
		model.addAttribute("experienceById", experienceById);
		return new ModelAndView("HR/hr/editExprience", "employeeDetails",
				new EmployeeQualificationDTO());
	}

	@RequestMapping(value = "postEditQulfn")
	public @ResponseBody ModelAndView postEditQualification(ModelMap model,
			EmployeeQualificationDTO employeeDetails) {
		QualificationMasterTO master = new QualificationMasterTO();
		master.setQualificationId(employeeDetails.getQualificationId());
		master.setQualification(employeeDetails.getQualification());
		master.setSpecialization(employeeDetails.getSpecialization());
		adminService.upDateAdmin(master);

		EmployeeDetailsTO emp = new EmployeeDetailsTO();
		emp.setEmpId(employeeDetails.getEmpId());
		EmployeeQualificationTO qualification = new EmployeeQualificationTO();
		qualification.setEmpQufnId(employeeDetails.getEmpQufnId());
		qualification.setInstitute(employeeDetails.getInstitute());
		qualification.setQualifiedYear(employeeDetails.getQualifiedYear());
		qualification.setPercentage(employeeDetails.getPercentage());
		qualification.setUniversity(employeeDetails.getUniversity());
		qualification.setEmployeeDetails(emp);
		qualification.setQualificationMaster(master);
		adminService.upDateAdmin(qualification);

		model.addAttribute("empId", employeeDetails.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "postEditExpern")
	public @ResponseBody ModelAndView postEditExperience(ModelMap model,
			EmployeeQualificationDTO employeeDetails) {
		EmployeeDetailsTO emp = new EmployeeDetailsTO();
		emp.setEmpId(employeeDetails.getEmpId());
		ExperienceDetailsTO experience = new ExperienceDetailsTO();
		experience.setExpId(employeeDetails.getExpId());
		experience.setCompanyName(employeeDetails.getCompanyName());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String fromdate = employeeDetails.getQualification();
		String toDate = employeeDetails.getSpecialization();
		try {
			Date date = formatter.parse(fromdate);
			experience.setFromDate(date);
			Date date1 = formatter.parse(toDate);
			experience.setToDate(date1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		experience.setDesignation(employeeDetails.getDesignation());
		experience.setCtcAnnum(employeeDetails.getCtcAnnum());
		experience.setReasonLeaving(employeeDetails.getReasonLeaving());
		experience.setVerificationDetails(employeeDetails
				.getVerificationDetails());
		experience.setEmployeeDetails(emp);
		adminService.upDateAdmin(experience);

		model.addAttribute("empId", employeeDetails.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/editGoal")
	public ModelAndView reviewGoals(ModelMap model, @RequestParam Integer goalId) {
		HashMap<String, String> employeeGoalById = hrService
				.getEmployeeGoalById(goalId);
		model.addAttribute("goalById", employeeGoalById);
		return new ModelAndView("HR/hr/editGoal", "goalTO", new GoalSettingTO());
	}

	@RequestMapping(value = "/editGoalsAdmin")
	public ModelAndView editGoalsAdmin(ModelMap model,
			@RequestParam Integer goalId) {
		HashMap<String, String> employeeGoalById = hrService
				.getEmployeeGoalById(goalId);
		model.addAttribute("goalById", employeeGoalById);
		return new ModelAndView("Admin/user/editGoalsAdmin", "goalTO",
				new GoalSettingTO());
	}

	@RequestMapping(value = "/postEditGoal")
	public ModelAndView postEditGoals(ModelMap model, GoalSettingTO goalTO) {
		HashMap<String, String> goalById = hrService.getEmployeeGoalById(goalTO
				.getGoalId());
		Calendar cal = Calendar.getInstance();
		goalTO.setRemarks(goalById.get("remarks") + " - (" + cal.getTime()
				+ " And " + goalTO.getStatus() + ") " + goalTO.getRemarks());

		adminService.upDateAdmin(goalTO);
		return new ModelAndView("redirect:viewGoal");
	}

	@RequestMapping(value = "/postEditGoalAdmin")
	public ModelAndView postEditGoalsAdmin(ModelMap model, GoalSettingTO goalTO) {
		HashMap<String, String> goalById = hrService.getEmployeeGoalById(goalTO
				.getGoalId());
		Calendar cal = Calendar.getInstance();
		goalTO.setRemarks(goalById.get("remarks") + " - (" + cal.getTime()
				+ " And " + goalTO.getStatus() + ") " + goalTO.getRemarks());

		adminService.upDateAdmin(goalTO);
		return new ModelAndView("redirect:welezouser_dashboard");
	}

	@RequestMapping(value = "/performance")
	public ModelAndView employeePerformanceHR(ModelMap model) {
		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);
		return new ModelAndView("HR/hr/employeePerformance", "performanceDTO",
				new PerformanceMetricsDTO());
	}

	@RequestMapping(value = "/selfEvaluation")
	public ModelAndView empselfEvaluation(ModelMap model) {
		ArrayList<HashMap<String, String>> allMetricsHR = hrService
				.getAllMetrics("All");
		model.addAttribute("allMetricsHR", allMetricsHR);
		ArrayList<HashMap<String, String>> allMetricsManager = hrService
				.getAllMetrics("Manager");
		model.addAttribute("allMetricsManager", allMetricsManager);
		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);
		return new ModelAndView("Admin/welezoconstant/selfEvaluation",
				"performanceDTO", new PerformanceMetricsDTO());
	}

	@RequestMapping(value = "/searchPerformance")
	public ModelAndView searchPerformanceMGR(ModelMap model,PerformanceMetricsDTO performanceDTO) {

		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(performanceDTO.getEmpId());
		model.addAttribute("employeeById", employeeById);

		model.addAttribute("month", performanceDTO.getEvaluatorPeriod());

		ArrayList<HashMap<String, String>> managerEntry = hrService.getEmpEvaluation(performanceDTO);
		model.addAttribute("managerEntry", managerEntry);
		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);
		if (managerEntry.isEmpty()) {
			ArrayList<HashMap<String, String>> allMetrics = hrService
					.getAllMetrics("All");
			model.addAttribute("allMetrics", allMetrics);
			ArrayList<HashMap<String, String>> allMetricsManager = hrService
					.getAllMetrics("Manager");
			model.addAttribute("allMetricsManager", allMetricsManager);
			model.addAttribute("check", "test");
			return new ModelAndView(
					"Admin/welezoconstant/employeePerformanceManager",
					"performanceDTO", new PerformanceMetricsDTO());
		} else {
			return new ModelAndView(
					"Admin/welezoconstant/employeePerformanceManager",
					"performanceDTO", new PerformanceMetricsDTO());
		}
	}

	@RequestMapping(value = "/searchPerformanceHr")
	public ModelAndView searchPerformanceHR(ModelMap model,
			PerformanceMetricsDTO performanceDTO) {

		EmployeeDetailsDTO employeeById = hrService
				.getEmployeeById(performanceDTO.getEmpId());
		model.addAttribute("employeeById", employeeById);
		model.addAttribute("month", performanceDTO.getEvaluatorPeriod());

		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		ArrayList<HashMap<String, String>> empEvaluation = hrService
				.getEmpEvaluation(performanceDTO);
		model.addAttribute("empEvaluationHR", empEvaluation);

		return new ModelAndView("HR/hr/employeePerformance", "performanceDTO",
				new PerformanceMetricsDTO());
	}

	@RequestMapping(value = "/savePerfromance")
	public ModelAndView saveEmployeePerformanceHR(ModelMap model,
			PerformanceMetricsDTO performanceDTO) {

		Integer[] metricId = performanceDTO.getMetricId();
		String[] text = performanceDTO.getText();

		if (performanceDTO.getModule().equalsIgnoreCase("HR")) {
			hrService.updateHRemployeeperformance(performanceDTO);
			return new ModelAndView("redirect:performance");
		} else if (performanceDTO.getModule().equalsIgnoreCase("Manager")) {
			for (int i = 0; i < metricId.length; i++) {
				EmpEvaluationTO evalunTO = new EmpEvaluationTO();
				evalunTO.setEmpId(performanceDTO.getEmpId());
				evalunTO.setMetricId(metricId[i]);
				evalunTO.setEvalPeriod(performanceDTO.getEvaluatorPeriod());
				evalunTO.setMgrEval(text[i]);
				Calendar cal = Calendar.getInstance();
				evalunTO.setMgrEvalDt(cal.getTime());
				adminService.saveAdmin(evalunTO);
			}
			return new ModelAndView("redirect:performanceMgr");
		} else {
			/*
			 * for (int i = 0; i < metricId.length; i++) { EmpEvaluationTO
			 * evalunTO = new EmpEvaluationTO();
			 * evalunTO.setEmpId(performanceDTO.getEmpId());
			 * evalunTO.setMetricId(metricId[i]);
			 * evalunTO.setEvalPeriod(performanceDTO.getEvaluatorPeriod());
			 * evalunTO.setSelfEval(text[i]); Calendar cal =
			 * Calendar.getInstance(); evalunTO.setSelfEvalDt(cal.getTime());
			 * adminService.saveAdmin(evalunTO); }
			 */
			return new ModelAndView("redirect:selfEvaluation");
		}
	}

	@RequestMapping(value = "/performanceMgr")
	public ModelAndView employeePerformanceManager(ModelMap model,
			Integer userId) {
		// List<EmployeeDetailsDTO> allEmployees =
		// hrService.getAllEmployees("STATUS = 'Joined'");
		ArrayList<HashMap<String, String>> employeesListByReportId = hrService
				.getEmployeesListByReportId(userId);
		model.addAttribute("allEmployees", employeesListByReportId);
		return new ModelAndView(
				"Admin/welezoconstant/employeePerformanceManager",
				"performanceDTO", new PerformanceMetricsDTO());
	}

	@RequestMapping(value = "/salComp")
	public ModelAndView salaryComponent(ModelMap model,	@RequestParam Integer[] salSlabId, String[] paidDays,String[] lateDays) {
		
		for(int i = 0; i < salSlabId.length ; i++ ){
			//System.out.println("salary " +salSlabId[i] +" "+paidDays[i]+" "+lateDays[i]);
			String query = "UPDATE salary_comp SET paid_days = "+paidDays[i]+" ,late_days = "+lateDays[i]+" WHERE id = "+salSlabId[i]+"" ;
			hrService.upDateQuery(query);
			
		}
		ArrayList<HashMap<String,String>> monthsList = hrService.getMonthsList();
		model.addAttribute("monthsList", monthsList);
		
		return new ModelAndView("redirect:salrSlab");
	}

	@RequestMapping(value = "/salrSlab")
	public ModelAndView empSalarySlab(ModelMap model) {
		//ArrayList<HashMap<String, String>> empSalslab = hrService.getAllEmpSalrSlab("2017-12-31");
		//model.addAttribute("empSalslab", empSalslab);
		ArrayList<HashMap<String,String>> monthsList = hrService.getMonthsList();
		model.addAttribute("monthsList", monthsList);
		return new ModelAndView("HR/hr/empSalSlab");
	}
	@RequestMapping(value = "/salrSlab1")
	public ModelAndView empSalarySlab1(ModelMap model,@RequestParam String months) {
		ArrayList<HashMap<String, String>> empSalslab = hrService.getAllEmpSalrSlab(months);
		model.addAttribute("empSalslab", empSalslab);
		ArrayList<HashMap<String,String>> monthsList = hrService.getMonthsList();
		model.addAttribute("monthsList", monthsList);
		return new ModelAndView("HR/hr/empSalSlab");
	}

	@RequestMapping(value = "/monthlySalList")
	public ModelAndView monthlyEmpSalaryDetails(ModelMap model) {
		ArrayList<HashMap<String, String>> monthlyEmpSalary = hrService
				.getMonthlyEmpSalary("");
		model.addAttribute("monthlyEmpSalary", monthlyEmpSalary);
		return new ModelAndView("HR/hr/monthlyEmpSalDetails");

	}

	@RequestMapping(value = "/monthlySal", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView monthlyEmpSalaryDetails2(ModelMap model,
			@RequestParam String month) {
		ArrayList<HashMap<String, String>> monthlyEmpSalary = hrService
				.getMonthlyEmpSalary(month);
		model.addAttribute("monthlyEmpSalary", monthlyEmpSalary);
		model.addAttribute("month", month);
		return new ModelAndView("HR/hr/monthlyEmpSalDetails");

	}

	@RequestMapping(value = "/saveEmpPayment")
	public ModelAndView saveEmployeePayment(ModelMap model,
			SalaryCompDTO salComponentDTO) {
		SalaryCompTO salCompTO = new SalaryCompTO();
		salCompTO.setBasicPerc(salComponentDTO.getBasicPerc());
		salCompTO.setEmpName(salComponentDTO.getEmpName());
		salCompTO.setEmpId(salComponentDTO.getEmpId());
		salCompTO.setGross(salComponentDTO.getGross());
		salCompTO.setLateDays(salComponentDTO.getLateDays());
		salCompTO.setPaidDays(salComponentDTO.getPaidDays());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String fromdate1 = salComponentDTO.getPayforMonth();
		try {
			Date date1 = formatter.parse(fromdate1);
			salCompTO.setPayforMonth(date1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		adminService.saveAdmin(salCompTO);
		/*
		 * Integer[] paytypeId = salComponentDTO.getPaytypeId(); Float[] amount
		 * = salComponentDTO.getAmount(); String[] dueDate =
		 * salComponentDTO.getDueDate(); for(int i = 0; i < paytypeId.length ;
		 * i++){ if(amount[i] != null) { EmpPaymentsTO empPayTO = new
		 * EmpPaymentsTO(); empPayTO.setAmount(amount[i]);
		 * empPayTO.setPayTypeId(paytypeId[i]); String fromdate = dueDate[i];
		 * try { Date date = formatter.parse(fromdate);
		 * empPayTO.setDueDate(date); }catch (ParseException e) {
		 * e.printStackTrace(); } empPayTO.setSalCompId(salCompTO.getId());
		 * Calendar cal = Calendar.getInstance();
		 * empPayTO.setPaidDate(cal.getTime());
		 * adminService.saveAdmin(empPayTO); }; }
		 */
		return new ModelAndView("redirect:salrSlab");
	}

	@RequestMapping(value = "/montlyPaySlip")
	public ModelAndView monthlyPaySlip(ModelMap model,
			@RequestParam Integer empId, String month) {
		HashMap<String, String> empMonthlySalSlip = hrService.getEmpMonthlySalSlip(empId, month);
		model.addAttribute("empSalSlip", empMonthlySalSlip);
		ArrayList<HashMap<String, String>> employeeACCDetails = hrService.getEmployeeACCDetails("Employee A/c Info", empId);
		model.addAttribute("employeeACCDetails", employeeACCDetails);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		model.addAttribute("employeeById", employeeById);
		hrService.getEmpRoleById(empId);
		HashMap<String, String> employeeDesignation = hrService
				.getEmployeeDesignation(empId, month);
		model.addAttribute("designation", employeeDesignation);

		return new ModelAndView("HR/hr/monthlyPaySlip");
	}

	@RequestMapping(value = "/saveQuestionnaries")
	public ModelAndView empAccDetails(ModelMap model,
			EmployeeQualificationDTO emplDto) {

		Integer[] qnId = emplDto.getQnId();
		String[] answer = emplDto.getAnswer();
		for (int i = 0; i < qnId.length; i++) {
			if (!answer[i].equalsIgnoreCase("")) {
				QnResponsesTO qnResp = new QnResponsesTO();
				qnResp.setRefId(emplDto.getEmpId());
				qnResp.setQnId(qnId[i]);
				qnResp.setAnswer(answer[i]);
				qnResp.setAttrType(emplDto.getAttrType());
				adminService.saveAdmin(qnResp);
			}
		}
		model.addAttribute("empId", emplDto.getEmpId());
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/block")
	public ModelAndView blockEmployee(ModelMap model,
			@RequestParam Integer empId, String releaveDate, String status,
			String remarks) {

		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		Calendar cal = Calendar.getInstance();
		String remarks1 = employeeById.getRemarks() + " - " + remarks + "( "
				+ status + ") ON " + cal.getTime();
		String query = "UPDATE employee_details SET status = '"
				+ status
				+ "',remarks = '"
				+ remarks1
				+ "' ,isActive = FALSE , update_date = CURRENT_TIMESTAMP WHERE emp_id = '"
				+ empId + "' ";
		hrService.upDateQuery(query);
		String date = null;
		try {
			Date txDate1 = new SimpleDateFormat("dd/MM/yyyy")
					.parse(releaveDate);
			date = new SimpleDateFormat("yyyy-MM-dd").format(txDate1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String query1 = "UPDATE employee_roles SET to_date = '" + date
				+ "' WHERE emp_id = '" + empId
				+ "' AND CURRENT_DATE BETWEEN from_date AND to_date ";
		hrService.upDateQuery(query1);
		model.addAttribute("empId", empId);
		return new ModelAndView("redirect:viewEmployeeById");
	}

	@RequestMapping(value = "/attendance11")
	public ModelAndView viewEmployeeAttendence(ModelMap model,
			@RequestParam Integer empId) {
		Calendar aCalendar = Calendar.getInstance();
		aCalendar.set(Calendar.DATE, 1);
		aCalendar.add(Calendar.DAY_OF_MONTH, -1);
		Date lastDateOfPreviousMonth = aCalendar.getTime();
		aCalendar.set(Calendar.DATE, 1);
		Date firstDateOfPreviousMonth = aCalendar.getTime();
		String firstDate = new SimpleDateFormat("dd/MM/yyyy")
				.format(firstDateOfPreviousMonth);
		String lastDate = new SimpleDateFormat("dd/MM/yyyy")
				.format(lastDateOfPreviousMonth);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		ArrayList<HashMap<String, String>> empAttenance = hrService
				.getEmpAttenance(employeeById.getBiometricId(), firstDate,
						lastDate);
		model.addAttribute("empAttenance", empAttenance);
		model.addAttribute("firstDate", firstDate);
		model.addAttribute("lastDate", lastDate);
		model.addAttribute("employeeById", employeeById);
		return new ModelAndView("HR/hr/empAttendance");
	}

	@RequestMapping(value = "/attendance12")
	public ModelAndView viewEmployeeAttendence12(ModelMap model,
			@RequestParam Integer empId, String firstDate, String lastDate) {

		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		ArrayList<HashMap<String, String>> empAttenance = hrService
				.getEmpAttenance(employeeById.getBiometricId(), firstDate,
						lastDate);
		model.addAttribute("empAttenance", empAttenance);
		model.addAttribute("firstDate", firstDate);
		model.addAttribute("lastDate", lastDate);
		model.addAttribute("employeeById", employeeById);
		return new ModelAndView("HR/hr/empAttendance");
	}

	@RequestMapping(value = "/attendanceUpload", method = RequestMethod.POST)
	public ModelAndView uploadHealthDoc(ModelMap model,
			@RequestParam CommonsMultipartFile file) throws Exception {

		String path = "/home/welezohealth/whms/attendance";

		// String path = "K:/attendance";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();
		} catch (Exception e) {
		}
		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + filename));
		return new ModelAndView("redirect:bio");
	}

	@RequestMapping(value = "/download", method = RequestMethod.GET)
	public void download(HttpServletResponse response,
			@RequestParam String fileName) throws IOException {

		System.out.println(fileName);
		File file = new File(fileName);
		InputStream is = new FileInputStream(file);
		// MIME type of the file
		response.setContentType("application/octet-stream");
		// Response header
		response.setHeader("Content-Disposition", "attachment; filename=\""
				+ file.getName() + "\"");
		// Read from the file and write into the response
		OutputStream os = response.getOutputStream();
		byte[] buffer = new byte[1024];
		int len;
		while ((len = is.read(buffer)) != -1) {
			os.write(buffer, 0, len);
		}
		os.flush();
		os.close();
		is.close();
	}

	@RequestMapping(value = "/ivDocument", method = RequestMethod.POST)
	public ModelAndView uploadInterviewerDoc(ModelMap model,
			@RequestParam("name") String name,
			@RequestParam CommonsMultipartFile file, @RequestParam Integer empId)
			throws Exception {
		String path = "/home/welezohealth/whms/others";
		// String path = "D:\\files\\doc";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();
			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();
		} catch (Exception e) {
			// System.out.println(e);
		}
		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + empId + "_" + name + "_"
				+ filename));
		model.addAttribute("empId", empId);
		return new ModelAndView("redirect:OtherEmployeeDetails");
	}

	@RequestMapping(value = "/userProfile")
	public ModelAndView viewUserProfile(ModelMap model,	@RequestParam Integer userId) {
		HashMap<String, String> employee = hrService.getEmployeeIdFromUserId(userId);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(Integer.parseInt(employee.get("empId")));
		model.addAttribute("employeeById", employeeById);
		EmployeeImagesTO employeeImage = report.getEmployeeImage(employeeById.getEmpId());
		String encode = Base64.encodeBase64String(employeeImage.getEmpImg());
		model.addAttribute("empImge", encode);
		List<EmployeeQualificationDTO> empRoleDesignation = hrService.getEmpRoleDesignation(Integer.parseInt(employee.get("empId")));
		model.addAttribute("empRoleDesignation", empRoleDesignation);

		ArrayList<HashMap<String, String>> employeeACCDetails = hrService
				.getEmployeeACCDetails("Employee A/c Info",
						Integer.parseInt(employee.get("empId")));
		model.addAttribute("employeeACCDetails", employeeACCDetails);

		ArrayList<HashMap<String, String>> salPayMonthsList = hrService.getSalPayMonthsList(Integer.parseInt(employee.get("empId")));
		model.addAttribute("monthList", salPayMonthsList);
		CallsUpload calls = new CallsUpload();
		String path = "/home/welezohealth/whms/hr/";
		ArrayList<HashMap<String, String>> employeeDocuments = calls
				.getEmployeeDocuments(Integer.parseInt(employee.get("empId"))
						+ "_" + employeeById.getEmpName(), path);
		model.addAttribute("documentList", employeeDocuments);

		String leaveQuery = "SELECT req.*, emp.emp_name,emp1.emp_name AS 'report' FROM leave_request req "
				+ " LEFT JOIN employee_details emp ON emp.emp_id = req.emp_id LEFT JOIN employee_roles roles ON roles.emp_id = req.emp_id "
				+ "LEFT JOIN employee_details emp1 ON emp1.emp_id = report_to WHERE CURRENT_DATE BETWEEN roles.from_date AND roles.to_date AND req.emp_id = '"
				+ employee.get("empId") + "' ORDER BY  req.request_id DESC";
		ArrayList<HashMap<String, String>> allLeavesAdmin = hrService
				.getAllLeavesAdmin(leaveQuery);
		model.addAttribute("leavesList", allLeavesAdmin);

		String goalQuery = "SELECT goals.*,emp.emp_name AS 'Set For'  FROM goal_setting goals "
				+ " LEFT JOIN employee_details emp ON emp.emp_id = goals.goal_set_for  "
				+ " WHERE goals.goal_set_for = '" + employee.get("empId") + "'";
		ArrayList<HashMap<String, String>> goalsAdmin = hrService.getGoalsAdmin(goalQuery);
		model.addAttribute("goalsAdmin", goalsAdmin);
		
		ArrayList<HashMap<String, String>> holidaylist= hrService.getallholidaylist();
		model.addAttribute("holiday", holidaylist);

		return new ModelAndView("Admin/user/employeeProfile");
	}

	@RequestMapping(value = "/attendance13")
	public ModelAndView viewEmployeeAttendenceInAdmin(ModelMap model,
			@RequestParam Integer empId) {
		Calendar aCalendar = Calendar.getInstance();
		aCalendar.set(Calendar.DATE, 1);
		aCalendar.add(Calendar.DAY_OF_MONTH, -1);
		Date lastDateOfPreviousMonth = aCalendar.getTime();
		aCalendar.set(Calendar.DATE, 1);
		Date firstDateOfPreviousMonth = aCalendar.getTime();
		String firstDate = new SimpleDateFormat("dd/MM/yyyy")
				.format(firstDateOfPreviousMonth);
		String lastDate = new SimpleDateFormat("dd/MM/yyyy")
				.format(lastDateOfPreviousMonth);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		ArrayList<HashMap<String, String>> empAttenance = hrService
				.getEmpAttenance(employeeById.getBiometricId(), firstDate,
						lastDate);
		model.addAttribute("empAttenance", empAttenance);
		model.addAttribute("firstDate", firstDate);
		model.addAttribute("lastDate", lastDate);
		model.addAttribute("employeeById", employeeById);
		return new ModelAndView("Admin/user/employeeAttendance");
	}

	@RequestMapping(value = "/attendance14")
	public ModelAndView viewEmployeeAttendenceInAdmin12(ModelMap model,
			@RequestParam Integer empId, String firstDate, String lastDate) {

		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		ArrayList<HashMap<String, String>> empAttenance = hrService
				.getEmpAttenance(employeeById.getBiometricId(), firstDate,
						lastDate);
		model.addAttribute("empAttenance", empAttenance);
		model.addAttribute("firstDate", firstDate);
		model.addAttribute("lastDate", lastDate);
		model.addAttribute("employeeById", employeeById);
		return new ModelAndView("Admin/user/employeeAttendance");
	}

	@RequestMapping(value = "/autoPaySlip")
	public ModelAndView monthlyPaySlipInAdmin(ModelMap model,
			@RequestParam Integer empId, String month) {

		HashMap<String, String> empMonthlySalSlip = hrService
				.getEmpMonthlySalSlip(empId, month);
		model.addAttribute("empSalSlip", empMonthlySalSlip);
		ArrayList<HashMap<String, String>> employeeACCDetails = hrService
				.getEmployeeACCDetails("Employee A/c Info", empId);
		model.addAttribute("employeeACCDetails", employeeACCDetails);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		model.addAttribute("employeeById", employeeById);
		hrService.getEmpRoleById(empId);
		HashMap<String, String> employeeDesignation = hrService
				.getEmployeeDesignation(empId, month);
		model.addAttribute("designation", employeeDesignation);
		return new ModelAndView("Admin/user/empPaySlip");
	}

	@RequestMapping(value = "/saveInterviewFeedback", method = RequestMethod.POST)
	public ModelAndView saveCusomerFeedback(ModelMap model, Integer[] qnId,
			String[] answer, Integer candidateId) {

		for (int i = 0; i < qnId.length; i++) {
			if (!answer[i].equalsIgnoreCase("")) {
				QnResponsesTO qnResp = new QnResponsesTO();
				qnResp.setRefId(candidateId);
				qnResp.setQnId(qnId[i]);
				qnResp.setAnswer(answer[i]);
				qnResp.setAttrType("Interview Feedback");
				adminService.saveAdmin(qnResp);
			}
		}
		model.addAttribute("empId", candidateId);
		return new ModelAndView("redirect:OtherEmployeeDetails");
	}

	@RequestMapping(value = "/candidateSalSlab")
	public ModelAndView saveCandidateRoleSalTab(ModelMap model,
			@RequestParam Integer candidateId, Integer roleId, Integer SalSlab,
			String joinDate) {
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");

		try {
			date = formatter.format(sdf.parse(joinDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String slabUpdate = "UPDATE recruitment SET slab_id = '" + SalSlab
				+ "', joining_date = '" + date + "',role_id = '" + roleId
				+ "' WHERE candidate_id ='" + candidateId + "'";
		hrService.upDateQuery(slabUpdate);
		model.addAttribute("empId", candidateId);

		return new ModelAndView("redirect:OtherEmployeeDetails");
	}

	@RequestMapping(value = "/addEmployeeDTOWelezo")
	public ModelAndView saveEmployeeFromRecruitment(ModelMap model,
			@RequestParam Integer candidateId) {

		String employee = "INSERT INTO employee_details(emp_name, dob, gender, personal_contact , personal_email, permanent_address, remarks,STATUS,update_date,isActive)"
				+ " (SELECT NAME, dob, gender, contact_number, email, address, remarks, 'Joined',CURRENT_TIMESTAMP ,TRUE FROM recruitment WHERE candidate_id = '"
				+ candidateId + "')";
		hrService.upDateQuery(employee);

		String recruitment = "UPDATE recruitment SET interview_status = 'Joined' WHERE candidate_id = '"
				+ candidateId + "'";
		hrService.upDateQuery(recruitment);

		return new ModelAndView("redirect:recuirmentlist");
	}

	@RequestMapping(value = "/generateQrCode")
	public ModelAndView QRCodeGenerator(ModelMap model, Integer empId,
			String empName) {

		String qrCodeData = "https://www.whms.welezohealth.com/employeedetailsInWeb?empId="+ empId;
		String filePath = "/home/welezohealth/whms/hr/" + empId + "_" + empName+ "_QR.png";
		// System.out.println(filePath);
		String charset = "UTF-8"; // or "ISO-8859-1"
		Map hintMap = new HashMap();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);

		BitMatrix matrix = null;
		try {
			matrix = new MultiFormatWriter().encode(
					new String(qrCodeData.getBytes(charset), charset),
					BarcodeFormat.QR_CODE, 200, 200, hintMap);
		} catch (UnsupportedEncodingException | WriterException e) {
			e.printStackTrace();
		}
		System.out.println("QR Code image created successfully!");
		try {
			MatrixToImageWriter.writeToFile(matrix,
					filePath.substring(filePath.lastIndexOf('.') + 1),
					new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}

		model.addAttribute("empId", empId);

		return new ModelAndView("redirect:viewEmployeeById");
	}
	@RequestMapping(value = "/employeedetailsInWeb")
	public ModelAndView employeedetailsInWeb1(ModelMap model,@RequestParam Integer empId) {
		
		model.addAttribute("empId", empId);
		return new ModelAndView("redirect:employeedetailsInWeb1");
	
	}
	@RequestMapping(value = "/employeedetailsInWeb1",method = { RequestMethod.GET,	RequestMethod.POST })
	public ModelAndView employeedetailsInWeb(ModelMap model,@RequestParam Integer empId) {

		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(empId);
		model.addAttribute("employeeById", employeeById);
		EmployeeImagesTO employeeImage = report.getEmployeeImage(empId);
		String encode = Base64.encodeBase64String(employeeImage.getEmpImg());
		model.addAttribute("empImge", encode);

		return new ModelAndView("HR/hr/employeeDetailsThruQr");
	}
	
	public void employeeDailyAttendance() {
		query = null;
		 Calendar now = Calendar.getInstance();
		  //  System.out.println("Current date : " + (now.get(Calendar.MONTH) + 1)+ "-"+ now.get(Calendar.DATE)+ "-"+ now.get(Calendar.YEAR));
		    //create an array of days
		    String[] strDays = new String[]{"SUNDAY","MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY"};
		    
		    //Day_OF_WEEK starts from 1 while array index starts from 0      
		 //   System.out.println("Current day is : " + strDays[now.get(Calendar.DAY_OF_WEEK) - 1]);
		   String day = strDays[now.get(Calendar.DAY_OF_WEEK) - 1];
		if( day == "SUNDAY"){
			
			 query = "INSERT IGNORE INTO emp_daily(emp_id, work_date, work_quantum, late_coming, att_mark) "
			 		+ " (SELECT emp_id, CURRENT_DATE , 1, 0, 'WO' FROM employee_details WHERE STATUS IN ('Joined') )";
		}
		else{
			
			 query = "INSERT IGNORE INTO emp_daily(emp_id, work_date, work_quantum, late_coming, att_mark) "
					+ "(SELECT emp_id, CURRENT_DATE , 1, 0, 'P' FROM employee_details WHERE STATUS IN ('Joined') )";
		}
		hrService.upDateQuery(query);
	
	}
}
