package com.welezo.whms.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.service.HRService;

@Controller
public class MeetingManagementController {

	@Autowired
	HRService hrService;
	@Autowired
	ReportController report;

	@RequestMapping(value = "/viewMeeting")
	public ModelAndView viewMeeting(ModelMap model, @RequestParam Integer userId) {

		HashMap<String, String> employee = hrService.getEmployeeIdFromUserId(userId);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(Integer.parseInt(employee.get("empId")));
		model.addAttribute("employeeById", employeeById);

		List<EmployeeDetailsDTO> allEmployees = hrService.getAllEmployees("emp.status = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		ArrayList<HashMap<String, String>> meetingAssignee = hrService.getMeetingDetails("Assigne", employeeById.getEmpId());
		model.addAttribute("meetingAssignee", meetingAssignee);

		ArrayList<HashMap<String, String>> meetingAttendee = hrService.getMeetingDetails("Attendee", employeeById.getEmpId());
		model.addAttribute("meetingAttendee", meetingAttendee);

		return new ModelAndView("Admin/meetingManagement/viewMom");
	}

	@RequestMapping(value = "/saveMeeting", method = RequestMethod.POST)
	public ModelAndView saveMeeting(ModelMap model, @RequestParam String mName,
			String mDescription, String mDate, String mTime, String mType,
			String[] attendeeId, String duration, String place, Integer hostId) {

		HashMap<String, String> employee = hrService.getEmployeeIdFromUserId(hostId);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(Integer.parseInt(employee.get("empId")));
		model.addAttribute("employeeById", employeeById);

		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(mDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String meetingQuery = "INSERT INTO meetings(m_name,m_description,m_type,m_date,m_time,duration,place,isInternal)"
				+ " VALUES('"
				+ mName
				+ "','"
				+ mDescription
				+ "','"
				+ mType
				+ "','"
				+ date
				+ "','"
				+ mTime
				+ "','"
				+ duration
				+ "','"
				+ place + "',TRUE)";
		hrService.upDateQuery(meetingQuery);

		for (int i = 0; i < attendeeId.length; i++) {
			System.out.println("atendees list " + attendeeId[i]);
			String attendeesQuery = "INSERT INTO meeting_attendees(attendee_id,isHost,attended,meeting_id)VALUES('"
					+ attendeeId[i]
					+ "','"
					+ hostId
					+ "',TRUE,"
					+ " (SELECT meeting_id FROM meetings WHERE m_name='"
					+ mName
					+ "' AND m_date='"
					+ date
					+ "' AND m_description ='" + mDescription + "' LIMIT 1))";
			hrService.upDateQuery(attendeesQuery);
		}

		model.addAttribute("userId", hostId);
		return new ModelAndView("redirect:viewMeeting");
	}

	@RequestMapping(value = "/viewMeetingById")
	public ModelAndView viewMeetingById(ModelMap model,
			@RequestParam Integer id, Integer meetingId) {

		String query = "UPDATE meeting_attendees SET view_notification = 0 WHERE id = '"+ id + "'";
		hrService.upDateQuery(query);

		HashMap<String, String> meetingById = hrService.getMeetingById(id);
		model.addAttribute("meetingById", meetingById);

		String meetingAttendees = report.getMeetingAttendees(meetingId);
		model.addAttribute("meetingAttendees", meetingAttendees);
		
		ArrayList<HashMap<String,String>> momList = hrService.getMOMList(meetingId);
		model.addAttribute("momList", momList);
		return new ModelAndView("Admin/meetingManagement/viewMeetingById");
	}
	@RequestMapping(value = "/viewAssignedById")
	public ModelAndView viewMeetingAssignedById(ModelMap model,	@RequestParam Integer id, Integer meetingId) {

		HashMap<String, String> meetingById = hrService.getMeetingAssignedById(meetingId);
		model.addAttribute("meetingById", meetingById);

		String meetingAttendees = report.getMeetingAttendees(meetingId);
		model.addAttribute("meetingAttendees", meetingAttendees);
		
		ArrayList<HashMap<String,String>> momList = hrService.getMOMList(meetingId);
		model.addAttribute("momList", momList);
		return new ModelAndView("Admin/meetingManagement/viewMeetingById");
	}
	

	@RequestMapping(value = "/enterMOM")
	public ModelAndView enterMOM(ModelMap model, @RequestParam Integer id) {

		HashMap<String, String> meetingById = hrService.getMeetingById(id);
		model.addAttribute("meetingById", meetingById);
		return new ModelAndView("Admin/meetingManagement/addMOM");
	}

	@RequestMapping(value = "/saveMOM")
	public ModelAndView saveMOM(ModelMap model,
			@RequestParam Integer meetingId, String minutesOfMeeting,String actionItems, Integer createdBy) {

		HashMap<String, String> employeeId = hrService.getEmployeeIdFromUserId(createdBy);

		String query = "INSERT INTO minutes_of_meeting(meeting_id,minutesOfMeeting,actionItems,createdBy,createdTime)"
				+ " VALUES('"
				+ meetingId
				+ "','"
				+ minutesOfMeeting
				+ "','"
				+ actionItems
				+ "','"
				+ employeeId.get("empId")
				+ "',CURRENT_TIMESTAMP)";
		hrService.upDateQuery(query);

		return new ModelAndView("Admin/meetingManagement/viewMeetingById");
	}

}
