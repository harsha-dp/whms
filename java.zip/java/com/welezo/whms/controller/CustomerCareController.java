package com.welezo.whms.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import net.sourceforge.tess4j.TesseractException;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.OcrReader;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.CustomerFamilyDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.dto.InteractionRegisterDTO;
import com.welezo.whms.dto.ProductOffersDTO;
import com.welezo.whms.dto.ServicesDTO;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.CallRecordsService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.CustomerFamilyTO;
import com.welezo.whms.to.EmpanellmentTO;
import com.welezo.whms.to.HealthAppointmentTO;
import com.welezo.whms.to.HospitalDetailsTO;
import com.welezo.whms.to.InteractionRegisterTO;
import com.welezo.whms.to.InventoryTO;
import com.welezo.whms.to.ItemMasterTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.QnResponsesTO;
import com.welezo.whms.to.RoleMasterTO;
import com.welezo.whms.to.ServicesTO;
import com.welezo.whms.to.TransactionMasterTO;
import com.welezo.whms.to.VendorsTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Controller
public class CustomerCareController {

	@Autowired
	AdminService adminService;

	@Autowired
	CallRecordsService callrecordservice;
	@Autowired
	UserService userService;
	@Autowired
	HRService hrService;
	@Autowired
	ReportController report;
	@Autowired
	HealthAppointmentController healthAppt;

	/*---start appointment form From here---------	 */
	@RequestMapping(value = "/serviceBaseAppointment")
	public ModelAndView serviceBaseAppointment(
			@RequestParam Integer transactionId, ModelMap model) {
		TransactionMasterTO txById = adminService.getTxById(transactionId);
		try {
			CustomerDeatilsTO custerDetails = adminService
					.getCustomerDetail(txById.getCustomerDeatils()
							.getCustomerId());
			model.addAttribute("custerDetails", custerDetails);
			List<CustomerFamilyDTO> family = adminService
					.getFamily(custerDetails.getCustomerId());
			model.addAttribute("custfamily", family);
		} catch (Exception e) {
			e.printStackTrace();
		}
		ProductMasterTO productdetails = adminService.getproductById(txById
				.getProductMaster().getProductId());
		model.addAttribute("txById", txById);

		model.addAttribute("productdetails", productdetails);

		EmployeeDetailsDTO csrName = hrService.getEmployeeById(txById.getCsr());
		model.addAttribute("csr", csrName.getEmpName());

		EmployeeDetailsDTO executiveName = hrService.getEmployeeById(txById.getExecutive());
		model.addAttribute("executive", executiveName.getEmpName());

		ChannelsTO channelName = adminService.getChannelName(txById
				.getChannel());
		model.addAttribute("channelName", channelName.getChannelsName());

		List<ProductOffersDTO> allProductSevice = adminService
				.getAllProductSevice(txById.getProductMaster().getProductId());
		List<ServicesDTO> ProductOffersDTO1 = new ArrayList<>();
		for (ProductOffersDTO service : allProductSevice) {
			ServicesTO allServices = adminService.getAllServices(service
					.getServicesId());
			ServicesDTO servicesDTO = new ServicesDTO();
			servicesDTO.setServiceId(allServices.getServiceId());
			servicesDTO.setCategory(allServices.getCategory());
			servicesDTO.setServiceName(allServices.getServiceName());
			servicesDTO.setQuantity(service.getQuantity());
			ProductOffersDTO1.add(servicesDTO);
		}
		model.addAttribute("services", ProductOffersDTO1);

		/*
		 * List<EmployeeDTO> allEmployeeDetails =
		 * adminService.getAllEmployeeDetails();
		 * model.addAttribute("allEmployeeDetails", allEmployeeDetails);
		 */

		/*
		 * List<HospitalServiceDTO> serviceBaseHospital =
		 * report.getServiceBaseHospital();
		 * model.addAttribute("serviceBaseHospital", serviceBaseHospital);
		 */

		List<HealthAppointmentDTO> serviceUtilizationByTxOffer = healthAppt.getServiceUtilizationByTxOffer(txById.getTransactionId());
		model.addAttribute("serviceUtilizationByTxOffer",serviceUtilizationByTxOffer);
		HealthAppointmentDTO appointmentDTO = new HealthAppointmentDTO();

		ArrayList<HashMap<String, String>> cityList = report.getCityList();
		model.addAttribute("cityList", cityList);

		return new ModelAndView("Admin/appointment/serviceBaseAppointment",
				"appointmentDTO", appointmentDTO);
	}

	@RequestMapping(value = "/checkServiceAvailable")
	public ModelAndView checkServiceAvailabe(ModelMap model,
			@ModelAttribute HealthAppointmentDTO appt) {

		ArrayList<HashMap<String, String>> allAvailableHospitalList = report.getAllAvailableHospitalList(appt.getAppointmentDate(),
						appt.getAppointmentDate(), appt.getServiceId(),
						appt.getServiceName());
		model.addAttribute("appointmentList", allAvailableHospitalList);
		model.addAttribute("fromDate", appt.getAppointmentDate());
		model.addAttribute("toDate", appt.getAppointmentDate());
		ServicesTO allServices = adminService.getAllServices(appt
				.getServiceId());
		model.addAttribute("allServices", allServices);
		model.addAttribute("City", appt.getServiceName());

		try {
			CustomerDeatilsTO custerDetails = adminService
					.getCustomerDetail(appt.getCustomerId());
			model.addAttribute("custerDetails", custerDetails);
			CustomerFamilyTO familyId = adminService.getFamilyId(appt
					.getFamilyId());
			model.addAttribute("familyId", familyId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("transactionId", appt.getTransactionId());
		return new ModelAndView("Admin/appointment/bookAppointment");
	}

	@RequestMapping(value = "/saveAppointment")
	public ModelAndView saveAppointment(ModelMap map,
			@RequestParam Integer hospitalId, String apptDate,
			Integer customerId, String timeSlot, Integer familyId,
			Integer serviceId, Integer transactionId, Integer bookedBy) {
		HospitalDetailsTO hospDetailsTO = new HospitalDetailsTO();
		hospDetailsTO.setHospitalId(hospitalId);
		ServicesTO servicesTO = new ServicesTO();
		servicesTO.setServiceId(serviceId);
		CustomerDeatilsTO custDetailsTO = new CustomerDeatilsTO();
		custDetailsTO.setCustomerId(customerId);
		CustomerFamilyTO FamilyTO = new CustomerFamilyTO();
		FamilyTO.setFamilyId(familyId);

		// adminService.get
		TransactionMasterTO masterTO = new TransactionMasterTO();
		masterTO.setTransactionId(transactionId);

		HealthAppointmentTO HealthAppointmentTO = new HealthAppointmentTO();

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format = (apptDate);
		try {
			Date date2 = formatter.parse(format);
			HealthAppointmentTO.setAppointmentDate(date2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		HealthAppointmentTO.setAppointmentTime(timeSlot);

		// Inserting value to database
		HealthAppointmentTO.setCustomerDeatils(custDetailsTO);
		HealthAppointmentTO.setServices(servicesTO);
		HealthAppointmentTO.setHospitalDetails(hospDetailsTO);
		HealthAppointmentTO.setFamilyId(FamilyTO.getFamilyId());
		HealthAppointmentTO.setTransactionMaster(masterTO);
		Calendar cal = Calendar.getInstance();
		HealthAppointmentTO.setBookedDate(cal.getTime());
		HealthAppointmentTO.setBookedBy(bookedBy);
		HealthAppointmentTO.setStatusAppointment("New");
		HealthAppointmentTO.setRemarks("New Appointment");
		HealthAppointmentTO.setSource("CUSTOMERCARE");
		adminService.saveAdmin(HealthAppointmentTO);

		healthAppt.addHealthAppt(transactionId, serviceId,
				HealthAppointmentTO.getAppointmentId());

		//sending health appointment sms details to customer
	/*	HashMap<String,String> smsTemplates = userService.getSMSTemplates("Health Appointment");
		
		 List<AddressDTO> addressEntityId = adminService.getAddressEntityId(customerId);
		 CustomerDeatilsTO customerDetail = adminService.getCustomerDetail(customerId);
			String url = "https://www.welezohealth.com/Customer/view_appointment/"+HealthAppointmentTO.getAppointmentId();
			
			ServicesTO allServices = adminService.getAllServices(2);
			String encode = smsTemplates.get("body");
			encode = encode.replaceAll("#service", allServices.getServiceName());
			System.out.println(encode);
			encode = encode.replaceAll("#date", apptDate);
			encode = encode.replaceAll("#time", timeSlot);
			 
			System.out.println(encode);
		 for (AddressDTO addressDTO : addressEntityId) {
			if(!addressDTO.getPrimaryMob().equalsIgnoreCase(null)){
				
				SMSNotifoication sms = new SMSNotifoication();
				String sendTextMessage = sms.sendTextMessage("9164074183",customerDetail.getCustomerName(),smsTemplates,url,encode);
				hrService.upDateQuery(sendTextMessage);
			} 
			else{
				SMSNotifoication sms = new SMSNotifoication();
				String sendTextMessage = sms.sendTextMessage(addressDTO.getAltMob(),customerDetail.getCustomerName(),smsTemplates,url,encode);
				hrService.upDateQuery(sendTextMessage);
			}
			
		}*/
		 
		
		map.addAttribute("appointmentId",HealthAppointmentTO.getAppointmentId());
		return new ModelAndView("redirect:viewappointment");
	}

	@RequestMapping(value = "/vocherSoftCopy")
	public ModelAndView eVoucherScannedCopy(ModelMap model,
			Integer appointmentId) {
		System.out.println(appointmentId);
		HashMap<String, String> eVocherData = report
				.getEVocherData(appointmentId);
		model.addAttribute("eVocherData", eVocherData);
		return new ModelAndView("Admin/appointment/sendVoucher");
	}

	@RequestMapping(value = "/viewappointment")
	public ModelAndView viewappointment(ModelMap model) {
		HealthAppointmentDTO healthAppointmentDTO = new HealthAppointmentDTO();

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		// cal.add(Calendar.DATE, -15);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		healthAppointmentDTO.setAppointmentDate(dateFormat.format(todate1));
		healthAppointmentDTO.setAppointmentTime(dateFormat.format(date));
		healthAppointmentDTO.setStatusAppointment("");
		healthAppointmentDTO.setServiceName("");
		try {
			List<HealthAppointmentDTO> allAppointments = adminService
					.getAllAppointments(healthAppointmentDTO);
			model.addAttribute("appointment", allAppointments);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<HashMap<String, String>> allservice = adminService.getAllservice();
		model.addAttribute("allservice", allservice);

		return new ModelAndView("Admin/appointment/viewappointment",
				"healthAppointmentDTO", healthAppointmentDTO);
	}
	@RequestMapping(value = "/viewappointmentList")
	public ModelAndView viewappointmentList(ModelMap model,@RequestParam String fromDate,String toDate) {
		HealthAppointmentDTO healthAppointmentDTO = new HealthAppointmentDTO();
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
		String ds1 = null;
		String ds2 = null;
		try{
			ds1 = sdf2.format(sdf1.parse(fromDate));
		 ds2 = sdf2.format(sdf1.parse(toDate));
		}catch(Exception e){}
	
		model.addAttribute("fromDate", ds1);
		model.addAttribute("toDate", ds2);
		healthAppointmentDTO.setAppointmentDate(ds1);
		healthAppointmentDTO.setAppointmentTime(ds2);
		healthAppointmentDTO.setStatusAppointment("");
		healthAppointmentDTO.setServiceName("");
		try {
			List<HealthAppointmentDTO> allAppointments = adminService.getAllAppointments(healthAppointmentDTO);
			model.addAttribute("appointment", allAppointments);
		} catch (Exception e) {
			e.printStackTrace();
		}
		 ArrayList<HashMap<String, String>> allservice = adminService.getAllservice();
		model.addAttribute("allservice", allservice);

		return new ModelAndView("Admin/appointment/viewappointment","healthAppointmentDTO", healthAppointmentDTO);
	}

	@RequestMapping(value = "/viewappointments", method = RequestMethod.POST)
	public ModelAndView viewappointment2(ModelMap model,
			HealthAppointmentDTO healthAppointmentDTO) {
		try {
			List<HealthAppointmentDTO> allAppointments = adminService
					.getAllAppointments(healthAppointmentDTO);
			model.addAttribute("appointment", allAppointments);
		} catch (Exception e) {
			e.printStackTrace();
		}
		 ArrayList<HashMap<String, String>> allservice = adminService.getAllservice();
		model.addAttribute("allservice", allservice);
		return new ModelAndView("Admin/appointment/viewappointment",
				"healthAppointmentDTO", healthAppointmentDTO);
	}

	@RequestMapping(value = "/editAppointment")
	public ModelAndView editAppointments(@RequestParam Integer appointmentId,
			ModelMap model) {
		HealthAppointmentDTO appointmentDTO = new HealthAppointmentDTO();
		HealthAppointmentTO appointmentById = adminService
				.getAppointmentById(appointmentId);
		model.addAttribute("appointmentById", appointmentById);
		String appointment = null;
		if (appointmentById.getAppointmentDate() != null) {
			appointment = new SimpleDateFormat("dd/MM/yyyy")
					.format(appointmentById.getAppointmentDate());
		}
		model.addAttribute("appointment", appointment);

		ServicesTO services = adminService.getAllServices(appointmentById
				.getServices().getServiceId());
		model.addAttribute("allServicesById", services);

		EmpanellmentTO hospitalById = adminService
				.getHospitalById(appointmentById.getHospitalDetails()
						.getHospitalId());
		model.addAttribute("hospitalById", hospitalById);

		CustomerDeatilsTO customerDetail = adminService
				.getCustomerDetail(appointmentById.getCustomerDeatils()
						.getCustomerId());
		model.addAttribute("custDetails", customerDetail);
		try {
			CustomerFamilyTO familyId = adminService
					.getFamilyId(appointmentById.getFamilyId());
			model.addAttribute("family", familyId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		List<WelezoConstantsTO> welezoConstant = adminService.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);

		List<WelezoConstantsTO> welezoWorkFlow = report.getWelezoWorkFlow("Health_appt_status");
		model.addAttribute("welezoWorkFlow", welezoWorkFlow);
		return new ModelAndView("Admin/appointment/editAppointment",
				"appointmentDTO", appointmentDTO);
	}

	@RequestMapping(value = "/postEditAppointment")
	public ModelAndView editPostAppointment(ModelMap map,
			@ModelAttribute HealthAppointmentDTO appointmentDTO) {

		HealthAppointmentTO appId1 = adminService
				.getAppointmentById(appointmentDTO.getAppointmentId());
		HealthAppointmentTO HealthAppointmentTO = new HealthAppointmentTO();
		HealthAppointmentTO.setAppointmentId(appointmentDTO.getAppointmentId());

		TransactionMasterTO tx = new TransactionMasterTO();
		tx.setTransactionId(appId1.getTransactionMaster().getTransactionId());
		HealthAppointmentTO.setTransactionMaster(tx);

		ServicesTO servicesTO = new ServicesTO();
		servicesTO.setServiceId(appId1.getServices().getServiceId());
		HealthAppointmentTO.setServices(servicesTO);

		HospitalDetailsTO detailsTO = new HospitalDetailsTO();
		detailsTO.setHospitalId(appId1.getHospitalDetails().getHospitalId());
		HealthAppointmentTO.setHospitalDetails(detailsTO);

		CustomerDeatilsTO customerDeatilsTO = new CustomerDeatilsTO();
		customerDeatilsTO.setCustomerId(appId1.getCustomerDeatils()
				.getCustomerId());
		HealthAppointmentTO.setCustomerDeatils(customerDeatilsTO);
		HealthAppointmentTO.setFamilyId(appointmentDTO.getFamilyId());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format1 = appointmentDTO.getAppointmentDate();
		try {
			Date date3 = formatter.parse(format1);
			HealthAppointmentTO.setAppointmentDate(date3);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		HealthAppointmentTO.setAppointmentTime(appointmentDTO
				.getAppointmentTime());
		HealthAppointmentTO.setStatusAppointment(appointmentDTO
				.getStatusAppointment());

		Calendar cal = Calendar.getInstance();
		HealthAppointmentTO.setBookedDate(appId1.getBookedDate());
		HealthAppointmentTO.setBookedBy(appId1.getBookedBy());
		HealthAppointmentTO.setUpdatedBy(appointmentDTO.getBookedBy());
		HealthAppointmentTO.setUpdatedDate(cal.getTime());
		UsermasterDTO userById = userService.getUserById(appointmentDTO
				.getBookedBy());
		HealthAppointmentTO.setRemarks(appId1.getRemarks() + "\n-"
				+ userById.getUserName() + " on " + cal.getTime() + ", "
				+ appointmentDTO.getRemarks() + " ");
		HealthAppointmentTO.setSource(appId1.getSource());
		adminService.upDateAdmin(HealthAppointmentTO);
		String status = appointmentDTO.getStatusAppointment();

		if (status.equals("Cancelled") || status.equals("Rescheduled")
				|| status.equals("Missed")) {
			healthAppt.cancelHealthAppt(appointmentDTO.getAppointmentId());

		}
		/*if(status.equals("Availed")){
			map.addAttribute("appointmentId", appointmentDTO.getAppointmentId());
			return new ModelAndView("redirect:customerFeedBack");
		}*/
		map.addAttribute("appointmentId", appointmentDTO.getAppointmentId());
		return new ModelAndView("redirect:viewappointment");
	}

	@RequestMapping(value = "/viewAppointmentsById")
	public ModelAndView viewAppointmentById(
			@RequestParam Integer appointmentId, ModelMap model) {
		HealthAppointmentDTO appointmentDTO = new HealthAppointmentDTO();

		HealthAppointmentTO appointmentById = adminService.getAppointmentById(appointmentId);
		ServicesTO services = adminService.getAllServices(appointmentById.getServices().getServiceId());
		EmpanellmentTO hospitalById = adminService.getHospitalById(appointmentById.getHospitalDetails()
						.getHospitalId());
		CustomerDeatilsTO customerDetail = adminService.getCustomerDetail(appointmentById.getCustomerDeatils()
						.getCustomerId());
		List<AddressDTO> addressEntityId = adminService.getAddressEntityId(appointmentById.getCustomerDeatils()
						.getCustomerId());
		model.addAttribute("addressEntityId", addressEntityId);

		model.addAttribute("hospitalById", hospitalById);
		model.addAttribute("custDetails", customerDetail);
		model.addAttribute("appointmentById", appointmentById);
		model.addAttribute("allServicesById", services);

		HashMap<String, String> healthAppointmnetFBRating = adminService.getCustomerFBById(appointmentId);
		model.addAttribute("custsatRateList", healthAppointmnetFBRating);
	
		ArrayList<HashMap<String,String>> questionBank = hrService.getQuestionBank("Customer Feedback");
		model.addAttribute("questionBank", questionBank);
		ArrayList<HashMap<String, String>> customerReports = healthAppt.getCustomerReports(appointmentId + "_");
		model.addAttribute("customerReports", customerReports);
		
		ArrayList<HashMap<String, String>> editCSatData = adminService.getCSatListforEdit(appointmentId);
		model.addAttribute("editCSatData", editCSatData);
		return new ModelAndView("Admin/appointment/viewAppointmentsById",
				"leadsDTO", appointmentDTO);
	}

	/* ============End Of Appointment form here=================== */

	@RequestMapping(value = "saveInterAction")
	public ModelAndView saveInterAction(ModelMap model,
			InteractionRegisterTO interactionRegisterTO) {
		Calendar cal = Calendar.getInstance();
		interactionRegisterTO.setInteractionDate(cal.getTime());
		interactionRegisterTO.setStatus("Open");
		interactionRegisterTO.setRemarks("NA");
		adminService.saveAdmin(interactionRegisterTO);
		return new ModelAndView("redirect:customercare");
	}

	@RequestMapping(value = "customercare")
	public ModelAndView customerCareDashBoard(ModelMap model) {

		InteractionRegisterDTO customerCareDasHBoardCount = report.getCustomerCareInteractionCount();
		model.addAttribute("dashBoardCount", customerCareDasHBoardCount);
		InteractionRegisterDTO customerCount = report.getCustomerCount();
		model.addAttribute("customerCount", customerCount);
		InteractionRegisterDTO hospitalCount = report.getHospitalCount();
		model.addAttribute("hospitalCount", hospitalCount);
		InteractionRegisterDTO healthApptCount = report.getHealthApptCount();
		model.addAttribute("healthApptCount", healthApptCount);

		String healthNewApptCount = report.getHealthNewApptCount();
		model.addAttribute("newApptCount", healthNewApptCount);
		
		HashMap<String,String> totalHealthAppointment = report.getTotalHealthAppointment();
		model.addAttribute("totalHealthAppointment", totalHealthAppointment);
		
		HashMap<String, String> totalPreEmployment = report.getNotification("SELECT COUNT(1) AS 'Total' FROM welezohe_corp.pre_employment WHERE STATUS NOT IN ('Missed')");
		model.addAttribute("totalPreEmployment", totalPreEmployment);
		
		HashMap<String, String> newPreEmpAppointment = report.getNotification("SELECT COUNT(1) AS 'Total' FROM welezohe_corp.pre_employment WHERE STATUS IN ('In Progress')");
		model.addAttribute("newPreEmpAppointment", newPreEmpAppointment);
		
		HashMap<String, String> vocuherPending = report.getNotification("SELECT COUNT(1) AS 'Total' FROM health_appointment WHERE status_appointment IN('Availed')");
		model.addAttribute("vocuherPending", vocuherPending);
		
		HashMap<String, String> feedBackPending = report.getNotification("SELECT COUNT(1) AS 'Total' FROM health_appointment WHERE status_appointment IN('Feed Back')");
		model.addAttribute("feedBackPending", feedBackPending);
		
		
		/*
		 * String addHealthAppt = report.addHealthAppt(12, 13, 43);
		 * System.out.println("=============== "+addHealthAppt);
		 */
	//	return new ModelAndView("Admin/appointment/customercare-dashboard");
		
		
		return new ModelAndView("Admin/dashboards/ccDashboards");
	}

	@RequestMapping(value = "editInteraction")
	public ModelAndView editInterActionMode(ModelMap model,
			Integer interactionId) {

		InteractionRegisterTO interActionTO = new InteractionRegisterTO();
		InteractionRegisterDTO interactionById = report
				.getInteractionById(interactionId);
		model.addAttribute("interactionById", interactionById);
		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		return new ModelAndView("Admin/appointment/editInteraction",
				"interActionTO", interActionTO);
	}

	@RequestMapping(value = "saveeditInterAction")
	public ModelAndView postEditInterAction(ModelMap model,
			InteractionRegisterTO interactionRegisterTO) {
		Calendar cal = Calendar.getInstance();
		UsermasterDTO userById = userService.getUserById(interactionRegisterTO
				.getInteractionBy());
		InteractionRegisterDTO interactionById = report
				.getInteractionById(interactionRegisterTO.getInteractionId());
		interactionRegisterTO.setRemarks(interactionById.getRemarks() + " - "
				+ userById.getUserName() + " ON " + cal.getTime() + " - "
				+ interactionRegisterTO.getRemarks());
		interactionRegisterTO.setInteractionBy(interactionById
				.getInteractionBy());
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss.S");
		try {
			Date date = dateFormat.parse(interactionById.getInteractionDate());
			interactionRegisterTO.setInteractionDate((date));
		} catch (Exception e) {
			e.printStackTrace();
		}
		adminService.upDateAdmin(interactionRegisterTO);
		return new ModelAndView("redirect:viewinteraction");
	}
/*
	@RequestMapping(value = "newcalldata")
	public ModelAndView newInterAction(ModelMap model) {
		IncomingCallRecordsTO callData = new IncomingCallRecordsTO();
		return new ModelAndView("Admin/appointment/newInteraction",
				"callRecordsTO", callData);
	}*/

	@RequestMapping(value = "savevocherNo")
	public ModelAndView saveVoucher(ModelMap model,
			HealthAppointmentDTO healthAppointmentDTO) {

		report.updateVoucherNumber(healthAppointmentDTO);
		model.addAttribute("appointmentId",
				healthAppointmentDTO.getAppointmentId());
		return new ModelAndView("redirect:viewAppointmentsById");
	}

	/* -----------------------from here start inventory module------------------ */
	/*@RequestMapping(value = "viewIteamsList")
	public ModelAndView addmaster(ModelMap model) {
		ItemMasterTO master = new ItemMasterTO();
		List<ItemMasterTO> itemMaster = adminService.getItemMaster();
		model.addAttribute("itemMaster", itemMaster);

		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("department", allDepartment);
		return new ModelAndView("Admin/Inventory/itemList", "master", master);
	}
*/
	/*@RequestMapping(value = "/savemaster", method = RequestMethod.POST)
	public ModelAndView saveItemmaster(ModelMap model,
			@ModelAttribute ItemMasterTO itemMasterTO) {
		adminService.saveAdmin(itemMasterTO);

		return new ModelAndView("redirect:viewIteamsList");
	}

	@RequestMapping(value = "vendorsList")
	public ModelAndView addams(ModelMap model) {
		VendorsTO vendor = new VendorsTO();
		List<VendorsTO> vendors = adminService.getVendors();
		model.addAttribute("vendors", vendors);
		return new ModelAndView("Admin/Inventory/addvendors", "addvendors",
				vendor);
	}

	@RequestMapping(value = "/savevendors", method = RequestMethod.POST)
	public ModelAndView saveaddams(ModelMap model,
			@ModelAttribute VendorsTO vendorsTO) {
		adminService.saveAdmin(vendorsTO);
		return new ModelAndView("redirect:vendorsList");
	}

	@RequestMapping(value = "editVendorsId")
	public ModelAndView editvendors(@RequestParam Integer vendorId,
			ModelMap model) {
		VendorsTO Vendor = new VendorsTO();
		VendorsTO vendor = adminService.getVendorByid(vendorId);
		model.addAttribute("vendor", vendor);
		return new ModelAndView("Admin/Inventory/editvendors", "Vendor", Vendor);

	}*/

	/*@RequestMapping(value = "/editvendorsave")
	public @ResponseBody ModelAndView Editvendorupdate(ModelMap model,
			@ModelAttribute VendorsTO vendorsDTO) {
		vendorsDTO.setVendorId(vendorsDTO.getVendorId());
		adminService.saveOrUpdate(vendorsDTO);
		return new ModelAndView("redirect:vendorsList");
	}

	@RequestMapping(value = "editItemId")
	public ModelAndView Editmaster(@RequestParam Integer itemId, ModelMap model) {
		ItemMasterTO itemMaster = new ItemMasterTO();
		ItemMasterTO master = adminService.getItemmasterByid(itemId);
		model.addAttribute("master", master);
		return new ModelAndView("Admin/Inventory/editItem", "itemMaster",
				itemMaster);

	}*/

	/*@RequestMapping(value = "editmastersave")
	public @ResponseBody ModelAndView Editmasterupdate(ModelMap model,
			@ModelAttribute ItemMasterTO itemMasterDTO) {
		itemMasterDTO.setItemId(itemMasterDTO.getItemId());
		adminService.saveOrUpdate(itemMasterDTO);
		return new ModelAndView("redirect:viewIteamsList");

	}*/

	/*@RequestMapping(value = "/saveinward", method = RequestMethod.POST)
	public ModelAndView saveInventory(ModelMap model,
			@ModelAttribute InventoryTO inventoryTO) {
		ItemMasterTO itemmasterByid = adminService
				.getItemmasterByid(inventoryTO.getItemId());
		if (inventoryTO.getEntryType().equals("InWard")) {
			Float totalQuantity = (itemmasterByid.getCurrentStock() + inventoryTO
					.getQuantity());
			report.updateItemMaster(inventoryTO.getItemId(), totalQuantity);
		} else {
			Float totalQuantity = (itemmasterByid.getCurrentStock() - inventoryTO
					.getQuantity());
			report.updateItemMaster(inventoryTO.getItemId(), totalQuantity);
		}
		Calendar cal = Calendar.getInstance();
		inventoryTO.setCreatedDate(cal.getTime());
		adminService.saveAdmin(inventoryTO);
		return new ModelAndView("redirect:searchItem");
	}*/

	/*@RequestMapping(value = "addinward")
	public ModelAndView addInWard(ModelMap model, @RequestParam Integer itemId,
			@RequestParam String itemName) {
		InventoryTO inventry = new InventoryTO();
		model.addAttribute("itemName", itemName);
		model.addAttribute("itemId", itemId);
		List<VendorsTO> allVendors = report.getAllVendors();
		model.addAttribute("allVendors", allVendors);
		return new ModelAndView("Admin/Inventory/addinward", "inventry",
				inventry);
	}
*/
	/*@RequestMapping(value = "addoutward")
	public ModelAndView addOutWard(ModelMap model,
			@RequestParam Integer itemId, @RequestParam String itemName) {
		InventoryTO inventry = new InventoryTO();
		model.addAttribute("itemName", itemName);
		model.addAttribute("itemId", itemId);

		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);
		String query = "SELECT DISTINCT emp.emp_name,role.department,emp.emp_id FROM employee_roles empRole "
				+ " LEFT JOIN role_master role ON role.role_id = empRole.role_id  LEFT JOIN employee_details emp ON emp.emp_id = empRole.emp_id ";
		ArrayList<HashMap<String, String>> getemployeeListThruRole = hrService
				.getemployeeListThruRole(query);
		model.addAttribute("allEmployeeDetails", getemployeeListThruRole);

		List<VendorsTO> allVendors = report.getAllVendors();
		model.addAttribute("allVendors", allVendors);
		return new ModelAndView("Admin/Inventory/outward", "inventry", inventry);
	}*/

	/*@RequestMapping(value = "editinwardid")
	public ModelAndView addiwardid(@RequestParam Integer itemId, ModelMap model) {

		InventoryTO inventoryTO = new InventoryTO();
		ItemMasterTO master = adminService.getItemmasterByid(itemId);
		model.addAttribute("master", master);
		return new ModelAndView("Admin/Inventory/addinward", "inventoryTO",
				inventoryTO);

	}*/

	@RequestMapping(value = "constant")
	public ModelAndView welezoconstatnt(ModelMap model) {
		WelezoConstantsTO welezo = new WelezoConstantsTO();
		List<WelezoConstantsTO> welezoconsta = adminService.getconstants();
		model.addAttribute("welezoconsta", welezoconsta);
		List<WelezoConstantsTO> allcategory = report.getallcategory();
		model.addAttribute("allcategory", allcategory);
		return new ModelAndView("Admin/welezoconstant/constant", "constant",
				welezo);
	}

	@RequestMapping(value = "/saveconstant", method = RequestMethod.POST)
	public ModelAndView welezoconstatnt(ModelMap model,
			@ModelAttribute WelezoConstantsTO welezoConstantsTO) {
		adminService.saveAdmin(welezoConstantsTO);
		return new ModelAndView("redirect:constant");
	}

	@RequestMapping(value = "editconstant")
	public ModelAndView editwelezoconstant(@RequestParam Integer id,
			ModelMap model) {
		WelezoConstantsTO welezoConstantsTO = new WelezoConstantsTO();
		WelezoConstantsTO welezo = adminService.getconstantbyid(id);
		model.addAttribute("welezo", welezo);
		return new ModelAndView("Admin/welezoconstant/editconstant",
				"welezoConstantsTO", welezoConstantsTO);

	}

	@RequestMapping(value = "/saveconstant")
	public @ResponseBody ModelAndView save(ModelMap model,
			WelezoConstantsTO welezoconstatntDTO) {
		welezoconstatntDTO.setId(welezoconstatntDTO.getId());
		adminService.saveOrUpdate(welezoconstatntDTO);
		return new ModelAndView("redirect:constant");
	}

	@RequestMapping(value = "/voucherEntry")
	public @ResponseBody ModelAndView getAllVoucherEntry(ModelMap model) {
		ArrayList<HashMap<String, String>> allVoucherEntry = report.getAllVoucherEntry();
		model.addAttribute("allVoucherEntry", allVoucherEntry);
		return new ModelAndView("Admin/appointment/voucherEntires",
				"healthApptTO", new HealthAppointmentTO());
	}

	@RequestMapping(value = "/saveVouchers")
	public @ResponseBody ModelAndView saveVochers(ModelMap model,HealthAppointmentTO healthApptTO) {
		report.updateReceivedVoucherNumbers(healthApptTO);
		return new ModelAndView("redirect:voucherEntry");

	}

	@RequestMapping(value = "/apptDocument", method = RequestMethod.POST)
	public ModelAndView uploadHealthDoc(ModelMap model,
			@RequestParam("name") String name,
			@RequestParam CommonsMultipartFile file,
			@RequestParam Integer appointmentId) throws Exception {

		String path = "/home/welezohealth/whms/apptReports";
	//	 String path = "D:/files/doc";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();

			String query ="UPDATE health_appointment SET report_status ='Report Updated' WHERE appointment_id = '"+appointmentId+"'";
		hrService.upDateQuery(query);
		} catch (Exception e) {
			// System.out.println(e);
		}

		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + appointmentId + "_" + name
				+ "_" + filename));

		model.addAttribute("appointmentId", appointmentId);
		
		return new ModelAndView("redirect:viewAppointmentsById");
	}

	@RequestMapping(value = "/checkAvailableHospital")
	public @ResponseBody ModelAndView viewAvailableHospital(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		// cal.add(Calendar.DATE, -15);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		model.addAttribute("serviceId", "3");
		model.addAttribute("city", "Bangalore");
		return new ModelAndView("redirect:getSeviceList");
	}

	@RequestMapping(value = "/getSeviceList" ,method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView viewAvailableHospitalList(ModelMap model,
			@RequestParam String fromDate, String toDate, Integer serviceId,
			String city) {
		ArrayList<HashMap<String, String>> cityList = report.getCityList();
		model.addAttribute("cityList", cityList);

		ArrayList<HashMap<String, String>> allAvailableHospitalList = report
				.getAllAvailableHospitalList(fromDate, toDate, serviceId, city);
	 ArrayList<HashMap<String, String>> allservice = adminService.getAllservice();
		model.addAttribute("allservice", allservice);
		model.addAttribute("appointmentList", allAvailableHospitalList);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("city", city);
		ServicesTO allServices = adminService.getAllServices(serviceId);
		model.addAttribute("allServices", allServices);
		return new ModelAndView("Admin/appointment/checkServiceAvailabe");
	}

	@RequestMapping(value = "/ajax")
	public @ResponseBody ModelAndView ajax(ModelMap model) {

		return new ModelAndView("Admin/welezoconstant/ajaxSearch");

	}

	@RequestMapping(value = "/storemasteritemontypes", method = RequestMethod.POST)
	@ResponseBody
	public ArrayList<HashMap<String, String>> getMasterItemsOnType(Long typeId,String itemName) {
		ArrayList<HashMap<String, String>> MasterItemsList = report.getCityList();
		return MasterItemsList;
	}
	@RequestMapping(value = "/appointmentList")
	public @ResponseBody ModelAndView appointmentListDateWise(ModelMap model) {
		JSONArray healthAppointmentListDatecalender = report.healthAppointmentListDatecalender();
		model.addAttribute("object", healthAppointmentListDatecalender);
		return new ModelAndView("Admin/appointment/appointmentList");

	}
	@RequestMapping(value = "/customerFeedBack")
	public @ResponseBody ModelAndView customerFeedBack(ModelMap model,@RequestParam Integer appointmentId) {
		
		ArrayList<HashMap<String,String>> questionBank = hrService.getQuestionBank("Customer Feedback");
		model.addAttribute("questionBank", questionBank);
		model.addAttribute("appointmentId", appointmentId);
		return new ModelAndView("Admin/appointment/addCustomerFeedbackForm");

	}
	
	@RequestMapping(value = "/saveCusomerFeedback",method = RequestMethod.POST)
	public ModelAndView saveCusomerFeedback(ModelMap model,Integer[] qnId,String[] answer,Integer appointmentId) {

		for (int i = 0; i < qnId.length; i++) {
			if (!answer[i].equalsIgnoreCase("")) {
				QnResponsesTO qnResp = new QnResponsesTO();
				qnResp.setRefId(appointmentId);
				qnResp.setQnId(qnId[i]);
				qnResp.setAnswer(answer[i]);
				qnResp.setAttrType("Customer Feedback");
				adminService.saveAdmin(qnResp);
			}
		}
		
		String query = "UPDATE health_appointment SET status_appointment = 'Availed' WHERE appointment_id ='"+appointmentId+"'";
		hrService.upDateQuery(query);
		return new ModelAndView("redirect:viewappointment");
	}
	@RequestMapping(value = "/viewCustomerFeedback",method = RequestMethod.GET)
	public ModelAndView viewCusomerFeedback(ModelMap model) {
		
		ArrayList<HashMap<String,String>> healthAppointmnetFBRating = adminService.getHealthAppointmnetFBRating();
		model.addAttribute("custsatRateList", healthAppointmnetFBRating);
	
		ArrayList<HashMap<String,String>> questionBank = hrService.getQuestionBank("Customer Feedback");
		model.addAttribute("questionBank", questionBank);
		return new ModelAndView("Admin/appointment/viewCustomerFeedbackList");
	}
	
	@RequestMapping(value = "/postEditCsat",method = RequestMethod.GET)
	public ModelAndView postEditCusomerFeedback(ModelMap model, String [] answer,Integer[] autoNum, Integer appointmentId) {
		
		for (int i = 0; i < autoNum.length; i++) {
				String query ="UPDATE qn_responses SET answer = '"+answer[i]+"' WHERE autoNum = '"+autoNum[i]+"'";
				hrService.upDateQuery(query);
		}
			
		model.addAttribute("appointmentId", appointmentId);
		return new ModelAndView("redirect:viewAppointmentsById");
	}
	
	@RequestMapping(value = "/viewCustomerReport",method = RequestMethod.GET)
	public ModelAndView viewCusomerReport(ModelMap model) {
		
		ArrayList<HashMap<String,String>> customerReportList = adminService.getCustomerReportList();
		model.addAttribute("customerReportList", customerReportList);
		return new ModelAndView("Admin/appointment/customerReport");
	}
	
/* -----------------------START OF  INVENTORY MODULE------------------ */
	
	@RequestMapping(value = "viewIteamsList")
	public ModelAndView addmaster(ModelMap model) {
		ItemMasterTO master = new ItemMasterTO();
		List<ItemMasterTO> itemMaster = adminService.getItemMaster();
		model.addAttribute("itemMaster", itemMaster);

		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("department", allDepartment);
		return new ModelAndView("Admin/Inventory/itemList", "master", master);
	}

	@RequestMapping(value = "/savemaster", method = RequestMethod.POST)
	public ModelAndView saveItemmaster(ModelMap model,
			@ModelAttribute ItemMasterTO itemMasterTO) {
		
		adminService.saveAdmin(itemMasterTO);

		return new ModelAndView("redirect:inOutWard");
	}

	@RequestMapping(value = "vendorsList")
	public ModelAndView addams(ModelMap model) {
		VendorsTO vendor = new VendorsTO();
		List<VendorsTO> vendors = adminService.getVendors();
		model.addAttribute("vendors", vendors);
		return new ModelAndView("Admin/Inventory/addvendors", "addvendors",
				vendor);
	}

	@RequestMapping(value = "/savevendors", method = RequestMethod.POST)
	public ModelAndView saveaddams(ModelMap model,
			@ModelAttribute VendorsTO vendors) {
		
		adminService.saveAdmin(vendors);
		return new ModelAndView("redirect:inOutWard");
	}

	@RequestMapping(value = "editVendorsId")
	public ModelAndView editvendors(@RequestParam Integer vendorId,
			ModelMap model) {
		VendorsTO Vendor = new VendorsTO();
		VendorsTO vendor = adminService.getVendorByid(vendorId);
		model.addAttribute("vendor", vendor);
		return new ModelAndView("Admin/Inventory/editvendors", "Vendor", Vendor);

	}

	@RequestMapping(value = "/editvendorsave")
	public @ResponseBody ModelAndView Editvendorupdate(ModelMap model,
			@ModelAttribute VendorsTO vendorsDTO) {
		vendorsDTO.setVendorId(vendorsDTO.getVendorId());
		adminService.saveOrUpdate(vendorsDTO);
		return new ModelAndView("redirect:vendorsList");
	}

	@RequestMapping(value = "editItemId")
	public ModelAndView Editmaster(@RequestParam Integer itemId, ModelMap model) {
		ItemMasterTO itemMaster = new ItemMasterTO();
		
		ItemMasterTO master = adminService.getItemmasterByid(itemId);
		
		model.addAttribute("master", master);
		return new ModelAndView("Admin/Inventory/editItem", "itemMaster",
				itemMaster);

	}

	@RequestMapping(value = "editmastersave")
	public @ResponseBody ModelAndView Editmasterupdate(ModelMap model,
			@ModelAttribute ItemMasterTO itemMasterDTO) {
		itemMasterDTO.setItemId(itemMasterDTO.getItemId());
		
		adminService.saveOrUpdate(itemMasterDTO);
		return new ModelAndView("redirect:inOutWard");
		
	}

	@RequestMapping(value = "/saveinward", method = RequestMethod.POST)
	public ModelAndView saveInventory(ModelMap model,@ModelAttribute InventoryTO inventoryTO) {
		ItemMasterTO itemmasterByid = adminService	
				.getItemmasterByid(inventoryTO.getItemId());
		
		
		if (inventoryTO.getEntryType().equals("InWard")) {
			Float totalQuantity = (itemmasterByid.getCurrentStock() + inventoryTO
					.getQuantity());
			report.updateItemMaster(inventoryTO.getItemId(), totalQuantity);
		} else if (inventoryTO.getEntryType().equals("OutWard")){
			Float totalQuantity = (itemmasterByid.getCurrentStock() - inventoryTO
					.getQuantity());
			report.updateItemMaster(inventoryTO.getItemId(), totalQuantity);
		}else{
			Float totalQuantity = (itemmasterByid.getCurrentStock() - 0);
			report.updateItemMaster(inventoryTO.getItemId(), totalQuantity);
		}
		Calendar cal = Calendar.getInstance();
		inventoryTO.setCreatedDate(cal.getTime());
		HashMap<String, String> employeeIdFromUserId = hrService.getEmployeeIdFromUserId(inventoryTO.getActionBy());
		inventoryTO.setIssuedTo(Integer.parseInt(employeeIdFromUserId.get("empId")));
		adminService.saveAdmin(inventoryTO);
		return new ModelAndView("redirect:inOutWard");
	}

	@RequestMapping(value = "addinward")
	public ModelAndView addInWard(ModelMap model, @RequestParam Integer itemId,
			@RequestParam String itemName) {
		InventoryTO inventry = new InventoryTO();
		model.addAttribute("itemName", itemName);
		model.addAttribute("itemId", itemId);
		List<VendorsTO> allVendors = report.getAllVendors();
		model.addAttribute("allVendors", allVendors);
		
		return new ModelAndView("Admin/Inventory/addinward", "inventry",
				inventry);
	}

	@RequestMapping(value = "inventoryDashboard")
	public ModelAndView inventoryDashboard(ModelMap model) {
		ArrayList<HashMap<String,String>> inventoryInWardReport = report.getInventoryInWardReport();
		model.addAttribute("inventoryInWardReport", inventoryInWardReport);
			
		ArrayList<HashMap<String,String>> inventoryOutWardReport = report.getInventoryOutWardReport();
		model.addAttribute("inventoryOutWardReport", inventoryOutWardReport);
		
		OcrReader ocr = new OcrReader();
		try {
			ocr.ocrTest();
		} catch (TesseractException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("Admin/Inventory/inventoryDashboard");
	}

	@RequestMapping(value = "inventory-dashboard")
	public ModelAndView inventoryReport2(ModelMap model) {
		return new ModelAndView("Admin/Inventory/inventory-dashboard");
	}
	
	@RequestMapping(value = "reissue")
	public ModelAndView reissue(ModelMap model,@RequestParam Integer itemId,@RequestParam String itemName) {
		InventoryTO inventry = new InventoryTO();
		model.addAttribute("itemName", itemName);
		model.addAttribute("itemId", itemId);

		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);
		String query = "SELECT DISTINCT emp.emp_name,role.department,emp.emp_id FROM employee_roles empRole "
				+ " LEFT JOIN role_master role ON role.role_id = empRole.role_id  LEFT JOIN employee_details emp ON emp.emp_id = empRole.emp_id ";
		ArrayList<HashMap<String, String>> getemployeeListThruRole = hrService
				.getemployeeListThruRole(query);
		model.addAttribute("allEmployeeDetails", getemployeeListThruRole);

		List<VendorsTO> allVendors = report.getAllVendors(itemId);
		model.addAttribute("allVendors", allVendors);
		return new ModelAndView("Admin/Inventory/reissue", "inventry", inventry);
		
	}
	
	@RequestMapping(value = "addoutward")
	public ModelAndView addOutWard(ModelMap model,
			@RequestParam Integer itemId, @RequestParam String itemName) {
		InventoryTO inventry = new InventoryTO();
		model.addAttribute("itemName", itemName);
		model.addAttribute("itemId", itemId);
		

		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);
		String query = "SELECT DISTINCT emp.emp_name,role.department,emp.emp_id FROM employee_roles empRole "
				+ " LEFT JOIN role_master role ON role.role_id = empRole.role_id  LEFT JOIN employee_details emp ON emp.emp_id = empRole.emp_id ";
		ArrayList<HashMap<String, String>> getemployeeListThruRole = hrService.getemployeeListThruRole(query);
		model.addAttribute("allEmployeeDetails", getemployeeListThruRole);

		List<VendorsTO> allVendors = report.getAllVendors(itemId);
		model.addAttribute("allVendors", allVendors);
		return new ModelAndView("Admin/Inventory/addoutward", "inventry", inventry);
	}

	@RequestMapping(value = "editinwardid")
	public ModelAndView addiwardid(@RequestParam Integer itemId, ModelMap model) {

		InventoryTO inventoryTO = new InventoryTO();
		ItemMasterTO master = adminService.getItemmasterByid(itemId);
		model.addAttribute("master", master);
		return new ModelAndView("Admin/Inventory/addinward", "inventoryTO",
				inventoryTO);
		//return new ModelAndView("redirect:inOutWard");

	}
	
	/* END OF INVENTORY MODULE */
}
