package com.welezo.whms.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CallsUpload;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.CollectionDTO;
import com.welezo.whms.dto.CustomerDeatilsAllDTO;
import com.welezo.whms.dto.CustomerFamilyDTO;
import com.welezo.whms.dto.CustomerReferencesDTO;
import com.welezo.whms.dto.DaywiseCallsIdDTO;
import com.welezo.whms.dto.DispatchTrackingDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.ExternalIdDTO;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.dto.HospitalServiceDTO;
import com.welezo.whms.dto.InteractionRegisterDTO;
import com.welezo.whms.dto.PaymentDetailsDTO;
import com.welezo.whms.dto.PresalesDTO;
import com.welezo.whms.dto.ProductOffersDTO;
import com.welezo.whms.dto.ResultsetColumnsDeatils;
import com.welezo.whms.dto.TeleCallRecordIdDTO;
import com.welezo.whms.dto.TransactionMasterDTO;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.CallRecordsService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;
import com.welezo.whms.to.AddressCatagoriesTO;
import com.welezo.whms.to.AddressTO;
import com.welezo.whms.to.ApplicationStockTO;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CollectionOffersTO;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.CustomerFamilyTO;
import com.welezo.whms.to.CustomerHealthanalysisTO;
import com.welezo.whms.to.CustomerReferencesTO;
import com.welezo.whms.to.DispatchTrackingTO;
import com.welezo.whms.to.EmpanellmentTO;
import com.welezo.whms.to.ExtensionDetailsTO;
import com.welezo.whms.to.ExternalIdTO;
import com.welezo.whms.to.HospitalServiceTO;
import com.welezo.whms.to.PaymentDetailsTO;
import com.welezo.whms.to.PresalesTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.ReferencesTO;
import com.welezo.whms.to.ServicesTO;
import com.welezo.whms.to.TablesUpdatesTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.to.TransactionMasterTO;
import com.welezo.whms.to.TransactionOffersTO;
import com.welezo.whms.to.UsermasterTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Controller
public class AdminController {

	private Logger LOG = Logger.getLogger(AdminController.class);
	HttpSession session = null;

	@Autowired
	AdminService adminService;

	@Autowired
	CallRecordsService callrecordservice;
	@Autowired
	UserService userService;
	@Autowired
	HealthAppointmentController healthAppt;
	@Autowired
	ReportController report;
	@Autowired
	HRService hrService;

	/* ------- Customer Application Form start from here----- */
	@RequestMapping(value = "/viewcustomers")
	public ModelAndView viewcustomers(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewcustomers(viwe all customer details) ");
		UsermasterTO loginDTO = new UsermasterTO();
		List<CustomerDeatilsAllDTO> allCustomer = adminService.getAllCustomer();
		model.addAttribute("custDetails", allCustomer);
		LOG.info("----------------------- End of viewcustomers(completed customer details) ");
		return new ModelAndView("Admin/application/viewcustomers",
				"viewcustomers", loginDTO);
	}

	@RequestMapping(value = "/addcustomers")
	public ModelAndView addCustomers(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into addCustomers(add new customer Details) ");
		CustomerDeatilsAllDTO customerDetails = new CustomerDeatilsAllDTO();

		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);

		List<AddressCatagoriesTO> allAddressCatagories = adminService
				.getAllAddressCatagories();
		model.addAttribute("allAddressCatagories", allAddressCatagories);
		LOG.info("----------------------- End of addCustomers(redirected to add application page)");
		return new ModelAndView("Admin/application/addApplications",
				"addcustomers", customerDetails);
	}

	// save admin saving application data into corresponding tables....
	@RequestMapping(value = "/saveApplication", method = RequestMethod.POST)
	public ModelAndView saveAdmin(ModelMap model,
			@ModelAttribute CustomerDeatilsAllDTO customerDeatilsDTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveAdmin(save customer Details from application) "
				+ customerDeatilsDTO.getCustomerName());
		CustomerDeatilsTO custDetailTO = new CustomerDeatilsTO();
		custDetailTO.setCustomerName(customerDeatilsDTO.getCustomerName());
		if (customerDeatilsDTO.getDob() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String dob = customerDeatilsDTO.getDob();
			try {
				Date date = formatter.parse(dob);
				custDetailTO.setDob(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
		}
		custDetailTO.setGender(customerDeatilsDTO.getGender());
		custDetailTO.setMaritalStatus(customerDeatilsDTO.getMaritalStatus());
		custDetailTO.setAnniversary(customerDeatilsDTO.getAnniversary());
		custDetailTO.setCorrespondence(customerDeatilsDTO.getCorrespondence());
		custDetailTO.setCommuniation(customerDeatilsDTO.getCommuniation());
		custDetailTO.setSector(customerDeatilsDTO.getSalaried());
		custDetailTO.setOcupation(customerDeatilsDTO.getOccupation());
		custDetailTO.setAnnualIncome(customerDeatilsDTO.getAnnualIncome());
		custDetailTO.setCreatedBy(customerDeatilsDTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		custDetailTO.setCreatedDate(cal.getTime());
		adminService.saveAdmin(custDetailTO);
		LOG.info("************ Inserting customer address details(save customer Details from application) "
				+ custDetailTO.getCustomerId());
		Integer addressType1 = customerDeatilsDTO.getAddressType1();
		Integer addressType2 = customerDeatilsDTO.getAddressType2();
		Integer[] entityId = { addressType1, addressType2 };
		String[] residenceAddresss = customerDeatilsDTO.getResidenceAddresss();
		String[] city = customerDeatilsDTO.getCity();
		String[] pincode = customerDeatilsDTO.getPincode();
		String[] landmark = customerDeatilsDTO.getLandmark();
		String[] landline = customerDeatilsDTO.getLandline();
		String[] email = customerDeatilsDTO.getEmail();
		String[] primaryMob = customerDeatilsDTO.getPrimaryMob();
		String[] altMob = customerDeatilsDTO.getAltMob();

		for (int i = 0; i < residenceAddresss.length; i++) {
			if (residenceAddresss[i] != "") {
				AddressTO custAddressTO = new AddressTO();
				AddressCatagoriesTO addressCatagoriesTO = new AddressCatagoriesTO();
				addressCatagoriesTO.setAddressTypeId((entityId[i]));
				custAddressTO.setAddressCatagories(addressCatagoriesTO);

				custAddressTO.setResidenceAddresss(residenceAddresss[i]);
				custAddressTO.setCity(city[i]);
				custAddressTO.setPincode(pincode[i]);
				custAddressTO.setLandmark(landmark[i]);
				custAddressTO.setLandline(landline[i]);
				custAddressTO.setEmail(email[i]);
				custAddressTO.setPrimaryMob(primaryMob[i]);
				custAddressTO.setAltMob(altMob[i]);
				custAddressTO.setEntityId(custDetailTO.getCustomerId());
				adminService.saveAdmin(custAddressTO);
			}
		}

		LOG.info("************	Insert customer family details(save customer Details from application) "
				+ custDetailTO.getCustomerId());
		String[] familyName = customerDeatilsDTO.getFamilyName();
		String[] sex = customerDeatilsDTO.getSex();
		String[] relationship = customerDeatilsDTO.getRelationship();
		Integer[] age = customerDeatilsDTO.getAge();
		String[] memberDOB = customerDeatilsDTO.getMemberDOB();
		for (int i = 0; i < familyName.length; i++) {
			if (familyName[i] != "") {
				CustomerFamilyTO cusFamilyTO = new CustomerFamilyTO();
				cusFamilyTO.setFName(familyName[i]);
				cusFamilyTO.setGender(sex[i]);
				cusFamilyTO.setRelationship(relationship[i]);
				cusFamilyTO.setAge(age[i]);
				cusFamilyTO.setIsactive(true);
				if ( memberDOB[i] != null) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String dobFamily = memberDOB[i];
				try {
					Date date1 = formatter.parse(dobFamily);
					cusFamilyTO.setDob(date1);
				} catch (ParseException e) {
					e.printStackTrace();
					LOG.error(e);
				}
				}
				cusFamilyTO.setCustomerDeatils(custDetailTO);
				adminService.saveAdmin(cusFamilyTO);
			}
		}
		LOG.info("************ Insert customer health details(save customer Details from application) "
				+ custDetailTO.getCustomerId());
		CustomerHealthanalysisTO custhealthTO = new CustomerHealthanalysisTO();
		custhealthTO.setM5(customerDeatilsDTO.getM5());
		custhealthTO.setM618(customerDeatilsDTO.getM618());
		custhealthTO.setM1935(customerDeatilsDTO.getM1935());
		custhealthTO.setM3650(customerDeatilsDTO.getM3650());
		custhealthTO.setM5165(customerDeatilsDTO.getM5165());
		custhealthTO.setM65(customerDeatilsDTO.getM65());
		custhealthTO.setPremium(customerDeatilsDTO.getPremium());
		custhealthTO.setInsurance(customerDeatilsDTO.getInsurance());
		custhealthTO.setDiagnostic(customerDeatilsDTO.getDiagnostic());
		custhealthTO.setConsultation(customerDeatilsDTO.getConsultion());
		custhealthTO.setPharmacy(customerDeatilsDTO.getPharmacy());
		custhealthTO
				.setHospitalization(customerDeatilsDTO.getHospitalization());
		custhealthTO.setCustHeight(customerDeatilsDTO.getCustHeigth());
		custhealthTO.setCustWeight(customerDeatilsDTO.getCustWeigth());
		custhealthTO.setSick(customerDeatilsDTO.getSick());
		custhealthTO.setHealthCheck(customerDeatilsDTO.getHealthCheck());
		custhealthTO.setConsultSpecialist(customerDeatilsDTO
				.getConsultSpecialist());
		custhealthTO.setVisitDentist(customerDeatilsDTO.getVisitDentist());
		custhealthTO.setMedicinFollow(customerDeatilsDTO.getMedicinFollow());
		custhealthTO.setSmoke(customerDeatilsDTO.getSmoke());
		custhealthTO.setAlcohol(customerDeatilsDTO.getAlcohol());
		custhealthTO.setFoodHabits(customerDeatilsDTO.getFoodHabits());
		custhealthTO.setCustSuffer(customerDeatilsDTO.getCustSuffer());
		custhealthTO.setParentsSuffer(customerDeatilsDTO.getParentsSuffer());
		custhealthTO.setExercise(customerDeatilsDTO.getExercise());
		custhealthTO.setStressfull(customerDeatilsDTO.getStressfull());
		custhealthTO.setSleep(customerDeatilsDTO.getSleep());

		custhealthTO.setMedicalHistory(customerDeatilsDTO.getMedicalHistory());
		custhealthTO.setCustomerDeatils(custDetailTO);
		adminService.saveAdmin(custhealthTO);
		LOG.info("************ Insert customer proof details(save customer Details from application) "
				+ custDetailTO.getCustomerId());
		String[] idType = customerDeatilsDTO.getIdType();
		String[] idNumber = customerDeatilsDTO.getIdNumber();

		for (int i1 = 0; i1 < idType.length; i1++) {
			if (idType[i1] != "") {
				ExternalIdTO externalIdTO = new ExternalIdTO();
				externalIdTO.setIdNumber(idNumber[i1]);
				externalIdTO.setIdType(idType[i1]);
				externalIdTO.setCustomerDeatils(custDetailTO);
				adminService.saveAdmin(externalIdTO);
			}
		}

		LOG.info("************ Insert customer references(save customer Details from application) "
				+ custDetailTO.getCustomerId());
		String[] name = customerDeatilsDTO.getName();
		String[] reff = customerDeatilsDTO.getRelationshipRef();
		String[] contact = customerDeatilsDTO.getContactNumber();

		for (int i = 0; i < name.length; i++) {
			if (name[i] != "") {
				CustomerReferencesTO referencesTO = new CustomerReferencesTO();
				referencesTO.setName(name[i]);
				referencesTO.setRelationship(reff[i]);
				referencesTO.setContactNumber(contact[i]);
				referencesTO.setCustomerDeatils(custDetailTO);
				adminService.saveAdmin(referencesTO);
			}
		}
		LOG.info("----------- End of customer details insertion(save customer Details from application) "
				+ custDetailTO.getCustomerId());

		model.addAttribute("customerId", custDetailTO.getCustomerId());

		return new ModelAndView("redirect:viewcustomersById");
	}

	// customer details delete methods....
	@RequestMapping(value = "/custDelete")
	public ModelAndView deleteCustomerDetail(@RequestParam Integer customerId) {
		LOG.info("++++++++++++++++++++++ Enter into deleteCustomerDetail"
				+ customerId);
		adminService.deleteCustomer(customerId);
		LOG.info("---------------------- End of deleteCustomerDetail redirect to view customer");
		return new ModelAndView("redirect:viewcustomers");
	}

	// customer edit form retrieve all customer data from database...
	@RequestMapping(value = "/custEdit")
	public ModelAndView editCustomerDetail(@RequestParam Integer customerId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into editCustomerDetail"
				+ customerId);
		CustomerDeatilsAllDTO cust = new CustomerDeatilsAllDTO();

		try {
			CustomerDeatilsTO custDetails = adminService.getCustomerDetail(customerId);
			model.addAttribute("custDetails", custDetails);
			String anniversay = null, dob = null;
			if (custDetails.getDob() != null) {
				dob = new SimpleDateFormat("dd/MM/yyyy").format(custDetails
						.getDob());
			}
			model.addAttribute("aniversary", anniversay);
			model.addAttribute("dob", dob);

			List<CustomerReferencesDTO> custRefrence = adminService
					.getCustRefrence(customerId);
			model.addAttribute("custRefrence", custRefrence);

			List<CustomerFamilyDTO> family = adminService.getFamily(customerId);
			model.addAttribute("family", family);

			CustomerHealthanalysisTO customerHealth = adminService
					.getCustomerHealth(customerId);
			model.addAttribute("customerHealth", customerHealth);

			try {
				AddressDTO residenceAddress = adminService.getAllAddress(
						custDetails.getCustomerId(), "Residence");
				AddressCatagoriesTO addressTypeId1 = adminService
						.getAddressTypeId(residenceAddress.getAddressCategory());
				residenceAddress.setAddressCatagories(addressTypeId1);
				model.addAttribute("residenceAddress", residenceAddress);
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e);
			}
			try {
				AddressDTO workPlaceAddress = adminService.getAllAddress(
						custDetails.getCustomerId(), "WorkPlace");
				AddressCatagoriesTO addressTypeId2 = adminService
						.getAddressTypeId(workPlaceAddress.getAddressCategory());
				workPlaceAddress.setAddressCatagories(addressTypeId2);
				model.addAttribute("workPlaceAddress", workPlaceAddress);

			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e);
			}
			try {
				AddressDTO otherAddress = adminService.getAllAddress(
						custDetails.getCustomerId(), "Other");
				AddressCatagoriesTO addressTypeId3 = adminService
						.getAddressTypeId(otherAddress.getAddressCategory());
				otherAddress.setAddressCatagories(addressTypeId3);
				model.addAttribute("workPlaceAddress", otherAddress);
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e);

			}
			List<ExternalIdDTO> proofId = adminService.getProofId(custDetails
					.getCustomerId());
			model.addAttribute("proofId", proofId);

			List<AddressCatagoriesTO> allAddressCatagories = adminService
					.getAllAddressCatagories();
			model.addAttribute("allAddressCatagories", allAddressCatagories);

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		LOG.info("---------------------- End of editCustomerDetail"
				+ customerId);
		return new ModelAndView("Admin/application/editApplication",
				"editCustomer", cust);
	}

	// after editing update particular id will be save....
	@RequestMapping(value = "/saveEdit", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveEdit(ModelMap map,
			@ModelAttribute CustomerDeatilsAllDTO customerDeatilsDTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveEdit "
				+ customerDeatilsDTO.getCustomerId());
		LOG.info("************ Alter  customer  details "
				+ customerDeatilsDTO.getCustomerId());
		CustomerDeatilsTO customerDetail = adminService
				.getCustomerDetail(customerDeatilsDTO.getCustomerId());
		CustomerDeatilsTO custDetailTO = new CustomerDeatilsTO();
		custDetailTO.setCustomerId(customerDeatilsDTO.getCustomerId());
		custDetailTO.setCustomerName(customerDeatilsDTO.getCustomerName());
		if (customerDeatilsDTO.getDob() != null) {
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String dob = customerDeatilsDTO.getDob();
			try {
				Date date = formatter.parse(dob);
				custDetailTO.setDob(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
		}
		custDetailTO.setGender(customerDeatilsDTO.getGender());
		custDetailTO.setMaritalStatus(customerDeatilsDTO.getMaritalStatus());
		custDetailTO.setAnniversary(customerDeatilsDTO.getAnniversary());
		custDetailTO.setCorrespondence(customerDeatilsDTO.getCorrespondence());
		custDetailTO.setCommuniation(customerDeatilsDTO.getCommuniation());
		custDetailTO.setSector(customerDeatilsDTO.getSalaried());
		custDetailTO.setOcupation(customerDeatilsDTO.getOccupation());
		custDetailTO.setCardNumber(customerDetail.getCardNumber());
		custDetailTO.setAnnualIncome(customerDeatilsDTO.getAnnualIncome());
		custDetailTO.setModifiedBy(customerDeatilsDTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		custDetailTO.setModifiedDate(cal.getTime());
		custDetailTO.setCreatedDate(customerDetail.getCreatedDate());
		custDetailTO.setCreatedBy(customerDetail.getCreatedBy());
		adminService.upDateAdmin(custDetailTO);

		LOG.info("************ Alter  customer Address  details "
				+ customerDeatilsDTO.getCustomerId());
		Integer addressType1 = customerDeatilsDTO.getAddressType1();
		Integer addressType2 = customerDeatilsDTO.getAddressType2();
		Integer[] entityId = { addressType1, addressType2 };
		Integer[] aid = customerDeatilsDTO.getAid();
		String[] residenceAddresss = customerDeatilsDTO.getResidenceAddresss();
		String[] city = customerDeatilsDTO.getCity();
		String[] pincode = customerDeatilsDTO.getPincode();
		String[] landmark = customerDeatilsDTO.getLandmark();
		String[] landline = customerDeatilsDTO.getLandline();
		String[] email = customerDeatilsDTO.getEmail();
		String[] primaryMob = customerDeatilsDTO.getPrimaryMob();
		String[] altMob = customerDeatilsDTO.getAltMob();

		try {
			for (int i = 0; i < residenceAddresss.length; i++) {
				if (residenceAddresss[i] != "") {

					AddressTO custAddressTO = new AddressTO();
					custAddressTO.setAid(aid[i]);
					AddressCatagoriesTO addressCatagoriesTO = new AddressCatagoriesTO();
					addressCatagoriesTO.setAddressTypeId((entityId[i]));
					custAddressTO.setAddressCatagories(addressCatagoriesTO);

					custAddressTO.setResidenceAddresss(residenceAddresss[i]);
					custAddressTO.setCity(city[i]);
					custAddressTO.setPincode(pincode[i]);
					custAddressTO.setLandmark(landmark[i]);
					custAddressTO.setLandline(landline[i]);
					custAddressTO.setEmail(email[i]);
					custAddressTO.setPrimaryMob(primaryMob[i]);
					custAddressTO.setAltMob(altMob[i]);
					custAddressTO.setEntityId(custDetailTO.getCustomerId());
					adminService.saveOrUpdate(custAddressTO);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}

		LOG.info("************ Alter  customer Family details "
				+ customerDeatilsDTO.getCustomerId());
		try {
			List<CustomerFamilyDTO> family = adminService
					.getFamily(customerDeatilsDTO.getCustomerId());
			Iterator<CustomerFamilyDTO> iterator = family.iterator();
			// Hava to use SELECT MAX(column_name) FROM table_name;
			String[] familyName2 = customerDeatilsDTO.getFamilyName();
			int i = 0;
			int[] familyID = new int[familyName2.length];
			while (iterator.hasNext() && i < familyName2.length) {
				CustomerFamilyDTO familyDTO = iterator.next();
				familyID[i] = familyDTO.getFamilyId();
				i++;
			}

			customerDeatilsDTO.setFamilyId(familyID);

			int[] familyID1 = customerDeatilsDTO.getFamilyId();
			String[] familyName = customerDeatilsDTO.getFamilyName();
			String[] sex = customerDeatilsDTO.getSex();
			String[] relationship = customerDeatilsDTO.getRelationship();
			Integer[] age = customerDeatilsDTO.getAge();
			String[] memberDOB = customerDeatilsDTO.getMemberDOB();

			for (int i1 = 0; i1 < familyName.length; i1++) {
				if (familyName[i1] != "") {
					CustomerFamilyTO cusFamilyTO = new CustomerFamilyTO();
					cusFamilyTO.setFamilyId(familyID1[i1]);
					cusFamilyTO.setFName(familyName[i1]);
					cusFamilyTO.setGender(sex[i1]);
					cusFamilyTO.setRelationship(relationship[i1]);
					cusFamilyTO.setAge(age[i1]);
						SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
						String dobFamily = memberDOB[i1];
						// System.out.println(memberDOB[i1]);
						try {
							Date date1 = formatter.parse(dobFamily);
							cusFamilyTO.setDob(date1);
						} catch (ParseException e) {
							e.printStackTrace();
							LOG.error(e);
					}
					cusFamilyTO.setCustomerDeatils(custDetailTO);
					adminService.saveOrUpdate(cusFamilyTO);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		LOG.info("************ Alter  customer Health details "
				+ customerDeatilsDTO.getCustomerId());
		try {
			CustomerHealthanalysisTO custhealthTO = new CustomerHealthanalysisTO();
			custhealthTO.setId(customerDeatilsDTO.getId());
			custhealthTO.setM5(customerDeatilsDTO.getM5());
			custhealthTO.setM618(customerDeatilsDTO.getM618());
			custhealthTO.setM1935(customerDeatilsDTO.getM1935());
			custhealthTO.setM3650(customerDeatilsDTO.getM3650());
			custhealthTO.setM5165(customerDeatilsDTO.getM5165());
			custhealthTO.setM65(customerDeatilsDTO.getM65());
			custhealthTO.setPremium(customerDeatilsDTO.getPremium());
			custhealthTO.setInsurance(customerDeatilsDTO.getInsurance());
			custhealthTO.setDiagnostic(customerDeatilsDTO.getDiagnostic());
			custhealthTO.setConsultation(customerDeatilsDTO.getConsultion());
			custhealthTO.setPharmacy(customerDeatilsDTO.getPharmacy());
			custhealthTO.setHospitalization(customerDeatilsDTO
					.getHospitalization());
			custhealthTO.setCustHeight(customerDeatilsDTO.getCustHeigth());
			custhealthTO.setCustWeight(customerDeatilsDTO.getCustWeigth());
			custhealthTO.setSick(customerDeatilsDTO.getSick());
			custhealthTO.setHealthCheck(customerDeatilsDTO.getHealthCheck());
			custhealthTO.setConsultSpecialist(customerDeatilsDTO
					.getConsultSpecialist());
			custhealthTO.setVisitDentist(customerDeatilsDTO.getVisitDentist());
			custhealthTO
					.setMedicinFollow(customerDeatilsDTO.getMedicinFollow());
			custhealthTO.setSmoke(customerDeatilsDTO.getSmoke());
			custhealthTO.setAlcohol(customerDeatilsDTO.getAlcohol());
			custhealthTO.setFoodHabits(customerDeatilsDTO.getFoodHabits());
			custhealthTO.setCustSuffer(customerDeatilsDTO.getCustSuffer());
			custhealthTO
					.setParentsSuffer(customerDeatilsDTO.getParentsSuffer());
			custhealthTO.setExercise(customerDeatilsDTO.getExercise());
			custhealthTO.setStressfull(customerDeatilsDTO.getStressfull());
			custhealthTO.setSleep(customerDeatilsDTO.getSleep());

			custhealthTO.setMedicalHistory(customerDeatilsDTO
					.getMedicalHistory());
			custhealthTO.setCustomerDeatils(custDetailTO);
			adminService.upDateAdmin(custhealthTO);
		} catch (Exception e) {
			LOG.error(e);
		}

		LOG.info("************ Alter  Customer  Proof details "
				+ customerDeatilsDTO.getCustomerId());
		try {
			int[] idtype = new int[customerDeatilsDTO.getIdType().length];
			int i3 = 0;
			List<ExternalIdDTO> proofList = adminService
					.getProofId(customerDeatilsDTO.getCustomerId());
			Iterator<ExternalIdDTO> iterator3 = proofList.iterator();
			while (iterator3.hasNext()
					&& i3 < customerDeatilsDTO.getIdType().length) {
				ExternalIdDTO customerProofDTO = (ExternalIdDTO) iterator3
						.next();
				idtype[i3] = customerProofDTO.getProofId();
				i3++;
			}
			customerDeatilsDTO.setProofId(idtype);

			int[] proofId = customerDeatilsDTO.getProofId();
			String[] idType = customerDeatilsDTO.getIdType();
			String[] idNumber = customerDeatilsDTO.getIdNumber();

			for (int i1 = 0; i1 < idNumber.length; i1++) {
				if (idNumber[i1] != "") {
					ExternalIdTO externalIdTO = new ExternalIdTO();
					externalIdTO.setProofId(proofId[i1]);
					externalIdTO.setIdNumber(idNumber[i1]);
					externalIdTO.setIdType(idType[i1]);
					externalIdTO.setCustomerDeatils(custDetailTO);
					adminService.saveOrUpdate(externalIdTO);
				}
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		LOG.info("************ Alter  customer References details "
				+ customerDeatilsDTO.getCustomerId());
		try {
			// //////////////////////customer reference table/////////////
			int[] refId = new int[customerDeatilsDTO.getName().length];
			int i2 = 0;
			List<CustomerReferencesDTO> custRefrence = adminService
					.getCustRefrence(customerDeatilsDTO.getCustomerId());
			Iterator<CustomerReferencesDTO> iterator2 = custRefrence.iterator();
			while (iterator2.hasNext()
					&& i2 < customerDeatilsDTO.getName().length) {
				CustomerReferencesDTO customerReferencesDTO = (CustomerReferencesDTO) iterator2
						.next();
				refId[i2] = customerReferencesDTO.getSl();
				i2++;
			}
			customerDeatilsDTO.setSl(refId);

			int[] sl = customerDeatilsDTO.getSl();
			String[] name = customerDeatilsDTO.getName();
			String[] relationshipRef = customerDeatilsDTO.getRelationshipRef();
			// String[] contactNumber = customerDeatilsDTO.getContactNumber();
			String[] testNo = customerDeatilsDTO.getTestNo();
			for (int i1 = 0; i1 < name.length; i1++) {
				if (name[i1] != "") {
					CustomerReferencesTO customerReferencesTO = new CustomerReferencesTO();
					customerReferencesTO.setReferenceId(sl[i1]);
					customerReferencesTO.setName(name[i1]);
					customerReferencesTO.setRelationship(relationshipRef[i1]);
					customerReferencesTO.setContactNumber(testNo[i1]);
					customerReferencesTO.setCustomerDeatils(custDetailTO);
					adminService.saveOrUpdate(customerReferencesTO);
				}
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		LOG.info("---------------------- End of saveEdit Customer sucessfully  ");
		map.addAttribute("customerId", customerDeatilsDTO.getCustomerId());
		return new ModelAndView("redirect:viewcustomersById");
	}

	/* ============End Of Customer Application form here==================== */
	@RequestMapping(value = "/viewstudent")
	public ModelAndView viewstudent() {
		CustomerDeatilsAllDTO customerDetail = new CustomerDeatilsAllDTO();
		return new ModelAndView("Admin/application/viewstudent", "viewstudent",
				customerDetail);
	}

	@RequestMapping(value = "/viewcustomersById")
	public ModelAndView viewCustomerDetails(@RequestParam Integer customerId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewCustomerDetails cust Id is"
				+ customerId);
		CustomerDeatilsAllDTO cust = new CustomerDeatilsAllDTO();
		try {
			CustomerDeatilsTO custDetails = adminService.getCustomerDetail(customerId);
			model.addAttribute("custDetails", custDetails);
			String anniversay = null, dob = null;
			if (custDetails.getDob() != null) {
				dob = new SimpleDateFormat("dd/MM/yyyy").format(custDetails.getDob());
			}
			model.addAttribute("aniversary", anniversay);
			model.addAttribute("dob", dob);

			List<CustomerReferencesDTO> custRefrence = adminService
					.getCustRefrence(customerId);
			model.addAttribute("custRefrence", custRefrence);

			List<CustomerFamilyDTO> family = adminService.getFamily(customerId);
			model.addAttribute("family", family);

			CustomerHealthanalysisTO customerHealth = adminService.getCustomerHealth(customerId);
			model.addAttribute("customerHealth", customerHealth);

			List<AddressTO> addressList = new ArrayList<>();
			List<AddressDTO> addressEntityId = adminService.getAddressEntityId(custDetails.getCustomerId());
			for (AddressDTO adress : addressEntityId) {
				AddressTO addressTO = new AddressTO();
				AddressCatagoriesTO addressTypeId = adminService.getAddressTypeId(adress.getAddressCategory());
				addressTO.setAddressCatagories(addressTypeId);
				addressTO.setAid(adress.getAid());
				addressTO.setResidenceAddresss(adress.getResidenceAddresss());
				addressTO.setCity(adress.getCity());
				addressTO.setLandmark(adress.getLandmark());
				addressTO.setLandline(adress.getLandline());
				addressTO.setEmail(adress.getEmail());
				addressTO.setPrimaryMob(adress.getPrimaryMob());
				addressTO.setAltMob(adress.getAltMob());
				addressTO.setPincode(adress.getPincode());
				addressList.add(addressTO);

			}
			model.addAttribute("customerAddress", addressList);
			List<ExternalIdDTO> proofId = adminService.getProofId(custDetails
					.getCustomerId());
			model.addAttribute("proofId", proofId);

			List<AddressCatagoriesTO> allAddressCatagories = adminService
					.getAllAddressCatagories();
			model.addAttribute("allAddressCatagories", allAddressCatagories);

		} catch (Exception e) {
			LOG.error(e);
		}
		List<TransactionMasterDTO> applicationNoInTx = report
				.applicationNoInTx();
		model.addAttribute("alltransaction", applicationNoInTx);
		List<TransactionMasterDTO> tranasctionByID = report
				.getTranasctionByID(customerId);
		model.addAttribute("tranasctionByID", tranasctionByID);
		LOG.info("---------------------- End of viewCustomerDetails cust Id is "
				+ customerId);
		return new ModelAndView("Admin/application/viewcustomersById",
				"viewcustomers", cust);
	}

	@RequestMapping(value = "/addstudent")
	public ModelAndView addstudent() {
		UsermasterTO loginDTO = new UsermasterTO();
		return new ModelAndView("Admin/application/addstudent", "addstudent",
				loginDTO);
	}

	@RequestMapping(value = "/savefamilyMember")
	public ModelAndView savefamilyMember(CustomerDeatilsAllDTO detailsAllDTO) {
		LOG.info("++++++++++++++++++++++ Enter into savefamilyMember(adding new family member) "
				+ detailsAllDTO.getCustomerId());
		CustomerDeatilsTO cust = new CustomerDeatilsTO();
		cust.setCustomerId(detailsAllDTO.getCustomerId());
		CustomerFamilyTO family = new CustomerFamilyTO();
		family.setFName(detailsAllDTO.getCustomerName());
		family.setAge(detailsAllDTO.getAddressType1());
		family.setRelationship(detailsAllDTO.getMaritalStatus());
		family.setGender(detailsAllDTO.getGender());
		family.setCustomerDeatils(cust);
		family.setIsactive(true);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String dob = detailsAllDTO.getDob();
		try {
			Date date = formatter.parse(dob);
			family.setDob(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		adminService.saveAdmin(family);
		LOG.info("---------------------- End of savefamilyMember(completed add family member ID is"
				+ family.getFamilyId()
				+ ")cust Id is "
				+ detailsAllDTO.getCustomerId());
		return new ModelAndView("redirect:viewcustomersById", "customerId",
				detailsAllDTO.getCustomerId());
	}

	@RequestMapping(value = "/saveExternalId")
	public ModelAndView saveExternalId(CustomerDeatilsAllDTO detailsAllDTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveExternalId(adding new Proof ) cust Id : "
				+ detailsAllDTO.getCustomerId());
		CustomerDeatilsTO cust = new CustomerDeatilsTO();
		cust.setCustomerId(detailsAllDTO.getCustomerId());
		ExternalIdTO external = new ExternalIdTO();
		external.setCustomerDeatils(cust);
		external.setIdType(detailsAllDTO.getCorrespondence());
		external.setIdNumber(detailsAllDTO.getAnniversary());
		adminService.saveAdmin(external);
		LOG.info("---------------------- End of saveExternalId(completed add Proof ID is"
				+ external.getProofId()
				+ ")cust Id is "
				+ detailsAllDTO.getCustomerId());
		return new ModelAndView("redirect:viewcustomersById", "customerId",
				detailsAllDTO.getCustomerId());
	}

	@RequestMapping(value = "/saveCustRefernces")
	public ModelAndView saveCustRefernces(CustomerDeatilsAllDTO detailsAllDTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveCustRefernces(adding new Customer Ref. ) cust Id : "
				+ detailsAllDTO.getCustomerId());
		CustomerDeatilsTO cust = new CustomerDeatilsTO();
		cust.setCustomerId(detailsAllDTO.getCustomerId());
		CustomerReferencesTO reff = new CustomerReferencesTO();
		reff.setName(detailsAllDTO.getSalaried());
		reff.setRelationship(detailsAllDTO.getOccupation());
		reff.setContactNumber(detailsAllDTO.getAnnualIncome());
		reff.setCreatedBy(detailsAllDTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		reff.setCreatedDate(cal.getTime());
		reff.setCustomerDeatils(cust);
		adminService.saveAdmin(reff);
		LOG.info("---------------------- End of saveCustRefernces(completed add Ref. ID is"
				+ reff.getReferenceId()
				+ ")cust Id is "
				+ detailsAllDTO.getCustomerId());
		return new ModelAndView("redirect:viewcustomersById", "customerId",
				detailsAllDTO.getCustomerId());
	}

	/* =======End Of Student form here===== */
	/*-----start Hospital Details form From here------ */
	// fetching all Hospital details from Hospital details tables and displaying
	// on viewHospital jsp page
	@RequestMapping(value = "/viewHospitals")
	public ModelAndView viewHospitals(ModelMap model) {
		model.addAttribute("city", "Bangalore");
		return new ModelAndView("redirect:viewHospital");

	}

	@RequestMapping(value = "/viewHospital", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView addHospitals(ModelMap model, @RequestParam String city) {
		LOG.info("++++++++++++++++++++++ Enter into addHospitals(View all empaneled hospital list )");
		HospitalServiceDTO hospitalServiceDTO = new HospitalServiceDTO();
		ArrayList<HashMap<String, String>> allHospital = adminService
				.getAllHospital(city);
		model.addAttribute("hospitalDetail", allHospital);

		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		ArrayList<HashMap<String, String>> cityList = report.getCityList();
		model.addAttribute("cityList", cityList);
		model.addAttribute("city", city);
		LOG.info("---------------------- End of addHospitals(View all empaneled hospital list ) ");
		return new ModelAndView("Admin/hospital/viewHospitals",
				"hospitalServiceDTO", hospitalServiceDTO);
	}

	@RequestMapping(value = "/saveHospital")
	public ModelAndView saveHospitals(ModelMap map,
			HospitalServiceDTO hospitalServiceDTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveHospitals saving hospital Name is : "
				+ hospitalServiceDTO.getNameHcc());
		EmpanellmentTO hospitalDetails = new EmpanellmentTO();
		if (hospitalServiceDTO.getFacilityChain() != null
				&& hospitalServiceDTO.getFacilityChain().length() > 2) {
			hospitalDetails.setFacilityChain(hospitalServiceDTO
					.getFacilityChain());
			hospitalDetails.setNameHcc(hospitalServiceDTO.getFacilityChain()
					+ " - " + hospitalServiceDTO.getLocation());
		} else {
			hospitalDetails.setNameHcc(hospitalServiceDTO.getNameHcc());
		}
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format = (hospitalServiceDTO.getEmpanelledDate());
		try {
			Date date = formatter.parse(format);
			hospitalDetails.setEmpanelledDate(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		hospitalDetails.setAddress(hospitalServiceDTO.getResidenceAddresss());
		hospitalDetails.setCity(hospitalServiceDTO.getCity());
		hospitalDetails.setPincode(hospitalServiceDTO.getPincode());
		hospitalDetails.setLatitude(hospitalServiceDTO.getLatitude());
		hospitalDetails.setLongitude(hospitalServiceDTO.getLongitude());
		hospitalDetails.setEscalationContact(hospitalServiceDTO
				.getEscalationContact());
		hospitalDetails.setAuthSignatory(hospitalServiceDTO.getAuthSignatory());
		hospitalDetails.setEmailIds(hospitalServiceDTO.getEmailIds());
		hospitalDetails.setApptBooking(hospitalServiceDTO.getApptBooking());
		hospitalDetails.setEscMail(hospitalServiceDTO.getEscMail());
		hospitalDetails.setLocation(hospitalServiceDTO.getLocation());
		hospitalDetails.setIsActive(true);
		adminService.saveAdmin(hospitalDetails);
		LOG.info("---------------------- hospital Details(successfully saved hospital Id is  : "
				+ hospitalDetails.getHospitalId() + ") ");
		LOG.info("************ Inserting hospital Details ");
		TablesUpdatesTO updates = new TablesUpdatesTO();
		updates.setOperationBy(hospitalServiceDTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		updates.setOperationDate(cal.getTime());
		updates.setOperations("Insert Operation");
		updates.setColumnId(hospitalDetails.getHospitalId());
		updates.setTableName("Empanellement");
		adminService.saveAdmin(updates);

		map.addAttribute("id", hospitalDetails.getHospitalId());
		LOG.info("---------------------- End of addHospitals(successfully saved hospital sevices ) ");
		return new ModelAndView("redirect:viewHospitalByID");
	}

	@RequestMapping(value = "/editHospital")
	public ModelAndView editHospital(@RequestParam Integer id, ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into editHospital where hospital Id = "
				+ id);
		HospitalServiceDTO hospitalDTO = new HospitalServiceDTO();
		EmpanellmentTO hospitalById = adminService.getHospitalById(id);
		model.addAttribute("hospitalById", hospitalById);
		try {
			String empanlledDate = new SimpleDateFormat("dd/MM/yyyy")
					.format(hospitalById.getEmpanelledDate());
			model.addAttribute("empanlledDate", empanlledDate);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		HospitalServiceTO hospitalServicelById = adminService
				.getHospitalServicelById(hospitalById.getHospitalId());
		model.addAttribute("hospitalServicelById", hospitalServicelById);

		List<HashMap<String, String>> allservice = adminService
				.getAllServiceForHospital(id);
		model.addAttribute("serviceHospital", allservice);

		List<ServicesTO> servicesTOs = new ArrayList<>();
		List<HospitalServiceDTO> allServiceByHid = adminService
				.getAllServiceByHid(id);
		for (HospitalServiceDTO service1 : allServiceByHid) {
			ServicesTO servicesDTO = new ServicesTO();
			ServicesTO allServices = adminService.getAllServices(service1
					.getServiceId());
			servicesDTO.setServiceId(allServices.getServiceId());
			servicesDTO.setCategory(allServices.getCategory());
			servicesDTO.setServiceName(allServices.getServiceName());
			servicesTOs.add(servicesDTO);
		}

		LOG.info("---------------------- End of editHospital where hospital Id = "
				+ id);
		return new ModelAndView("Admin/hospital/editHospital", "hospitalDTO",
				hospitalDTO);
	}

	// post editing hospital register form....
	@RequestMapping(value = "/postEdit", method = RequestMethod.POST)
	public @ResponseBody ModelAndView postEdithospital(ModelMap map,
			@ModelAttribute HospitalServiceDTO hospitalServiceDTO) {
		LOG.info("++++++++++++++++++++++ Enter into postEdithospital where hospital Id = "
				+ hospitalServiceDTO.getHospitalId());

		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(hospitalServiceDTO
					.getEmpanelledDate()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "UPDATE empanellment SET empanelled_date ='" + date
				+ "',location = '" + hospitalServiceDTO.getLocation()
				+ "',address='" + hospitalServiceDTO.getResidenceAddresss()
				+ "',city ='" + hospitalServiceDTO.getCity() + "',"
				+ " pincode ='" + hospitalServiceDTO.getPincode()
				+ "',latitude = '" + hospitalServiceDTO.getLatitude() + "', "
				+ " longitude='" + hospitalServiceDTO.getLongitude()
				+ "',appt_booking='" + hospitalServiceDTO.getApptBooking()
				+ "',escalation_contact='"
				+ hospitalServiceDTO.getEscalationContact() + "',"
				+ "auth_signatory = '" + hospitalServiceDTO.getAuthSignatory()
				+ "',email_id='" + hospitalServiceDTO.getEmailIds()
				+ "',esc_mail ='" + hospitalServiceDTO.getEscMail()
				+ "' WHERE hospital_id = '"
				+ hospitalServiceDTO.getHospitalId() + "'";
		hrService.upDateQuery(query);

		LOG.info("************ Alter postEdithospital successfully  ");
		TablesUpdatesTO updates = new TablesUpdatesTO();
		updates.setOperationBy(hospitalServiceDTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		updates.setOperationDate(cal.getTime());
		updates.setOperations("Update Operation");
		updates.setColumnId(hospitalServiceDTO.getHospitalId());
		updates.setTableName("Empanellement");
		adminService.saveAdmin(updates);
		LOG.info("---------------------- End of postEdithospital  where hospital Id = "
				+ hospitalServiceDTO.getHospitalId());
		return new ModelAndView("redirect:viewHospitals");
	}

	@RequestMapping(value = "/viewHospitalByID")
	public @ResponseBody ModelAndView viewHospitalById(
			@RequestParam Integer id, ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewHospitalById where hospital Id = "
				+ id);
		HospitalServiceDTO hospitalDTO = new HospitalServiceDTO();
		EmpanellmentTO hospitalById = adminService.getHospitalById(id);
	
		HospitalServiceTO hospitalServicelById = adminService.getHospitalServicelById(hospitalById.getHospitalId());
		
		List<HospitalServiceDTO> allServiceByHid = adminService.getAllServiceByHid(id);
		model.addAttribute("serviceHospital", allServiceByHid);

		model.addAttribute("hospitalById", hospitalById);
		model.addAttribute("hospitalServicelById", hospitalServicelById);

		ArrayList<HashMap<String, String>> allservice = adminService.getAllServiceForHospital(id);
		model.addAttribute("allservice", allservice);
		List<HospitalServiceDTO> serviceUtilization = report.getServiceUtilization(hospitalById.getHospitalId());
		model.addAttribute("sreviceUtilization", serviceUtilization);

		List<HospitalServiceDTO> hospitalServiceSummary = report.getHospitalServiceSummary(hospitalById.getHospitalId());
		model.addAttribute("hospitalSreviceSummary", hospitalServiceSummary);

		CallsUpload calls = new CallsUpload();
		String path = "/home/welezohealth/whms/MOU/";
		// String path = "D:\\files\\doc\\";
		ArrayList<HashMap<String, String>> hospitalDocuments = calls
				.getEmployeeDocuments(id + "", path);
		model.addAttribute("documentList", hospitalDocuments);

		LOG.info("---------------------- End of viewHospitalById where hospital Id = "
				+ id);
		return new ModelAndView("Admin/hospital/viewHospitalByID",
				"hospitalDTO", hospitalDTO);
	}

	@RequestMapping(value = "/saveHospitalService", method = RequestMethod.POST)
	public ModelAndView saveHospitalServices(ModelMap model,
			@RequestParam Integer[] serviceId, Integer hospitalId,
			String empanelledDate) {
		SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
		Date expDate = null;
		String format = null;
		try {
			Date now = formatter1.parse(empanelledDate);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(now);
			calendar.add(Calendar.YEAR, 1);
			expDate = calendar.getTime();
			format = formatter1.format(expDate);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		for (int i = 0; i < serviceId.length; i++) {
			System.out.println(serviceId[i]);
			String query = "INSERT INTO hospital_service(service_id,hospital_id ,service_start_date,service_end_date)"
					+ " VALUES('"
					+ serviceId[i]
					+ "','"
					+ hospitalId
					+ "','"
					+ empanelledDate + "','" + format + "')";
			hrService.upDateQuery(query);
		}

		model.addAttribute("id", hospitalId);
		return new ModelAndView("redirect:viewHospitalByID");
	}

	@RequestMapping(value = "/editHospitalService")
	public ModelAndView editHospitalServices(ModelMap model,
			@RequestParam Integer id) {

		HashMap<String, String> hospitalServices = adminService
				.getHospitalServices(id);
		model.addAttribute("hospitalServices", hospitalServices);

		SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-mm-dd");
		try {
			String date = formatter.format(sdf.parse(hospitalServices
					.get("serviceStartDate")));
			String date1 = formatter.format(sdf.parse(hospitalServices
					.get("serviceEndDate")));
			model.addAttribute("startDate", date);
			model.addAttribute("endDate", date1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("Admin/hospital/editHospitalService");
	}

	@RequestMapping(value = "/postEditHospitalService", method = RequestMethod.POST)
	public ModelAndView postEditHospitalServices(ModelMap model,
			@RequestParam Integer id, Integer hospitalId, String startDate,
			String endDate) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(startDate));
			date1 = formatter.format(sdf.parse(endDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "UPDATE hospital_service SET service_start_date = '"
				+ date + "' , service_end_date = '" + date1 + "' WHERE id = '"
				+ id + "'";
		hrService.upDateQuery(query);

		model.addAttribute("id", hospitalId);
		return new ModelAndView("redirect:viewHospitalByID");
	}

	@RequestMapping(value = "/hospitalDocument", method = RequestMethod.POST)
	public ModelAndView uploadHospitalDocuments(ModelMap model,
			@RequestParam CommonsMultipartFile file,
			@RequestParam Integer hospitalId) throws Exception {

		String path = "/home/welezohealth/whms/MOU";
		// String path = "D:/files/doc";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();
			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();

		} catch (Exception e) {
			// System.out.println(e);
		}

		File uploadedFile = new File(path + "/" + filename);
		uploadedFile
				.renameTo(new File(path + "/" + hospitalId + "_" + filename));

		model.addAttribute("id", hospitalId);
		return new ModelAndView("redirect:viewHospitalByID");
	}

	/* =====End Of Hospital form here=========== */

	// ///////////////////////////start transaction part /////////////////////
	@RequestMapping(value = "/viewTransaction")
	public ModelAndView viewTranaction(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewTranaction");
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -7);
		Date todate1 = cal.getTime();
		model.addAttribute("fromdate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);

		TransactionMasterTO masterTO = new TransactionMasterTO();
		masterTO.setPaymentStatus(dateFormat.format(todate1));
		masterTO.setCardNumber(todate);
		masterTO.setTxStatus("");
		List<TransactionMasterDTO> alltransaction = adminService
				.getAlltransaction(masterTO);
		model.addAttribute("transation", alltransaction);
		LOG.info("---------------------- End of viewTranaction redirected to view transaction jsp page");
		return new ModelAndView("Admin/transaction/viewTransaction",
				"viewaccounts", masterTO);
	}

	@RequestMapping(value = "/filterTransaction")
	public ModelAndView filterTranaction(ModelMap model,
			TransactionMasterTO masterTO) {
		LOG.info("++++++++++++++++++++++ Enter into filterTranaction ");
		TransactionMasterTO masterTO1 = new TransactionMasterTO();
		List<TransactionMasterDTO> alltransaction = adminService
				.getAlltransaction(masterTO);
		model.addAttribute("transation", alltransaction);
		model.addAttribute("fromdate", masterTO.getPaymentStatus());
		model.addAttribute("toDate", masterTO.getCardNumber());
		model.addAttribute("txStatus", masterTO.getTxStatus());
		LOG.info("---------------------- End of filterTranaction Search thorugh "
				+ masterTO.getPaymentStatus()
				+ ","
				+ masterTO.getCardNumber()
				+ " and " + masterTO.getTxStatus());
		return new ModelAndView("Admin/transaction/viewTransaction",
				"viewaccounts", masterTO1);
	}

	@RequestMapping(value = "/editTransaction")
	public ModelAndView edittransaction(@RequestParam Integer transactionId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into edittransaction tx Id is : "
				+ transactionId);
		LOG.info("*Landing page here we can see all tx................. ");
		TransactionMasterTO txById = adminService.getTxById(transactionId);
		model.addAttribute("txById", txById);
		try {
			CustomerDeatilsTO custerDetails = adminService
					.getCustomerDetail(txById.getCustomerDeatils()
							.getCustomerId());
			model.addAttribute("custerDetails", custerDetails);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		ProductMasterTO productdetails = adminService.getproductById(txById
				.getProductMaster().getProductId());
		model.addAttribute("productdetails", productdetails);

		// EmployeeDTO employeeId = adminService.getEmployeeId(txById.getCsr());
		EmployeeDetailsDTO csrName = hrService.getEmployeeById(txById.getCsr());
		model.addAttribute("csr", csrName.getEmpName());

		EmployeeDetailsDTO executiveName = hrService.getEmployeeById(txById
				.getExecutive());
		model.addAttribute("executive", executiveName.getEmpName());

		ChannelsTO channelName = adminService.getChannelName(txById
				.getChannel());
		model.addAttribute("channelName", channelName.getChannelsName());

		ArrayList<HashMap<String, String>> allTxOffers = adminService
				.getAllTxOffers(txById.getTransactionId());
		model.addAttribute("services", allTxOffers);

		TeamsTO teamName = adminService.getTeamName(txById.getTeam());
		model.addAttribute("teamName", teamName);

		DispatchTrackingTO dispatchDetails = adminService
				.getDispatchDetails(txById.getTransactionId());
		model.addAttribute("dispatchDetails", dispatchDetails);

		ArrayList<HashMap<String, String>> customerPayment = adminService
				.getCustomerPayment(txById.getTransactionId());
		model.addAttribute("customerPayment", customerPayment);

		List<HospitalServiceDTO> serviceUsed = report.getServiceUsed(txById
				.getTransactionId());
		model.addAttribute("serviceUsed", serviceUsed);
		List<InteractionRegisterDTO> interactionByTx = report
				.getInteractionByTx(txById.getTransactionId());
		model.addAttribute("interactionByTx", interactionByTx);
		List<HealthAppointmentDTO> serviceUtilizationByTxOffer = healthAppt
				.getServiceUtilizationByTxOffer(txById.getTransactionId());
		model.addAttribute("serviceUtilizationByTxOffer",
				serviceUtilizationByTxOffer);

		CallsUpload calls = new CallsUpload();
		String path = "/home/welezohealth/whms/Applications/";
		// String path = "D:\\files\\doc\\";
		ArrayList<HashMap<String, String>> employeeDocuments = calls
				.getEmployeeDocuments(txById.getApplicationNo(), path);
		model.addAttribute("documentList", employeeDocuments);
		LOG.info("---------------------- End of EditTransaction ");
		return new ModelAndView("Admin/transaction/viewTransactionDetails");
	}

	@RequestMapping(value = "/viewPayments")
	public ModelAndView viewPayments(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -10);
		Date todate1 = cal.getTime();
		model.addAttribute("fromdate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);

		TransactionMasterTO masterTO = new TransactionMasterTO();
		masterTO.setPaymentStatus(dateFormat.format(todate1));
		masterTO.setCardNumber(todate);
		masterTO.setTxStatus("");
		List<TransactionMasterDTO> allPayments = adminService
				.getAllPayments(masterTO);
		model.addAttribute("alltransaction", allPayments);
		return new ModelAndView("Admin/payments/viewPayments", "viewaccounts",
				masterTO);
	}

	@RequestMapping(value = "/filterPayments")
	public ModelAndView filterPayments(ModelMap model,
			TransactionMasterTO masterTO) {

		List<TransactionMasterDTO> allPayments = adminService
				.getAllPayments(masterTO);
		model.addAttribute("alltransaction", allPayments);

		return new ModelAndView("Admin/payments/viewPayments", "viewaccounts",
				masterTO);
	}

	@RequestMapping(value = "/bulkpayment")
	public ModelAndView viewBulkPaymentCheque(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewBulkPaymentCheque");
		List<TransactionMasterDTO> paymentsBulkOperation = adminService
				.getPaymentsBulkOperation();
		model.addAttribute("paymentsBulkOperation", paymentsBulkOperation);

		model.addAttribute("headline", "CHEQUE PRESENTATION");
		model.addAttribute("status", false);
		PaymentDetailsDTO payment = new PaymentDetailsDTO();
		LOG.info("---------------------- End of viewBulkPaymentCheque");
		return new ModelAndView("Admin/payments/viewBulkPayment", "payment",
				payment);
	}

	@RequestMapping(value = "/bulkpaymentOthers")
	public ModelAndView viewBulkPaymentOthers(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewBulkPaymentOthers");
		List<TransactionMasterDTO> paymentsBulkOperation = adminService
				.getPaymentsBulkOperationForOthers();
		model.addAttribute("paymentsBulkOperation", paymentsBulkOperation);
		model.addAttribute("headline", "PAYMENT APPROVAL");
		model.addAttribute("status", true);
		PaymentDetailsDTO payment = new PaymentDetailsDTO();
		LOG.info("---------------------- End of viewBulkPaymentOthers");
		return new ModelAndView("Admin/payments/viewBulkPayment", "payment",
				payment);
	}

	@RequestMapping(value = "/savebulkpayment")
	public @ResponseBody ModelAndView saveBulkPayment(ModelMap model,
			PaymentDetailsDTO paymentDetailsTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveBulkPayment");
		Integer[] paymentIdArray = paymentDetailsTO.getPaymentIdArray();
		for (int i = 0; i < paymentIdArray.length; i++) {
			LOG.info("************ Updating Bulk  payment details Payment Id is : "
					+ (paymentIdArray[i]));
			PaymentDetailsTO paymentById = adminService
					.getPaymentById(paymentIdArray[i]);
			PaymentDetailsTO paymentDetailsTO2 = new PaymentDetailsTO();
			TransactionMasterTO tx = new TransactionMasterTO();

			tx.setTransactionId(paymentById.getTransactionMaster()
					.getTransactionId());

			paymentDetailsTO2.setPaymentId(paymentById.getPaymentId());
			paymentDetailsTO2.setTransactionMaster(tx);
			paymentDetailsTO2.setModeOfPayment(paymentById.getModeOfPayment());
			paymentDetailsTO2.setAmount(paymentById.getAmount());
			paymentDetailsTO2
					.setChequeAuthCode(paymentById.getChequeAuthCode());
			paymentDetailsTO2
					.setTerminalNumber(paymentById.getTerminalNumber());
			paymentDetailsTO2.setBank(paymentById.getBank());
			paymentDetailsTO2.setApprovalBy(paymentById.getApprovalBy());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			paymentDetailsTO2.setChequeDate(paymentById.getChequeDate());
			String format1 = (paymentDetailsTO.getPrensentedDate());
			try {
				Date date1 = formatter.parse(format1);
				paymentDetailsTO2.setPrensentedDate(date1);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			String format2 = (paymentDetailsTO.getApprovalDate());
			try {
				Date date2 = formatter.parse(format2);
				paymentDetailsTO2.setApprovalDate(date2);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}

			paymentDetailsTO2.setUpdatedBy(paymentDetailsTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			paymentDetailsTO2.setUpdatedDate((cal.getTime()));
			paymentDetailsTO2.setCreatedBy(paymentById.getCreatedBy());
			paymentDetailsTO2.setCreatedDate(paymentById.getCreatedDate());

			paymentDetailsTO2.setStatus(paymentDetailsTO.getStatus());
			// paymentDetailsTO2.setApprovalOn(paymentDetailsTO.getApprovalOn());
			adminService.upDateAdmin(paymentDetailsTO2);
			LOG.info("************ Upadting Transaction Master from bulk payment Where Tx Id is : "
					+ paymentById.getTransactionMaster().getTransactionId());
			TransactionMasterTO txById = adminService.getTxById(paymentById
					.getTransactionMaster().getTransactionId());
			ProductMasterTO proMasterTO = new ProductMasterTO();
			proMasterTO.setProductId(txById.getProductMaster().getProductId());

			TransactionMasterTO transactionMasterTO = new TransactionMasterTO();
			transactionMasterTO.setTransactionId(txById.getTransactionId());
			String txStatus = "New";

			if (paymentDetailsTO.getStatus().equalsIgnoreCase(
					"Payment Approved")) {
				txStatus = "Payment Approved";
				LOG.info("************ If( Payment Approved ) ");
				DispatchTrackingTO dispatchTrackingTO = new DispatchTrackingTO();
				Date date1 = new Date();
				dispatchTrackingTO.setCreatedDate(date1);
				dispatchTrackingTO.setCreatedBy(txById.getCreatedBy());
				dispatchTrackingTO.setDispatchStatus("New");
				dispatchTrackingTO.setTransactionMaster(transactionMasterTO);
				dispatchTrackingTO.setApplicationStatus("New");
				adminService.saveAdmin(dispatchTrackingTO);
				LOG.info("************ same data enter into dispatch from bulk payment where Dispatch Id is : "
						+ dispatchTrackingTO.getTrackId());

				hrService
						.upDateQuery("UPDATE welezohe_accounts.acc_trx SET isSettled = 1,created_by ='"
								+ txById.getUpdateBy()
								+ "', created_date = CURRENT_TIMESTAMP WHERE pay_ref ='"
								+ txById.getApplicationNo() + "'");
				if (txById.getChannel().equals(8)) {
					System.out.println("channel : " + txById.getChannel());
					report.updateCardNumber(txById.getCustomerDeatils()
							.getCustomerId(), txById.getTransactionId());
				}
			} else if (paymentDetailsTO.getStatus().equalsIgnoreCase(
					"Cheque Returned")) {
				txStatus = "Cheque Recollect";
			} else {
				txStatus = "In Progress";
			}
			String query = "UPDATE transaction_master SET tx_status = '"
					+ txStatus + "' ,update_by = '" + txById.getCreatedBy()
					+ "',update_date=CURRENT_DATE WHERE transaction_id = '"
					+ txById.getTransactionId() + "'";
			hrService.upDateQuery(query);

			if (paymentDetailsTO.getStatus().equalsIgnoreCase(
					"Payment Approved")) {
				if (txById.getProductMaster().getProductId() == 15) {
					ArrayList<HashMap<String, String>> allCollectionOffers = adminService
							.getAllCollectionOffers(report
									.getCollectionIdThruTx(txById
											.getTransactionId()));
					for (HashMap<String, String> dto : allCollectionOffers) {
						int sId = Integer.parseInt(dto.get("serviceId"));
						int qty = Integer.parseInt(dto.get("quantity"));
						ServicesTO servicesTO = new ServicesTO();
						servicesTO.setServiceId(sId);
						TransactionOffersTO offersTO = new TransactionOffersTO();
						offersTO.setQuantity(qty);
						offersTO.setServices(servicesTO);
						offersTO.setTransactionMaster(transactionMasterTO);
						String voucherNumber = healthAppt.getVoucherNumber(sId,
								qty);
						offersTO.setVoucherNo(voucherNumber);
						healthAppt.clearVoucherNumber(voucherNumber, sId);
						adminService.saveAdmin(offersTO);
						LOG.info("************ Transaction Offers Customized Sevice Voucher entry : "
								+ voucherNumber
								+ " where Customized Service Id is " + sId);
					}

				} else {
					List<ProductOffersDTO> allProductSevice = adminService
							.getAllProductSevice(txById.getProductMaster()
									.getProductId());

					for (ProductOffersDTO dto : allProductSevice) {
						ServicesTO servicesTO = new ServicesTO();
						servicesTO.setServiceId(dto.getServicesId());
						TransactionOffersTO offersTO = new TransactionOffersTO();
						offersTO.setQuantity(dto.getQuantity());
						offersTO.setServices(servicesTO);
						offersTO.setTransactionMaster(transactionMasterTO);
						String voucherNumber = healthAppt.getVoucherNumber(
								dto.getServicesId(), dto.getQuantity());
						offersTO.setVoucherNo(voucherNumber);
						healthAppt.clearVoucherNumber(voucherNumber,
								dto.getServicesId());
						adminService.saveAdmin(offersTO);
						LOG.info("************ Transaction Offers Voucher entry : "
								+ voucherNumber
								+ " where Service Id is "
								+ dto.getServicesId());
					}
				}
			}
		}
		LOG.info("---------------------- End of saveBulkPayment");
		return new ModelAndView("redirect:viewPayments");
	}

	@RequestMapping(value = "/editpayment")
	public ModelAndView editPayment(@RequestParam Integer paymentId,
			ModelMap model) {
		PaymentDetailsDTO paymentDetailsTO = new PaymentDetailsDTO();
		PaymentDetailsTO paymentById = adminService.getPaymentById(paymentId);
		String approval = null, cheque = null, expiry = null, presented = null;
		if (paymentById.getApprovalDate() != null) {
			approval = new SimpleDateFormat("dd/MM/yyyy").format(paymentById
					.getApprovalDate());
		}
		if (paymentById.getChequeDate() != null) {
			cheque = new SimpleDateFormat("dd/MM/yyyy").format(paymentById
					.getChequeDate());
		}

		if (paymentById.getPrensentedDate() != null) {
			presented = new SimpleDateFormat("dd/MM/yyyy").format(paymentById
					.getPrensentedDate());
		}
		String[] payment = { approval, cheque, expiry, presented };
		model.addAttribute("paymentDate", payment);
		model.addAttribute("paymentById", paymentById);
		return new ModelAndView("Admin/payments/editPayment",
				"paymentDetailsTO", paymentDetailsTO);
	}

	@RequestMapping(value = "/postEditPayment")
	public @ResponseBody ModelAndView postEditPayment(ModelMap model,
			PaymentDetailsDTO paymentDetailsTO) {
		LOG.info("++++++++++++++++++++++ Enter into postEditPayment where payment Id is : "
				+ paymentDetailsTO.getPaymentId());
		LOG.info("************ Updating payment details ");
		PaymentDetailsTO paymentById = adminService
				.getPaymentById(paymentDetailsTO.getPaymentId());
		PaymentDetailsTO paymentDetailsTO2 = new PaymentDetailsTO();
		TransactionMasterTO tx = new TransactionMasterTO();
		tx.setTransactionId(paymentById.getTransactionMaster()
				.getTransactionId());
		paymentDetailsTO2.setTransactionMaster(tx);
		paymentDetailsTO2.setPaymentId(paymentDetailsTO.getPaymentId());
		paymentDetailsTO2.setModeOfPayment(paymentDetailsTO.getModeOfPayment());
		paymentDetailsTO2.setAmount(paymentDetailsTO.getAmount());
		paymentDetailsTO2.setChequeAuthCode(paymentDetailsTO
				.getChequeAuthCode());
		paymentDetailsTO2.setTerminalNumber(paymentDetailsTO
				.getTerminalNumber());
		paymentDetailsTO2.setBank(paymentDetailsTO.getBank());
		paymentDetailsTO2.setApprovalBy(paymentDetailsTO.getApprovalBy());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format = (paymentDetailsTO.getChequeDate());
		try {
			Date date = formatter.parse(format);
			paymentDetailsTO2.setChequeDate(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		String format1 = (paymentDetailsTO.getPrensentedDate());
		try {
			Date date1 = formatter.parse(format1);
			paymentDetailsTO2.setPrensentedDate(date1);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		String format2 = (paymentDetailsTO.getApprovalDate());
		try {
			Date date2 = formatter.parse(format2);
			paymentDetailsTO2.setApprovalDate(date2);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}

		paymentDetailsTO2.setUpdatedBy(paymentDetailsTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		paymentDetailsTO2.setUpdatedDate((cal.getTime()));
		paymentDetailsTO2.setCreatedBy(paymentById.getCreatedBy());
		paymentDetailsTO2.setCreatedDate(paymentById.getCreatedDate());

		paymentDetailsTO2.setStatus(paymentDetailsTO.getStatus());
		// paymentDetailsTO2.setApprovalOn(paymentDetailsTO.getApprovalOn());
		adminService.upDateAdmin(paymentDetailsTO2);
		LOG.info("************ Updating Transaction Master where Tx Id is "
				+ paymentById.getTransactionMaster().getTransactionId());
		TransactionMasterTO txById = adminService.getTxById(paymentById
				.getTransactionMaster().getTransactionId());

		ProductMasterTO proMasterTO = new ProductMasterTO();
		proMasterTO.setProductId(txById.getProductMaster().getProductId());

		TransactionMasterTO transactionMasterTO = new TransactionMasterTO();
		transactionMasterTO.setTransactionId(txById.getTransactionId());
		String txStatus = "New";

		if (paymentDetailsTO.getStatus().equalsIgnoreCase("Payment Approved")) {
			txStatus = "Payment Approved";

			DispatchTrackingTO dispatchTrackingTO = new DispatchTrackingTO();
			Date date1 = new Date();
			dispatchTrackingTO.setCreatedDate(date1);
			dispatchTrackingTO.setCreatedBy(txById.getCreatedBy());
			dispatchTrackingTO.setDispatchStatus("New");
			dispatchTrackingTO.setTransactionMaster(transactionMasterTO);
			dispatchTrackingTO.setApplicationStatus("New");
			adminService.saveAdmin(dispatchTrackingTO);
			LOG.info("************ same data enter into dispatch where Dispatch Id is : "
					+ dispatchTrackingTO.getTrackId());
			hrService
					.upDateQuery("UPDATE welezohe_accounts.acc_trx SET isSettled = 1,created_by ='"
							+ txById.getCreatedBy()
							+ "', created_date = CURRENT_TIMESTAMP WHERE pay_ref ='"
							+ txById.getApplicationNo() + "'");
			LOG.info("************ Accounts transaction is setteled application No is : "
					+ txById.getApplicationNo());

			if (txById.getChannel().equals(8)) {
				// System.out.println("channel : "+txById.getChannel());
				report.updateCardNumber(txById.getCustomerDeatils()
						.getCustomerId(), txById.getTransactionId());
			}
		} else if (paymentDetailsTO.getStatus().equalsIgnoreCase(
				"Cheque Returned")) {
			txStatus = "Cheque Recollect";
		} else {
			txStatus = "In Progress";
		}
		String query = "UPDATE transaction_master SET tx_status = '" + txStatus
				+ "' ,update_by = '" + txById.getCreatedBy()
				+ "',update_date=CURRENT_DATE WHERE transaction_id = '"
				+ txById.getTransactionId() + "'";
		hrService.upDateQuery(query);

		if (paymentDetailsTO.getStatus().equalsIgnoreCase("Payment Approved")) {
			if (txById.getProductMaster().getProductId() == 15) {
				ArrayList<HashMap<String, String>> allCollectionOffers = adminService
						.getAllCollectionOffers(report
								.getCollectionIdThruTx(txById
										.getTransactionId()));
				for (HashMap<String, String> dto : allCollectionOffers) {
					int sId = Integer.parseInt(dto.get("serviceId"));
					int qty = Integer.parseInt(dto.get("quantity"));
					ServicesTO servicesTO = new ServicesTO();
					servicesTO.setServiceId(sId);
					TransactionOffersTO offersTO = new TransactionOffersTO();
					offersTO.setQuantity(qty);
					offersTO.setServices(servicesTO);
					offersTO.setTransactionMaster(transactionMasterTO);
					String voucherNumber = healthAppt
							.getVoucherNumber(sId, qty);
					offersTO.setVoucherNo(voucherNumber);
					healthAppt.clearVoucherNumber(voucherNumber, sId);
					adminService.saveAdmin(offersTO);
					LOG.info("************ Transaction Offers Customized Sevice Voucher entry : "
							+ voucherNumber
							+ " where Customized Service Id is " + sId);
				}

			} else {
				List<ProductOffersDTO> allProductSevice = adminService
						.getAllProductSevice(txById.getProductMaster()
								.getProductId());

				for (ProductOffersDTO dto : allProductSevice) {
					ServicesTO servicesTO = new ServicesTO();
					servicesTO.setServiceId(dto.getServicesId());
					TransactionOffersTO offersTO = new TransactionOffersTO();
					offersTO.setQuantity(dto.getQuantity());
					offersTO.setServices(servicesTO);
					offersTO.setTransactionMaster(transactionMasterTO);
					String voucherNumber = healthAppt.getVoucherNumber(
							dto.getServicesId(), dto.getQuantity());
					offersTO.setVoucherNo(voucherNumber);
					healthAppt.clearVoucherNumber(voucherNumber,
							dto.getServicesId());
					adminService.saveAdmin(offersTO);
					LOG.info("************ Transaction Offers Voucher entry : "
							+ voucherNumber + " where Service Id is "
							+ dto.getServicesId());
				}
			}
		}
		return new ModelAndView("redirect:viewPayments");
	}

	@RequestMapping(value = "/viewdispatch")
	public ModelAndView viewDispatchTrack(ModelMap model) {
		DispatchTrackingDTO dispatchDTO = new DispatchTrackingDTO();
		LOG.info("++++++++++++++++++++++ Enter into viewDispatchTrack ");
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -15);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		dispatchDTO.setCreatedBy(dateFormat.format(todate1));
		dispatchDTO.setDispatchDate(dateFormat.format(date));
		dispatchDTO.setDispatchStatus("");
		List<DispatchTrackingDTO> allDispatchTracks = adminService
				.getAllDispatchTracks(dispatchDTO);
		model.addAttribute("dispatchTrack", allDispatchTracks);
		LOG.info("---------------------- End of viewDispatchTrack");
		return new ModelAndView("Admin/dispatch/viewdispatch", "dispatchDTO",
				dispatchDTO);
	}

	@RequestMapping(value = "/searchDispatch")
	public ModelAndView searchDispatch(ModelMap model,
			DispatchTrackingDTO dispatchDTO) {
		LOG.info("++++++++++++++++++++++ Enter into searchDispatch");
		List<DispatchTrackingDTO> allDispatchTracks = adminService
				.getAllDispatchTracks(dispatchDTO);

		model.addAttribute("dispatchTrack", allDispatchTracks);
		LOG.info("---------------------- End of searchDispatch ");
		return new ModelAndView("Admin/dispatch/viewdispatch", "dispatchDTO",
				dispatchDTO);
	}

	@RequestMapping(value = "/editDispatch")
	public ModelAndView editDispatchTrack(@RequestParam Integer trackId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into editDispatchTrack Where TrackId is : "
				+ trackId);
		DispatchTrackingDTO dispatchTrackingDTO = new DispatchTrackingDTO();
		DispatchTrackingTO dispatchTrackById = adminService
				.getDispatchTrackById(trackId);
		model.addAttribute("dispatchTrackById", dispatchTrackById);

		TransactionMasterTO txById = adminService.getTxById(dispatchTrackById
				.getTransactionMaster().getTransactionId());
		model.addAttribute("txById", txById);

		CustomerDeatilsTO customerDetail = adminService
				.getCustomerDetail(txById.getCustomerDeatils().getCustomerId());
		model.addAttribute("custerDetails", customerDetail);
		AddressDTO residenceAddress = adminService.getAllAddress(
				customerDetail.getCustomerId(), "Residence");
		model.addAttribute("residenceAddress", residenceAddress);
		AddressDTO workplaceAddress = adminService.getAllAddress(
				customerDetail.getCustomerId(), "WorkPlace");
		model.addAttribute("WorkPlace", workplaceAddress);

		ArrayList<HashMap<String, String>> allTxOffers = adminService
				.getAllTxOffers(dispatchTrackById.getTransactionMaster()
						.getTransactionId());
		model.addAttribute("services", allTxOffers);

		ProductMasterTO getproductById = adminService.getproductById(txById
				.getProductMaster().getProductId());
		model.addAttribute("productName", getproductById.getProductName());

		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);

		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		LOG.info("---------------------- End of editDispatchTrack");
		return new ModelAndView("Admin/dispatch/editDispatch",
				"dispatchTrackingTO", dispatchTrackingDTO);
	}

	@RequestMapping(value = "/posteditDispatch")
	public ModelAndView postEditDisPatchTrack(ModelMap model,
			DispatchTrackingDTO dispatchTrackingTO) {
		LOG.info("++++++++++++++++++++++ Enter into postEditDisPatchTrack where Track Id is : "
				+ dispatchTrackingTO.getTrackId());
		LOG.info("************ Updating Voucher Numbers where Tx Id is :  "
				+ dispatchTrackingTO.getTransactionId());

		report.updateTxOffers(dispatchTrackingTO);
		model.addAttribute("trackId", dispatchTrackingTO.getTrackId());
		LOG.info("---------------------- End of postEditDisPatchTrack(updated voucher No.)");
		return new ModelAndView("redirect:editDispatch");
	}

	@RequestMapping(value = "/saveDispatch")
	public ModelAndView saveDisPatchTrack(ModelMap model,
			DispatchTrackingDTO dispatchTrackingTO) {
		LOG.info("++++++++++++++++++++++ Enter into saveDisPatchTrack (Updated Dispatch Tracker ) where tracker Id is : "
				+ dispatchTrackingTO.getTrackId());
		DispatchTrackingTO dispatchTrackById = adminService
				.getDispatchTrackById(dispatchTrackingTO.getTrackId());
		TransactionMasterTO masterTO = new TransactionMasterTO();
		masterTO.setTransactionId(dispatchTrackById.getTransactionMaster()
				.getTransactionId());

		DispatchTrackingTO trackingTO = new DispatchTrackingTO();
		trackingTO.setTrackId(dispatchTrackingTO.getTrackId());
		trackingTO.setConsignmentReference(dispatchTrackingTO
				.getConsignmentReference());
		trackingTO.setDispatchStatus(dispatchTrackingTO.getDispatchStatus());
		trackingTO.setCreatedBy(Integer.parseInt(dispatchTrackingTO
				.getCreatedBy()));
		Calendar cal = Calendar.getInstance();
		trackingTO.setCreatedDate(cal.getTime());
		trackingTO.setDispatchThrough(dispatchTrackingTO.getDispatchThrough());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format = dispatchTrackingTO.getDispatchDate();
		try {
			Date date = formatter.parse(format);
			trackingTO.setDispatchDate(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		trackingTO.setTransactionMaster(masterTO);
		trackingTO.setApplicationStatus(dispatchTrackById
				.getApplicationStatus());
		trackingTO.setDeliveryStatus(dispatchTrackingTO.getDispatchStatus());
		adminService.upDateAdmin(trackingTO);
		LOG.info("---------------------- End of saveDisPatchTrack (Updated Dispatch Tracker ) ");
		return new ModelAndView("redirect:viewdispatch");
	}

	@RequestMapping(value = "/viewDispatchDetails")
	public ModelAndView viewDispatchDetails(@RequestParam Integer trackId,
			ModelMap model) {

		LOG.info("++++++++++++++++++++++ Enter into viewDispatchDetails (view dispatch by Id ) where tracker Id is : "
				+ trackId);
		DispatchTrackingDTO dispatchTrackingDTO = new DispatchTrackingDTO();
		DispatchTrackingTO dispatchTrackById = adminService
				.getDispatchTrackById(trackId);
		model.addAttribute("dispatchTrackById", dispatchTrackById);

		TransactionMasterTO txById = adminService.getTxById(dispatchTrackById
				.getTransactionMaster().getTransactionId());
		model.addAttribute("txById", txById);

		ProductMasterTO getproductById = adminService.getproductById(txById
				.getProductMaster().getProductId());
		model.addAttribute("productName", getproductById.getProductName());
		CustomerDeatilsTO customerDetail = adminService
				.getCustomerDetail(txById.getCustomerDeatils().getCustomerId());
		model.addAttribute("custerDetails", customerDetail);

		AddressDTO residenceAddress = adminService.getAllAddress(
				customerDetail.getCustomerId(), "Residence");
		model.addAttribute("residenceAddress", residenceAddress);
		AddressDTO workplaceAddress = adminService.getAllAddress(
				customerDetail.getCustomerId(), "WorkPlace");
		model.addAttribute("WorkPlace", workplaceAddress);
		ArrayList<HashMap<String, String>> allTxOffers = adminService
				.getAllTxOffers(dispatchTrackById.getTransactionMaster()
						.getTransactionId());
		model.addAttribute("services", allTxOffers);

		/*
		 * List<EmployeeDTO> allEmployeeDetails =
		 * adminService.getAllEmployeeDetails();
		 * model.addAttribute("allEmployeeDetails", allEmployeeDetails);
		 */

		CallsUpload calls = new CallsUpload();
		String path = "/home/welezohealth/whms/Applications/";
		// String path = "D:\\files\\doc\\";
		ArrayList<HashMap<String, String>> employeeDocuments = calls
				.getEmployeeDocuments(txById.getApplicationNo(), path);
		model.addAttribute("documentList", employeeDocuments);

		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);

		ArrayList<HashMap<String, String>> dispatchList = adminService
				.getDispatchList(dispatchTrackById.getTransactionMaster()
						.getTransactionId());
		model.addAttribute("dispatchList", dispatchList);

		LOG.info("---------------------- End of viewDispatchDetails ");
		return new ModelAndView("Admin/dispatch/dispatchDetails",
				"dispatchTrackingTO", dispatchTrackingDTO);
	}

	@RequestMapping(value = "/editDispatchdetails")
	public ModelAndView editDispatchDetails(
			DispatchTrackingDTO dispatchTrackingDTO, ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into editDispatchDetails ");
		DispatchTrackingTO dispatchTrackById = adminService
				.getDispatchTrackById(dispatchTrackingDTO.getTrackId());
		dispatchTrackById.setReceviedBy(dispatchTrackingDTO.getReceviedBy());
		dispatchTrackById.setDeliveryStatus(dispatchTrackingDTO
				.getDeliveryStatus());
		dispatchTrackById.setUpdatedBy(dispatchTrackingDTO.getUpdatedBy());
		Calendar cal = Calendar.getInstance();
		dispatchTrackById.setUpdatedDate(cal.getTime());

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format = dispatchTrackingDTO.getDispatchDate();
		try {
			Date date = formatter.parse(format);
			dispatchTrackById.setReceivedDate(date);
		} catch (ParseException e) {
			LOG.error(e);
		}
		adminService.upDateAdmin(dispatchTrackById);

		model.addAttribute("trackId", dispatchTrackingDTO.getTrackId());
		return new ModelAndView("redirect:viewDispatchDetails");
	}

	@RequestMapping(value = "/viewpresales")
	public ModelAndView addpresales(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into addpresales(go to view presales jsp page)");
		PresalesDTO presalesDTO = new PresalesDTO();
		List<PresalesTO> allpresales = adminService.getAllpresales();
		List<PresalesTO> presalesList = new ArrayList<>();
		for (PresalesTO preSales : allpresales) {
			PresalesTO presalesTO = new PresalesTO();
			if (preSales.getLeadsId() > 1) {
				presalesTO.setLeadsId(preSales.getLeadsId());
				presalesTO.setCustomerName(preSales.getCustomerName());
				try {
					ProductMasterTO getproductById = adminService
							.getproductById(Integer.parseInt(preSales
									.getProductIntrested()));
					presalesTO.setProductIntrested(getproductById
							.getProductName());
				} catch (NumberFormatException e) {
					LOG.error(e);
				}
				try {
					AddressTO Address = adminService.getAddress(preSales
							.getAddress().getAid());
					presalesTO.setAddress(Address);
				} catch (Exception e) {
					LOG.error(e);
				}

				ChannelsTO channelName = adminService.getChannelName(preSales
						.getChannel());
				if (preSales.getChannel() != 0) {
					presalesTO.setRemark(channelName.getChannelsName());
				}
				presalesTO.setDateAppointment(preSales.getDateAppointment());
				// EmployeeDTO employeeId1 =
				// adminService.getEmployeeId(preSales.getExecutive());
				// presalesTO.setExecutive(employeeId1.getEmpName());
				// EmployeeDTO employeeId =
				// adminService.getEmployeeId(preSales.getCsr());
				// presalesTO.setCsr(employeeId.getEmpName());
				presalesTO.setStatus(preSales.getStatus());
				presalesList.add(presalesTO);
			}
		}

		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);

		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);
		model.addAttribute("presalesDetail", presalesList);
		LOG.info("---------------------- End of addpresales redirected to viewpresales jsp");
		return new ModelAndView("Admin/presales/viewpresales", "presalesDTO",
				presalesDTO);
	}

	// depends on id able to see customer lead details in view..fetching data
	@RequestMapping(value = "/presalesview")
	public ModelAndView viewPresalesById(@RequestParam Integer leadsId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into viewPresalesByID where presales Id is : "
				+ leadsId);
		PresalesTO presalesById = adminService.getPresalesById(leadsId);
		HashMap<String, String> presalesThrId = adminService
				.getPresalesThrId(leadsId);
		model.addAttribute("leadsById", presalesThrId);
		List<TeleCallRecordIdDTO> teleCallsByPhoneNo = callrecordservice
				.teleCallsByPhoneNo(presalesThrId.get("primaryMob"));
		model.addAttribute("teleCallsByPhoneNo", teleCallsByPhoneNo);

		List<PresalesTO> searchPresales = adminService
				.SearchPresales(presalesById.getAddress().getAid());
		model.addAttribute("listPresales", searchPresales);
		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);
		LOG.info("---------------------- End of viewPresalesByID ");
		return new ModelAndView("Admin/presales/viewPresalesByID",
				"presalesDTO", new PresalesDTO());
	}

	@RequestMapping(value = "/editpresales")
	public ModelAndView editpresales(@RequestParam Integer leadsId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into editpresales where presales Id is : "
				+ leadsId);
		HashMap<String, String> presalesThrId = adminService
				.getPresalesThrId(leadsId);
		model.addAttribute("leadsById", presalesThrId);
		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);
		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		List<ApplicationStockTO> allApplicationNo = adminService
				.getAllApplicationNo("Issued");
		model.addAttribute("allApplicationNo", allApplicationNo);

		LOG.info("---------------------- End of editpresales");
		return new ModelAndView("Admin/presales/editpresales", "presalesDTO",
				new PresalesDTO());
	}

	// new presales details save in leads table...
	@RequestMapping(value = "/savePresales")
	public ModelAndView savepresales(ModelMap map,
			@ModelAttribute PresalesDTO presalesDTO) {

		LOG.info("++++++++++++++++++++++ Enter into savepresales where cust Name is : "+ presalesDTO.getCustomerName());
		AddressTO addressTO = new AddressTO();
		addressTO.setResidenceAddresss(presalesDTO.getResidenceAddresss());
		addressTO.setPrimaryMob(presalesDTO.getPrimaryMob());
		addressTO.setCity(presalesDTO.getCity());
		addressTO.setPincode(presalesDTO.getPincode());
		adminService.saveAdmin(addressTO);

		PresalesTO presalesTO = new PresalesTO();
		presalesTO.setCustomerName(presalesDTO.getCustomerName());
		presalesTO.setProductIntrested(presalesDTO.getProductIntrested());
		presalesTO.setCsr(presalesDTO.getCsr());
		presalesTO.setTeamName(presalesDTO.getTeamName());
		presalesTO.setChannel(presalesDTO.getChannel());
		presalesTO.setAppointmentType("Fresh");
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String format = presalesDTO.getDateAppointment();
		try {
			Date date = formatter.parse(format);
			presalesTO.setDateAppointment(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		presalesTO.setTimeAppointment(presalesDTO.getTimeAppointment());
		presalesTO.setExecutive(presalesDTO.getExecutive());
		presalesTO.setStatus("New Appointment");
		presalesTO.setCreatedBy(presalesDTO.getCreatedBy());
		Calendar cal = Calendar.getInstance();
		presalesTO.setCreatedDate((cal.getTime()));
		presalesTO.setAddress(addressTO);
		UsermasterDTO userById = userService.getUserById(presalesDTO
				.getCreatedBy());
		presalesTO.setRemark(userById.getUserName() + " on " + cal.getTime()
				+ presalesDTO.getRemark());
		adminService.saveAdmin(presalesTO);
		LOG.info("---------------------- End of savepresales (saved successfully)");
		return new ModelAndView("redirect:searchAppointment");
	}

	@RequestMapping(value = "/postEditpresales")
	public ModelAndView postEditPresales(ModelMap model, PresalesDTO presalesDTO) {
		LOG.info("++++++++++++++++++++++ Enter into postEditPresales presales Id is : "
				+ presalesDTO.getLeadsId());
		PresalesTO presalesById = adminService.getPresalesById(presalesDTO
				.getLeadsId());
		AddressTO addressTO = new AddressTO();
		addressTO.setAid(presalesById.getAddress().getAid());
		addressTO.setResidenceAddresss(presalesDTO.getResidenceAddresss());
		addressTO.setPrimaryMob(presalesDTO.getPrimaryMob());
		addressTO.setCity(presalesDTO.getCity());
		addressTO.setPincode(presalesDTO.getPincode());
		adminService.saveOrUpdate(addressTO);

		if (presalesDTO.getStatus() == null) {
			LOG.info("************ Inside postEditPresales if status == null ");
			PresalesTO presalesTO = new PresalesTO();
			presalesTO.setLeadsId(presalesDTO.getLeadsId());
			presalesTO.setCustomerName(presalesDTO.getCustomerName());
			presalesTO.setProductIntrested(presalesDTO.getProductIntrested());
			presalesTO.setCsr(presalesDTO.getCsr());
			presalesTO.setTeamName(presalesDTO.getTeamName());
			presalesTO.setChannel(presalesDTO.getChannel());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String format = (presalesDTO.getDateAppointment());
			try {
				Date date = formatter.parse(format);
				presalesTO.setDateAppointment(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			presalesTO.setUpdatedBy(presalesDTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			presalesTO.setUpdatedDate((cal.getTime()));
			presalesTO.setCreatedBy(presalesById.getCreatedBy());
			presalesTO.setCreatedDate(presalesById.getCreatedDate());
			presalesTO.setTimeAppointment(presalesDTO.getTimeAppointment());
			presalesTO.setExecutive(presalesDTO.getExecutive());
			presalesTO.setStatus("New Appointment");
			UsermasterDTO userById = userService.getUserById(presalesDTO
					.getCreatedBy());
			presalesTO.setAppointmentType(presalesById.getAppointmentType());
			presalesTO.setRemark(presalesById.getRemark() + "\n - "
					+ userById.getUserName() + " on " + cal.getTime()
					+ " - Did Not Select Any Status ");
			presalesTO.setReasons(presalesDTO.getReasons());
			presalesTO.setMeetingStatus(presalesDTO.getMeetingStatus());
			presalesTO.setAddress(addressTO);
			adminService.upDateAdmin(presalesTO);

		} else if (presalesDTO.getStatus().equalsIgnoreCase("Rescheduled")) {
			LOG.info("************ Inside postEditPresales if status == 'Rescheduled' ");
			// updating same values and changing status
			PresalesTO presalesById2 = adminService.getPresalesById(presalesDTO
					.getLeadsId());
			PresalesTO presalesTO = new PresalesTO();
			presalesTO.setLeadsId(presalesDTO.getLeadsId());
			presalesTO.setCustomerName(presalesById2.getCustomerName());
			presalesTO.setProductIntrested(presalesById2.getProductIntrested());
			presalesTO.setCsr(presalesById2.getCsr());
			presalesTO.setTeamName(presalesById2.getTeamName());
			presalesTO.setChannel(presalesById2.getChannel());

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String format = (presalesDTO.getDateAppointment());
			try {
				Date date = formatter.parse(format);
				presalesTO.setDateAppointment(presalesById2.getDateAppointment());
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			presalesTO.setUpdatedBy(presalesDTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			presalesTO.setUpdatedDate((cal.getTime()));
			presalesTO.setCreatedBy(presalesById2.getCreatedBy());
			presalesTO.setCreatedDate(presalesById2.getCreatedDate());

			presalesTO.setTimeAppointment(presalesById2.getTimeAppointment());
			presalesTO.setExecutive(presalesById2.getExecutive());
			presalesTO.setStatus(presalesDTO.getStatus());
			presalesTO.setAppointmentType(presalesById2.getAppointmentType());
			UsermasterDTO userById = userService.getUserById(presalesDTO
					.getCreatedBy());
			presalesTO.setRemark(presalesById2.getRemark() + " - "
					+ userById.getUserName() + " on " + cal.getTime()
					+ "Rescheduled");
			presalesTO.setReasons(presalesById2.getReasons());
			presalesTO.setMeetingStatus(presalesById2.getMeetingStatus());
			presalesTO.setAddress(addressTO);
			adminService.upDateAdmin(presalesTO);// update previous appointment
													// changing status
			PresalesTO presalesTO1 = new PresalesTO();
			presalesTO1.setLeadsId(presalesDTO.getLeadsId());
			presalesTO1.setCustomerName(presalesDTO.getCustomerName());
			presalesTO1.setProductIntrested(presalesDTO.getProductIntrested());
			presalesTO1.setCsr(presalesDTO.getCsr());
			presalesTO1.setTeamName(presalesDTO.getTeamName());
			presalesTO1.setChannel(presalesDTO.getChannel());
			SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy");
			String format1 = (presalesDTO.getDateAppointment());
			try {
				Date date1 = formatter1.parse(format1);
				presalesTO1.setDateAppointment(date1);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			Calendar cal1 = Calendar.getInstance();
			presalesTO1.setCreatedBy(presalesDTO.getCreatedBy());
			presalesTO1.setCreatedDate(cal1.getTime());
			presalesTO1.setTimeAppointment(presalesDTO.getTimeAppointment());
			presalesTO1.setExecutive(presalesDTO.getExecutive());
			presalesTO1.setStatus("New Appointment");
			presalesTO1.setAppointmentType("FollowUp");
			presalesTO1.setRemark(presalesDTO.getRemark());
			presalesTO1.setReasons(presalesDTO.getReasons());
			presalesTO1.setMeetingStatus(presalesDTO.getMeetingStatus());
			presalesTO1.setAddress(addressTO);
			adminService.saveAdmin(presalesTO1);// saving new appointment

		} else if (presalesDTO.getStatus().equalsIgnoreCase("Collected")) {
			LOG.info("************ Inside postEditPresales if status == 'Collected' ");
			// updating pre-sales table as collected status
			PresalesTO presalesTO = new PresalesTO();
			presalesTO.setLeadsId(presalesDTO.getLeadsId());
			presalesTO.setCustomerName(presalesDTO.getCustomerName());
			presalesTO.setProductIntrested(presalesDTO.getProductIntrested());
			presalesTO.setCsr(presalesDTO.getCsr());
			presalesTO.setTeamName(presalesDTO.getTeamName());
			presalesTO.setChannel(presalesDTO.getChannel());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String format = (presalesDTO.getDateAppointment());
			try {
				Date date = formatter.parse(format);
				presalesTO.setDateAppointment(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			presalesTO.setUpdatedBy(presalesDTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			presalesTO.setUpdatedDate((cal.getTime()));
			presalesTO.setCreatedBy(presalesById.getCreatedBy());
			presalesTO.setCreatedDate(presalesById.getCreatedDate());
			presalesTO.setAppointmentType(presalesById.getAppointmentType());
			presalesTO.setTimeAppointment(presalesDTO.getTimeAppointment());
			presalesTO.setExecutive(presalesDTO.getExecutive());
			presalesTO.setStatus(presalesDTO.getStatus());
			presalesTO.setAppointmentType(presalesById.getAppointmentType());
			UsermasterDTO userById = userService.getUserById(presalesDTO
					.getCreatedBy());
			presalesTO.setRemark(presalesById.getRemark() + "\n - "
					+ userById.getUserName() + " on " + cal.getTime()
					+ presalesDTO.getRemark());
			presalesTO.setReasons(presalesDTO.getReasons());
			presalesTO.setMeetingStatus(presalesDTO.getMeetingStatus());
			presalesTO.setAddress(addressTO);
			adminService.upDateAdmin(presalesTO);

			ProductMasterTO getproductById = adminService
					.getproductById(Integer.parseInt(presalesDTO
							.getProductIntrested()));
			// pre-sales converted into collection updating collection table
			CollectionTO collectionTO = new CollectionTO();
			ProductMasterTO masterTO = new ProductMasterTO();
			masterTO.setProductId(Integer.parseInt(presalesDTO
					.getProductIntrested()));
			collectionTO.setProductMaster(masterTO);
			PresalesTO presalesTO1 = new PresalesTO();
			presalesTO1.setLeadsId(presalesDTO.getLeadsId());
			collectionTO.setPresales(presalesTO);
			collectionTO.setPrice(getproductById.getProductPrice());
			collectionTO.setChannel(presalesDTO.getChannel());
			collectionTO.setCsr(presalesDTO.getCsr());
			collectionTO.setExecutive(presalesDTO.getExecutive());
			collectionTO.setTeam(presalesDTO.getTeamName());
			collectionTO.setApplicationNo(presalesDTO.getApplicationNo());
			LOG.info("************ Collected Application NO is ==  "
					+ presalesDTO.getApplicationNo());
			String reportDate = presalesDTO.getDateAppointment();
			Date date = null;
			try {
				date = new SimpleDateFormat("dd/MM/yyyy").parse(reportDate);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			collectionTO.setColectedDate(date);
			collectionTO.setCreatedBy(presalesDTO.getCreatedBy());
			collectionTO.setCreatedDate(cal.getTime());
			collectionTO.setPaymentMode(presalesDTO.getPaymentMode());
			adminService.saveAdmin(collectionTO);

			PresalesTO presalesById2 = adminService.getPresalesById(presalesDTO
					.getLeadsId());
			presalesById2.setCollectionId(collectionTO.getCollectionId());
			adminService.upDateAdmin(presalesById2);
			Integer productIntrested = Integer.parseInt(presalesDTO
					.getProductIntrested());
			if (productIntrested == 15) {
				System.out.println("inside customized if condition...........");
				model.addAttribute("collectionId",
						collectionTO.getCollectionId());
				return new ModelAndView("redirect:customizedService");
			}
		} else if (presalesDTO.getStatus().equalsIgnoreCase("New")) {
			LOG.info("************ Inside postEditPresales if status == 'New' ");
			// save new appointment for existing customer
			PresalesTO presalesTO = new PresalesTO();
			// presalesTO.setLeadsId(presalesDTO.getLeadsId());
			presalesTO.setCustomerName(presalesDTO.getCustomerName());
			presalesTO.setProductIntrested(presalesDTO.getProductIntrested());
			presalesTO.setCsr(presalesDTO.getCsr());
			presalesTO.setTeamName(presalesDTO.getTeamName());
			presalesTO.setChannel(presalesDTO.getChannel());
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String format = (presalesDTO.getDateAppointment());
			try {
				Date date = formatter.parse(format);
				presalesTO.setDateAppointment(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			presalesTO.setCreatedBy(presalesById.getCreatedBy());
			presalesTO.setCreatedDate(presalesById.getCreatedDate());
			presalesTO.setAppointmentType("FollowUp");
			presalesTO.setTimeAppointment(presalesDTO.getTimeAppointment());
			presalesTO.setExecutive(presalesDTO.getExecutive());
			presalesTO.setStatus("New Appointment");
			presalesTO.setRemark(presalesDTO.getRemark());
			presalesTO.setAddress(addressTO);
			adminService.saveAdmin(presalesTO);
		} else { // if status is not interested this will execute
			LOG.info("************ Inside postEditPresales if status no selected(Refresh) ");
			PresalesTO presalesTO = new PresalesTO();
			presalesTO.setLeadsId(presalesDTO.getLeadsId());
			presalesTO.setCustomerName(presalesDTO.getCustomerName());
			presalesTO.setProductIntrested(presalesDTO.getProductIntrested());
			presalesTO.setCsr(presalesDTO.getCsr());
			presalesTO.setTeamName(presalesDTO.getTeamName());
			presalesTO.setChannel(presalesDTO.getChannel());

			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String format = (presalesDTO.getDateAppointment());
			try {
				Date date = formatter.parse(format);
				presalesTO.setDateAppointment(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			presalesTO.setUpdatedBy(presalesDTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			presalesTO.setUpdatedDate((cal.getTime()));
			presalesTO.setCreatedBy(presalesById.getCreatedBy());
			presalesTO.setCreatedDate(presalesById.getCreatedDate());
			presalesTO.setAppointmentType(presalesById.getAppointmentType());
			presalesTO.setTimeAppointment(presalesDTO.getTimeAppointment());
			presalesTO.setExecutive(presalesDTO.getExecutive());
			presalesTO.setStatus(presalesDTO.getStatus());
			presalesTO.setRemark(presalesDTO.getRemark());
			presalesTO.setReasons(presalesDTO.getReasons());
			presalesTO.setMeetingStatus(presalesDTO.getMeetingStatus());
			presalesTO.setAddress(addressTO);
			adminService.upDateAdmin(presalesTO);
		}
		LOG.info("---------------------- End of posteditPresales (edit presales successfully saved) ");
		return new ModelAndView("redirect:searchAppointment");
	}

	@RequestMapping(value = "filterCollection")
	public ModelAndView filterCollection(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		String fromDate = dateFormat.format(date);
		String toDate = dateFormat.format(date);
		ArrayList<HashMap<String, String>> filterCollection1 = report.FilterCollection1(fromDate, toDate, "");
		model.addAttribute("allCollections", filterCollection1);

		return new ModelAndView("Admin/collections/viewCollections");
	}

	@RequestMapping(value = "/viewCollections")
	public @ResponseBody ModelAndView viewCollections(ModelMap model,
			String fromDate, String toDate, String csr) {
		LOG.info("++++++++++++++++++++++ Enter into viewCollections(View All data )");
		ArrayList<HashMap<String, String>> filterCollection1 = report
				.FilterCollection1(fromDate, toDate, csr);
		model.addAttribute("allCollections", filterCollection1);

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		model.addAttribute("allProducts", allProducts);

		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		LOG.info("---------------------- End of viewCollections");
		return new ModelAndView("Admin/collections/viewCollections");
	}

	@RequestMapping(value = "/accountsViewCollection")
	public @ResponseBody ModelAndView accountViewCollections(ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into accountViewCollections (where tx Id is null)");
		CollectionTO collectionTO = new CollectionTO();
		ArrayList<HashMap<String, String>> allCollections = adminService
				.getAllCollections();

		model.addAttribute("allCollections", allCollections);
		LOG.info("---------------------- End of accountViewCollections");
		return new ModelAndView("Admin/collections/accountsViewCollection",
				"collectionTO", collectionTO);
	}

	@RequestMapping(value = "/submitCollection")
	public ModelAndView submitCollections(@RequestParam Integer collectionId,
			ModelMap model) {
		LOG.info("++++++++++++++++++++++ Enter into submitCollections where collection Id is : "
				+ collectionId);
		CollectionDTO collectionDTO = new CollectionDTO();

		CollectionTO collectionById = adminService
				.getCollectionById(collectionId);
		model.addAttribute("collectionById", collectionById);
		try {
			String dateAppointment = null;
			if (collectionById.getColectedDate() != null) {
				dateAppointment = new SimpleDateFormat("dd/MM/yyyy")
						.format(collectionById.getColectedDate());
			}
			model.addAttribute("collectionDate", dateAppointment);

			ProductMasterTO getproductById = adminService
					.getproductById(collectionById.getProductMaster()
							.getProductId());
			model.addAttribute("getproductById", getproductById);

			List<EmployeeDTO> allEmployeeDetails = adminService
					.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
			model.addAttribute("allEmployeeDetails", allEmployeeDetails);

			List<HashMap<String, String>> allProducts = adminService
					.getAllProducts();
			model.addAttribute("allProducts", allProducts);

			List<TeamsTO> allTeamName = adminService.getAllTeamName();
			model.addAttribute("allTeamName", allTeamName);
			TeamsTO teamName = adminService.getTeamName(collectionById
					.getTeam());
			model.addAttribute("teamName", teamName);

			List<ChannelsTO> allChannels = adminService.getAllChannels();
			model.addAttribute("allChannels", allChannels);

			ChannelsTO channelName = adminService.getChannelName(collectionById
					.getChannel());
			model.addAttribute("channelName", channelName);

			PresalesTO presalesById = adminService
					.getPresalesById(collectionById.getPresales().getLeadsId());
			model.addAttribute("presalesById", presalesById);

			List<ApplicationStockTO> allApplicationNo = adminService
					.getAllApplicationNo("Issued");
			model.addAttribute("allApplicationNo", allApplicationNo);

		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		try {
			EmployeeDetailsDTO csrName = hrService
					.getEmployeeById(collectionById.getCsr());
			model.addAttribute("csr", csrName.getEmpName());
		} catch (NullPointerException e) {
		}
		try {
			EmployeeDetailsDTO executiveName = hrService
					.getEmployeeById(collectionById.getExecutive());
			model.addAttribute("executive", executiveName.getEmpName());
		} catch (NullPointerException e) {
		}
		ArrayList<HashMap<String, String>> allCollectionOffers = adminService
				.getAllCollectionOffers(collectionId);
		model.addAttribute("CollectionOffers", allCollectionOffers);

		List<WelezoConstantsTO> bankList = adminService.getWelezoConstant();
		model.addAttribute("bankList", bankList);

		ArrayList<HashMap<String, String>> welezoBankList = adminService
				.getWelezoBankList();
		model.addAttribute("welezoBankList", welezoBankList);

		LOG.info("---------------------- End of submitCollections");
		return new ModelAndView("Admin/collections/submitCollection",
				"collectionDTO", collectionDTO);
	}

	@RequestMapping(value = "/editCollection")
	public ModelAndView editCollections(@RequestParam Integer collectionId,
			ModelMap model) {
		CollectionDTO collectionDTO = new CollectionDTO();
		LOG.info("++++++++++++++++++++++ Enter into editCollections where collection Id is : "
				+ collectionId);
		CollectionTO collectionById = adminService
				.getCollectionById(collectionId);
		model.addAttribute("collectionById", collectionById);
		String dateAppointment = null;
		if (collectionById.getColectedDate() != null) {
			dateAppointment = new SimpleDateFormat("dd/MM/yyyy")
					.format(collectionById.getColectedDate());
		}
		model.addAttribute("collectionDate", dateAppointment);

		ProductMasterTO getproductById = adminService
				.getproductById(collectionById.getProductMaster()
						.getProductId());
		model.addAttribute("getproductById", getproductById);

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csrList", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executiveList", executiveList);

		EmployeeDetailsDTO csrName = hrService.getEmployeeById(collectionById
				.getCsr());
		model.addAttribute("csr", csrName.getEmpName());

		EmployeeDetailsDTO executiveName = hrService
				.getEmployeeById(collectionById.getExecutive());
		model.addAttribute("executive", executiveName.getEmpName());

		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);
		TeamsTO teamName = adminService.getTeamName(collectionById.getTeam());
		model.addAttribute("teamName", teamName);
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);

		ChannelsTO channelName = adminService.getChannelName(collectionById
				.getChannel());
		model.addAttribute("channelName", channelName);
		PresalesTO presalesById = adminService.getPresalesById(collectionById
				.getPresales().getLeadsId());
		model.addAttribute("presalesById", presalesById);

		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		List<ApplicationStockTO> allApplicationNo = adminService
				.getAllApplicationNo("Issued");
		model.addAttribute("allApplicationNo", allApplicationNo);

		ArrayList<HashMap<String, String>> allCollectionOffers = adminService
				.getAllCollectionOffers(collectionId);
		model.addAttribute("CollectionOffers", allCollectionOffers);

		LOG.info("---------------------- End of editCollections");

		return new ModelAndView("Admin/collections/editCollection",
				"collectionDTO", collectionDTO);
	}

	@RequestMapping(value = "/submitCollections")
	public ModelAndView submitCollections(ModelMap model,
			CollectionDTO collectionDTO) {
		LOG.info("++++++++++++++++++++++ Enter into submitCollections where collection Id is : "
				+ collectionDTO.getCollectionId());
		CollectionTO collectionById = adminService
				.getCollectionById(collectionDTO.getCollectionId());
		ProductMasterTO productMasterTO = new ProductMasterTO();
		productMasterTO.setProductId(collectionDTO.getProductnumber());
		CustomerDeatilsTO customerDeatils = new CustomerDeatilsTO();
		customerDeatils
				.setCustomerId(collectionById.getPresales().getLeadsId());
		if (collectionDTO.getApplicationNo() != "") {
			PresalesTO presalesTO = new PresalesTO();
			presalesTO.setLeadsId(collectionById.getPresales().getLeadsId());
			TransactionMasterTO txMasterTO = new TransactionMasterTO();
			txMasterTO.setApplicationNo(collectionDTO.getApplicationNo());
			txMasterTO.setProductMaster(productMasterTO);
			txMasterTO.setPaymentStatus(collectionDTO.getPaymentMode());
			txMasterTO.setAmount((float) (collectionDTO.getPrice()));
			txMasterTO.setCsr(Integer.parseInt(collectionDTO.getCsr()));
			txMasterTO.setExecutive(Integer.parseInt(collectionDTO
					.getExecutive()));
			txMasterTO.setChannel(collectionDTO.getChannel());
			txMasterTO.setTeam(collectionDTO.getTeam());
			txMasterTO.setTxStatus("New");
			txMasterTO.setRemarks(collectionDTO.getRemarks());
			txMasterTO.setCreatedBy(collectionDTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			txMasterTO.setCreatedDate((cal.getTime()));
			SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy");
			String colletdate1 = collectionDTO.getColectedDate();
			Date date1 = null;
			try {
				date1 = formatter1.parse(colletdate1);
				txMasterTO.setCollectedDate(date1);
				Date now = formatter1.parse(colletdate1);
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(now);
				calendar.add(Calendar.YEAR, 1);
				Date expDate = calendar.getTime();
				txMasterTO.setExpriryDate(expDate);
			} catch (Exception e) {
				e.printStackTrace();
				LOG.error(e);
			}
			adminService.saveAdmin(txMasterTO);
			LOG.info("************ Inserting transaction master where Tx Id is : "
					+ txMasterTO.getTransactionId());
			report.insertAccountTransaction(collectionDTO.getApplicationNo());
			LOG.info("************ Inserting account Transaction that application No. is "
					+ collectionDTO.getApplicationNo());
			adminService.getUpdateApplnStatus(collectionDTO.getApplicationNo(),
					"For Data Entry");
			collectionById.setTransactionId(txMasterTO.getTransactionId());
			adminService.upDateAdmin(collectionById);

			PaymentDetailsTO payDetailsTO = new PaymentDetailsTO();
			payDetailsTO.setModeOfPayment(collectionDTO.getPaymentMode());
			payDetailsTO.setAmount(collectionDTO.getPrice());
			payDetailsTO.setChequeAuthCode(collectionDTO.getChequeAuthCode());

			System.out.println("Mode of payment:"
					+ collectionDTO.getPaymentMode());
			System.out.println("cheque Date" + collectionDTO.getChequeDate());

			String paymentMode = collectionDTO.getPaymentMode();
			Date date = null;
			if (paymentMode.equals("Cheque")) {
				System.out.println("Inside else if check");
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				try {
					date = formatter.parse(collectionDTO.getChequeDate());
				} catch (ParseException e) {
					e.printStackTrace();
				}
			} else {
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				System.out.println("Inside esle payment is not cheque");
				try {
					date = formatter.parse(collectionDTO.getColectedDate());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			payDetailsTO.setChequeDate(date);
			payDetailsTO.setTerminalNumber(collectionDTO.getTerminalNumber());
			payDetailsTO.setBank(collectionDTO.getBank());
			payDetailsTO.setStatus("New");
			payDetailsTO.setCardNumber(collectionDTO.getCardNumber());
			payDetailsTO.setCreatedBy(collectionDTO.getCreatedBy());
			payDetailsTO.setCreatedDate((cal.getTime()));
			payDetailsTO.setCreditedTo(collectionDTO.getCreditedTo());
			payDetailsTO.setTransactionMaster(txMasterTO);
			adminService.saveAdmin(payDetailsTO);
			LOG.info("************ Inserting payment Details where Tx Id is : "
					+ txMasterTO.getTransactionId());
			return new ModelAndView("redirect:accountsViewCollection");
		} else {
			return new ModelAndView("redirect:accountsViewCollection");
		}
	}

	@RequestMapping(value = "/postEditCollections")
	public ModelAndView postEditCollection(ModelMap model,CollectionDTO collectionDTO) {
		CollectionTO collectionById = adminService.getCollectionById(collectionDTO.getCollectionId());

		ProductMasterTO productMasterTO = new ProductMasterTO();
		productMasterTO.setProductId(collectionDTO.getProductnumber());
		PresalesTO presalesTO = new PresalesTO();
		presalesTO.setLeadsId(collectionById.getPresales().getLeadsId());
		CollectionTO collectionTO = new CollectionTO();
		collectionTO.setCollectionId(collectionDTO.getCollectionId());
		collectionTO.setProductMaster(productMasterTO);
		collectionTO.setChannel(collectionDTO.getChannel());
		collectionTO.setPaymentMode(collectionDTO.getPaymentMode());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String collectionDate = collectionDTO.getColectedDate();
		try {
			Date date = formatter.parse(collectionDate);
			collectionTO.setColectedDate(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		// collectionTO.setCollectedBy(collectionDTO.getCollectedBy());
		collectionTO.setCsr(Integer.parseInt(collectionDTO.getCsr()));
		collectionTO.setPrice(collectionDTO.getPrice());
		collectionTO.setExecutive(Integer.parseInt(collectionDTO.getExecutive()));
		collectionTO.setTeam(collectionDTO.getTeam());
		collectionTO.setUpdatedBy(collectionDTO.getCreatedBy());
		Calendar cal1 = Calendar.getInstance();
		collectionTO.setUpdatedDate((cal1.getTime()));
		collectionTO.setCreatedBy(collectionById.getCreatedBy());
		collectionTO.setCreatedDate(collectionById.getCreatedDate());
		collectionTO.setPresales(presalesTO);
		collectionTO.setApplicationNo(collectionDTO.getApplicationNo());
		adminService.upDateAdmin(collectionTO);
		return new ModelAndView("redirect:filterCollection");
	}

	@RequestMapping(value = "/checkOut")
	public ModelAndView checkOutPayment(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		TransactionMasterTO masterTO = new TransactionMasterTO();
		masterTO.setPaymentStatus("01/11/2016");
		masterTO.setCardNumber(dateFormat.format(date));
		masterTO.setTxStatus("Cheque Returned");
		List<TransactionMasterDTO> allPayments = adminService
				.getAllPayments(masterTO);
		model.addAttribute("alltransaction", allPayments);
		return new ModelAndView("Admin/payments/checkOutPayment");
	}

	@RequestMapping(value = "/reCollectPayment")
	public ModelAndView editReCollectPayment(@RequestParam Integer paymentId,
			ModelMap model, HttpServletRequest request) {
		CollectionDTO collectionTO = new CollectionDTO();
		PaymentDetailsTO paymentById = adminService.getPaymentById(paymentId);

		TransactionMasterTO txById = adminService.getTxById(paymentById
				.getTransactionMaster().getTransactionId());
		model.addAttribute("txById", txById);

		ProductMasterTO getproductById = adminService.getproductById(txById
				.getProductMaster().getProductId());
		model.addAttribute("getproductById", getproductById);

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csrList", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executiveList", executiveList);

		// EmployeeDTO employeeId = h.getEmployeeId(txById.getCsr());
		EmployeeDetailsDTO csrName = hrService.getEmployeeById(txById.getCsr());
		model.addAttribute("csr", csrName.getEmpName());

		EmployeeDetailsDTO executiveName = hrService.getEmployeeById(txById
				.getExecutive());
		model.addAttribute("executive", executiveName.getEmpName());

		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);

		TeamsTO teamName = adminService.getTeamName(txById.getTeam());
		model.addAttribute("teamName", teamName);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);

		ChannelsTO channelName = adminService.getChannelName(txById
				.getChannel());
		model.addAttribute("channelName", channelName);

	
		List<WelezoConstantsTO> bankList = adminService.getWelezoConstant();
		model.addAttribute("bankList", bankList);

		
		model.addAttribute("paymentById", paymentById);
		return new ModelAndView("Admin/payments/reCollectPayment",
				"collectionDTO", collectionTO);
	}

	@RequestMapping(value = "/resubmitpayments")
	public ModelAndView submitPayment(ModelMap model,
			CollectionDTO collectionDTO) {

		ProductMasterTO productMasterTO = new ProductMasterTO();
		productMasterTO.setProductId(collectionDTO.getProductnumber());

		if (collectionDTO.getApplicationNo() != "") {

			String txQuery = "UPDATE transaction_master SET tx_status = 'Payment Resubmitted' ,update_by = '"
					+ collectionDTO.getCreatedBy()
					+ "', update_date = CURRENT_DATE, payment_status='"
					+ collectionDTO.getPaymentMode()
					+ "',"
					+ " remarks = 'Payment collected back and submitting again' WHERE transaction_id = '"
					+ collectionDTO.getTransactionId() + "'";
			hrService.upDateQuery(txQuery);
			// System.out.println("tranx query : " + txQuery);

			// System.out.println("transation id " +
			// collectionDTO.getTransactionId());
			// System.out.println("payment id " +
			// collectionDTO.getCollectionId());
			String payQuery = "UPDATE payment_details SET STATUS = 'Payment Resubmitted', updated_by = '"
					+ collectionDTO.getCreatedBy()
					+ "', "
					+ "updated_date = CURRENT_TIMESTAMP WHERE payment_id = '"
					+ collectionDTO.getCollectionId() + "'";
			hrService.upDateQuery(payQuery);

			PaymentDetailsTO payDetailsTO = new PaymentDetailsTO();
			payDetailsTO.setModeOfPayment(collectionDTO.getPaymentMode());
			payDetailsTO.setAmount(collectionDTO.getPrice());
			payDetailsTO.setChequeAuthCode(collectionDTO.getChequeAuthCode());
			if (collectionDTO.getChequeDate() != null) {
				SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
				String cheqdate = collectionDTO.getChequeDate();
				try {
					Date date = formatter.parse(cheqdate);
					payDetailsTO.setChequeDate(date);
				} catch (ParseException e) {
					e.printStackTrace();
					LOG.error(e);
				}
			}
			payDetailsTO.setTerminalNumber(collectionDTO.getTerminalNumber());
			payDetailsTO.setBank(collectionDTO.getBank());
			payDetailsTO.setStatus("New");

			payDetailsTO.setCreatedBy(collectionDTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			payDetailsTO.setCreatedDate(cal.getTime());

			TransactionMasterTO tx = new TransactionMasterTO();
			tx.setTransactionId(collectionDTO.getTransactionId());
			payDetailsTO.setTransactionMaster(tx);
			adminService.saveAdmin(payDetailsTO);

			return new ModelAndView("redirect:checkOut");
		} else {
			return new ModelAndView("redirect:checkOut");
		}
	}

	@RequestMapping(value = "/applicationNumber")
	public ModelAndView addApplicationNo(Model model,
			@ModelAttribute CustomerDeatilsAllDTO customerDeatilsDTO) {

		HashMap<String, String> applicationNoTx = adminService
				.getApplicationNoTx(customerDeatilsDTO.getApplicationNumber());

		CustomerDeatilsTO customerDeatilsTO = new CustomerDeatilsTO();
		customerDeatilsTO.setCustomerId(customerDeatilsDTO.getCustomerId());
		// System.out.println("cust and Tx id : "+customerDeatilsDTO.getCustomerId()
		// + Integer.parseInt(applicationNoTx.get("transactionId")));
		report.updateCardNumber(customerDeatilsDTO.getCustomerId(),
				Integer.parseInt(applicationNoTx.get("transactionId")));

		adminService.getUpdateApplnStatus(
				customerDeatilsDTO.getApplicationNumber(), "Received");
		model.addAttribute("customerId", customerDeatilsDTO.getCustomerId());
		return new ModelAndView("redirect:viewcustomersById");
	}

	@RequestMapping(value = "/viewCalls")
	public ModelAndView ViewDayWiseCalls(Model model) {
		List<DaywiseCallsIdDTO> allDailyCalls = adminService.getAllDailyCalls();
		model.addAttribute("allDailyCalls", allDailyCalls);
		return new ModelAndView("Admin/customerCallRecords/viewDayWiseCalls");
	}

	@RequestMapping(value = "/viewExtensionDetails")
	public ModelAndView viewExtensionDetails(Model model) throws SQLException {
		List<ExtensionDetailsTO> geteExtensionDetails = adminService
				.geteExtensionDetails();
		List<EmployeeDTO> extensDetails = new ArrayList<>();
		for (ExtensionDetailsTO extension : geteExtensionDetails) {
			EmployeeDTO empExtn = new EmployeeDTO();
			EmployeeDTO employeeId = adminService.getEmployeeId(extension
					.getEmpId());
			empExtn.setEmpName(employeeId.getEmpName());
			empExtn.setExtensionNumber(extension.getExtensionNo().toString());
			empExtn.setEmpContact(employeeId.getEmpContact());
			empExtn.setEmpId(extension.getEmpId());
			empExtn.setEmpMobile(employeeId.getEmpMobile());
			empExtn.setEmpEmail(employeeId.getEmpEmail());
			extensDetails.add(empExtn);

		}
		model.addAttribute("extenstion", extensDetails);
		// ResultSet rs = adminService.executeQuery();

		return new ModelAndView("Admin/customerCallRecords/extenstionDetails");
	}

	@RequestMapping(value = "/applicationStatus")
	public ModelAndView viewExtensionDetails(Model model,
			ResultsetColumnsDeatils resultSet) {
		String[] checkBox = resultSet.getCheckBox();

		for (int i = 0; i < checkBox.length; i++) {
			ApplicationStockTO stock = new ApplicationStockTO();
			stock.setApplicationNo(checkBox[i]);
			stock.setIssuedTo(Integer.parseInt(resultSet.getColumnName()));
			stock.setStatus(resultSet.getHyperLink());
			stock.setIssuedBy(resultSet.getColumnNumber().toString());
			Calendar cal = Calendar.getInstance();
			stock.setIssuedDate(cal.getTime());
			adminService.saveOrUpdate(stock);
		}
		return new ModelAndView("redirect:viewDetails2");
	}

	@RequestMapping(value = "/searchAppointment")
	public ModelAndView searchAppointment(Model model) {
		PresalesDTO presales = new PresalesDTO();
		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", (todate));

		presales.setStatus("");
		presales.setMeetingStatus("");
		presales.setApplicationNo("");
		presales.setCity("");
		presales.setDateAppointment(dateFormat.format(todate1));
		presales.setTimeAppointment((todate));
		List<HashMap<String, String>> filterAPresales = adminService
				.FilterAPresales(presales);
		model.addAttribute("presalesDetail", filterAPresales);

		return new ModelAndView("Admin/presales/searchPreSalesAppointments",
				"presales", presales);
	}

	@RequestMapping(value = "/searchAppointment2")
	public ModelAndView searchAppointmentDetails(Model model,
			PresalesDTO presales) {
		PresalesDTO presales1 = new PresalesDTO();
		List<HashMap<String, String>> filterAPresales = adminService.FilterAPresales(presales);
		model.addAttribute("presalesDetail", filterAPresales);

		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		model.addAttribute("fromDate", presales.getDateAppointment());
		model.addAttribute("toDate", presales.getTimeAppointment());
		return new ModelAndView("Admin/presales/searchPreSalesAppointments",
				"presales", presales1);
	}

	@RequestMapping(value = "viewreference")
	public ModelAndView customerReference(ModelMap model) {
		ReferencesTO referencesTO = new ReferencesTO();
		return new ModelAndView("Admin/application/custreference",
				"referencesTO", referencesTO);
	}

	@RequestMapping(value = "saveReference")
	public ModelAndView saveCustomerReference(ModelMap model,
			ReferencesTO referencesTO) {
		adminService.saveAdmin(referencesTO);

		return new ModelAndView("Admin/application/custreference");
	}

	@RequestMapping(value = "searchCollection")
	public ModelAndView searchColelction(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		model.addAttribute("groupBy", "Collection Date");
		return new ModelAndView("redirect:collectionSummary");
	}

	@RequestMapping(value = "telesalesdashboard")
	public ModelAndView teleSalesDashBoard(ModelMap model) {

		return new ModelAndView("Admin/presales/teleSales_dashboard");
	}

	@RequestMapping(value = "txdashboard")
	public ModelAndView transactionDashBoard(ModelMap model) {
		
		HashMap<String, String> totalTransaction = report.getNotification("SELECT   COUNT(1) AS 'Total' FROM transaction_master WHERE tx_status  IN ('Payment Approved','New','In Progress')");
		model.addAttribute("totalTransaction", totalTransaction);

		String pendingSubmissionCount = report.getPendingSubmissionCount();
		model.addAttribute("totalSubmission", pendingSubmissionCount);
		
		HashMap<String, String> totalPayment = report.getNotification("SELECT COUNT(1) AS 'Total' FROM payment_details WHERE STATUS IN ('Payment Approved','New')");
		model.addAttribute("totalPayment",totalPayment);
		
		HashMap<String, String> pendingPaymentApproval = report.getNotification("SELECT COUNT(1) AS 'Total' FROM payment_details WHERE STATUS IN ('New')");
		model.addAttribute("pendingPaymentApproval", pendingPaymentApproval);
		
		return new ModelAndView("Admin/transaction/transaction_dashboard");
	}

	@RequestMapping(value = "customizedService")
	public ModelAndView presalesCustomizedSevices(ModelMap model,
			@RequestParam Integer collectionId) {
		// System.out.println("collection Id : " + collectionId);
		List<HashMap<String, String>> services = adminService.getAllservice();
		model.addAttribute("services", services);

		model.addAttribute("collectionId", collectionId);
		return new ModelAndView("Admin/presales/addCustomizedSevice",
				"service", new ServicesTO());

	}

	@RequestMapping(value = "saveCustomizedService")
	public ModelAndView savepresalesProduct(ModelMap model,
			@RequestParam Integer collectionId, Float amount,
			Integer updatedBy, Integer[] serviceId, Integer[] quantity) {

		String query = "UPDATE collection SET price = '" + amount
				+ "', updated_by='" + updatedBy
				+ "', updated_date = CURRENT_TIMESTAMP WHERE collection_id= '"
				+ collectionId + "'";
		hrService.upDateQuery(query);

		for (int i = 0; i < serviceId.length; i++) {
			if (quantity[i] != null) {
				CollectionOffersTO offersTo = new CollectionOffersTO();
				offersTo.setCollectionId(collectionId);
				offersTo.setServiceId(serviceId[i]);
				offersTo.setQuantity(quantity[i]);
				adminService.saveAdmin(offersTo);
			}
		}
		return new ModelAndView("redirect:searchAppointment");
	}

	@RequestMapping(value = "customerSearch")
	public ModelAndView customerSearchBeforeAdd(ModelMap model) {
		return new ModelAndView("Admin/application/customerPreview");

	}

	@RequestMapping(value = "customerSearch1", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView customerSearchBeforeAdd1(ModelMap model,
			@RequestParam String cardRPhnNumber) {
		ArrayList<HashMap<String, String>> customerList = adminService
				.getCustomerList(cardRPhnNumber);
		model.addAttribute("customerList", customerList);
		return new ModelAndView("Admin/application/customerPreview");

	}

	@RequestMapping(value = "/walkInCustomers")
	public @ResponseBody ModelAndView walkInCustomer(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		return new ModelAndView("redirect:walkInCustomers1");
	}

	@RequestMapping(value = "walkInCustomers1")
	public ModelAndView walkInCustomerDetails(ModelMap model, String fromDate,
			String toDate) {
		ArrayList<HashMap<String, String>> walkinCustomer = adminService
				.getWalkinCustomer(fromDate, toDate);
		model.addAttribute("walkinCustomer", walkinCustomer);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		return new ModelAndView("Admin/presales/walkInCustomerList");
	}

	@RequestMapping(value = "editWalkInCustomer")
	public ModelAndView editWalkInCustomer(ModelMap model,
			@RequestParam Integer id) {

		HashMap<String, String> walkinCustomerById = adminService
				.getWalkinCustomerById(id);
		model.addAttribute("walkIncust", walkinCustomerById);

		return new ModelAndView("Admin/presales/editWalkInCustomer");
	}

	@RequestMapping(value = "saveWalkInCustomer")
	public ModelAndView saveWalkInCustomer(ModelMap model,
			@RequestParam Integer id, @RequestParam String status,
			String remarks, String fromDate, String toDate) {

		String query = "UPDATE walkin_customer SET STATUS = '" + status
				+ "',remarks = '" + remarks + "' WHERE id = '" + id + "'";
		hrService.upDateQuery(query);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		return new ModelAndView("redirect:walkInCustomers1");
	}

	@RequestMapping(value = "/applicationUpload", method = RequestMethod.POST)
	public ModelAndView uploadApplicationSoftCopy(ModelMap model,
			@RequestParam CommonsMultipartFile file,
			@RequestParam String applicationNumber, Integer trackId)
			throws Exception {
		String path = "/home/welezohealth/whms/Applications";
		// String path = "D:\\files\\doc";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();
			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();
		} catch (Exception e) {
			// System.out.println(e);
		}
		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + applicationNumber + "_"+ filename));

		String query = "UPDATE dispatch_tracking SET application_status = 'Uploaded' WHERE track_id = '"
				+ trackId + "'";
		hrService.upDateQuery(query);
		model.addAttribute("trackId", trackId);
		return new ModelAndView("redirect:editDispatch");
	}

	@RequestMapping(value = "saveRTODispatch", method = RequestMethod.POST)
	public ModelAndView saveDispatchRTO(ModelMap model,
			@RequestParam Integer txId, @RequestParam Integer createdBy,
			@RequestParam String dispatchStatus, String deliveryStatus,
			String dispatchDate, String dispatchThrough,
			String consignmentReference) {
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date1 = formatter.format(sdf.parse(dispatchDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query = "INSERT INTO dispatch_tracking(dispatch_date,dispatch_through,consignment_reference,dispatch_status,delivery_status,transaction_id,created_by,created_date)"
				+ " VALUES('"
				+ date1
				+ "','"
				+ dispatchThrough
				+ "','"
				+ consignmentReference
				+ "','"
				+ dispatchStatus
				+ "','"
				+ deliveryStatus
				+ "','"
				+ txId
				+ "','"
				+ createdBy
				+ "',CURRENT_TIMESTAMP)";
		hrService.upDateQuery(query);

		return new ModelAndView("redirect:viewdispatch");
	}

	@RequestMapping(value = "/detailsDispach")
	public ModelAndView detailsDispatch() {
		ArrayList<HashMap<String, String>> presales = adminService
				.getDetailsCustomer();

		return new ModelAndView("Admin/dispatch/customerDispatchAddr",
				"presales", presales);
	}
	@RequestMapping(value = "/operationDashboards")
	public ModelAndView operationDashboard(ModelMap model) {
		
		ArrayList<HashMap<String,String>> voucherList = report.getVoucherList();
		model.addAttribute("voucherList", voucherList);

		ArrayList<HashMap<String, String>> applicationStatusReport = report.getApplicationStatusReport();
		model.addAttribute("applicationStatusReport", applicationStatusReport);
		
		ArrayList<HashMap<String,String>> dispatchStatusReport = report.getDispatchStatusReport();
		model.addAttribute("dispatchStatusReport", dispatchStatusReport);
		
		HashMap<String, String> pendingDispatch = report.getNotification("SELECT COUNT(1) AS 'Total' FROM dispatch_tracking WHERE `dispatch_status` IN ('New')");
		model.addAttribute("pendingDispatch", pendingDispatch);
		
		HashMap<String, String> totalDispatch = report.getNotification("SELECT COUNT(1) AS 'Total' FROM dispatch_tracking WHERE dispatch_status IN ('New','InTransit','InProgress')");
		model.addAttribute("totalDispatch", totalDispatch);
		
		HashMap<String, String> outWard = report.getNotification("SELECT COUNT(1) AS 'Total' FROM inventory WHERE entry_type = 'OutWard' AND action_date= CURRENT_DATE");
		model.addAttribute("outWard", outWard);
		
		HashMap<String, String> inWard = report.getNotification("SELECT COUNT(1) AS 'Total' FROM inventory WHERE entry_type = 'InWard' AND action_date= CURRENT_DATE");
		model.addAttribute("inWard", inWard);
		
		return new ModelAndView("Admin/dashboards/operationDashboards");
	}
	
	@RequestMapping(value = "/salesDashboards")
	public ModelAndView salesDashboard(ModelMap model) {
	
		
		
		return new ModelAndView("Admin/dashboards/salesDashboards");
	}
	@RequestMapping(value = "/telSalesDashboards")
	public ModelAndView teleSalesDashboard(ModelMap model) {
	
		PresalesTO presalesCount = report.presalesCount();
		model.addAttribute("presalesCount", presalesCount);

		HashMap<String, String> todayCollection = report.getNotification("SELECT COUNT(1) AS 'Total' FROM collection WHERE colected_date = CURRENT_DATE");
		model.addAttribute("todayCollection", todayCollection);

		CollectionTO callsCount = report.callsCount();
		model.addAttribute("callsCount", callsCount);
		
		return new ModelAndView("Admin/dashboards/teleSaleDashBoard");
	}
	@RequestMapping(value = "/applicationStatusSearch")
	public ModelAndView applicationStatusSearch(ModelMap model) {
		
		return new ModelAndView("Admin/application/applicationStatusSearch");
	}
	@RequestMapping(value = "/applicationStatusSearch1")
	public ModelAndView applicationStatusSearch1(ModelMap model,@RequestParam String applicationNo) {
		
		HashMap<String,String> applicationStatusDispatch = adminService.getApplicationStatusDispatch(applicationNo);
		model.addAttribute("applicationStatusDispatch", applicationStatusDispatch);
		HashMap<String,String> applicationStatusTx = adminService.getApplicationStatusTx(applicationNo);
		model.addAttribute("applicationStatusTx", applicationStatusTx);
		
		return new ModelAndView("Admin/application/applicationStatusSearch");
	}
	@RequestMapping(value = "/invoiceTx")
	public ModelAndView retailCustomerInvoice(ModelMap model,@RequestParam Integer transactionId) {
		
		HashMap<String, String> invoiceTransactionDetails = adminService.getInvoiceTransactionDetails(transactionId);
		model.addAttribute("invoiceTransactionDetails", invoiceTransactionDetails);
		AddressDTO allAddress = adminService.getAllAddress(Integer.parseInt(invoiceTransactionDetails.get("customerId")),invoiceTransactionDetails.get("correspondence"));
		model.addAttribute("address", allAddress);
		
		ArrayList<HashMap<String,String>> servicesBasedOnProductId = adminService.getServicesBasedOnProductId(Integer.parseInt(invoiceTransactionDetails.get("productId")));
		model.addAttribute("servicesBasedOnProductId", servicesBasedOnProductId);
		return new ModelAndView("Admin/transaction/transactionInvoice");
	}
	@RequestMapping(value = "/retention")
	public ModelAndView viewRetension()
	{
		return new ModelAndView("Admin/retension/retensionReport");
	}
	
	/*@RequestMapping(value = "/charts")
	public ModelAndView viewCharts()
	{
		return new ModelAndView("Admin/graph");
	}*/
}
