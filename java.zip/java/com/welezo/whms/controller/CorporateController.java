
package com.welezo.whms.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.welezo.whms.daoImpl.CorporateDaoImpl;
import com.welezo.whms.dto.CorpHospitalDTO;
import com.welezo.whms.dto.CorporateAppointmentsDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.CallRecordsService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.ContactAddressTO;
import com.welezo.whms.to.ContactTO;
import com.welezo.whms.to.CorporateAppointmentsTO;
import com.welezo.whms.to.CorporateDetailsTO;
import com.welezo.whms.to.CorporateServiceOffersTO;
import com.welezo.whms.to.Person;
import com.welezo.whms.to.ProductGenTO;
import com.welezo.whms.to.ServiceParametersTo;
import com.welezo.whms.to.TablesUpdatesTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Controller
public class CorporateController {
	private Logger LOG = Logger.getLogger(CorporateController.class);
	@Autowired
	AdminService adminService;

	@Autowired
	CallRecordsService callrecordservice;
	@Autowired
	UserService userService;

	@Autowired
	ReportController report;

	@Autowired
	HRService hr;
	@Autowired
	CorporateDaoImpl corporate;

	@RequestMapping(value = "viewcrp")
	public ModelAndView corporate(ModelMap model, Integer corporateId) {
		CorporateAppointmentsDTO corporateTO = new CorporateAppointmentsDTO();
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		model.addAttribute("corporateId", corporateId);
		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		return new ModelAndView("Admin/corporate/corporateDetails",
				"corporateDTO", corporateTO);
	}

	@RequestMapping(value = "saveCorporate")
	public ModelAndView saveCorporate(ModelMap model,CorporateAppointmentsDTO corporateTO) {
		LOG.info("Inside Save corporate method and request object value  : "+ corporateTO);

		boolean validateCorporateDetails = corporate.validateCorporateDetails(corporateTO.getCorporateName());
		if(validateCorporateDetails == false){
		// System.out.println("corporate parent id : "+corporateTO.getParentId());
		try {
			CorporateDetailsTO corporateDetailsTO = new CorporateDetailsTO();
			corporateDetailsTO.setCorporateName(corporateTO.getCorporateName());
			corporateDetailsTO.setChannelId(corporateTO.getChannelId());
			corporateDetailsTO.setStatus("New");
			corporateDetailsTO.setExecutive(Integer.parseInt(corporateTO.getExecutive()));
			corporateDetailsTO.setHeadCount(corporateTO.getTotalStrength());
			corporateDetailsTO.setEntityType(corporateTO.getEntityType());

			if (corporateTO.getTypeCorporate().equalsIgnoreCase("branch")) {
				// System.out.println("I am branch of corpoarte");
				corporateDetailsTO.setParentId(corporateTO.getParentId());
			} else {
				// System.out.println("I am main of corpoarte");
				corporateDetailsTO.setParentId(corporateDetailsTO
						.getCorporateId());
			}

			corporateDetailsTO.setCreatedBy(corporateTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			corporateDetailsTO.setCreatedDate(cal.getTime());
			adminService.saveAdmin(corporateDetailsTO);
			LOG.info("Successfully corporate data saved into corporate_details tables then corporate Id is "
					+ corporateDetailsTO.getCorporateId());
			if (corporateTO.getParentId() == null) {
				corporateDetailsTO.setCorporateId(corporateDetailsTO
						.getCorporateId());
				corporateDetailsTO.setParentId(corporateDetailsTO
						.getCorporateId());
				adminService.upDateAdmin(corporateDetailsTO);
			}

			ContactAddressTO contactAddressTO = new ContactAddressTO();
			contactAddressTO.setAddressLine(corporateTO.getResidenceAddresss());
			contactAddressTO.setCity(corporateTO.getCity());
			contactAddressTO.setPincode(corporateTO.getPincode());
			contactAddressTO.setLandmark(corporateTO.getLandmark());
			contactAddressTO.setAltNo(corporateTO.getLandline());
			contactAddressTO.setEmail(corporateTO.getEmail());
			contactAddressTO.setAddressType(11);
			contactAddressTO.setEntityId(corporateDetailsTO.getCorporateId());
			contactAddressTO.setIsDefault(true);
			adminService.saveAdmin(contactAddressTO);
			LOG.info("Succesfully corporate address inserted to Contact_address table then address_id is :"
					+ contactAddressTO.getAddressId());

			TablesUpdatesTO updates = new TablesUpdatesTO();
			updates.setOperationBy(corporateTO.getCreatedBy());
			updates.setOperationDate(cal.getTime());
			updates.setColumnId(corporateDetailsTO.getCorporateId());
			updates.setTableName("corporate_details");
			updates.setOperations("Insert Values");
			adminService.saveAdmin(updates);
			
			
			if(!corporateTO.getName().equalsIgnoreCase("")){
			ContactTO contactTO = new ContactTO();
			contactTO.setContactName(corporateTO.getName());
			contactTO.setContactStatus("New");
			contactTO.setDesignation(corporateTO.getDesignation());
			contactTO.setPrimaryContact(corporateTO.getMeetingStatus());
			contactTO.setPrimaryEmail(corporateTO.getStatus());
			contactTO.setContactType("Fresh");
			contactTO.setCorporateDetails(corporateDetailsTO);
			adminService.saveAdmin(contactTO);
			}
			
			model.addAttribute("corporateId",corporateDetailsTO.getCorporateId());
			
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
			return new ModelAndView("redirect:viewcorporatebyId");
		}
		
		return new ModelAndView("redirect:viewcorporatebyId");
		}
		else{
			model.addAttribute("msg", corporateTO.getCorporateName() +" Already Existing In CRM");
			return new ModelAndView("Admin/errorpage");
		}
		
	}

	@RequestMapping(value = "corporateAppointment")
	public ModelAndView corporateAppointment(ModelMap model,
			@RequestParam String corporateName, String corporateID) {
		model.addAttribute("corporateName", corporateName);
		model.addAttribute("corporateID", corporateID);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);

		return new ModelAndView("Admin/corporate/corporateAppointment",
				"corporateDTO", new CorporateAppointmentsDTO());
	}

	@RequestMapping(value = "corporateAppointmentEx")
	public ModelAndView corporateAppointmentForExisting(ModelMap model,
			String corporateName, Integer contactId) {

		CorporateAppointmentsDTO contactById = corporate
				.getContactById(contactId);
		model.addAttribute("contactById", contactById);

		model.addAttribute("corporateName", corporateName);
		model.addAttribute("corporateID", contactById.getCorporateId());
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);
		return new ModelAndView("Admin/corporate/corporateAppointment",
				"corporateDTO", new CorporateAppointmentsDTO());
	}

	@RequestMapping(value = "saveCorporateAppointment")
	public ModelAndView corporateAppointment(ModelMap model,
			CorporateAppointmentsDTO corporateTO) {

		if (corporateTO.getContactId() == null) {
			CorporateDetailsTO corporateDetailsTO = new CorporateDetailsTO();
			corporateDetailsTO.setCorporateId(corporateTO.getCorporateId());
			System.out.println(corporateTO.getCorporateId());
			
			ContactTO contact = new ContactTO();
			contact.setContactName(corporateTO.getName());
			contact.setPrimaryContact(corporateTO.getPrimaryMob());
			contact.setPrimaryEmail(corporateTO.getEmail());
			contact.setDesignation(corporateTO.getDesignation());
			
			contact.setCorporateDetails(corporateDetailsTO);
			
			adminService.saveAdmin(contact);

			TablesUpdatesTO updates = new TablesUpdatesTO();
			updates.setOperationBy(corporateTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			updates.setOperationDate(cal.getTime());
			updates.setColumnId(contact.getContactId());
			updates.setTableName("contact");
			updates.setOperations("Insert Values");
			adminService.saveAdmin(updates);
			
			CorporateAppointmentsTO appointmentsTO = new CorporateAppointmentsTO();
			appointmentsTO.setContact(contact);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String cheqdate = corporateTO.getAppointmentDate();
			try {
				Date date = formatter.parse(cheqdate);
				appointmentsTO.setAppointmentDate(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			appointmentsTO.setTimeAppointment(corporateTO.getTimeAppointment());
			appointmentsTO.setExecutive(Integer.parseInt(corporateTO
					.getExecutive()));
			appointmentsTO.setMeetingStatus("New");
			appointmentsTO.setStatus(corporateTO.getStatus());
			appointmentsTO.setPurpose(corporateTO.getPurpose());
			appointmentsTO.setRemarks(corporateTO.getRemarks());
			adminService.saveAdmin(appointmentsTO);

			TablesUpdatesTO updates1 = new TablesUpdatesTO();
			updates1.setOperationBy(corporateTO.getCreatedBy());
			Calendar cal1 = Calendar.getInstance();
			updates1.setOperationDate(cal1.getTime());
			updates1.setColumnId(appointmentsTO.getAppointmentId());
			updates1.setTableName("corporate_appointment");
			updates1.setOperations("Insert Operation");
			adminService.saveAdmin(updates1);
		} else {
			CorporateDetailsTO corporateDetailsTO = new CorporateDetailsTO();
			corporateDetailsTO.setCorporateId(corporateTO.getCorporateId());
			
			ContactTO contact = new ContactTO();
			contact.setContactId(corporateTO.getContactId());
			contact.setContactName(corporateTO.getName());
			contact.setPrimaryContact(corporateTO.getPrimaryMob());
			contact.setPrimaryEmail(corporateTO.getEmail());
			contact.setDesignation(corporateTO.getDesignation());
			contact.setCorporateDetails(corporateDetailsTO);
			
			adminService.upDateAdmin(contact);

			CorporateAppointmentsTO appointmentsTO = new CorporateAppointmentsTO();
			appointmentsTO.setContact(contact);
			SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			String cheqdate = corporateTO.getAppointmentDate();
			try {
				Date date = formatter.parse(cheqdate);
				appointmentsTO.setAppointmentDate(date);
			} catch (ParseException e) {
				e.printStackTrace();
				LOG.error(e);
			}
			appointmentsTO.setTimeAppointment(corporateTO.getTimeAppointment());
			appointmentsTO.setExecutive(Integer.parseInt(corporateTO
					.getExecutive()));
			appointmentsTO.setMeetingStatus("FollowUp");
			appointmentsTO.setStatus("Existing customer");
			appointmentsTO.setPurpose("Meeting");
			appointmentsTO.setRemarks(corporateTO.getRemarks());
			adminService.saveAdmin(appointmentsTO);

			TablesUpdatesTO updates = new TablesUpdatesTO();
			updates.setOperationBy(corporateTO.getCreatedBy());
			Calendar cal = Calendar.getInstance();
			updates.setOperationDate(cal.getTime());
			updates.setColumnId(appointmentsTO.getAppointmentId());
			updates.setTableName("corporate_appointment");
			updates.setOperations("Insert Operation");
			adminService.saveAdmin(updates);
		}
		model.addAttribute("corporateId", corporateTO.getCorporateId());

		return new ModelAndView("redirect:viewcorporatebyId");
	}

	@RequestMapping(value = "viewcorporate")
	public ModelAndView viewCorporate(ModelMap model, @RequestParam Integer userId,String roleType) {

		System.out.println("role type is :"+roleType);
		HashMap<String, String> employeeId = hr.getEmployeeIdFromUserId(userId);
		
		if(roleType.equalsIgnoreCase("Corporate Executive")){
		List<HashMap<String, String>> allCorporate = corporate.getAllCorporate("WHERE adr.address_type = 11 AND corp.executive = '"+employeeId.get("empId")+"'");
		model.addAttribute("allCorporate", allCorporate);
		}
		else{
			List<HashMap<String, String>> allCorporate = corporate.getAllCorporate("WHERE adr.address_type = 11 ");
			model.addAttribute("allCorporate", allCorporate);
		}
		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);

		return new ModelAndView("Admin/corporate/viewCorporate","corporateDTO", new CorporateAppointmentsDTO());
	}

	@RequestMapping(value = "viewcorporatebyId", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView viewCorporateById(ModelMap model, Integer corporateId) {
		LOG.info("++++++++++++++++++++++ Enter into viewCorporateById where corp Id is : "
				+ corporateId);

		HashMap<String, String> corporateById = corporate.getCorporateById(corporateId);
		model.addAttribute("corporateById", corporateById);

		List<CorporateAppointmentsDTO> corporateBranch = corporate
				.getCorporateBranch(corporateId);
		model.addAttribute("corporateBranch", corporateBranch);

		ArrayList<HashMap<String, String>> corporateApptThruCorpId = corporate
				.getCorporateApptThruCorpId(corporateId);
		model.addAttribute("apptList", corporateApptThruCorpId);

		ArrayList<HashMap<String, String>> corporateContactListCorpId = corporate
				.getCorporateContactListCorpId(corporateId);
		model.addAttribute("conatctList", corporateContactListCorpId);

		ArrayList<HashMap<String, String>> corporatePreEmploymentList = corporate
				.getCorporatePreEmploymentList(corporateId);
		model.addAttribute("preEmpList", corporatePreEmploymentList);

		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);

		ArrayList<HashMap<String,String>> corporatInterActionList = corporate.getCorporatInterActionList(corporateId);
		model.addAttribute("interActionList", corporatInterActionList);
		LOG.info("---------------------- End of viewCorporateById ");
		return new ModelAndView("Admin/corporate/viewCorporateDetails",
				"corporateDTO", new CorporateAppointmentsDTO());
	}

	@RequestMapping(value = "corporateContactList")
	public ModelAndView corporateContactList(ModelMap model, Integer corporateId) {

		LOG.info("++++++++++++++++++++++ Enter into corporateContactList where corpt Id is : "
				+ corporateId);
		List<CorporateAppointmentsDTO> corporateContactList = corporate
				.getCorporateContactList(corporateId);
		model.addAttribute("corporateContactList", corporateContactList);
		LOG.info("---------------------- End of corporateContactList ");
		return new ModelAndView("Admin/corporate/corporateContact",
				"corporateDTO", new CorporateAppointmentsDTO());
	}

	@RequestMapping(value = "viewcorporateappointment")
	public ModelAndView viewCorporateAppointment(ModelMap model, @RequestParam Integer userId, String roleType) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy",
				Locale.ENGLISH);
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		HashMap<String, String> employee = hr.getEmployeeIdFromUserId(userId);
		if(roleType.equalsIgnoreCase("Corporate Executive")){
		model.addAttribute("executive", employee.get("empId"));
		}
		else{
			model.addAttribute("executive", "");	
		}
		return new ModelAndView("redirect:viewcorpAppt");
	}

	@RequestMapping(value = "viewcorpAppt")
	public ModelAndView viewCorporateAppointment1(ModelMap model,@RequestParam String fromDate, String toDate, String executive) {
		List<CorporateAppointmentsDTO> viewCorporateAppointment = corporate
				.getViewCorporateAppointment(fromDate, toDate, executive);
		model.addAttribute("viewCorporateAppointment", viewCorporateAppointment);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);

		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);
		
		if(!executive.equalsIgnoreCase("")){
		EmployeeDetailsDTO employeeById = hr.getEmployeeById(Integer.parseInt(executive));
		model.addAttribute("employeeById", employeeById);
		}
		return new ModelAndView("Admin/corporate/viewCorporateAppointment");
	}

	@RequestMapping(value = "editcorporateAppointment")
	public ModelAndView editCorporateAppointment(ModelMap model,String corporateId) {
		try {
			CorporateAppointmentsDTO corptAppointmentById = corporate.getCorptAppointmentById(corporateId);
			model.addAttribute("corptAppointmentById", corptAppointmentById);

			List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
			model.addAttribute("executive", executiveList);

			List<WelezoConstantsTO> welezoConstant = adminService.getWelezoConstant();
			model.addAttribute("welezoConstant", welezoConstant);
		} catch (Exception e) {
			LOG.error(e);
		}
		return new ModelAndView("Admin/corporate/editCorporate","corporateDTO", new CorporateAppointmentsDTO());
	}

	@RequestMapping(value = "posteditcorptAppointment")
	public ModelAndView postEditCorporateAppointment(ModelMap model,CorporateAppointmentsDTO corporateTO) {

		CorporateAppointmentsDTO corptAppointmentById = corporate.getCorptAppointmentById(corporateTO.getAppointmentId().toString());
		
		ContactTO contact = new ContactTO();
		contact.setContactId(corporateTO.getContactId());
		CorporateAppointmentsTO appointmentsTO = new CorporateAppointmentsTO();
		appointmentsTO.setAppointmentId(corporateTO.getAppointmentId());
		appointmentsTO.setContact(contact);
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String cheqdate = corporateTO.getAppointmentDate();
		try {
			Date date = formatter.parse(cheqdate);
			appointmentsTO.setAppointmentDate(date);
		} catch (ParseException e) {
			e.printStackTrace();
			LOG.error(e);
		}
		Calendar cal = Calendar.getInstance();
		appointmentsTO.setTimeAppointment(corporateTO.getTimeAppointment());
		appointmentsTO
				.setExecutive(Integer.parseInt(corporateTO.getExecutive()));
		appointmentsTO.setMeetingStatus(corporateTO.getMeetingStatus());
		appointmentsTO.setStatus(corporateTO.getStatus());
		appointmentsTO.setPurpose("Meeting");
		UsermasterDTO userById = userService.getUserById(corporateTO
				.getCreatedBy());
		appointmentsTO.setRemarks(corptAppointmentById.getRemarks() + " \n- "
				+ userById.getUserName() + ", " + cal.getTime() + ", "
				+ corporateTO.getRemarks());
		adminService.upDateAdmin(appointmentsTO);
		TablesUpdatesTO updates = new TablesUpdatesTO();
		updates.setOperationBy(corporateTO.getCreatedBy());
		updates.setOperationDate(cal.getTime());
		updates.setColumnId(corporateTO.getAppointmentId());
		updates.setUpdates("edit appointment");
		updates.setTableName("corporate_appointment");
		updates.setOperations("update Values");
		adminService.saveAdmin(updates);
		
		model.addAttribute("corporateId", corporateTO.getCorporateId());

		return new ModelAndView("redirect:viewcorporatebyId");
	}

	@RequestMapping(value = "saveCorpInterActions")
	public ModelAndView saveNewInterAction(ModelMap model,
			@RequestParam String remarks, String purpose, String status,
			Integer interactionBy, String interactionMode, Integer corporateId,
			String contactName, String designation, String primaryContact,
			String primaryEmail,String appointmentDate,String timeAppointment,String executive) {

		CorporateDetailsTO corporateTO = new CorporateDetailsTO();
		corporateTO.setCorporateId(corporateId);

		ContactTO contactTO = new ContactTO();
		contactTO.setContactName(contactName);
		contactTO.setPrimaryContact(primaryContact);
		contactTO.setPrimaryEmail(primaryEmail);
		contactTO.setDesignation(designation);
		contactTO.setCorporateDetails(corporateTO);
		adminService.saveAdmin(contactTO);

		HashMap<String, String> employee = hr.getEmployeeIdFromUserId(interactionBy);
		String query = "INSERT INTO corporate_interaction (contact_id,corporate_id,interaction_mode,interaction_by,interaction_date,purpose,status,remarks)"
				+ " VALUES('"
				+ contactTO.getContactId()
				+ "','"
				+ corporateId
				+ "','"
				+ interactionMode
				+ "','"
				+ employee.get("empId")
				+ "',CURRENT_TIMESTAMP,'"+purpose+"','"
				+ status
				+ "','"
				+ remarks
				+ "');";

	//	System.out.println(query);
		// HRService hr = new HRServiceImpl();
		hr.upDateQuery(query);

		if(interactionMode.equalsIgnoreCase("Visit")){
			SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
			SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
			String date = null;
			try {

				date = formatter.format(sdf.parse(appointmentDate));
			} catch (Exception e) {
				e.printStackTrace();
			}
			String query2 = "INSERT INTO corporate_appointments (executive,appointment_date,time_appointment,meeting_status,STATUS,purpose,remarks,contact_id)"
					+ " VALUES('"+executive+"','"+date+"','"+timeAppointment+"','Fresh','New','Meeting','"+remarks+"','"+contactTO.getContactId()+"');";
		System.out.println("Visit appt :"+query2);
			hr.upDateQuery(query2);
		}
		model.addAttribute("corporateId", corporateId);

		return new ModelAndView("redirect:viewcorporatebyId");
	}
	@RequestMapping(value = "addInteractionForExistingContact")
	public ModelAndView addInteractionForExistingContact(ModelMap model,Integer contactId) {
		List<WelezoConstantsTO> welezoConstant = adminService.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		HashMap<String, String> corporateContactByID = corporate.getCorporateContactByID(contactId);
		model.addAttribute("contactById", corporateContactByID);
		
		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);

		return new ModelAndView("Admin/corporate/addInteractionExistingContact");
	}
	@RequestMapping(value = "saveCorpInterActionsExisting")
	public ModelAndView saveExisitingContactInterAction(ModelMap model,@RequestParam String remarks, String purpose, String status,
			Integer interactionBy, String interactionMode, Integer corporateId,Integer contactId,
			String contactName, String designation, String primaryContact,
			String primaryEmail,String timeAppointment,String appointmentDate,Integer executive) {

		String query1 = "UPDATE contact SET contact_name ='"+contactName+"',designation = '"+designation+"',primary_contact = '"+primaryContact+"',primary_email='"+primaryEmail+"',contact_status ='Updated' WHERE contact_id = '"+contactId+"'";
		hr.upDateQuery(query1);
		HashMap<String, String> employeeIdFromUserId = hr.getEmployeeIdFromUserId(interactionBy);
		
		String query = "INSERT INTO corporate_interaction (contact_id,corporate_id,interaction_mode,interaction_by,interaction_date,purpose,status,remarks)"
				+ " VALUES('"+contactId+ "','"
				+ corporateId
				+ "','"
				+ interactionMode
				+ "','"
				+ employeeIdFromUserId.get("empId")
				+ "',CURRENT_TIMESTAMP,'"+purpose+"','"
				+ status
				+ "','"
				+ remarks+ "')";

		//System.out.println(query);
		hr.upDateQuery(query);
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		String date = null;
		try {

			date = formatter.format(sdf.parse(appointmentDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String query2 = "INSERT INTO corporate_appointments (executive,appointment_date,time_appointment,meeting_status,STATUS,purpose,remarks,contact_id)"
				+ " VALUES('"+executive+"','"+date+"','"+timeAppointment+"','Fresh','New','Meeting','"+remarks+"','"+contactId+"')";
	
		hr.upDateQuery(query2);
		
		model.addAttribute("corporateId", corporateId);

		return new ModelAndView("redirect:viewcorporatebyId");
	}
	@RequestMapping(value = "postEditCorporateDetails")
	public ModelAndView postEditCorporateDetails(ModelMap model,CorporateAppointmentsDTO corporateDTO) {
		
		String query ="UPDATE corporate_details SET corporate_name = '"+corporateDTO.getCorporateName()+"',head_count ='"+corporateDTO.getTotalStrength()+"',channel_id ='"+corporateDTO.getChannelId()+"' WHERE corporate_id = '"+corporateDTO.getCorporateId()+"'";
		hr.upDateQuery(query);
		System.out.println(query);
		String query1 = "UPDATE contact_address SET address_line ='"+corporateDTO.getResidenceAddresss()+"',city = '"+corporateDTO.getCity()+"',pincode = '"+corporateDTO.getPincode()+"', landmark = '"+corporateDTO.getLandmark()+"',alt_no = '"+corporateDTO.getLandline()+"' WHERE  address_id ='"+corporateDTO.getAppointmentId()+"' ";
		hr.upDateQuery(query1);
		System.out.println(query1);
		model.addAttribute("corporateId", corporateDTO.getCorporateId());
		return new ModelAndView("redirect:viewcorporatebyId");
	}
	
	@RequestMapping(value = "viewCorpInteraction")
	public ModelAndView viewCorpInteraction(ModelMap model, @RequestParam Integer userId, String roleType) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH);
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		HashMap<String, String> employee = hr.getEmployeeIdFromUserId(userId);
		if(roleType.equalsIgnoreCase("Corporate Executive")){
		model.addAttribute("executive", employee.get("empId"));
		}
		else{
			model.addAttribute("executive", "");	
		}
		return new ModelAndView("redirect:viewCorpInteractions");
	}

	@RequestMapping(value = "viewCorpInteractions", method ={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView viewCorpInteraction1(ModelMap model,@RequestParam String fromDate, String toDate, String executive) {
	
		 ArrayList<HashMap<String, String>> corporatInterActionList = corporate.getCorporatInterActionList(fromDate, toDate,executive);
		
		model.addAttribute("corporateInteraction", corporatInterActionList);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);

		List<EmployeeDTO> executiveList = adminService.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND department LIKE '%Corporate%'");
		model.addAttribute("executive", executiveList);
		
		if(!executive.equalsIgnoreCase("")){
		EmployeeDetailsDTO employeeById = hr.getEmployeeById(Integer.parseInt(executive));
		model.addAttribute("employeeById", employeeById);
		}
		return new ModelAndView("Admin/corporate/viewCorporateInteraction");
	}

/*---------------------------------------Sunil Sir-----------------------------------------*/
	
	
	

	
	@RequestMapping(value="saveProductList" ,method = RequestMethod.POST)
	public  ModelAndView saveProductList(ModelMap model, CorporateAppointmentsDTO corporateTO, Integer corporateId) throws ParseException{
		try{
	    
	    
	        CorporateServiceOffersTO 	corporateServiceOffersTO= new CorporateServiceOffersTO();
	    	CorporateServiceOffersTO 	corporateServiceOffersTOO= new CorporateServiceOffersTO();
	    	ProductGenTO productGenTO =new ProductGenTO() ;
	    	
			corporateServiceOffersTO.setCorpId(corporateTO.getCorporateId());
			corporateServiceOffersTO.setHealthCheckId(corporateTO.getHealthCheckId());
			corporateServiceOffersTO.setServiceHeadCount(corporateTO.getServiceHeadCount());
			corporateServiceOffersTO.setIsActive(1);
			corporateServiceOffersTO.setProName(corporateTO.getProName());
			adminService.saveAdmin(corporateServiceOffersTO);
		
			
	       int []listArray =  corporateTO.getServiceList(); 				
	       
			corporateServiceOffersTOO=corporate.getCorpServiceById(corporateTO.getCorporateId());
			int prodId=corporateServiceOffersTOO.getProductId();
					
			

			for (int i = 0; i <  listArray.length; i++) {			
				productGenTO.setProductId(prodId);
			    productGenTO.setServiceList(listArray[i]);
		      
		    	adminService.saveAdmin(productGenTO);
			}
			
			List<EmployeeDTO> executiveList = adminService
					.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
					model.addAttribute("executive", executiveList);	
					model.addAttribute("corporateId", corporateTO.getCorporateId());
					model.addAttribute("prodID",corporateServiceOffersTOO.getProductId());
		}catch(Exception e ){
			e.printStackTrace();
			
		}
		
		return new ModelAndView("redirect:viewCorpProd");		
	}
	
	

	@RequestMapping(value="viewCorpProd")
	public ModelAndView viewCorpProduct(ModelMap model){
		
		ArrayList <HashMap<String, String>> allCorpProd =  corporate.getAllCorpProd();
		model.addAttribute("allCorpProd", allCorpProd);
		
		return new ModelAndView("Admin/corporate/viewCorpProd","corporateDTO",new CorporateAppointmentsDTO());
	}



@RequestMapping(value="viewcorpProdbyIdOnly")
public ModelAndView viewcorpProdbyIdOnly(ModelMap model,Integer prodId, Integer corporateId , String prodName){
	
	ArrayList<HashMap<String, String>> prodList = corporate.getCorpProducts(prodId);
	model.addAttribute("prodId", prodId);
	model.addAttribute("corporateId", corporateId);
	model.addAttribute("prodList", prodList);
	model.addAttribute("prodName", prodName);
	return new ModelAndView("Admin/corporate/viewcorpProdbyIdOnly", "corporateDTO",new CorporateAppointmentsDTO() );
}







/*product Generation Methods*/

@RequestMapping(value="productGeneration")
public ModelAndView prodGenerationForm(ModelMap model, Integer  corporateId){
	
	
	System.out.println("productGeneration Inside");
	System.out.println("corporateId in corporateId:"+ corporateId);
	
	
	HashMap<String, String> corporateById = corporate.getCorporateById(corporateId);
	model.addAttribute("corporateById", corporateById);
	model.addAttribute("corporateId", corporateId);
	
	
	List<ServiceParametersTo> serviceParam =  corporate.getServiceParametersList();		
	Iterator<ServiceParametersTo> iterator = serviceParam.iterator();
	JSONArray mArray = new JSONArray();		
	try {	
	while (iterator.hasNext()) {			
		ServiceParametersTo servicePara = (ServiceParametersTo) iterator.next();			
		JSONObject obj = new JSONObject();
		obj.put("id", servicePara.getHealthParameterId() );
		obj.put("text", servicePara.getScreening());
		obj.put("parentId", servicePara.getParentId());
		mArray.put(obj);		
			
		String string = mArray.toString();			
		model.addAttribute("object", string);	
	}
	} catch (Exception e) {
		e.printStackTrace();
	}   
	
	return new ModelAndView("Admin/corporate/productGeneration", "corporateDTO",new CorporateAppointmentsDTO());
} 
@RequestMapping(value = "validateCaptchaThroughAJAX", method = RequestMethod.POST)
@ResponseBody
public String corpProductGeneration(@RequestBody String json) 	throws IOException {

System.out.println("testing link");
ObjectMapper mapper = new ObjectMapper();
Person requesValue = mapper.readValue(json, 
	Person.class);
Person person = new Person();	
person.setProName(requesValue.getProName());
List<Integer> list=requesValue.getServiceList();

try{


CorporateServiceOffersTO 	corporateServiceOffersTO= new CorporateServiceOffersTO();
CorporateServiceOffersTO 	corporateServiceOffersTOO= new CorporateServiceOffersTO();
ProductGenTO productGenTO =new ProductGenTO() ;

corporateServiceOffersTO.setCorpId(requesValue.getCompanyId());
corporateServiceOffersTO.setHealthCheckId(requesValue.getHealthMode());
corporateServiceOffersTO.setServiceHeadCount(requesValue.getEmpCount());
corporateServiceOffersTO.setIsActive(1);
corporateServiceOffersTO.setProName(requesValue.getProName());

adminService.saveAdmin(corporateServiceOffersTO);


List<Integer>listArray =  requesValue.getServiceList();

corporateServiceOffersTOO=corporate.getCorpServiceById(requesValue.getCompanyId());
int prodId=corporateServiceOffersTOO.getProductId();
for (int i = 0; i < listArray.size(); i++) {			
	productGenTO.setProductId(prodId);
    productGenTO.setServiceList(listArray.get(i));
   	adminService.saveAdmin(productGenTO);
}
}catch(Exception e ){
e.printStackTrace();

}




String viewName = "Success";
if (viewName.equalsIgnoreCase("Success")) {
person.setValidation("Success");
} else {
person.setValidation("Error");
}

return toJson(person);
}

private String toJson(Person person) {
ObjectMapper mapper = new ObjectMapper();
try {
String value = mapper.writeValueAsString(person);
return value;
} catch (JsonProcessingException e) {
e.printStackTrace();
return null;
}
}

@RequestMapping(value="viewcorpProdbyId")
public ModelAndView viewcorpProdbyId(ModelMap model, @RequestParam Integer corporateId){

HashMap<String, String> corporateById = corporate.getCorporateById(corporateId);
model.addAttribute("corporateById", corporateById);

ArrayList< HashMap<String, String>>  getCorpProdById= corporate.getCorpProdById(corporateId);
model.addAttribute("corpProdById", getCorpProdById);
model.addAttribute("corporateId", corporateId);
return new ModelAndView("Admin/corporate/viewcorpProdbyId","corporateDTO",new CorporateAppointmentsDTO());

}

@RequestMapping(value="requestGenerationForm")
public ModelAndView requestGenerationForm(ModelMap model,@RequestParam Integer  corporateId){
	

	ArrayList<HashMap<String, String>> corpEmailROQ = corporate.getEmailByCorpId(corporateId);

	
	model.addAttribute("corporateId", corporateId);
	ArrayList<HashMap<String, String>> corpProduct = corporate.getCorpProdById(corporateId);
	model.addAttribute("corpProduct", corpProduct);
	model.addAttribute("corpEmailROQ", corpEmailROQ);	
return new ModelAndView("Admin/corporate/requestGenerationForm", "corpHospitalDTO",new CorpHospitalDTO() );
	
}

@RequestMapping(value="generateRequestQuotation")
public ModelAndView generateRequestQuotation(ModelMap model, CorpHospitalDTO corpHospitalTO){
	try {

		ArrayList<ArrayList<HashMap<String, String>>>  prefProdParam = new ArrayList<ArrayList<HashMap<String,String>>>();
		/*String executiveName=corpHospitalTO.getExecutiveName();
		String fromEmail=corpHospitalTO.getFromEmail();
		String reporttoName=corpHospitalTO.getReporttoName();
		String toEmail=corpHospitalTO.getToEmail();*/
		
		
		Integer []selectedPrefProduct = corpHospitalTO.getPrefProduct();	
		for (int i =0; i<selectedPrefProduct.length;i++) {			
			prefProdParam.add(corporate.getCorpProducts(selectedPrefProduct[i])); 
		}		
		model.addAttribute("prefProdParam", prefProdParam);	
		
	}catch(Exception e){
		 e.printStackTrace();
	}
	return new ModelAndView("Admin/corporate/generateRequestQuotation", "corpHospitalDTO", new CorpHospitalDTO());
}
}


