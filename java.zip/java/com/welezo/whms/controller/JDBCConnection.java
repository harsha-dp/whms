package com.welezo.whms.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JDBCConnection {


		static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
		static final String DB_URL = "jdbc:mysql://167.88.3.119/welezohe_whms";
		static final String USER = "welezohe_read";
		static final String PASS = "ReadDbWelezo@123";

		public  ArrayList<String> getDistinctValues(String sql) {
			Connection conn = null;
			Statement stmt = null;
			ArrayList<String> list = new ArrayList<String>();
			try{
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection(DB_URL,USER,PASS);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(sql);

				while(rs.next()){
					String value = rs.getString(1);
					list.add(value);
					//System.out.println( value);
				}
				//STEP 6: Clean-up environment
				rs.close();
				stmt.close();
				conn.close();
			}catch(SQLException se){
				//Handle errors for JDBC
				se.printStackTrace();
			}catch(Exception e){
				//Handle errors for Class.forName
				e.printStackTrace();
			}finally{
				//finally block used to close resources
				try{
					if(stmt!=null)
						stmt.close();
				}catch(SQLException se2){
				}// nothing we can do
				try{
					if(conn!=null)
						conn.close();
				}catch(SQLException se){
					se.printStackTrace();
				}//end finally try
			}//end try
			//System.out.println("Goodbye!");
			return list;
		}

	}
