package com.welezo.whms.controller;

import java.io.IOException;

import javax.mail.MessagingException;

import net.sourceforge.tess4j.TesseractException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;

import com.welezo.whms.commons.OcrReader;
import com.welezo.whms.commons.SMSNotifoication;

@Controller
public class ScheduledTaskController {

	@Autowired
	MailReportController user;

	@Autowired
	HRContoller hrController;

	@Scheduled(cron = "06 12 16 * * MON-SAT")
	public void teleSales() throws InterruptedException, MessagingException,
			TesseractException {
		// user.teleSalesDepartmentEmailReports();
		OcrReader ocr = new OcrReader();
		ocr.ocrTest();
		//Thread.sleep(1000);
	}

	// @Scheduled(cron = "01 15 11 * * MON-SAT")
	public void hrAttendance() throws InterruptedException, MessagingException {
		user.hrDepartmentEmailReports();
		// Thread.sleep(500);
	}

	// @Scheduled(cron = "01 33 08 * * *")
	public void dailyAttendance() throws InterruptedException,
			MessagingException {
		// user.hrDepartmentEmailReports();
		hrController.employeeDailyAttendance();

	}

	// @Scheduled(cron = "01 37 09 * * *")
	public void smsCampign() throws InterruptedException, MessagingException {
		SMSNotifoication sms = new SMSNotifoication();
		try {
			sms.smsCampign();
		} catch (IOException e) {
			// System.out.println(e.printStackTrace());
			e.printStackTrace();
		}
	}

}
