package com.welezo.whms.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.commons.Utilities;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.ResultsetColumnsDeatils;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.to.DataAllocationTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Controller
public class TSDataBaseAnalysisController extends CustomHibenateDaoSupport {
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	AdminService adminService;
	@Autowired
	HRService hrService;

	@RequestMapping(value = "/callsData")
	public @ResponseBody ModelAndView excelSheetupload(ModelMap model,
			@RequestParam CommonsMultipartFile file,
			@RequestParam String details, @RequestParam String name,
			@RequestParam String quantity) {

	String path = "/home/welezohealth/whms/telesalesDBMS";
	//	 String path = "C:/home";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();
			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();
		} catch (Exception e) {
		}
		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + filename));

		Integer sourceId = getSourceId(details, name, quantity);

		Connection connection = sessionFactory.getCurrentSession().connection();
		PreparedStatement pstmt = null;
		//System.out.println("inside excel converter");
		String value = "";
		try {

			Workbook workbook = null;
		String excelFilePath = "/home/welezohealth/whms/telesalesDBMS/" + filename;
		//	String excelFilePath = "C:/home/" + filename;
			FileInputStream inputStream = new FileInputStream(new File(
					excelFilePath));
			if (excelFilePath.endsWith("xls")) {
				workbook = new HSSFWorkbook(inputStream);
			} else if (excelFilePath.endsWith("xlsx")) {
				workbook = new XSSFWorkbook(inputStream);
			} else {
				throw new IllegalArgumentException("Incorrect file format");
			}
			Sheet sheet = workbook.getSheetAt(0);

			Iterator<Row> itr = sheet.iterator();
			// Iterating over Excel file in Java
			int recCount = 0;
			while (itr.hasNext()) {
				Row row = itr.next();
				// Iterating over each column of Excel file
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					switch (cell.getCellType()) {
					case Cell.CELL_TYPE_BOOLEAN:
						value = "" + cell.getBooleanCellValue();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						String number = "" + cell.getNumericCellValue();
						// value = number.replaceFirst("\\.",
						// "").replaceAll("E9","");
						Utilities utility = new Utilities();
						value = utility.getNumberFromExponentialFormat(number);

						if (value.length() < 10) {
							System.out.println(number + "   Invalid number ? "
									+ value);
						}
						break;
					case Cell.CELL_TYPE_STRING:
						value = "" + cell.getStringCellValue();
						break;
					case Cell.CELL_TYPE_BLANK:
						value = " " + cell.getCellComment();
						break;
					default:
						break;
					}
					String query = "INSERT INTO leads_upload (source_id,phone_no) VALUES ('"
							+ sourceId + "','" + value + "') ";
					try {
						pstmt = connection.prepareStatement(query);
						// pstmt.addBatch(query);
						recCount++;
						// if(recCount%10 == 0){
						// pstmt.executeBatch();
						// System.out.println("Total rows " + recCount);
						// }
						pstmt.executeUpdate();
						if (recCount % 100 == 0) {
							// System.out.println("Total rows " + recCount);
						}
					} catch (Exception e) {
						// LOG.error(e.getMessage());
						// System.out.println(e.getMessage());
					}
				}
			}

			inputStream.close();
		} catch (FileNotFoundException fe) {
			fe.printStackTrace();
		} catch (IOException ie) {
			ie.printStackTrace();
		} finally {
		}
		//System.out.println("completed");
		updateLeadsUploadTables(sourceId);
		return new ModelAndView("redirect:welezouser_dashboard");
	}

	public Integer getSourceId(String details, String name, String quantity) {
		int sourceId = 0;
		try {
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			String insertQuery = "INSERT INTO lead_sources (source_details,provided_by,qty,upload_date) VALUES ('"
					+ details
					+ "','"
					+ name
					+ "','"
					+ quantity
					+ "',CURRENT_TIMESTAMP)";
			PreparedStatement updPrepStmt = connection
					.prepareStatement(insertQuery);
			updPrepStmt.execute(insertQuery);
			String s = "SELECT MAX(source_id) AS 'id' FROM lead_sources";
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				sourceId = rs.getInt("id");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sourceId;
	}

	public void updateLeadsUploadTables(Integer sourceId) {
		try {
			String query = "CREATE table temp_existing_leads AS "
					+ " SELECT * FROM leads_upload WHERE source_id='"
					+ sourceId
					+ "' AND phone_no IN (SELECT phone_no FROM leads_upload WHERE source_id !='"
					+ sourceId + "' )";
			hrService.upDateQuery(query);

			String query1 = "UPDATE leads_upload SET lead_status='Existing Lead' WHERE source_id="
					+ sourceId
					+ " AND lead_status='New' AND phone_no IN "
					+ "(SELECT phone_no FROM temp_existing_leads)";
			hrService.upDateQuery(query1);

			String query3 = "UPDATE leads_upload SET lead_status = 'Invalid Number' WHERE source_id="
					+ sourceId
					+ " AND (phone_no LIKE '% %' OR LENGTH(phone_no) !=10)";
			hrService.upDateQuery(query3);
			String query4 = "UPDATE leads_upload SET lead_status = 'Customer' WHERE source_id="
					+ sourceId
					+ " AND lead_status = 'New' AND phone_no IN("
					+ "SELECT  primary_mob FROM address WHERE LENGTH(primary_mob) > 3 AND entity_id > 0)";
			hrService.upDateQuery(query4);
			String query5 = "UPDATE leads_upload SET lead_status = 'Customer' WHERE source_id="
					+ sourceId
					+ " AND lead_status = 'New' AND phone_no IN "
					+ "(SELECT  alt_mob FROM address WHERE LENGTH(alt_mob) > 3 AND entity_id > 0) ";
			hrService.upDateQuery(query5);

			String query6 = "UPDATE leads_upload SET lead_status = 'Presales' WHERE source_id="
					+ sourceId
					+ " AND lead_status = 'New' AND phone_no IN "
					+ "(SELECT  primary_mob FROM address WHERE LENGTH(primary_mob) > 3)";
			hrService.upDateQuery(query6);

			String query7 = "UPDATE leads_upload SET lead_status = 'Presales' WHERE source_id="
					+ sourceId
					+ " AND lead_status = 'New' AND phone_no IN"
					+ " (SELECT  alt_mob FROM address WHERE LENGTH(alt_mob) > 3)";
			hrService.upDateQuery(query7);

			/*String query8 = "UPDATE leads_upload SET lead_status  = 'Telesales Call'  WHERE source_id = "
					+ sourceId
					+ " AND lead_status='New' AND phone_no IN "
					+ " (SELECT phone_no FROM call_details WHERE department='Sales' AND call_date > '2017-06-01 00:00:00')";
			hrService.upDateQuery(query8);
			System.out.println(query8);*/

			String query9 = "UPDATE leads_upload SET lead_status  = 'For Allocation'  WHERE source_id = "
					+ sourceId + " AND lead_status='New' ";
			hrService.upDateQuery(query9);
			//System.out.println(query9);

			String query2 = "DROP table temp_existing_leads";
			hrService.upDateQuery(query2);
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	@RequestMapping(value = "/sourceDetails")
	public @ResponseBody ModelAndView getAllSourceDetails(ModelMap model) {
		ArrayList<HashMap<String, String>> sourceList = new ArrayList<>();
		try {
			String s = "SELECT ld.source_id, src.source_details, COUNT(1) data_Quantity, SUM(CASE WHEN lead_status = 'For Allocation' THEN 1 ELSE 0 END) 'ForAllocation' "
					+ " FROM leads_upload ld LEFT JOIN lead_sources src  ON ld.source_id= src.source_id GROUP BY ld.source_id HAVING SUM(CASE WHEN lead_status = 'For Allocation' THEN 1 ELSE 0 END) > 0";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("sourceId", rs.getString("source_id"));
				list.put("sourceDetails", rs.getString("source_details"));
				list.put("dataQuantity", rs.getString("data_Quantity"));
				list.put("ForAllocation", rs.getString("ForAllocation"));
				sourceList.add(list);
			}
			model.addAttribute("sourceList", sourceList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("Admin/DBMStelesales/SourceDetails");
	}

	@RequestMapping(value = "/dataAllocation")
	public @ResponseBody ModelAndView dataAllocationToCsr(ModelMap model,
			@RequestParam Integer sourceId) {

		
		HashMap<String, String> sourceDetailsById = getSourceDetailsById(sourceId);
		model.addAttribute("sourceDetailsById", sourceDetailsById);
	
		ArrayList<HashMap<String, String>> geteExtensionNoAndCsr = adminService.geteExtensionNoAndCsr();
		model.addAttribute("extnCsrList", geteExtensionNoAndCsr);

		return new ModelAndView("Admin/DBMStelesales/contactAllocation");
	}

	public HashMap<String, String> getSourceDetailsById(Integer sourceId) {
		HashMap<String, String> sourceData = new HashMap<String, String>();
		try {
			String s = "SELECT ld.source_id,src.provided_by,src.upload_date, src.source_details, COUNT(1) data_Quantity, SUM(CASE WHEN lead_status = 'For Allocation' THEN 1 ELSE 0 END) 'ForAllocation' "
					+ " FROM leads_upload ld LEFT JOIN lead_sources src  ON ld.source_id= src.source_id WHERE ld.source_id = '"
					+ sourceId
					+ "' GROUP BY ld.source_id HAVING SUM(CASE WHEN lead_status = 'For Allocation' THEN 1 ELSE 0 END) > 0";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				sourceData.put("sourceId", rs.getString("source_id"));
				sourceData.put("sourceDetails", rs.getString("source_details"));
				sourceData.put("dataQuantity", rs.getString("data_Quantity"));
				sourceData.put("ForAllocation", rs.getString("ForAllocation"));
				sourceData.put("providedBy", rs.getString("provided_by"));
				sourceData.put("uploadDate", rs.getString("upload_date"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sourceData;
	}

	@RequestMapping(value = "/saveAllocatedData", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveDataAllocation(ModelMap model,
			@RequestParam Integer sourceId, Integer allocatedBy,
			String[] empId, Integer allocatedNo, String remarks) {
		Calendar cal = Calendar.getInstance();
		DataAllocationTO allocation = new DataAllocationTO();
		allocation.setSourceId(sourceId);
		allocation.setAllocatedBy(allocatedBy);
		allocation.setAllocationDate(cal.getTime());
		allocation.setRemarks(remarks);
		adminService.saveAdmin(allocation);

		for (int i = 0; i < empId.length; i++) {
			if (empId[i] != null) {
				// System.out.println("emp id :"+empId[i]);
				String query = "UPDATE  leads_upload SET lead_status = 'Allocated' ,csr = '"
						+ empId[i]
						+ "' ,allocation_id = '"
						+ allocation.getAllocationId()
						+ "' "
						+ " WHERE `source_id` = '"
						+ sourceId
						+ "' AND lead_status ='For Allocation' ORDER BY id LIMIT "
						+ allocatedNo + "";
				hrService.upDateQuery(query);
			}
		}
		model.addAttribute("sourceId", sourceId);
		return new ModelAndView("redirect:dataAllocation");
	}

	@RequestMapping(value = "/viewAllocation")
	public ModelAndView viewAllocation(ModelMap model) {

		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csrList", allEmployeeDetails);
		Calendar calendar = Calendar.getInstance();
		String firstDate = new SimpleDateFormat("dd/MM/yyyy").format(calendar
				.getTime());
		model.addAttribute("fromDate", firstDate);
		return new ModelAndView("Admin/DBMStelesales/viewAllocation");
	}

	@RequestMapping(value = "/viewAllocation1" , method = RequestMethod.POST)
	public ModelAndView viewAllocation1(ModelMap model,
			@RequestParam String date, Integer csr) {
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date1 = formatter.format(sdf.parse(date));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> phoneList = new ArrayList<>();
		try {
			String s = "SELECT ld.*, emp.emp_name,alc.`allocation_date` FROM leads_upload ld  LEFT JOIN employee_details emp ON emp.emp_id = ld.csr "
					+ " LEFT JOIN data_allocation alc ON alc.allocation_id = ld.allocation_id "
					+ " WHERE ld.csr = '"
					+ csr
					+ "' AND (allocation_date BETWEEN '"
					+ date1
					+ " 00:00:00' AND '" + date1 + " 23:59:59')";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("phoneNo", rs.getString("phone_no"));
				list.put("empName", rs.getString("emp_name"));
				list.put("allocationDate", rs.getString("allocation_date"));
				list.put("id", rs.getString("id"));
				phoneList.add(list);
			}
			EmployeeDetailsDTO employeeById = hrService.getEmployeeById(csr);
			model.addAttribute("employeeId", employeeById);

			model.addAttribute("phoneList", phoneList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", date);
		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csrList", allEmployeeDetails);

		return new ModelAndView("Admin/DBMStelesales/viewAllocation");
	}

	@RequestMapping(value = "/sourceDetailsById")
	public @ResponseBody ModelAndView getSourceDetailsById(ModelMap model,
			@RequestParam Integer sourceId) {
		ArrayList<HashMap<String, String>> sourceList = new ArrayList<>();
		try {
			String s = "SELECT source_id,lead_status, COUNT(1) as 'Total'  FROM leads_upload WHERE source_id = '"
					+ sourceId
					+ "' GROUP BY lead_status,source_id "
					+ "UNION ALL SELECT source_id,'GRAND TOTAL', COUNT(1)  FROM leads_upload WHERE source_id = '"
					+ sourceId + "'  GROUP BY source_id ORDER BY 3";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("sourceId", rs.getString("source_id"));
				list.put("Total", rs.getString("Total"));
				list.put("leadStatus", rs.getString("lead_status"));
				sourceList.add(list);
			}
			model.addAttribute("sourceList", sourceList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		HashMap<String, String> sourceDetailsById = getSourceDetailsById(sourceId);
		model.addAttribute("sourceDetails", sourceDetailsById);
		ArrayList<HashMap<String, String>> allAllocatedData = getAllAllocatedData(sourceId);
		model.addAttribute("allAllocatedData", allAllocatedData);
		return new ModelAndView("Admin/DBMStelesales/sourceDetailById");
	}

	public ArrayList<HashMap<String, String>> getAllAllocatedData(
			Integer sourceId) {
		ArrayList<HashMap<String, String>> extenstionList = new ArrayList<>();
		try {
			String s = "SELECT CAST(allocation_date AS DATE) AS 'Allocated Date', ld.csr AS 'EMPID',emp.emp_name AS 'CSR NAME', COUNT(1) AS 'Allocated'"
					+ " FROM leads_upload ld LEFT JOIN employee_details emp ON emp.emp_id = ld.csr "
					+ " LEFT JOIN data_allocation allc	ON allc.allocation_id = ld.allocation_id "
					+ " WHERE ld.source_id = '"+ sourceId+ "' AND ld.lead_status = 'Allocated' GROUP BY ld.csr ,allc.allocation_date UNION ALL "
					+ "SELECT '', '','GRAND TOTAL', COUNT(1) AS 'Allocated' FROM leads_upload ld  "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = ld.csr LEFT JOIN data_allocation allc ON allc.allocation_id = ld.allocation_id "
					+ " WHERE ld.source_id = '"+ sourceId+ "' AND ld.lead_status = 'Allocated'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("empId", rs.getString("EMPID"));
				list.put("empName", rs.getString("CSR NAME"));
				list.put("Allocated", rs.getString("Allocated"));
				list.put("allocatedDate", rs.getString("Allocated Date"));
				
				extenstionList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return extenstionList;
	}

	@RequestMapping(value = "/updateCallStatus")
	public ModelAndView updateCallStatus(ModelMap model) {

		ArrayList<HashMap<String, String>> geteExtensionNoAndCsr = adminService.geteExtensionNoAndCsr();
		model.addAttribute("extnCsrList", geteExtensionNoAndCsr);
		Calendar calendar = Calendar.getInstance();
		String firstDate = new SimpleDateFormat("dd/MM/yyyy").format(calendar
				.getTime());
		model.addAttribute("fromDate", firstDate);
		return new ModelAndView("Admin/DBMStelesales/callStatusUpdate");
	}

	@RequestMapping(value = "/updateCallStatus1", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView updateCallStatus1(ModelMap model,
			@RequestParam String date, Integer csr) {
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date1 = formatter.format(sdf.parse(date));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> phoneList = new ArrayList<>();
		try {
			String s = "SELECT cal.*,emp.emp_name FROM call_status cal LEFT JOIN  employee_details emp ON emp.emp_id = cal.emp_id "
					+ " WHERE cal.emp_id = '"
					+ csr
					+ "' AND (calltime BETWEEN '"
					+ date1
					+ " 00:00:00' AND '"
					+ date1 + " 23:59:59') AND call_status IN ('Called')";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("phoneNo", rs.getString("phone"));
				list.put("empName", rs.getString("emp_name"));
				list.put("id", rs.getString("id"));
				list.put("duration", rs.getString("duration"));
				list.put("calltime", rs.getString("calltime"));
				phoneList.add(list);
			}
			EmployeeDetailsDTO employeeById = hrService.getEmployeeById(csr);
			model.addAttribute("employeeId", employeeById);

			model.addAttribute("phoneList", phoneList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", date);
		ArrayList<HashMap<String, String>> geteExtensionNoAndCsr = adminService.geteExtensionNoAndCsr();
		model.addAttribute("extnCsrList", geteExtensionNoAndCsr);

		List<WelezoConstantsTO> welezoConstant = adminService.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		return new ModelAndView("Admin/DBMStelesales/callStatusUpdate");
	}

	@RequestMapping(value = "/saveCallStatus", method = RequestMethod.POST)
	public ModelAndView saveCallStatus(ModelMap model,@RequestParam Integer[] id, String[] status, Integer empId,
			String fromDate, String[] remarks, String[] reasons,String[] phoneNo, String[] nextDate) {
	
		System.out.println("array index = " + id.length);
		int index = id.length;
		for (int i = 0; i < index; i++) {
			if (!status[i].equalsIgnoreCase("")) {
				String query = "UPDATE call_status SET call_status = '"
						+ status[i] + "',reason = '" + reasons[i]
						+ "',remarks ='" + remarks[i] + "' WHERE id = '"
						+ id[i] + "'";
				System.out.println(query);
				hrService.upDateQuery(query);
				
				if (status[i].equalsIgnoreCase("Call Back")) {
					
					String query1 = "INSERT INTO call_back (emp_id, entity_id, entity_type, phone_no,sc_datetime, created_date ) VALUES('"
							+ empId	+ "','"	+ id[i]+ "','Presales','"+ phoneNo[i]+ "','"+ nextDate[i]+ "',CURRENT_TIMESTAMP)";
					System.out.println(query1);
					hrService.upDateQuery(query1);
				}
			}
		}
		model.addAttribute("csr", empId);
		model.addAttribute("date", fromDate);

		return new ModelAndView("redirect:updateCallStatus1");
	}
	@RequestMapping(value = "callsDispositions")
	public ModelAndView searchCallDetails(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		model.addAttribute("groupBy", "Call Back Report");
		return new ModelAndView("redirect:callsDispositions1");
	}
	
	@RequestMapping(value = "/callsDispositions1")
	public ModelAndView callStatusDispositionReport(ModelMap model,@RequestParam String fromDate, @RequestParam String toDate,@RequestParam String groupBy) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = null;
			if(groupBy.equalsIgnoreCase("Calls Disposition")){
			 s = "SELECT LEFT(calltime, 10) AS call_date,  "
					+ "SUM(CASE WHEN call_status = 'Called' THEN 1 ELSE 0 END) PendingStatus,"
					+ "SUM(CASE WHEN call_status = 'NotInterested' THEN 1 ELSE 0 END) NotInterested, "
					+ "SUM(CASE WHEN call_status = 'NotListening' THEN 1 ELSE 0 END) NotListening, "
					+ "SUM(CASE WHEN call_status = 'Call Back' THEN 1 ELSE 0 END) CallBack, "
					+ "SUM(CASE WHEN call_status = 'Cannot Sell' THEN 1 ELSE 0 END) CannotSell, "
					+ "SUM(CASE WHEN call_status = 'Sale Done' THEN 1 ELSE 0 END) SaleDone,"
					+ "SUM(CASE WHEN call_status = 'FollowedUp' THEN 1 ELSE 0 END) FollowedUp, "
					+ " SUM(CASE WHEN call_status = 'Interested' THEN 1 ELSE 0 END) Interested,  "
					+ "SUM(CASE WHEN call_status = 'Active' THEN 1 ELSE 0 END) ActiveBelow30sec, "
					+ "COUNT(1) TotalPresentation FROM call_status WHERE duration >= 00 AND (calltime BETWEEN '"+date+" 00:00:00'AND '"+date1+" 23:59:59') GROUP BY 1";
			}else{
				s="SELECT cl.call_back_id,cl.phone_no,cl.sc_datetime AS 'call Back',emp.emp_name,st.duration,st.extn_no,st.call_status,st.reason,"
						+ " st.remarks,st.calltime FROM call_back cl "
						+ "LEFT JOIN call_status st ON st.id = cl.entity_id "
						+ "LEFT JOIN  employee_details emp ON emp.emp_id = cl.emp_id "
						+ "WHERE cl.sc_datetime BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:59:59'";
			}
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);

			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("groupBy", groupBy);
		return new ModelAndView("Admin/DBMStelesales/callDispositionReport");
	}
}