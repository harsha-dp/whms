package com.welezo.whms.controller;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.SMSNotifoication;
import com.welezo.whms.dto.InteractionRegisterDTO;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.EmployeeImagesTO;
import com.welezo.whms.to.PresalesTO;
import com.welezo.whms.to.UserActivityTO;
import com.welezo.whms.to.UsermasterTO;

@Controller
public class UserController {
	HttpSession session = null;
	@Autowired
	UserService userService;
	@Autowired
	AdminService adminService;
	@Autowired
	HRService hrService;
	@Autowired
	ReportController report;
	@Autowired
	private JavaMailSender mailSender;

	// first page open in server i.e login page..
	@RequestMapping(value = "check")
	public ModelAndView display(ModelMap model) {
		UsermasterDTO loginDTO = new UsermasterDTO();
		// String employeeBirthdayList = report.employeeBirthdayList();
		// model.addAttribute("dobList", employeeBirthdayList);
		return new ModelAndView("Admin/welezo-login", "login", loginDTO);
	}

	@RequestMapping(value = "error")
	public ModelAndView error(ModelMap model) {

		return new ModelAndView("Admin/errorpage");
	}

	@RequestMapping(value = "/signup")
	public ModelAndView signup() {
		UsermasterDTO loginDTO = new UsermasterDTO();
		return new ModelAndView("Admin/welezo-register", "signup", loginDTO);
	}

	@RequestMapping(value = "/forgotpwd")
	public ModelAndView forpwd() throws MessagingException {
		UsermasterDTO loginDTO = new UsermasterDTO();
		final String toAddr = "lohithvn1990@gmail.com";
		final String fromAddr = "care@welezohealth.com";
		// email subject
		final String subject = "Dear.. This email sent by welezo ";
		// email body
		final String body = "Promotional HEALTH CARE PVT Ltd.. MAKE INDIA HEALTHY..";

		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(toAddr);
		email.setSubject(subject);
		email.setText(body);
		email.setFrom(fromAddr);
		// sends the e-mail
		// mailSender.send(email);
		mailSender.send(email);

		// InputStream is = null;
		String toAddr1 = "hiremath@welezohealth.com";
		String fromAddr1 = "care@welezohealth.com";
		String subject1 = "My Test Mail";
		String body1 = "Test mail body";

		MimeMessage message = mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(fromAddr1);
			helper.setTo(toAddr1);
			helper.setSubject(subject1);
			helper.setText(body1);
			helper.addAttachment("Test.docx", new File("D://date.docx"));
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return new ModelAndView("Admin/welezo-recoverpw", "forgotpwd", loginDTO);
	}

	// when enter user-name and password from login page validate here and send
	// values to dashboard page..
	@RequestMapping(value = "/welezouser_dashboard")
	public String login(ModelMap model, UsermasterDTO dto,
			HttpSession httpSession) {

		try {
			if (!(dto.getUserMail().isEmpty())
					&& !(dto.getPassword().isEmpty())) {
				UsermasterDTO login = userService.login(dto.getUserMail(),
						dto.getPassword());
				model.addAttribute("userLogin", login);

				if (login.getUserMail() != null && login.getPassword() != null) {

					if (login.getUserMail().equals(dto.getUserMail())
							&& (login.getRoleType().equals("HR"))
							&& login.getPassword().equalsIgnoreCase(
									dto.getPassword())) {

						try {
							InetAddress ip = InetAddress.getLocalHost();
							String hostname = ip.getHostName();
							UserActivityTO userActivityTO = new UserActivityTO();
							userActivityTO.setIpAddress(ip.toString());
							userActivityTO.setMac(hostname);
							DateFormat dateFormat = new SimpleDateFormat(
									"dd/MM/yyyy HH:mm:ss");
							Date date1 = new Date();
							String reportDate = dateFormat.format(date1);
							// dateFormat.getTimeInstance();
							Date date = null;
							try {
								date = new SimpleDateFormat(
										"dd/MM/yyyy HH:mm:ss")
										.parse(reportDate);
								Timestamp timestamp = new Timestamp(
										date.getTime());
								userActivityTO.setLoginDate(date);
								userActivityTO.setLoginTime(timestamp);
							} catch (ParseException e) {
								e.printStackTrace();
							}
							UsermasterTO usermasterTo = new UsermasterTO();
							usermasterTo.setUserId(login.getUserId());
							userActivityTO.setUsermaster(usermasterTo);
							adminService.saveOrUpdate(userActivityTO);

						} catch (Exception e) {
							e.printStackTrace();
							return "redirect:check";
						}
						try {
							httpSession.setAttribute("USERNAME",
									login.getUserName());
							httpSession.setAttribute("USERID",
									login.getUserId());
							httpSession.setAttribute("ROLETYPE",
									login.getRoleType());

							HashMap<String, String> employeeIdFromUserId = hrService
									.getEmployeeIdFromUserId(login.getUserId());
							EmployeeImagesTO employeeImage1 = report
									.getEmployeeImage(Integer
											.parseInt(employeeIdFromUserId
													.get("empId")));
							String encode = Base64
									.encodeBase64String(employeeImage1
											.getEmpImg());
							model.addAttribute("empImge1", encode);
							httpSession.setAttribute("empImge1", encode);

							HashMap<String, String> roleBaseAccessRoleId = report
									.getRoleBaseAccessRoleId(employeeIdFromUserId
											.get("empId"));
							httpSession.setAttribute("roleAccess",
									roleBaseAccessRoleId);

							String query = "SELECT * FROM user_access ua LEFT JOIN modules mods ON mods.module_id = ua.module_id WHERE ua.role_id = '"
									+ roleBaseAccessRoleId.get("empRoleId")
									+ "' AND ua.module_priority IS  TRUE ORDER BY mods.module_name";
							System.out.println("Role base Access :" + query);
							ArrayList<HashMap<String, String>> userAccessModule = userService
									.getUserAccessModule(query);
							model.addAttribute("userAccessModule",
									userAccessModule);
							httpSession.setAttribute("userAccessModule",
									userAccessModule);
						} catch (Exception e) {
							e.printStackTrace();
							return "redirect:check";
						}
						return "HR/dashboard";

					} else {
						try {
							InetAddress ip = InetAddress.getLocalHost();
							String hostname = ip.getHostName();
							UserActivityTO userActivityTO = new UserActivityTO();
							userActivityTO.setIpAddress(ip.toString());
							userActivityTO.setMac(hostname);
							DateFormat dateFormat = new SimpleDateFormat(
									"dd/MM/yyyy HH:mm:ss");
							Date date1 = new Date();
							String reportDate = dateFormat.format(date1);
							// dateFormat.getTimeInstance();
							Date date = null;
							try {
								date = new SimpleDateFormat(
										"dd/MM/yyyy HH:mm:ss")
										.parse(reportDate);
								Timestamp timestamp = new Timestamp(
										date.getTime());
								// System.out.println(timestamp);
								userActivityTO.setLoginDate(date);
								userActivityTO.setLoginTime(timestamp);
							} catch (ParseException e) {
								e.printStackTrace();
								return "redirect:check";
							}
							UsermasterTO usermasterTo = new UsermasterTO();
							usermasterTo.setUserId(login.getUserId());
							userActivityTO.setUsermaster(usermasterTo);
							adminService.saveOrUpdate(userActivityTO);
						} catch (Exception e) {
							e.printStackTrace();
							return "redirect:check";
						}
						try {
							httpSession.setAttribute("USERNAME",
									login.getUserName());
							httpSession.setAttribute("USERID",
									login.getUserId());
							httpSession.setAttribute("ROLETYPE",
									login.getRoleType());
							HashMap<String, String> employeeIdFromUserId = hrService
									.getEmployeeIdFromUserId(login.getUserId());
							EmployeeImagesTO employeeImage1 = report
									.getEmployeeImage(Integer
											.parseInt(employeeIdFromUserId
													.get("empId")));
							String encode = Base64
									.encodeBase64String(employeeImage1
											.getEmpImg());
							model.addAttribute("empImge1", encode);
							httpSession.setAttribute("empImge1", encode);
						} catch (Exception e) {
							e.printStackTrace();

							return "redirect:check";
						}

						PresalesTO presalesCount = report.presalesCount();
						model.addAttribute("presalesCount", presalesCount);

						CollectionTO callsCount = report.callsCount();
						model.addAttribute("callsCount", callsCount);

						InteractionRegisterDTO customerCount = report
								.getCustomerCount();
						model.addAttribute("customerCount", customerCount);

						InteractionRegisterDTO hospitalCount = report
								.getHospitalCount();
						model.addAttribute("hospitalCount", hospitalCount);

						InteractionRegisterDTO healthApptCount = report
								.getHealthApptCount();
						model.addAttribute("healthApptCount", healthApptCount);

						HashMap<String, String> meetingNotification = report
								.meetingNotification(login.getUserId());
						model.addAttribute("meetingNotification",
								meetingNotification);
						// httpSession.setAttribute("userAccessModule",userAccessModule);

						model.addAttribute("msg",
								"Welcome " + login.getUserName());
						HashMap<String, String> leavesCountByreportId = report
								.leavesCountByreportId(login.getUserId());
						model.addAttribute("leavesCountByreportId",
								leavesCountByreportId);
						httpSession.setAttribute("leavesCountByreportId",
								leavesCountByreportId);

						HashMap<String, String> employeeIdFromUserId = hrService
								.getEmployeeIdFromUserId(login.getUserId());
						HashMap<String, String> roleBaseAccessRoleId = report
								.getRoleBaseAccessRoleId(employeeIdFromUserId
										.get("empId"));
						model.addAttribute("roleAccess", roleBaseAccessRoleId);
						httpSession.setAttribute("roleAccess",
								roleBaseAccessRoleId);

						String query = "SELECT * FROM user_access ua LEFT JOIN modules mods ON mods.module_id = ua.module_id WHERE ua.role_id = '"
								+ roleBaseAccessRoleId.get("empRoleId")
								+ "' AND ua.module_priority IS  TRUE ORDER BY mods.module_name";
						System.out.println("role baes: " + query);
						ArrayList<HashMap<String, String>> userAccessModule = userService
								.getUserAccessModule(query);
						model.addAttribute("userAccessModule", userAccessModule);
						httpSession.setAttribute("userAccessModule",
								userAccessModule);
						return "Admin/welezoadmin-dashboard";
					}
				}
			}
		} catch (Exception e) {
			PresalesTO presalesCount = report.presalesCount();
			model.addAttribute("presalesCount", presalesCount);

			CollectionTO callsCount = report.callsCount();
			model.addAttribute("callsCount", callsCount);
			InteractionRegisterDTO customerCount = report.getCustomerCount();
			model.addAttribute("customerCount", customerCount);

			InteractionRegisterDTO hospitalCount = report.getHospitalCount();
			model.addAttribute("hospitalCount", hospitalCount);

			InteractionRegisterDTO healthApptCount = report
					.getHealthApptCount();
			model.addAttribute("healthApptCount", healthApptCount);

			HashMap<String, String> leavesCountByreportId = report
					.leavesCountByreportId((Integer) httpSession
							.getAttribute("USERID"));
			model.addAttribute("leavesCountByreportId", leavesCountByreportId);

			try {
				HashMap<String, String> meetingNotification = report
						.meetingNotification((Integer) httpSession
								.getAttribute("USERID"));
				model.addAttribute("meetingNotification", meetingNotification);
			} catch (NullPointerException es) {
				es.printStackTrace();
			}
			return "Admin/welezoadmin-dashboard";

		}
		return "redirect:check";
	}

	@RequestMapping(value = "/signup1", method = RequestMethod.POST)
	public ModelAndView signup(ModelMap map,
			@ModelAttribute UsermasterDTO usermasterDTO) {

		if (userService.checkCredentials(usermasterDTO.getMobileNumber(),
				usermasterDTO.getUserMail()) != true) {
			UsermasterTO usermasterTO = new UsermasterTO();
			usermasterTO.setUserName(usermasterDTO.getUserName());
			usermasterTO.setUserMail(usermasterDTO.getUserMail());
			usermasterTO.setPassword(usermasterDTO.getPassword());
			usermasterTO.setMobileNumber(usermasterDTO.getMobileNumber());
			usermasterTO.setRoleType("SYSTEM");
			userService.save(usermasterTO);

			// userService.UpDateUserAccess(usermasterTO.getUserId(),
			// usermasterDTO.getUserMail());

			final String toAddr = usermasterDTO.getUserMail();
			final String fromAddr = "care@welezohealth.com";
			// email subject
			final String subject = "Welezo Registration Successful.";
			// email body
			final String body = "Dear "
					+ usermasterDTO.getUserName()
					+ ",\n"
					+ " Thank you for registering to Welezo Health Management System."
					+ "\n"
					+ " You can access the application through http://whms.welezohealth.com \n"
					+ "\n"
					+ "Your job specific role access will be provided after review.\n"
					+ "\n" + "Thanks \n" + "Team Welezo \n";

			SimpleMailMessage email = new SimpleMailMessage();
			email.setTo(toAddr);
			email.setSubject(subject);
			email.setText(body);
			email.setFrom(fromAddr);
			mailSender.send(email);
		} else {
			System.out.println("registered alreday !");
			map.addAttribute("check", "Registered alreday !");
		}
		return new ModelAndView("redirect:check");
	}

	@RequestMapping(value = "/logout")
	public ModelAndView logout(@RequestParam Integer userId,
			HttpServletRequest request, HttpServletResponse response,
			HttpSession session) {
		// System.out.println(userId);
		UsermasterDTO userById = userService.getUserById(userId);
		userById.setUserId(userId);

		session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Pragma", "no-cache"); // HTTP 1.0
		response.setHeader("Cache-Control", "no-store"); // HTTP 1.1
		response.setDateHeader("Expires", 0); // prevents caching at the proxy
												// server

		request.getSession().removeAttribute("USERNAME");
		request.getSession().invalidate();
		return new ModelAndView("redirect:check");
	}

	@RequestMapping(value = "/Lockscreen")
	public ModelAndView lockscreen() {
		UsermasterDTO loginDTO = new UsermasterDTO();
		// List<UsermasterDTO> allUser = userService.getAllUser();
		return new ModelAndView("Admin/lockscreen", "loginDTO", loginDTO);
	}

	@RequestMapping(value = "/moduleAccess")
	public ModelAndView moduleAccess(ModelMap model, HttpSession httpSession,
			@RequestParam Integer userId) {
		HashMap<String, String> employeeIdFromUserId = hrService
				.getEmployeeIdFromUserId(userId);
		HashMap<String, String> roleBaseAccessRoleId = report
				.getRoleBaseAccessRoleId(employeeIdFromUserId.get("empId"));

		String query = "SELECT * FROM user_access ua LEFT JOIN modules mods ON mods.module_id = ua.module_id WHERE ua.role_id = '"
				+ roleBaseAccessRoleId.get("empRoleId")
				+ "' AND ua.module_priority IS  FALSE ORDER BY mods.module_name";
		ArrayList<HashMap<String, String>> userAccessModule1 = userService
				.getUserAccessModule(query);
		model.addAttribute("userAccessModule1", userAccessModule1);

		String query1 = "SELECT * FROM user_access ua LEFT JOIN modules mods ON mods.module_id = ua.module_id WHERE ua.role_id = '"
				+ roleBaseAccessRoleId.get("empRoleId")
				+ "' AND ua.module_priority IS  TRUE ORDER BY mods.module_name";
		ArrayList<HashMap<String, String>> userAccessModule = userService
				.getUserAccessModule(query1);
		model.addAttribute("userAccessModule", userAccessModule);

		httpSession.setAttribute("userAccessModule", userAccessModule);

		return new ModelAndView("Admin/moduleAccess");
	}

	@RequestMapping(value = "/saveAccess")
	public ModelAndView saveAccess(ModelMap model,
			@RequestParam String[] accessId, @RequestParam Integer userId) {

		// System.out.println(accessId);
		for (int i = 0; i < accessId.length; i++) {
			String query = "UPDATE user_access SET `module_priority` = 1 WHERE accessId = '"
					+ accessId[i] + "'";
			// System.out.println("insert = " + query);
			hrService.upDateQuery(query);
		}
		model.addAttribute("userId", userId);
		return new ModelAndView("redirect:moduleAccess");
	}

	@RequestMapping(value = "/removeModules")
	public ModelAndView removeAccess(ModelMap model,
			@RequestParam String[] accessId, @RequestParam Integer userId) {

		// System.out.println(accessId);
		for (int i = 0; i < accessId.length; i++) {
			String query = "UPDATE user_access SET `module_priority` = 0 WHERE accessId = '"
					+ accessId[i] + "'";
			System.out.println(query);
			hrService.upDateQuery(query);
		}
		model.addAttribute("userId", userId);
		return new ModelAndView("redirect:moduleAccess");
	}

	@RequestMapping(value = "/changePassword")
	public ModelAndView changePassword(UsermasterDTO usermasterDTO) {
		// System.out.println(usermasterDTO.getPassword());
		UsermasterDTO userById = userService.getUserById(usermasterDTO
				.getUserId());
		UsermasterTO usermasterTO = new UsermasterTO();
		usermasterTO.setUserId(userById.getUserId());
		usermasterTO.setPassword(usermasterDTO.getPassword());
		usermasterTO.setUserName(userById.getUserName());
		usermasterTO.setUserMail(userById.getUserMail());
		usermasterTO.setCreatedBy(userById.getCreatedBy());
		usermasterTO.setCreatedDate(userById.getCreatedDate());
		usermasterTO.setMobileNumber(userById.getMobileNumber());
		usermasterTO.setRoleType(userById.getRoleType());
		usermasterTO.setUserLoginName(userById.getUserLoginName());
		adminService.upDateAdmin(usermasterTO);
		return new ModelAndView("redirect:check");
	}

	@RequestMapping(value = "/sms")
	public ModelAndView sms(ModelMap model) {

		HashMap<String, String> smsTemplates = userService
				.getSMSTemplates("Welcome Message");

		SMSNotifoication sms = new SMSNotifoication();
		String url = "";
		String sendTextMessage = sms.sendTextMessage("9164074183", "Lohith",
				smsTemplates, url, smsTemplates.get("body"));
		// hrService.upDateQuery(sendTextMessage);

		return new ModelAndView("redirect:welezouser_dashboard");

	}

	@RequestMapping(value = "/scan")
	public ModelAndView pdfScan(ModelMap model) {

		// fis = new FileInputStream("C:/Users/Admin/Downloads/MHC.pdf");
		try {
			PDDocument doc = PDDocument.load(new File("sample.pdf"));
			String text = new PDFTextStripper().getText(doc);
			;
			System.out
					.println("Text in PDF\n---------------------------------");
			System.out.println(text);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ModelAndView("redirect:welezouser_dashboard");

	}
}
