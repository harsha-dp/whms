package com.welezo.whms.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import net.sourceforge.tess4j.TesseractException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CardGenerator;
import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.commons.OcrReader;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.AttendenceDTO;
import com.welezo.whms.dto.DispatchTrackingDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.dto.HospitalServiceDTO;
import com.welezo.whms.dto.InteractionRegisterDTO;
import com.welezo.whms.dto.PresalesDTO;
import com.welezo.whms.dto.ResultsetColumnsDeatils;
import com.welezo.whms.dto.TransactionMasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.to.AddressCatagoriesTO;
import com.welezo.whms.to.AddressTO;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.EmployeeImagesTO;
import com.welezo.whms.to.ExtensionDetailsTO;
import com.welezo.whms.to.HealthAppointmentTO;
import com.welezo.whms.to.InteractionRegisterTO;
import com.welezo.whms.to.InventoryTO;
import com.welezo.whms.to.PresalesTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.to.VendorsTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Controller
public class ReportController extends CustomHibenateDaoSupport {

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	AdminService adminService;

	@Autowired
	HRService hrService;

	@RequestMapping(value = "/viewDetails2")
	public ModelAndView viewcustomers(ModelMap model) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT DISTINCT Ast.application_no AS 'Application', Ast.issued_date AS 'Issued On', Ast.status 'Stock Status', emp.emp_name 'Issued To'"
					+ "FROM application_stock Ast LEFT JOIN employee_details emp ON Ast.issued_to = emp.emp_id WHERE Ast.status NOT IN ('For Data Entry','Received')"
					+ "ORDER BY Ast.application_no";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);

			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);

		return new ModelAndView("Admin/application/applicationStatus", "rest",
				new ResultsetColumnsDeatils());
	}

	@RequestMapping(value = "callDetails1")
	public ModelAndView searchCallDetails(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		model.addAttribute("groupBy", "Calls Report");
		return new ModelAndView("redirect:callDetails");
	}

	@RequestMapping(value = "/callDetails", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView viewCallDeatils(ModelMap model,
			@RequestParam String fromDate, @RequestParam String toDate,
			@RequestParam String groupBy) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String groupByPhrase1 = "concat(extension_no, ' (', ifnull(emp_name,'Welezo'), ')')  AS 'User Name'";
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = null;
			if (groupBy.equalsIgnoreCase("Calls Report")) {
				s = "SELECT "
						+ groupByPhrase1
						+ ", COUNT(extension_no) AS 'Total Calls',"
						+ "CONCAT('', FLOOR(SUM(duration)/60), ':', SUM(duration)%60) AS 'Total Duration', "
						+ "SUM(CASE WHEN duration < 30 THEN 1 ELSE 0 END) 'Calls < 30Sec',"
						+ "SUM(CASE WHEN duration BETWEEN 30 AND 180 THEN 1 ELSE 0 END) 'Calls < 3 Min',"
						+ "SUM(CASE WHEN duration BETWEEN 181 AND 300 THEN 1 ELSE 0 END) 'Calls 3 To 5 Min',"
						+ "SUM(CASE WHEN duration BETWEEN 301 AND 419 THEN 1 ELSE 0 END) 'Calls 5 To 7 Min',"
						+ "SUM(CASE WHEN duration > 419 THEN 1 ELSE 0 END) 'Calls > 7 Min'"
						+ "FROM call_details WHERE call_date BETWEEN '" + date
						+ " 00:00:00' AND '" + date1
						+ " 23:59:59' AND department LIKE '%Sales%' GROUP BY 1";
			} else if (groupBy.equalsIgnoreCase("Average Calls")) {
				s = "SELECT CONCAT(extension_no, '-', emp_name) AS 'CSR Name',  COUNT(1) 'Total Calls', SUM(duration) AS 'CallDuration(Sec)',"
						+ "CONCAT(FLOOR(SUM(duration)/3600) , ':',  CEIL((SUM(duration)%3600 - SUM(duration)%60)/60), ':', SUM(duration)%60 ) AS 'TotalDuration(HH:MM:SS)',"
						+ "FLOOR(COUNT(1) / COUNT( DISTINCT LEFT(call_date,10) )) AS 'CallsPerDay', COUNT( DISTINCT LEFT(call_date,10) ) AS 'TotalDays' "
						+ "FROM call_details WHERE call_date BETWEEN '"
						+ date
						+ " 00:00:00' AND '"
						+ date1
						+ " 00:00:00' AND department IN ('Sales') GROUP BY 1";
			} else {
				s = "SELECT  CONCAT(extension_no, ' (', IFNULL(emp_name,'Welezo'), ')')  AS 'User Name', COUNT(extension_no) AS 'Total Calls', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '00:00:00' AND '23:59:59' THEN 1 ELSE 0 END) AS 'FullDay', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '00:00:00' AND '13:29:59' THEN 1 ELSE 0 END) AS 'FirstHalf', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '13:30:00' AND '23:59:59' THEN 1 ELSE 0 END) AS 'SecondHalf',"
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '00:00:00' AND '10:59:59' THEN 1 ELSE 0 END) AS 'Before 11', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '11:00:00' AND '11:59:59' THEN 1 ELSE 0 END) AS '11 to 12',  "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '12:00:00' AND '13:29:59' THEN 1 ELSE 0 END) AS '12 to 1:30',"
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '13:30:00' AND '14:59:59' THEN 1 ELSE 0 END) AS '1:30 to 3', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '15:00:00' AND '15:59:59' THEN 1 ELSE 0 END) AS '3 to 4', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '16:00:00' AND '16:59:59' THEN 1 ELSE 0 END) AS '4 to 5', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '17:00:00' AND '17:59:59' THEN 1 ELSE 0 END) AS '5 to 6', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '18:00:00' AND '23:59:59' THEN 1 ELSE 0 END) AS 'After 6' "
						+ " FROM call_details WHERE call_date BETWEEN '"
						+ date
						+ " 00:00:00' AND '"
						+ date1
						+ " 23:59:59' "
						+ " AND department LIKE '%Sales%' GROUP BY 1 UNION "
						+ " SELECT 'Z-Total' AS 'GroupingColumn',COUNT(extension_no) AS 'Total Calls',  "
						+ "SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '00:00:00' AND '23:59:59' THEN 1 ELSE 0 END) AS 'FullDay', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '00:00:00' AND '13:29:59' THEN 1 ELSE 0 END) AS 'FirstHalf', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '13:30:00' AND '23:59:59' THEN 1 ELSE 0 END) AS 'SecondHalf', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '00:00:00' AND '10:59:59' THEN 1 ELSE 0 END) AS 'Before 11', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '11:00:00' AND '11:59:59' THEN 1 ELSE 0 END) AS '11 to 12', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '12:00:00' AND '13:29:59' THEN 1 ELSE 0 END) AS '12 to 1:30', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '13:30:00' AND '14:59:59' THEN 1 ELSE 0 END) AS '1:30 to 3', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '15:00:00' AND '15:59:59' THEN 1 ELSE 0 END) AS '3 to 4', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '16:00:00' AND '16:59:59' THEN 1 ELSE 0 END) AS '4 to 5', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '17:00:00' AND '17:59:59' THEN 1 ELSE 0 END) AS '5 to 6', "
						+ " SUM(CASE WHEN RIGHT(call_date, 8) BETWEEN '18:00:00' AND '23:59:59' THEN 1 ELSE 0 END) AS 'After 6' "
						+ " FROM call_details WHERE call_date BETWEEN '"
						+ date
						+ " 00:00:00' AND '"
						+ date1
						+ " 23:59:59' AND department LIKE '%Sales%'";
			}
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("groupBy", groupBy);

		return new ModelAndView("Admin/customerCallRecords/searchCallsDetails");
	}

	@RequestMapping(value = "/viewCallsByDurations")
	public ModelAndView viewCallsByDurations(ModelMap model,
			@RequestParam String fromDate, @RequestParam String toDate,
			@RequestParam String extension, @RequestParam String fromDuration,
			@RequestParam String toDuration) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String groupByPhrase1 = "CONCAT(extension_no, ' (', IFNULL(emp_name, 'Welezo'),')') AS 'Extension User', phone_no AS 'Contact Number',call_date AS 'Call Time', duration AS 'Duration'";
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT " + groupByPhrase1
					+ "FROM call_details WHERE call_date BETWEEN '" + date
					+ " 00:00:00' AND '" + date1 + " 23:59:59' AND `duration`"
					+ " BETWEEN '" + fromDuration + "' AND '" + toDuration
					+ "' AND extension_no = '" + extension + "' ORDER BY 1";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("extension", extension);
		List<ExtensionDetailsTO> extensionDetails = adminService
				.geteExtensionDetails();
		model.addAttribute("extensionDetails", extensionDetails);
		return new ModelAndView(
				"Admin/customerCallRecords/searchCallsByDuration");
	}

	@RequestMapping(value = "presalesSummary")
	public ModelAndView presalesSummary(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		String csr = "";
		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);
		return new ModelAndView("redirect:presalesSummary1", "csr", csr);
	}

	@RequestMapping(value = "/presalesSummary1", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView presalesSummary(ModelMap model,
			@RequestParam String fromDate, @RequestParam String toDate,
			@RequestParam String csr) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String groupByPhrase = "csr_name AS 'CSR'";
		if (csr.equalsIgnoreCase("Channel")) {
			groupByPhrase = "channels_name AS 'Channels'";
		} else if (csr.equalsIgnoreCase("Executive")) {
			groupByPhrase = "executive_name AS 'Executive'";
		} else if (csr.equalsIgnoreCase("Date Of Appointment")) {
			groupByPhrase = "date_appointment AS 'Appt. Date'";
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT "
					+ groupByPhrase
					+ ", COUNT(1) AS 'Total Appts', "
					+ "SUM(CASE WHEN appointment_type = 'Fresh' THEN 1 ELSE 0 END) AS 'Fresh', "
					+ "SUM(CASE WHEN appointment_type != 'Fresh' THEN 1 ELSE 0 END) AS 'FollowUp',"
					+ "SUM(CASE WHEN meeting_status = 'Met' THEN 1 ELSE 0 END) AS 'Meetings',"
					+ "SUM(CASE WHEN STATUS = 'Collected' THEN 1 ELSE 0 END) AS 'Collections',"
					+ "SUM(CASE WHEN STATUS = 'Not Interested' THEN 1 ELSE 0 END) AS 'Not Interested',"
					+ "SUM(CASE WHEN STATUS = 'Rescheduled' THEN 1 ELSE 0 END) AS 'Rescheduled',"
					+ "SUM(CASE WHEN STATUS = 'New Appointment' THEN 1 ELSE 0 END) AS 'New'"
					+ "FROM presales_appts WHERE date_appointment BETWEEN '"
					+ date
					+ "' AND '"
					+ date1
					+ "'"
					+ "AND product_name NOT IN ('Make India Healthy') GROUP BY 1 UNION ALL "
					+ "SELECT 'Z-TOTAL', COUNT(1) AS 'Total Appts',"
					+ "SUM(CASE WHEN appointment_type = 'Fresh' THEN 1 ELSE 0 END) AS 'Fresh', "
					+ "SUM(CASE WHEN appointment_type != 'Fresh' THEN 1 ELSE 0 END) AS 'FollowUp',"
					+ "SUM(CASE WHEN meeting_status = 'Met' THEN 1 ELSE 0 END) AS 'Meetings',"
					+ "SUM(CASE WHEN STATUS = 'Collected' THEN 1 ELSE 0 END) AS 'Collections',"
					+ "SUM(CASE WHEN STATUS = 'Not Interested' THEN 1 ELSE 0 END) AS 'Not Interested',"
					+ "SUM(CASE WHEN STATUS = 'Rescheduled' THEN 1 ELSE 0 END) AS 'Rescheduled',"
					+ "SUM(CASE WHEN STATUS = 'New Appointment' THEN 1 ELSE 0 END) AS 'New'"
					+ "FROM presales_appts WHERE date_appointment BETWEEN '"
					+ date + "' AND '" + date1 + "' "
					+ "AND product_name NOT IN ('Make India Healthy')";

			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);
		return new ModelAndView("Admin/presales/presalessummary");
	}

	@RequestMapping(value = "/collectionSummary", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView collectionSummary(ModelMap model,
			@RequestParam String fromDate, @RequestParam String toDate,
			@RequestParam String groupBy) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String groupByPhrase = null;
		if (groupBy.equalsIgnoreCase("CSR")) {
			groupByPhrase = "emp.emp_name AS 'CSR Name'";
		} else {
			groupByPhrase = "colected_date AS 'Collection Date' ";
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT "
					+ groupByPhrase
					+ ", "
					+ " SUM(  CASE WHEN `payment_mode` = 'Cash' THEN 1 ELSE 0 END) AS 'Cash Sales', "
					+ " SUM(  CASE WHEN `payment_mode` = 'Cheque' THEN 1 ELSE 0 END) AS 'Cheque Sales', "
					+ " SUM(  CASE WHEN `payment_mode` = 'Credit/debit' THEN 1 ELSE 0 END) AS 'Credit /Debit ',"
					+ " SUM(  CASE WHEN `payment_mode` = 'NEFT' THEN 1 ELSE 0 END) AS 'NEFT Sales',"
					+ " SUM(  CASE WHEN `payment_mode` = 'Card' THEN 1 ELSE 0 END) AS 'Card Sales',"
					+ " SUM(  CASE WHEN `payment_mode` = 'CC Avenue' THEN 1 ELSE 0 END) AS 'CC Avenue',"
					+ " SUM(  CASE WHEN `payment_mode` = 'PayTM' THEN 1 ELSE 0 END) AS 'PayTM Sales',"
					+ " COUNT(1) AS 'Total', "
					+ " SUM(  CASE WHEN `payment_mode` = 'Cash' THEN price ELSE 0 END) AS 'Cash Revenue', "
					+ " SUM(  CASE WHEN `payment_mode` = 'Cheque' THEN price ELSE 0 END) AS 'Cheque Revenue', "
					+ " SUM(  CASE WHEN `payment_mode` = 'Credit/debit' THEN price ELSE 0 END) AS 'Credit /Debit', "
					+ " SUM(  CASE WHEN `payment_mode` = 'NEFT' THEN price ELSE 0 END) AS 'NEFT Revenue', "
					+ " SUM(  CASE WHEN `payment_mode` = 'Card' THEN price ELSE 0 END) AS 'Card Revenue',"
					+ " SUM(  CASE WHEN `payment_mode` = 'CC Avenue' THEN price ELSE 0 END) AS 'CC Avenue Revenue',"
					+ " SUM(  CASE WHEN `payment_mode` = 'PayTM' THEN price ELSE 0 END) AS 'PayTM Revenue',"
					+ " SUM(price) AS 'Collection Amount', "
					+ " SUM( CASE WHEN trx.tx_status IN ('Payment Approved') THEN trx.amount ELSE 0 END) 'Realized Amount' "
					+ " FROM collection col LEFT JOIN employee_details emp ON col.csr = emp.`emp_id`  "
					+ " LEFT JOIN transaction_master trx ON col.transaction_id = trx.transaction_id "
					+ " WHERE colected_date BETWEEN '" + date + "' AND '"
					+ date1 + "' GROUP BY 1";

			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("groupBy", groupBy);
		return new ModelAndView("Admin/collections/searchCollection");
	}

	public ArrayList<HashMap<String, String>> FilterCollection1(
			String fromDate, String toDate, String csr) {
		ArrayList<HashMap<String, String>> colectionList = new ArrayList<>();
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT colle.*,pre.customer_name,prod.product_name,emp.emp_name AS 'CSR Name',emp1.emp_name AS 'Executives' ,team.team_name,chanl.channels_name "
					+ " FROM collection colle LEFT JOIN presales pre ON pre.leads_id = colle.leads_id "
					+ "LEFT JOIN product_master prod ON prod.product_id = colle.product_id LEFT JOIN employee_details emp ON emp.emp_id = colle.csr "
					+ "LEFT JOIN employee_details emp1 ON emp1.emp_id = colle.executive LEFT JOIN teams team ON team.team_id = colle.team "
					+ "LEFT JOIN channels chanl ON chanl.channel_id = colle.channel "
					+ " WHERE  colle.colected_date BETWEEN '"
					+ date
					+ " 00:00:00' AND '"
					+ date1
					+ " 23:59:59' AND  colle.csr LIKE '%"+csr+"%'  ";

			System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> colection = new HashMap<String, String>();
				colection.put("collectionId", rs.getString("collection_id"));
				colection.put("paymentMode", rs.getString("payment_mode"));
				try {
					SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/YYYY");
					// list.put("openDate",sdf.format(rs.getDate("open_date")));
					colection.put("colectedDate",
							sdf1.format(rs.getDate("colected_date")));
				} catch (NullPointerException e) {
					e.printStackTrace();
				}
				colection.put("price", rs.getString("price"));
				colection.put("leadsId", rs.getString("leads_id"));
				colection.put("customerName", rs.getString("customer_name"));
				colection.put("productName", rs.getString("product_name"));
				colection.put("CSRName", rs.getString("CSR Name"));
				colection.put("Executives", rs.getString("Executives"));
				colection.put("teamName", rs.getString("team_name"));
				colection.put("channelsName", rs.getString("channels_name"));
				colection.put("transactionId", rs.getString("transaction_id"));
				colection.put("applicationNo", rs.getString("application_No"));
				colectionList.add(colection);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return colectionList;
	}

	@RequestMapping(value = "/search")
	public ModelAndView searchBox(ModelMap model) {
		List<AddressDTO> searchCustomer = null;
		PresalesDTO presalesDTO = new PresalesDTO();
		model.addAttribute("searchCustomer", searchCustomer);
		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);
		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);
		return new ModelAndView("Admin/customerCallRecords/search",
				"presalesDTO", presalesDTO);
	}

	@RequestMapping(value = "/searchCustomer", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView searchByPhoneNo(ModelMap model,
			@RequestParam String phoneNumber) {
		ResultSet rs, rs1 = null;
		PreparedStatement prepareStatement = null;
		Connection connection, connection1 = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT leads_id AS 'Lead Id', customer_name AS 'Customer Name', `product_name` AS 'Product Name', csr_name AS CSR, date_appointment AS 'Appt. Date', time_appointment AS 'Appt. Time',"
					+ "STATUS AS 'Status' FROM presales_appts"
					+ " WHERE primary_mob = '" + phoneNumber + "'";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> stkList1 = new ArrayList<>();
		try {
			String s1 = "SELECT CONCAT(extension_no, '(',IFNULL(emp_name, ''),')') AS 'Called By', phone_no AS 'Contact No.', "
					+ "call_date AS 'Called On', duration AS Duration FROM call_details WHERE phone_no='"
					+ phoneNumber + "' ORDER BY call_date DESC";
			connection1 = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection1.prepareStatement(s1);
			rs1 = prepareStatement.executeQuery();
			ResultSetMetaData rdms1 = rs1.getMetaData();
			int columnCount1 = rdms1.getColumnCount();
			List<ResultsetColumnsDeatils> columnList1 = new ArrayList<>();
			for (int j1 = 1; j1 <= columnCount1; j1++) {
				ResultsetColumnsDeatils rest1 = new ResultsetColumnsDeatils();
				rest1.setColumnName(rdms1.getColumnName(j1));
				columnList1.add(rest1);
			}
			model.addAttribute("columnName1", columnList1);
			while (rs1.next()) {
				int i1 = 1;
				HashMap<String, String> stkMap1 = new HashMap<String, String>();
				for (i1 = 1; i1 <= columnCount1; i1++) {
					stkMap1.put("attr" + i1, rs1.getString(i1));
				}
				stkList1.add(stkMap1);
			}
			model.addAttribute("stkList1", stkList1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		List<EmployeeDTO> csrList = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		List<EmployeeDTO> executiveList = adminService
				.getAllEmployeeDetails("NOT IN ('CSR', 'Sr. CSR') AND section LIKE '%Sales%'");
		model.addAttribute("executive", executiveList);
		List<HashMap<String, String>> allProducts = adminService
				.getAllProducts();
		model.addAttribute("allProducts", allProducts);
		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);
		model.addAttribute("phoneNumber", phoneNumber);

		HashMap<String, String> customerMoreThan3Appointment = customerMoreThan3Appointment(phoneNumber);
		model.addAttribute("customerMoreThan3Appointment",customerMoreThan3Appointment);
		HashMap<String, String> customerLastCallRxFsomCSR = customerLastCallRxFsomCSR(phoneNumber);
		model.addAttribute("customerLastCallRxFsomCSR",
				customerLastCallRxFsomCSR);

		return new ModelAndView("Admin/customerCallRecords/search",
				"presalesDTO", new PresalesDTO());
	}

	@RequestMapping(value = "/searchCustomerTx")
	public ModelAndView viewCustomerTx(ModelMap model,
			@RequestParam String cardRPhnNumber) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT  DISTINCT transaction_id AS 'Health Check', tm.customer_id AS 'Customer' , application_no AS 'App. No.', tx_status 'Status', cust.customer_name"
					+ " 'Customer Name', tm.card_number 'Card Number' FROM transaction_master tm "
					+ " LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN address adr ON (cust.customer_id = adr.entity_id AND address_type_id IN (1,2,3)) "
					+ "WHERE adr.primary_mob = '"
					+ cardRPhnNumber
					+ "' OR tm.card_number LIKE '%"
					+ cardRPhnNumber
					+ "%' OR cust.dob = '"
					+ cardRPhnNumber
					+ "' OR tm.application_No ='" + cardRPhnNumber + "'";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();

			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		InteractionRegisterDTO customerCareDasHBoardCount = getCustomerCareInteractionCount();
		model.addAttribute("dashBoardCount", customerCareDasHBoardCount);
		InteractionRegisterDTO customerCount = getCustomerCount();
		model.addAttribute("customerCount", customerCount);
		InteractionRegisterDTO hospitalCount = getHospitalCount();
		model.addAttribute("hospitalCount", hospitalCount);
		InteractionRegisterDTO healthApptCount = getHealthApptCount();
		model.addAttribute("healthApptCount", healthApptCount);
		return new ModelAndView("Admin/dashboards/ccDashboards");
	}

	public PresalesTO presalesCount() {
		PresalesTO PresalesTO = new PresalesTO();
		try {
			String s = "SELECT SUM( CASE WHEN date_appointment = CURRENT_DATE THEN 1 ELSE 0 END) AS ApptsToday,"
					+ "SUM(CASE WHEN DATE(created_date) = CURRENT_DATE THEN 1 ELSE 0 END) AS ApptsGenerated,"
					+ "SUM(CASE WHEN DATE(created_date) = CURRENT_DATE  AND meeting_status = 'Met' THEN 1 ELSE 0 END) "
					+ "AS 'Meetings' FROM presales";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				PresalesTO.setAppointmentType(rs.getString("ApptsToday"));
				PresalesTO.setMeetingStatus(rs.getString("ApptsGenerated"));
				PresalesTO.setCustomerName(rs.getString("Meetings"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return PresalesTO;
	}

	

	public CollectionTO callsCount() {
		CollectionTO collectionTO = new CollectionTO();
		try {
			String s = "SELECT COUNT(1) AS 'Total Calls', SUM(CASE WHEN duration >= 300 THEN 1 ELSE 0 END) AS 'Presentations'"
					+ "FROM call_details WHERE department = 'Sales' AND SUBSTR(call_date,1, 10) = CONCAT(YEAR(CURRENT_DATE), '-',"
					+ " IF(MONTH(CURRENT_DATE) <= 9, '0', ''), MONTH(CURRENT_DATE), '-', "
					+ "IF(DAY(CURRENT_DATE) < 10, '0', ''), DAY(CURRENT_DATE) )";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				collectionTO.setPrice(rs.getInt("Total Calls"));
				collectionTO.setApplicationNo(rs.getString("Presentations"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return collectionTO;
	}

	public List<TransactionMasterDTO> applicationNoInTx() {
		List<TransactionMasterDTO> transctionDetails = new ArrayList<>();
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		try {
			String s = "SELECT application_No,transaction_id FROM transaction_master WHERE customer_id IS NULL";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();

			while (rs.next()) {
				TransactionMasterDTO masterTO = new TransactionMasterDTO();
				masterTO.setTransactionId(rs.getInt("transaction_id"));
				masterTO.setApplicationNo(rs.getString("application_No"));

				transctionDetails.add(masterTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transctionDetails;
	}

	public List<TransactionMasterDTO> getTranasctionByID(Integer txId) {
		List<TransactionMasterDTO> transctionDetails = new ArrayList<>();

		try {
			String s = "SELECT tm.transaction_id,tm.expriry_date, tm.application_No AS 'App. No', cust.customer_name AS 'Customer Name', pm.product_name AS 'Product',"
					+ "pay.status AS 'App. Status', tm.collected_date AS 'Collected Date',tm.card_number AS 'Card No.', csrs.emp_name AS 'CSR Name',"
					+ "exe.emp_name AS 'Executive Name', team.team_name AS 'Team Name',chn.channels_name AS 'Channel Name', pay.`mode_of_payment` "
					+ "AS 'Payment Mode',tm.customer_id FROM transaction_master tm "
					+ "LEFT JOIN payment_details pay ON tm.transaction_id = pay.transaction_id "
					+ "LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN product_master pm ON tm.product_id = pm.product_id "
					+ "LEFT JOIN employee_details csrs ON tm.csr = csrs.emp_id "
					+ "LEFT JOIN employee_details exe ON tm.executive = exe.emp_id "
					+ "LEFT JOIN channels chn ON tm.channel = chn.channel_id "
					+ "LEFT JOIN teams team ON tm.team = team.team_id WHERE tm.`customer_id` = '"
					+ txId + "'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				TransactionMasterDTO txDTO = new TransactionMasterDTO();
				txDTO.setTransactionId(rs.getInt("transaction_id"));
				txDTO.setApplicationNo(rs.getString("App. No"));
				txDTO.setCardNumber(rs.getString("Card No."));
				txDTO.setCsr(rs.getString("CSR Name"));
				txDTO.setCollectedDate(rs.getString("Collected Date"));
				txDTO.setPaymentStatus(rs.getString("Payment Mode"));
				txDTO.setExecutive(rs.getString("Executive Name"));
				txDTO.setCsr(rs.getString("CSR Name"));
				txDTO.setTxStatus(rs.getString("App. Status"));
				txDTO.setProductName(rs.getString("Product"));
				txDTO.setCustomerName(rs.getString("Customer Name"));
				txDTO.setExpriryDate(rs.getDate("expriry_date"));
				transctionDetails.add(txDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transctionDetails;
	}

	@RequestMapping(value = "healthsummary")
	public ModelAndView healthSummary(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		String groupByPhrase1 = "Date Of Appointment";
		return new ModelAndView("redirect:healthapptsummary", "groupByPhrase1",
				groupByPhrase1);
	}

	@RequestMapping(value = "/healthapptsummary")
	public ModelAndView healthAppointmentSummary(ModelMap model,
			String fromDate, String toDate, String groupByPhrase1) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String groupByPhrase = "appt_date AS 'Appointment Date'";
		if (groupByPhrase1.equalsIgnoreCase("Health Care")) {
			groupByPhrase = "ServiceCentre AS 'Health Center'";
		} else if (groupByPhrase1.equalsIgnoreCase("Date Of Appointment")) {
			groupByPhrase = "appt_date AS 'Appointment Date'";
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT "
					+ groupByPhrase
					+ ", COUNT(1) AS 'Total Appointments', "
					+ "SUM( CASE WHEN Category = 'Dentistry' THEN 1 ELSE 0 END) 'Dentistry',"
					+ "SUM( CASE WHEN Category = 'Consultation' THEN 1 ELSE 0 END) 'Consultation',"
					+ "SUM(CASE WHEN Service = 'Master Health Check' THEN 1 ELSE 0 END) 'MHC',"
					+ "SUM(CASE WHEN Service = 'Executive Health Check' THEN 1 ELSE 0 END) 'EHC',"
					+ "SUM(CASE WHEN Service = 'Total Wellness Check' THEN 1 ELSE 0 END) 'TWC',"
					+ "SUM(CASE WHEN Service = 'Well Women Health Check' THEN 1 ELSE 0 END) 'WWHC',"
					+ "SUM(CASE WHEN Service = 'Senior Citizen Health Check' THEN 1 ELSE 0 END) 'SCHC',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Women]' THEN 1 ELSE 0 END) 'PHC-Women',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Men]' THEN 1 ELSE 0 END) 'PHC-Men',"
					+ "SUM(CASE WHEN Service = 'Medical Cash Back 200' THEN 1 ELSE 0 END) 'MCB-200',"
					+ "SUM(CASE WHEN Service = 'Medical Cash Back 500' THEN 1 ELSE 0 END) 'MCB-500' "
					+ "FROM service_utilization WHERE `Appt_Status` NOT IN ('Missed','Cancelled','Rescheduled') AND `Appt_Date` BETWEEN '"
					+ date
					+ "' AND '"
					+ date1
					+ "' GROUP BY 1 UNION "
					+ "SELECT 'Z-Total' AS 'GroupingColumn', COUNT(1) AS 'Total Appointments', "
					+ "SUM( CASE WHEN Category = 'Dentistry' THEN 1 ELSE 0 END) 'Dentistry',"
					+ "SUM( CASE WHEN Category = 'Consultation' THEN 1 ELSE 0 END) 'Consultation',"
					+ "SUM(CASE WHEN Service = 'Master Health Check' THEN 1 ELSE 0 END) 'MHC',"
					+ "SUM(CASE WHEN Service = 'Executive Health Check' THEN 1 ELSE 0 END) 'EHC',"
					+ "SUM(CASE WHEN Service = 'Total Wellness Check' THEN 1 ELSE 0 END) 'TWC', "
					+ "SUM(CASE WHEN Service = 'Well Women Health Check' THEN 1 ELSE 0 END) 'WWHC',"
					+ "SUM(CASE WHEN Service = 'Senior Citizen Health Check' THEN 1 ELSE 0 END) 'SCHC',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Women]' THEN 1 ELSE 0 END) 'PHC-Women',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Men]' THEN 1 ELSE 0 END) 'PHC-Men',"
					+ "SUM(CASE WHEN Service = 'Medical Cash Back 200' THEN 1 ELSE 0 END) 'MCB-200',"
					+ "SUM(CASE WHEN Service = 'Medical Cash Back 500' THEN 1 ELSE 0 END) 'MCB-500' "
					+ "FROM service_utilization WHERE `Appt_Status` NOT IN ('Missed','Cancelled','Rescheduled') AND `Appt_Date` BETWEEN '"
					+ date + "' AND '" + date1 + "'";

			// System.out.println(s);
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("groupByPhrase", groupByPhrase1);
		return new ModelAndView("Admin/appointment/serviceUtilization");
	}

	@RequestMapping(value = "addInteraction")
	public ModelAndView addInteraction(ModelMap model, Integer transactionId,
			Integer customerId) {
		InteractionRegisterTO interActionTO = new InteractionRegisterTO();
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		try {
			String s = "SELECT  DISTINCT transaction_id AS 'Health Check', tm.customer_id AS 'Customer' , application_no AS 'App. No.', "
					+ "tx_status 'Status', cust.customer_name 'Customer Name', tm.card_number 'Card Number' ,adr.`primary_mob` "
					+ "FROM transaction_master tm "
					+ "LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN address adr ON (cust.customer_id = adr.entity_id AND address_type_id = (CASE WHEN cust.`correspondence` = 'Residence' THEN 1 ELSE 2 END) ) "
					+ "WHERE cust.`customer_id`='"
					+ customerId
					+ "' AND tm.`transaction_id`='" + transactionId + "'";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();

			while (rs.next()) {
				InteractionRegisterTO registerTO = new InteractionRegisterTO();
				registerTO.setCustomerId(rs.getInt("Customer"));
				registerTO.setTransactionId(rs.getInt("Health Check"));
				registerTO.setDetails(rs.getString("Customer Name"));
				registerTO.setPurpose(rs.getString("primary_mob"));

				model.addAttribute("registerTO", registerTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		List<WelezoConstantsTO> welezoConstant = adminService
				.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		return new ModelAndView("Admin/reception/addInteraction",
				"interActionTO", interActionTO);
	}

	public List<HospitalServiceDTO> getServiceUtilization(Integer hospitalId) {
		List<HospitalServiceDTO> hospilatService = new ArrayList<>();

		try {
			String s = "SELECT * FROM service_utilization WHERE  hospital_id = '"
					+ hospitalId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HospitalServiceDTO hospital = new HospitalServiceDTO();
				hospital.setId(rs.getInt("appointment_id"));
				hospital.setResidenceAddresss(rs.getString("Customer_Name"));
				hospital.setCity(rs.getString("Service"));
				hospital.setCategory(rs.getString("Category"));
				hospital.setEmail(rs.getString("ProductName"));
				hospital.setEmpanelledDate(rs.getString("Appt_Date"));
				hospital.setLandline(rs.getString("Appt_Status"));
				hospital.setNameHcc(rs.getString("ServiceCentre"));
				hospital.setPincode(rs.getString("Appt_Time"));
				hospilatService.add(hospital);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return hospilatService;
	}

	public List<HospitalServiceDTO> getHospitalServiceSummary(Integer hospitalId) {
		List<HospitalServiceDTO> hospilatService = new ArrayList<>();

		try {
			String s = "SELECT ServiceCentre, Category, Service, MAX(appt_date) AS 'Recent Appointment', COUNT(1) AS 'Total Appointments' FROM service_utilization  "
					+ "WHERE Appt_Status NOT IN ('Missed','Cancelled', 'Rescheduled') AND hospital_id = '"
					+ hospitalId
					+ "' GROUP BY ServiceCentre, Category, Service";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HospitalServiceDTO hospital = new HospitalServiceDTO();
				// hospital.setId(rs.getInt("appointment_id"));
				// hospital.setResidenceAddresss(rs.getString("Customer_Name"));
				hospital.setCity(rs.getString("Service"));
				hospital.setCategory(rs.getString("Category"));
				// hospital.setEmail(rs.getString("ProductName"));
				hospital.setEmpanelledDate(rs.getString("Total Appointments"));
				hospital.setLandline(rs.getString("Recent Appointment"));
				hospital.setNameHcc(rs.getString("ServiceCentre"));
				// hospital.setPincode(rs.getString("Appt_Time"));
				hospilatService.add(hospital);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return hospilatService;
	}

	@RequestMapping(value = "dispatchSummary")
	public ModelAndView dispatchSummary(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		return new ModelAndView("redirect:dispatchSummary1");
	}

	@RequestMapping(value = "/dispatchSummary1", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView dispatchSummary1(ModelMap model, String fromDate,
			String toDate) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}

		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT dispatch_date, SUM(CASE WHEN delivery_status IS NULL THEN 1 ELSE 0 END) AS 'Yet to Dispatch',"
					+ "SUM(CASE WHEN delivery_status = 'InTransit' THEN 1 ELSE 0 END) AS 'In Transit',"
					+ "SUM(CASE WHEN delivery_status = 'Received' THEN 1 ELSE 0 END) AS 'Received',"
					+ "SUM(CASE WHEN delivery_status = 'RTO' THEN 1 ELSE 0 END) AS 'RTO',"
					+ "COUNT(1) AS  'Total Cases' FROM dispatch_tracking "
					+ " WHERE dispatch_date BETWEEN '"
					+ date
					+ " 00:00:00' AND '" + date1 + " 23:59:59' GROUP BY 1";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		return new ModelAndView("Admin/dispatch/dispacthSummary");
	}

	public List<HospitalServiceDTO> getServiceBaseHospital() {
		List<HospitalServiceDTO> hospilatService = new ArrayList<>();
		try {
			String s = "SELECT det.`hospital_id`,ser.`service_id`,`service_name`,det.`name_hcc` FROM `hospital_service` hospser "
					+ "LEFT JOIN `empanellment` det ON det.`hospital_id` = hospser.`hospital_id` "
					+ "LEFT JOIN `services` ser ON ser.`service_id` = hospser.`service_id`";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HospitalServiceDTO hospital = new HospitalServiceDTO();
				hospital.setHospitalId(rs.getInt("hospital_id"));
				hospital.setServiceId(rs.getInt("service_id"));
				hospital.setServiceName(rs.getString("service_name"));
				hospital.setNameHcc(rs.getString("name_hcc"));
				hospilatService.add(hospital);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return hospilatService;
	}

	@RequestMapping(value = "viewinteraction")
	public ModelAndView viewInterAction1(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		model.addAttribute("purpose", "");
		model.addAttribute("mode", "Incoming Call");
		String status = "";
		return new ModelAndView("redirect:viewinteractions", "status", status);
	}

	@RequestMapping(value = "/viewinteractions")
	public ModelAndView viewInterAction2(ModelMap model, String fromDate,
			String toDate, String status, String purpose, String mode) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT intr.interaction_id,cust.customer_name,intr.interaction_date,usr.user_name, intr.interaction_mode,  "
					+ "intr.purpose, intr.status,tran.transaction_id "
					+ "FROM interaction_register intr LEFT JOIN customer_deatils cust ON intr.customer_id = cust.customer_id "
					+ "LEFT JOIN transaction_master tran ON intr.transaction_id = tran.transaction_id "
					+ "LEFT JOIN usermaster usr ON intr.interaction_by = usr.user_id "
					+ "WHERE intr.`interaction_date` BETWEEN '"
					+ date
					+ " 00:00:00' AND '"
					+ date1
					+ " 23:59:59' AND intr.`status` LIKE '%"
					+ status
					+ "%' AND intr.purpose LIKE '%"
					+ purpose
					+ "%' AND intr.interaction_mode LIKE '%"
					+ mode
					+ "%'"
					+ " ORDER BY intr.interaction_date DESC";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("status", status);
		model.addAttribute("purpose", purpose);
		model.addAttribute("mode", mode);
		return new ModelAndView("Admin/appointment/viewinteraction");
	}

	public InteractionRegisterDTO getInteractionById(Integer interactionId) {
		InteractionRegisterDTO interActionTO = new InteractionRegisterDTO();
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		try {
			String s = "SELECT DISTINCT cust.`customer_id`,cust.`customer_name`,inter.`interaction_id`,inter.`transaction_id`,inter.`interaction_mode`,"
					+ "inter.`interaction_thru`,inter.`status`,inter.`purpose`,inter.`remarks`,adr.`primary_mob`,inter.`details`,inter.`interaction_by`,inter.`interaction_date` "
					+ "FROM `interaction_register`inter "
					+ "LEFT JOIN `customer_deatils`cust ON inter.`customer_id` = cust.`customer_id` "
					+ "LEFT JOIN address adr ON (cust.customer_id = adr.entity_id AND address_type_id IN (1,2,3)) "
					+ "WHERE inter.`interaction_id`= '" + interactionId + "'";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();

			while (rs.next()) {
				// InteractionRegisterTO registerTO = new
				// InteractionRegisterTO();
				interActionTO.setCustomerId(rs.getInt("customer_id"));
				interActionTO.setTransactionId(rs.getInt("transaction_id"));
				interActionTO.setDetails(rs.getString("details"));
				interActionTO.setPurpose(rs.getString("purpose"));
				interActionTO.setInteractionId(rs.getInt("interaction_id"));
				interActionTO.setInteractionMode(rs
						.getString("interaction_mode"));
				interActionTO.setInteractionThru(rs
						.getString("interaction_thru"));
				interActionTO.setRemarks(rs.getString("remarks"));
				interActionTO.setCustomerName(rs.getString("customer_name"));
				interActionTO.setNameHcc(rs.getString("primary_mob"));
				interActionTO.setStatus(rs.getString("status"));
				interActionTO.setInteractionDate(rs
						.getString("interaction_date"));
				interActionTO.setInteractionBy(rs.getInt("interaction_by"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return interActionTO;
	}

	public InteractionRegisterDTO getCustomerCareInteractionCount() {
		InteractionRegisterDTO dashboradCount = new InteractionRegisterDTO();
		try {
			String s = "SELECT 'Incoming Calls' AS Count_Catagory, COUNT(1) AS Total FROM interaction_register "
					+ "WHERE interaction_mode = 'Incoming Call'  AND DATE(interaction_date) = (CURRENT_DATE )";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				dashboradCount.setInteractionMode(rs.getString("Total"));
				// dashboradCount.setDetails(rs.getString("Count_Catagory"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dashboradCount;
	}

	public InteractionRegisterDTO getCustomerCount() {
		InteractionRegisterDTO dashboradCount = new InteractionRegisterDTO();
		try {
			String s = "SELECT  'Customers' AS Count_Catagory, COUNT(DISTINCT customer_id) AS Total FROM transaction_master "
					+ "WHERE tx_status NOT IN ('In Progress', 'New', 'Cheque Recollect', 'Cancelled')";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				dashboradCount.setCustomerName(rs.getString("Total"));
				// dashboradCount.setDetails(rs.getString("Count_Catagory"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dashboradCount;
	}

	public InteractionRegisterDTO getHospitalCount() {
		InteractionRegisterDTO dashboradCount = new InteractionRegisterDTO();
		try {
			String s = "SELECT  'Health Centres' AS Count_Catagory, COUNT(DISTINCT hospital_id) AS Total FROM empanellment WHERE isActive IS TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				dashboradCount.setNameHcc(rs.getString("Total"));
				// dashboradCount.setDetails(rs.getString("Count_Catagory"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dashboradCount;
	}

	public InteractionRegisterDTO getHealthApptCount() {
		InteractionRegisterDTO dashboradCount = new InteractionRegisterDTO();
		try {
			String s = "SELECT 'Utilization' AS Count_Category, COUNT(1)  AS Total FROM service_utilization "
					+ " WHERE appt_status NOT IN ('Cancelled', 'Rescheduled', 'Missed') AND `Appt_Date` = (CURRENT_DATE )";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				dashboradCount.setServiceName(rs.getString("Total"));
				// dashboradCount.setDetails(rs.getString("Count_Catagory"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dashboradCount;
	}

	public String getHealthNewApptCount() {
		String string = null;
		try {
			String s = "SELECT 'Open Appointment' AS Count_Category, COUNT(1)  AS Total FROM service_utilization WHERE Appt_Status = 'New'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				string = rs.getString("Total");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return string;
	}

	public String getPendingSubmissionCount() {
		String string = null;
		try {
			String s = "SELECT COUNT(1) AS 'Pending Submission' FROM collection WHERE transaction_id IS NULL";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				string = rs.getString("Pending Submission");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return string;
	}

	
	public HashMap<String, String> getTotalHealthAppt() {
		HashMap<String, String> appt = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) AS 'Total Appointment' FROM health_appointment WHERE status_appointment IN('Availed','Voucher Received','Report Collected','New')";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				appt.put("totalAppt", rs.getString("Total Appointment"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return appt;
	}

	public List<WelezoConstantsTO> getWelezoWorkFlow(String workType) {
		List<WelezoConstantsTO> welezoWorkList = new ArrayList<>();
		try {
			String s = "SELECT * FROM `welezo_workflow` WHERE w_type = '"
					+ workType + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				WelezoConstantsTO workFlow = new WelezoConstantsTO();
				workFlow.setId(rs.getInt("id"));
				workFlow.setConstType(rs.getString("w_type"));
				workFlow.setCDisplay(rs.getString("w_to"));
				workFlow.setCValue(rs.getString("w_from"));
				welezoWorkList.add(workFlow);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return welezoWorkList;
	}

	public List<HospitalServiceDTO> getServiceUsed(Integer txId) {
		List<HospitalServiceDTO> hospilatService = new ArrayList<>();
		try {
			String s = "SELECT * FROM `service_utilization` WHERE  `transaction_id` = '"
					+ txId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HospitalServiceDTO hospital = new HospitalServiceDTO();
				hospital.setId(rs.getInt("appointment_id"));
				hospital.setServiceName(rs.getString("Service"));
				hospital.setCategory(rs.getString("Appt_For"));
				hospital.setEmpanelledDate(rs.getString("Appt_Date"));
				hospital.setLandline(rs.getString("Appt_Status"));
				hospital.setNameHcc(rs.getString("ServiceCentre"));
				hospital.setPincode(rs.getString("Appt_Time"));
				hospilatService.add(hospital);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return hospilatService;
	}

	public List<InteractionRegisterDTO> getInteractionByTx(Integer txId) {
		List<InteractionRegisterDTO> interActionList = new ArrayList<>();
		try {
			String s = "SELECT * FROM `interaction_register` WHERE  `transaction_id` = '"
					+ txId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				InteractionRegisterDTO action = new InteractionRegisterDTO();
				action.setInteractionId(rs.getInt("interaction_id"));
				action.setInteractionMode(rs.getString("interaction_mode"));
				action.setPurpose(rs.getString("purpose"));
				action.setInteractionDate(rs.getString("interaction_date"));
				action.setStatus(rs.getString("status"));
				// action.setNameHcc(rs.getString("ServiceCentre"));
				// action.setPincode(rs.getString("Appt_Time"));
				interActionList.add(action);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return interActionList;
	}

	public void updateVoucherNumber(HealthAppointmentDTO healthAppointmentDTO) {

		try {
			String query = "UPDATE health_appointment SET   testimonial_status='"
					+ healthAppointmentDTO.getTestimonialStatus()
					+ "'"
					+ " WHERE appointment_id='"
					+ healthAppointmentDTO.getAppointmentId() + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@RequestMapping(value = "/voucher")
	public ModelAndView searchVoucher(ModelMap model) {
		return new ModelAndView("Admin/dispatch/vouchersearch");
	}

	@RequestMapping(value = "/searchVoucher")
	public ModelAndView searchVoucherNo(ModelMap model,
			@RequestParam String voucherNo) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT tx.`transaction_id` AS 'Trasaction',cust.`customer_name` AS 'Customer Name',tx.`card_number` AS 'Welezo Card',offers.`voucher_no` AS 'Voucher Number' "
					+ "FROM `transaction_offers` offers "
					+ "LEFT JOIN `transaction_master`tx ON offers.`transaction_id` = tx.`transaction_id` "
					+ "LEFT JOIN `customer_deatils` cust ON cust.`customer_id` = tx.`customer_id` "
					+ "WHERE  voucher_no = '"
					+ voucherNo
					+ "' OR voucher_no LIKE '"
					+ voucherNo
					+ " %' OR  voucher_no LIKE '%"
					+ voucherNo
					+ "' OR voucher_no LIKE '% " + voucherNo + " %'";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return new ModelAndView("Admin/dispatch/vouchersearch");
	}

	@RequestMapping(value = "/searchItem")
	public ModelAndView searchByitem(ModelMap model) {
		ResultSet rs;
		PreparedStatement prepareStatement;
		Connection connection;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT item_id AS 'Id',item_name AS 'Iteam Name',unit_of_measure AS 'Unit Of Measure',current_stock AS 'Current Stock'"
					+ " FROM item_master ";
			// + " WHERE item_name = '"+ itemId + "' ";
			// System.out.println(s);
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);

		InventoryTO inventry = new InventoryTO();
		
	ArrayList<HashMap<String,String>> inventoryInWardReport = getInventoryInWardReport();
	model.addAttribute("inventoryInWardReport", inventoryInWardReport);
		
	ArrayList<HashMap<String,String>> inventoryOutWardReport = getInventoryOutWardReport();
	model.addAttribute("inventoryOutWardReport", inventoryOutWardReport);
		
		return new ModelAndView("Admin/Inventory/inventoryDashboard",
				"inventry", inventry);
	}

	/*public List<VendorsTO> getAllVendors() {
		List<VendorsTO> vendorList = new ArrayList<>();
		try {
			String s = "SELECT * FROM vendors";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				VendorsTO vendor = new VendorsTO();
				vendor.setVendorId(rs.getInt("vendor_id"));
				vendor.setVendorName(rs.getString("vendor_name"));
				vendor.setVendorCompany(rs.getString("vendor_company"));
				vendorList.add(vendor);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vendorList;

	}*/

	/*public void updateItemMaster(Integer iteamId, Float stock) {
		try {
			String query = "UPDATE item_master SET current_stock ='" + stock
					+ "' WHERE item_id='" + iteamId + "' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/

	public List<WelezoConstantsTO> getallcategory() {
		List<WelezoConstantsTO> list = new ArrayList<>();
		try {
			String s = "SELECT DISTINCT  const_type FROM welezo_constants";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				WelezoConstantsTO welezo = new WelezoConstantsTO();

				welezo.setConstType(rs.getString("const_type"));
				list.add(welezo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public void updateEmpImg(byte[] bytes, Integer empId) {
		ResultSet rs = null;
		int id = 0;
		try {
			String s = "SELECT * FROM employee_images WHERE emp_id = '" + empId
					+ "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			if (rs.next()) {
				id = rs.getInt("id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		Session session = sessionFactory.openSession();
		session.beginTransaction();
		EmployeeImagesTO emp = null;
		emp = (EmployeeImagesTO) session.get(EmployeeImagesTO.class, id);
		emp.setEmpImg(bytes);// Set the updated userName to the model field
		session.update(emp); // Update to the database table
		session.getTransaction().commit();
	}

	public EmployeeImagesTO getEmployeeImage(Integer empId) {
		ResultSet rs = null;
		EmployeeImagesTO employeeImg = new EmployeeImagesTO();
		try {
			String s = "SELECT * FROM employee_images WHERE emp_id = '" + empId
					+ "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			if (rs.next()) {
				employeeImg.setEmpId(rs.getInt("emp_id"));
				employeeImg.setEmpImg(rs.getBytes("emp_img"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeImg;
	}

	@RequestMapping(value = "/payCalculator", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView payCalculator(Model model, Integer gross, Integer empId) {

		// System.out.println("emplyee id : " + empId);
		int basicPerc;
		if (gross < 12500) {
			basicPerc = 60;
		} else if (gross < 15400) {
			basicPerc = 50;
		} else {
			basicPerc = 40;
		}

		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT  '" + gross + "' as 'gross', '" + basicPerc
					+ "' as 'basic_percent', ROUND('" + gross + "'*'"
					+ basicPerc + "'/100,0) AS basic," + "ROUND(0.4*('" + gross
					+ "'*'" + basicPerc + "'/100)) AS hra, ROUND('" + gross
					+ "' - '" + gross + "'*'" + basicPerc + "'/100 - 0.4*('"
					+ gross + "'*'" + basicPerc + "'/100)) AS others,"
					+ "ROUND(IF('" + gross + "' >= 21000, 0 ,  1.75*'" + gross
					+ "'/100), 0) AS esi, ROUND('" + gross + "'*'" + basicPerc
					+ "'/100*0.12, 0) AS epf, " + "IF('" + gross
					+ "'>15000, 200, 0) AS pt, ROUND( '" + gross + "' - IF('"
					+ gross + "' >= 21000, 0 ,  1.75*'" + gross + "'/100) -  '"
					+ gross + "'*'" + basicPerc + "'/100*0.12 - IF('" + gross
					+ "'>15000, 200, 0) ,0) AS nett," + "ROUND('" + gross
					+ "'*'" + basicPerc
					+ "'/100*0.12) AS company_pf, ROUND(IF('" + gross
					+ "' >= 21000, 0 ,  1.75*'" + gross
					+ "'/100), 0) AS company_esi, " + "ROUND(('" + gross
					+ "' + IF('" + gross + "' >= 21000, 0 ,  1.75*'" + gross
					+ "'/100) + '" + gross + "'*'" + basicPerc
					+ "'/100*0.12), 0) AS ctc " + "FROM DUAL";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("gross", rs.getString("gross"));
				list.put("basicPercent", rs.getString("basic_percent"));
				list.put("basic", rs.getString("basic"));
				list.put("hra", rs.getString("hra"));
				list.put("others", rs.getString("others"));
				list.put("esi", rs.getString("esi"));
				list.put("epf", rs.getString("epf"));
				list.put("pt", rs.getString("pt"));
				list.put("nett", rs.getString("nett"));
				list.put("company_pf", rs.getString("company_pf"));
				list.put("company_esi", rs.getString("company_esi"));
				list.put("ctc", rs.getString("ctc"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("salaryDeatils", list);
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("todayDate", dateFormat.format(date));
		return new ModelAndView("HR/hr/payCalculator");
	}

	@RequestMapping(value = "/attendance")
	public ModelAndView attendence(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		return new ModelAndView("redirect:attendance1");
	}

	@RequestMapping(value = "/attendance1", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView attendenceList(ModelMap model,
			@RequestParam String fromDate, @RequestParam String toDate) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT details.emp_name AS 'Emp Name',SUM(CASE WHEN att_mark IN ('A','L') THEN 1 ELSE 0 END) 'Absents',"
					+ " SUM(CASE WHEN att_mark IN ('P', 'WO') THEN 1 ELSE 0 END) 'Present', SUM(CASE WHEN att_mark = 'Lt' THEN 1 ELSE 0 END) AS 'Lates',"
					+ " SUM(CASE WHEN att_mark = 'HD' THEN 1 ELSE 0 END) AS 'Half Days',"
					+ " MAX(CASE WHEN DAY(work_date) = 1 THEN att_mark ELSE NULL END) AS Day1,MAX(CASE WHEN DAY(work_date) = 2 "
					+ "THEN att_mark ELSE NULL END) AS Day2, MAX(CASE WHEN DAY(work_date) = 3 THEN att_mark ELSE NULL END) AS Day3, "
					+ "MAX(CASE WHEN DAY(work_date) = 4 THEN att_mark ELSE NULL END) AS Day4, MAX(CASE WHEN DAY(work_date) = 5 "
					+ "THEN att_mark ELSE NULL END) AS Day5, MAX(CASE WHEN DAY(work_date) = 6 THEN att_mark ELSE NULL END) AS Day6, "
					+ "MAX(CASE WHEN DAY(work_date) = 7 THEN att_mark ELSE NULL END) AS Day7, MAX(CASE WHEN DAY(work_date) = 8 "
					+ "THEN att_mark ELSE NULL END) AS Day8, MAX(CASE WHEN DAY(work_date) = 9 THEN att_mark ELSE NULL END) AS Day9, "
					+ "MAX(CASE WHEN DAY(work_date) = 10 THEN att_mark ELSE NULL END) AS Day10, MAX(CASE WHEN DAY(work_date) = 11 "
					+ "THEN att_mark ELSE NULL END) AS Day11, MAX(CASE WHEN DAY(work_date) = 12 THEN att_mark ELSE NULL END) AS Day12, "
					+ "MAX(CASE WHEN DAY(work_date) = 13 THEN att_mark ELSE NULL END) AS Day13, MAX(CASE WHEN DAY(work_date) = 14 "
					+ "THEN att_mark ELSE NULL END) AS Day14, MAX(CASE WHEN DAY(work_date) = 15 THEN att_mark ELSE NULL END) AS Day15,"
					+ " MAX(CASE WHEN DAY(work_date) = 16 THEN att_mark ELSE NULL END) AS Day16, MAX(CASE WHEN DAY(work_date) = 17 "
					+ "THEN att_mark ELSE NULL END) AS Day17, MAX(CASE WHEN DAY(work_date) = 18 THEN att_mark ELSE NULL END) AS Day18, "
					+ "MAX(CASE WHEN DAY(work_date) = 19 THEN att_mark ELSE NULL END) AS Day19, MAX(CASE WHEN DAY(work_date) = 20 THEN att_mark ELSE NULL END)"
					+ " AS Day20, MAX(CASE WHEN DAY(work_date) = 21 THEN att_mark ELSE NULL END) AS Day21, MAX(CASE WHEN DAY(work_date) = 22"
					+ " THEN att_mark ELSE NULL END) AS Day22, MAX(CASE WHEN DAY(work_date) = 23 THEN att_mark ELSE NULL END) AS Day23, "
					+ "MAX(CASE WHEN DAY(work_date) = 24 THEN att_mark ELSE NULL END) AS Day24, MAX(CASE WHEN DAY(work_date) = 25 THEN att_mark ELSE NULL END)"
					+ " AS Day25, MAX(CASE WHEN DAY(work_date) = 26 THEN att_mark ELSE NULL END) AS Day26, MAX(CASE WHEN DAY(work_date) = 27 "
					+ "THEN att_mark ELSE NULL END) AS Day27, MAX(CASE WHEN DAY(work_date) = 28 THEN att_mark ELSE NULL END) AS Day28,  "
					+ " MAX(CASE WHEN DAY(work_date) = 29 THEN att_mark ELSE NULL END) AS Day29, "
					+ "  MAX(CASE WHEN DAY(work_date) = 30 THEN att_mark ELSE NULL END) AS Day30, "
					+ "  MAX(CASE WHEN DAY(work_date) = 31 THEN att_mark ELSE NULL END) AS Day31 "
					+ " FROM emp_daily emp "
					+ " LEFT JOIN employee_details details ON details.emp_id = emp.emp_id "
					+ "WHERE emp.work_date BETWEEN '"
					+ date
					+ "' AND '"
					+ date1 + "' GROUP BY emp.emp_id ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnLabel(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		return new ModelAndView("HR/hr/attendance");
	}

	@RequestMapping(value = "/addAtendance")
	public ModelAndView addAttendence(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		return new ModelAndView("redirect:addAttendance1");
	}

	@RequestMapping(value = "/addAttendance1")
	public ModelAndView attendenceList(ModelMap model,
			@RequestParam String fromDate) throws ParseException {
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT daily.*,emp.emp_name FROM emp_daily daily  LEFT JOIN employee_details emp ON emp.emp_id = daily.emp_id "
					+ "WHERE work_date = '" + date + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("attendenceId", rs.getString("id"));
				list.put("empId", rs.getString("emp_id"));
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/YYYY");
				list.put("workDate", sdf1.format(rs.getDate("work_date")));
				list.put("loginTime", rs.getString("login_time"));
				list.put("logoutTime", rs.getString("logout_time"));
				list.put("workQuantum", rs.getString("work_quantum"));
				list.put("lateComing", rs.getString("late_coming"));
				list.put("attMark", rs.getString("att_mark"));
				list.put("empName", rs.getString("emp_name"));
				stkList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("stkList", stkList);
		model.addAttribute("fromDate", fromDate);
		return new ModelAndView("HR/hr/addAttendence", "attendenceDTO",
				new AttendenceDTO());
	}

	public void updateAttendence(AttendenceDTO attendenceDTO) {
		Integer[] attendenceId = attendenceDTO.getAttendenceId();
		String[] attMark = attendenceDTO.getAttmark();
		String[] workQuantum = attendenceDTO.getWorkQuantum();
		//String[] loginTime = attendenceDTO.getLoginTime();
		//String[] logOutTime = attendenceDTO.getLogOutTime();
		for (int i = 0; i < attendenceId.length; i++) {
			try {
				String query = "UPDATE emp_daily SET  att_mark = '" + attMark[i] + "' WHERE id = '" + attendenceId[i] + "' ";
				Connection connection = sessionFactory.getCurrentSession()
						.connection();
				PreparedStatement updPrepStmt = connection
						.prepareStatement(query);
				updPrepStmt.executeUpdate(query);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public ArrayList<HashMap<String, String>> getAllVoucherEntry() {
		ArrayList<HashMap<String, String>> appointmentList = new ArrayList<>();
		try {
			String s = "SELECT trxOff.*,ser.appointment_id,ser.Category,ser.Service,ser.ServiceCentre,ser.Customer_Name,ser.Used_By,"
					+ "ser.Appt_Date,ser.transaction_id,ser.customer_id FROM transaction_offers  trxOff LEFT JOIN service_utilization ser ON trxOff.usage_id = ser.appointment_id "
					+ " WHERE trxOff.usage_id > 0  AND ser.Appt_Status = 'Availed' AND ser.Category NOT IN('Dentistry')";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("appointmentId", rs.getString("appointment_id"));
				list.put("Category", rs.getString("Category"));
				list.put("Service", rs.getString("Service"));
				list.put("ServiceCentre", rs.getString("ServiceCentre"));
				list.put("CustomerName", rs.getString("Customer_Name"));
				list.put("UsedBy", rs.getString("Used_By"));
				list.put("ApptDate", rs.getString("Appt_Date"));
				list.put("voucherNo", rs.getString("voucher_no"));
				list.put("customerId", rs.getString("customer_id"));
				appointmentList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return appointmentList;
	}

	public void updateReceivedVoucherNumbers(HealthAppointmentTO healthApptTO) {
		try {
			String query = " UPDATE health_appointment SET tx_offers_voucher = '"
					+ healthApptTO.getTxOffersVoucher()
					+ "', status_appointment = 'Voucher Received', "
					+ " voucher_received_date = CURRENT_DATE  WHERE appointment_id = '"
					+ healthApptTO.getAppointmentId() + "' ";
			System.out.println(query);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateTxOffers(DispatchTrackingDTO dispatchTrackingTO) {

		Integer[] txOffersId = dispatchTrackingTO.getTxOffersId();
		String[] voucherNo = dispatchTrackingTO.getVoucherNo();

		for (int i = 0; i < txOffersId.length; i++) {
			if (txOffersId[i] != null) {
				try {
					String query = "UPDATE transaction_offers SET voucher_no = '"
							+ voucherNo[i]
							+ "',track_id = '"
							+ dispatchTrackingTO.getTrackId()
							+ "' WHERE txoffer_id = '" + txOffersId[i] + "' ";
					Connection connection = sessionFactory.getCurrentSession()
							.connection();
					PreparedStatement updPrepStmt = connection
							.prepareStatement(query);
					updPrepStmt.executeUpdate(query);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void updateCardNumber(Integer customerId, Integer txId) {

		System.out.println("Inside update card " + customerId);
		List<AddressDTO> addressEntityId = adminService
				.getAddressEntityId(customerId);

		for (AddressDTO adress : addressEntityId) {
			CustomerDeatilsTO customerDetail = adminService
					.getCustomerDetail(customerId);
			AddressTO addressTO = new AddressTO();
			AddressCatagoriesTO addressTypeId = adminService
					.getAddressTypeId(adress.getAddressCategory());
			addressTO.setAddressCatagories(addressTypeId);

			if (addressTypeId.getAddressType().equalsIgnoreCase(
					customerDetail.getCorrespondence())) {
				if (adress.getPincode() != null
						&& customerDetail.getDob().toString() != null
						&& customerDetail.getCustomerName() != null) {
					addressTO.setPincode(adress.getPincode());
					CardGenerator card = new CardGenerator();
					ArrayList<String> generateCardNumber = card
							.generateCardNumber(customerDetail.getDob()
									.toString(), adress.getPincode(),
									customerDetail.getCustomerName());
					updateCustomercard(generateCardNumber, txId, customerId);
				}
			}
		}

	}

	public void updateCustomercard(ArrayList<String> generateCardNumber,
			Integer txId, Integer customerId) {
		System.out.println("updateCustomercard " + txId + customerId);
		String existCard = null;
		Connection connection;
		try {
			String s = "SELECT customer_id,card_number FROM customer_deatils WHERE customer_id = '"
					+ customerId + "'";
			connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				existCard = rs.getString("card_number");
			}
			rs = null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (existCard == null) {
			for (Iterator<String> iterator = generateCardNumber.iterator(); iterator
					.hasNext();) {
				String cardNo = (String) iterator.next();
				try {
					String s = "SELECT * FROM customer_deatils WHERE card_number  = '"
							+ cardNo + "'";
					connection = sessionFactory.getCurrentSession()
							.connection();
					PreparedStatement prepareStatement = connection
							.prepareStatement(s);
					ResultSet rs = prepareStatement.executeQuery();
					if (rs.next()) {
						rs = null;
					} else {
						String query = "UPDATE customer_deatils SET card_number ='"
								+ cardNo
								+ "' WHERE customer_id = '"
								+ customerId + "'";

						System.out.println("query :" + query);
						hrService.upDateQuery(query);
						String query1 = "UPDATE transaction_master SET card_number = '"
								+ cardNo
								+ "',customer_id = '"
								+ customerId
								+ "' WHERE transaction_id =  '" + txId + "'";

						System.out.println("query1 upadate: " + query1);
						hrService.upDateQuery(query1);
						break;
					}
					rs = null;
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		} else {
			String query2 = "UPDATE transaction_master SET card_number = '"
					+ existCard + "',customer_id = '" + customerId
					+ "'  WHERE transaction_id =  '" + txId + "'";
			System.out.println(query2);
			hrService.upDateQuery(query2);

		}
	}

	public Integer getCollectionIdThruTx(Integer txId) {
		Integer id = null;
		try {
			String s = "SELECT collection_id FROM collection WHERE transaction_id = '"
					+ txId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				id = rs.getInt("collection_id");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return id;
	}

	public void insertAccountTransaction(String applicationNo) {
		try {
			String query = "INSERT INTO welezohe_accounts.acc_trx(trx_date, from_acc, to_acc, amount, pay_ref, mode_of_pay, ledger, narration, isSettled, entity, entity_id) "
					+ "(SELECT collected_date, 7 AS from_acc, CASE WHEN payment_status='Cash' THEN 6 WHEN payment_status='CreditCard' THEN 4 ELSE 1 END AS to_acc,  "
					+ "amount, application_no AS refNo, payment_status, 193, 'From the sale of Product', 0, 'Transaction', transaction_id "
					+ " FROM welezohe_whms.transaction_master WHERE application_no='"
					+ applicationNo + "')  ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// @RequestMapping(value = "/getSeviceList" )
	public ArrayList<HashMap<String, String>> getAllAvailableHospitalList(
			String fromDate, String toDate, Integer serviceId, String city) {
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}

		ArrayList<HashMap<String, String>> appointmentList = new ArrayList<>();
		try {
			String s = "SELECT sch.*,emp.`city` FROM schedule_service sch LEFT JOIN `empanellment` emp ON emp.`hospital_id` = sch.hospital_id "
					+ " WHERE sch.calendarDate BETWEEN '"
					+ date
					+ "' AND '"
					+ date1
					+ "' AND sch.service_id = '"
					+ serviceId
					+ "' "
					+ " AND emp.`city` =  '"
					+ city
					+ "' ORDER BY sch.calendarDate,sch.hospital_id ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("ServiceCentre", rs.getString("ServiceCentre"));
				list.put("hospitalId", rs.getString("hospital_id"));
				list.put("serviceId", rs.getString("service_id"));
				list.put("service", rs.getString("service"));
				list.put("Category", rs.getString("Category"));
				try {
					SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/YYYY");
					list.put("calendarDate",
							sdf1.format(rs.getDate("calendarDate")));
				} catch (NullPointerException e) {
					e.printStackTrace();
				}

				list.put("totalAppt", rs.getString("Day_Total"));
				list.put("Slot0800", rs.getString("Slot_0800"));
				list.put("Slot0815", rs.getString("Slot_0815"));
				list.put("Slot0830", rs.getString("Slot_0830"));
				list.put("Slot0845", rs.getString("Slot_0845"));
				list.put("Slot0900", rs.getString("Slot_0900"));
				list.put("Slot1000", rs.getString("Slot_1000"));
				list.put("Slot1100", rs.getString("Slot_1100"));
				list.put("Slot1200", rs.getString("Slot_1200"));
				list.put("Slot1400", rs.getString("Slot_1400"));
				list.put("Slot1500", rs.getString("Slot_1500"));
				list.put("Slot1600", rs.getString("Slot_1600"));
				list.put("Slot1700", rs.getString("Slot_1700"));
				list.put("Slot1800", rs.getString("Slot_1800"));
				appointmentList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return appointmentList;
	}

	public ArrayList<HashMap<String, String>> getCityList() {
		ArrayList<HashMap<String, String>> cityList = new ArrayList<>();
		try {
			String s = "SELECT DISTINCT city FROM empanellment ORDER BY city";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("city", rs.getString("city"));
				cityList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cityList;
	}

	@RequestMapping(value = "/leavecalender")
	public @ResponseBody ModelAndView leave(ModelMap model) {
		ArrayList<HashMap<String, String>> empList = new ArrayList<>();

		try {
			String s = "SELECT DATE(call_date) AS 'Date', COUNT(1) AS 'TotalCalls' FROM tele_call_record GROUP BY DATE(call_date)";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			JSONArray mArray = new JSONArray();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("Date", rs.getString("Date"));
				list.put("TotalCalls", rs.getString("TotalCalls"));
				empList.add(list);
				JSONObject obj = new JSONObject();
				obj.put("date", rs.getString("Date"));
				obj.put("calls", rs.getString("TotalCalls"));
				mArray.put(obj);
			}
			String string = mArray.toString();
			model.addAttribute("object", string);
			// System.out.println("Controller value == "+ string);

		} catch (Exception e) {
			e.printStackTrace();
		}

		model.addAttribute("list", empList);

		return new ModelAndView("HR/hr/leavesCalender", "leavecalender",
				empList);
	}

	public ArrayList<HashMap<String, String>> getAllCategory() {
		ArrayList<HashMap<String, String>> serviceList = new ArrayList<>();
		try {
			String s = "SELECT DISTINCT category FROM Services";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("category", rs.getString("category"));
				serviceList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return serviceList;
	}

	public ArrayList<HashMap<String, String>> employeeBirthdayList() {
		ArrayList<HashMap<String, String>> dobList = new ArrayList<>();
		try {
			String s = "SELECT emp_id, emp_name, dob, DATE_ADD(dob, INTERVAL IF(DAYOFYEAR(dob) >= DAYOFYEAR(CURDATE()),"
					+ "  YEAR(CURDATE())-YEAR(dob), YEAR(CURDATE())-YEAR(dob)+1) YEAR) AS next_birthday    FROM employee_details "
					+ " WHERE dob IS NOT NULL AND STATUS = 'Joined' HAVING  next_birthday BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) "
					+ " ORDER BY next_birthday";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			JSONArray mArray = new JSONArray();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("empName", rs.getString("emp_name"));
				list.put("DOB", rs.getString("next_birthday"));
				/*
				 * JSONObject obj = new JSONObject(); obj.put("Name",
				 * rs.getString("emp_name")); obj.put("DOB",
				 * rs.getString("next_birthday")); mArray.put(obj);
				 */
				dobList.add(list);
			}
			// string = mArray.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dobList;
	}

	public HashMap<String, String> getEVocherData(Integer appointmentId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT ser.*,adds.email FROM service_utilization ser LEFT JOIN address adds ON adds.entity_id = ser.customer_id "
					+ "  WHERE `appointment_id` = '" + appointmentId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.put("ServiceCentre", rs.getString("ServiceCentre"));
				list.put("service", rs.getString("service"));
				list.put("ApptDate", rs.getString("Appt_Date"));
				list.put("ApptTime", rs.getString("Appt_Time"));
				list.put("CustomerName", rs.getString("Customer_Name"));
				list.put("ApptFor", rs.getString("Appt_For"));
				list.put("appointmentId", rs.getString("appointment_id"));
				list.put("UserReln", rs.getString("User_Reln"));

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public JSONArray healthAppointmentListDatecalender() {
		JSONArray mArray = new JSONArray();
		try {
			String s = "SELECT Appt_Date,COUNT(1) as 'Total', SUM(CASE WHEN category = 'Health Check' THEN 1 ELSE 0 END) AS 'healthcheck', "
					+ " SUM(CASE WHEN category = 'Consultation' THEN 1 ELSE 0 END) AS 'consultation', "
					+ " SUM(CASE WHEN category = 'Dentistry' THEN 1 ELSE 0 END) AS 'dentistry', "
					+ " SUM(CASE WHEN category = 'Pharmacy' THEN 1 ELSE 0 END) AS 'pharmacy' FROM service_utilization WHERE Appt_Status NOT IN ('Cancelled','Missed') GROUP BY Appt_Date";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				JSONObject obj = new JSONObject();
				obj.put("date", rs.getString("Appt_Date"));
				obj.put("calls", rs.getString("Total"));
				obj.put("healthcheck", rs.getString("healthcheck"));
				obj.put("consultation", rs.getString("consultation"));
				obj.put("dentistry", rs.getString("dentistry"));
				obj.put("pharmacy", rs.getString("pharmacy"));
				mArray.put(obj);
			}
			// String string = mArray.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return mArray;
	}

	public HashMap<String, String> meetingNotification(Integer userId) {
		HashMap<String, String> employee = hrService.getEmployeeIdFromUserId(userId);
		EmployeeDetailsDTO employeeById = hrService.getEmployeeById(Integer.parseInt(employee.get("empId")));
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) AS total FROM meeting_attendees att LEFT JOIN meetings met ON met.meeting_id = att.meeting_id "
					+ " WHERE att.attendee_id = '"
					+ employeeById.getEmpId()
					+ "'  AND att.view_notification = 1 GROUP  BY att.attendee_id UNION "
					+ "SELECT COUNT(1) AS total FROM meeting_attendees att LEFT JOIN meetings met ON met.meeting_id = att.meeting_id "
					+ "WHERE att.attendee_id = '"
					+ employeeById.getEmpId()
					+ "'  AND att.view_notification = 1 GROUP  BY att.attendee_id";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("total", rs.getString("total"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	public String getMeetingAttendees(Integer meetingId) {
		String att = "";
		try {
			String s = "SELECT meet.*,emp.emp_name FROM meeting_attendees meet LEFT JOIN employee_details emp ON emp.emp_id = meet.attendee_id "
					+ " WHERE meet.meeting_id = '" + meetingId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				att = att + ", " + rs.getString("emp_name");
				// JSONObject obj = new JSONObject();
				// obj.put("attedneeName", rs.getString("emp_name"));
				// obj.put("calls", rs.getString("Total"));
				// obj.put("healthcheck", rs.getString("healthcheck"));

				// mArray.put(obj);
			}
			// String string = mArray.toString();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return att;
	}

	public ArrayList<HashMap<String, String>> getEmployeeAbsenties() {

		ArrayList<HashMap<String, String>> empList = new ArrayList<>();
		try {
			String s = "SELECT att.emp_id,att.att_mark, emp.emp_name FROM emp_daily att LEFT JOIN employee_details emp ON emp.emp_id = att.emp_id "
					+ " WHERE att.work_date = CURRENT_DATE AND att.att_mark IN ('A','HD','L','Lt')";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("empId", rs.getString("emp_id"));
				list.put("attMark", rs.getString("att_mark"));
				list.put("empName", rs.getString("emp_name"));
				empList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return empList;
	}

	public ArrayList<HashMap<String, String>> getCSRSummary() {

		ArrayList<HashMap<String, String>> empList = new ArrayList<>();
		try {
			String s = "SELECT csr_name, SUM(tx.amount) AS 'Revenue', COUNT(1) AS 'Sales' FROM view_PayTrxCust tx "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = tx.csr_id WHERE  tx.status IN ('Payment Approved','New') AND emp.status = 'Joined'"
					+ " GROUP BY 1 UNION SELECT 'Z-GRAND TOTAL', SUM(tx.amount) AS 'Revenue',COUNT(1) AS 'Sales'FROM view_PayTrxCust tx "
					+ "LEFT JOIN `employee_details` emp ON emp.emp_id = tx.csr_id WHERE tx.status IN ('Payment Approved','New') AND emp.status = 'Joined'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("Sales", rs.getString("Sales"));
				list.put("Revenue", rs.getString("Revenue"));
				list.put("empName", rs.getString("csr_name"));
				empList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return empList;
	}

	public ArrayList<HashMap<String, String>> getCSRMonthlyReport(String fromDate,String toDate) {

		ArrayList<HashMap<String, String>> empList = new ArrayList<>();
		try {
			String s = "SELECT IFNULL(csr_name,'Welezo') AS 'CSR', CONCAT(LEFT(MONTHNAME(collected_date),3), ' ', RIGHT(YEAR(collected_date),2)) AS 'Month', COUNT(1) AS 'Sales',"
					+ " SUM(amount) AS 'Revenue', ROUND(AVG(amount),2) AS 'Ticket Size' FROM  view_paytrxcust "
					+ " WHERE collected_date BETWEEN '"+fromDate+"' AND '"+toDate+"' AND STATUS NOT IN ('Cheque Bounce') GROUP BY 1 UNION ALL "
					+ " SELECT 'Z-Total', '', COUNT(1) AS 'Sales', SUM(amount) AS 'Revenue', ROUND(AVG(amount),2) AS 'Ticket Size' FROM  view_PayTrxCust "
					+ " WHERE collected_date BETWEEN '"+fromDate+"' AND '"+toDate+"' AND STATUS NOT IN ('Cheque Bounce')";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("Sales", rs.getString("Sales")+"");
				list.put("Revenue", rs.getString("Revenue")+"");
				list.put("csrName", rs.getString("CSR")+"");
				list.put("Month", rs.getString("Month")+"");
				list.put("TicketSize", rs.getString("Ticket Size")+"");
				empList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return empList;
	}

	public ArrayList<HashMap<String, String>> getTodayPresalesAppointment(String date) {

		ArrayList<HashMap<String, String>> apptList = new ArrayList<>();
		try {
			String s = "SELECT  IFNULL(csr_name,'Welezo')AS 'CSR',COUNT(1) AS 'Total Appts',"
					+ " SUM(CASE WHEN appointment_type = 'Fresh' THEN 1 ELSE 0 END) AS 'Fresh', "
					+ " SUM(CASE WHEN appointment_type != 'Fresh' THEN 1 ELSE 0 END) AS 'FollowUp',"
					+ " SUM(CASE WHEN meeting_status = 'Met' THEN 1 ELSE 0 END) AS 'Meetings', "
					+ " SUM(CASE WHEN STATUS = 'Collected' THEN 1 ELSE 0 END) AS 'Collections',"
					+ " SUM(CASE WHEN STATUS = 'Not Interested' THEN 1 ELSE 0 END) AS 'Not Interested',"
					+ " SUM(CASE WHEN STATUS = 'Rescheduled' THEN 1 ELSE 0 END) AS 'Rescheduled',"
					+ " SUM(CASE WHEN STATUS = 'New Appointment' THEN 1 ELSE 0 END) AS 'New'"
					+ " FROM presales_appts WHERE date_appointment = '"+date+"'  "
					+ "AND product_name NOT IN ('Make India Healthy') GROUP BY 1 UNION ALL "
					+ " SELECT 'Z-TOTAL', COUNT(1) AS 'Total Appts', SUM(CASE WHEN appointment_type = 'Fresh' THEN 1 ELSE 0 END) AS 'Fresh', "
					+ " SUM(CASE WHEN appointment_type != 'Fresh' THEN 1 ELSE 0 END) AS 'FollowUp',"
					+ " SUM(CASE WHEN meeting_status = 'Met' THEN 1 ELSE 0 END) AS 'Meetings',"
					+ " SUM(CASE WHEN STATUS = 'Collected' THEN 1 ELSE 0 END) AS 'Collections',"
					+ "SUM(CASE WHEN STATUS = 'Not Interested' THEN 1 ELSE 0 END) AS 'Not Interested',"
					+ " SUM(CASE WHEN STATUS = 'Rescheduled' THEN 1 ELSE 0 END) AS 'Rescheduled',"
					+ "SUM(CASE WHEN STATUS = 'New Appointment' THEN 1 ELSE 0 END) AS 'New'"
					+ " FROM presales_appts WHERE date_appointment = '"+date+"'  AND product_name NOT IN ('Make India Healthy')";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("CSR", rs.getString("CSR")+"");
				list.put("TotalAppts", rs.getString("Total Appts")+"");
				list.put("Fresh", rs.getString("Fresh")+"");
				list.put("FollowUp", rs.getString("FollowUp")+"");
				list.put("Meetings", rs.getString("Meetings")+"");
				list.put("Collections", rs.getString("Collections")+"");
				list.put("NotInterested", rs.getString("Not Interested")+"");
				list.put("Rescheduled", rs.getString("Rescheduled")+"");
				list.put("New", rs.getString("New")+"");
				apptList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return apptList;
	}

	public ArrayList<HashMap<String, String>> getCSRDailyCallsReport(String toDate) {

		ArrayList<HashMap<String, String>> callsList = new ArrayList<>();
		try {
			String s = "SELECT CONCAT(extension_no, ' (', IFNULL(emp_name,'Welezo'), ')')  AS 'User Name', COUNT(extension_no) AS 'Total Calls',"
					+ "CONCAT('', FLOOR(SUM(duration)/60), ':', SUM(duration)%60) AS 'Total Duration', "
					+ "SUM(CASE WHEN duration < 30 THEN 1 ELSE 0 END) 'Calls < 30Sec', "
					+ "SUM(CASE WHEN duration BETWEEN 30 AND 180 THEN 1 ELSE 0 END) 'Calls < 3 Min',"
					+ "SUM(CASE WHEN duration BETWEEN 181 AND 300 THEN 1 ELSE 0 END) 'Calls 3 To 5 Min',"
					+ "SUM(CASE WHEN duration BETWEEN 301 AND 419 THEN 1 ELSE 0 END) 'Calls 5 To 7 Min',"
					+ "SUM(CASE WHEN duration > 419 THEN 1 ELSE 0 END) 'Calls > 7 Min' "
					+ "FROM call_details WHERE call_date BETWEEN '"+toDate+" 00:00:00' AND '"+toDate+" 23:59:59' AND department LIKE '%Sales%' GROUP BY 1"
					+ " UNION ALL SELECT  'Z-Total',COUNT(extension_no) AS 'Total Calls',"
					+ "CONCAT('', FLOOR(SUM(duration)/60), ':', SUM(duration)%60) AS 'Total Duration', "
					+ "SUM(CASE WHEN duration < 30 THEN 1 ELSE 0 END) 'Calls < 30Sec', "
					+ "SUM(CASE WHEN duration BETWEEN 30 AND 180 THEN 1 ELSE 0 END) 'Calls < 3 Min',"
					+ "SUM(CASE WHEN duration BETWEEN 181 AND 300 THEN 1 ELSE 0 END) 'Calls 3 To 5 Min',"
					+ "SUM(CASE WHEN duration BETWEEN 301 AND 419 THEN 1 ELSE 0 END) 'Calls 5 To 7 Min',"
					+ "SUM(CASE WHEN duration > 419 THEN 1 ELSE 0 END) 'Calls > 7 Min' "
					+ " FROM call_details WHERE call_date BETWEEN '"+toDate+" 00:00:00' AND '"+toDate+" 23:59:59' AND department LIKE '%Sales%'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("CSRName", rs.getString("User Name")+"");
				list.put("TotalCalls", rs.getString("Total Calls"));
				list.put("TotalDuration", rs.getString("Total Duration")+"");
				list.put("Calls30Sec", rs.getString("Calls < 30Sec")+"");
				list.put("Calls3Min", rs.getString("Calls < 3 Min")+"");
				list.put("Calls3To5Min", rs.getString("Calls 3 To 5 Min")+"");
				list.put("Calls5To7Min", rs.getString("Calls 5 To 7 Min")+"");
				list.put("Calls7Min", rs.getString("Calls > 7 Min")+"");
				callsList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return callsList;
	}

	public HashMap<String, String> customerMoreThan3Appointment(String mobileNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) AS 'Total Appoitment',Customer_Name FROM presales_appts WHERE primary_mob = '"
					+ mobileNo + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("totalAppt", rs.getString("Total Appoitment"));
				list.put("CustomerName", rs.getString("Customer_Name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	public HashMap<String, String> customerLastCallRxFsomCSR(String mobileNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT CONCAT(extension_no, '(',IFNULL(emp_name, ''),')') AS 'Called By', phone_no AS 'Contact No.', "
					+ "call_date AS 'Called On', duration AS Duration FROM call_details WHERE phone_no='"
					+ mobileNo + "' ORDER BY call_date DESC LIMIT 1";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("CalledBy", rs.getString("Called By"));
				list.put("CalledOn", rs.getString("Called On"));
				list.put("Duration", rs.getString("Duration"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	public ArrayList<HashMap<String, String>> getHealthApptSummaryEmail(String date) {

		ArrayList<HashMap<String, String>> apptList = new ArrayList<>();
		try {
			String s = "SELECT ServiceCentre AS 'Health Center' ,COUNT(1) AS 'Total Appointments', "
					+ "SUM( CASE WHEN Category = 'Dentistry' THEN 1 ELSE 0 END) 'Dentistry',"
					+ "SUM( CASE WHEN Category = 'Consultation' THEN 1 ELSE 0 END) 'Consultation',"
					+ "SUM(CASE WHEN Service = 'Master Health Check' THEN 1 ELSE 0 END) 'MHC',"
					+ "SUM(CASE WHEN Service = 'Executive Health Check' THEN 1 ELSE 0 END) 'EHC',"
					+ "SUM(CASE WHEN Service = 'Total Wellness Check' THEN 1 ELSE 0 END) 'TWC',"
					+ "SUM(CASE WHEN Service = 'Well Women Health Check' THEN 1 ELSE 0 END) 'WWHC',"
					+ "SUM(CASE WHEN Service = 'Senior Citizen Health Check' THEN 1 ELSE 0 END) 'SCHC',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Women]' THEN 1 ELSE 0 END) 'PHC-Women',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Men]' THEN 1 ELSE 0 END) 'PHC-Men',"
					+ "SUM(CASE WHEN Service = 'WELLNESS BASIC CHECK' THEN 1 ELSE 0 END) 'WBC',"
					+ "SUM(CASE WHEN Service = 'WELLNESS EXECUTIVE CHECK' THEN 1 ELSE 0 END) 'WEC' ,"
					+ "SUM(CASE WHEN Service = 'WELLNESS MASTER CHECK' THEN 1 ELSE 0 END) 'WMC' "
					+ "FROM service_utilization WHERE `Appt_Status` NOT IN ('Missed','Cancelled','Rescheduled')"
					+ "AND `Appt_Date` BETWEEN '"+date+" 00:00:00' AND '"+date+" 23:59:59' GROUP BY 1 UNION "
					+ "SELECT 'Z-Total' AS 'GroupingColumn', COUNT(1) AS 'Total Appointments', "
					+ "SUM( CASE WHEN Category = 'Dentistry' THEN 1 ELSE 0 END) 'Dentistry',"
					+ "SUM( CASE WHEN Category = 'Consultation' THEN 1 ELSE 0 END) 'Consultation',"
					+ "SUM(CASE WHEN Service = 'Master Health Check' THEN 1 ELSE 0 END) 'MHC',"
					+ "SUM(CASE WHEN Service = 'Executive Health Check' THEN 1 ELSE 0 END) 'EHC',"
					+ "SUM(CASE WHEN Service = 'Total Wellness Check' THEN 1 ELSE 0 END) 'TWC', "
					+ "SUM(CASE WHEN Service = 'Well Women Health Check' THEN 1 ELSE 0 END) 'WWHC',"
					+ "SUM(CASE WHEN Service = 'Senior Citizen Health Check' THEN 1 ELSE 0 END) 'SCHC',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Women]' THEN 1 ELSE 0 END) 'PHC-Women',"
					+ "SUM(CASE WHEN Service = 'Platinum Health Check [Men]' THEN 1 ELSE 0 END) 'PHC-Men',"
					+ "SUM(CASE WHEN Service = 'WELLNESS EXECUTIVE CHECK' THEN 1 ELSE 0 END) 'WBC',"
					+ "SUM(CASE WHEN Service = 'WELLNESS EXECUTIVE CHECK' THEN 1 ELSE 0 END) 'WEC',"
					+ "SUM(CASE WHEN Service = 'WELLNESS MASTER CHECK' THEN 1 ELSE 0 END) 'WMC' "
					+ "FROM service_utilization WHERE `Appt_Status` NOT IN ('Missed','Cancelled','Rescheduled')"
					+ " AND `Appt_Date` BETWEEN '"+date+" 00:00:00' AND '"+date+" 23:59:59'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("AppointmentDate", rs.getString("Health Center"));
				list.put("TotalAppointments",rs.getString("Total Appointments") + "");
				list.put("Dentistry", rs.getString("Dentistry") + "");
				list.put("Consultation", rs.getString("Consultation") + "");
				list.put("MHC", rs.getString("MHC") + "");
				list.put("EHC", rs.getString("EHC") + "");
				list.put("TWC", rs.getString("TWC") + "");
				list.put("WWHC", rs.getString("WWHC") + "");
				list.put("SCHC", rs.getString("SCHC") + "");
				list.put("PHCWomen", rs.getString("PHC-Women") + "");
				list.put("PHCMen", rs.getString("PHC-Men") + "");
				list.put("WBC", rs.getString("WBC") + "");
				list.put("WEC", rs.getString("WEC") + "");
				list.put("WMC", rs.getString("WMC") + "");

				apptList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return apptList;
	}

	public ArrayList<HashMap<String, String>> getTotalEmployeeReport() {

		ArrayList<HashMap<String, String>> empList = new ArrayList<>();
		try {
			String s = "SELECT STATUS,COUNT(1) as 'Total' FROM employee_details GROUP BY STATUS UNION ALL SELECT 'Total',COUNT(1) FROM employee_details";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("STATUS", rs.getString("STATUS"));
				list.put("Total", rs.getString("Total"));

				empList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return empList;
	}
	public ArrayList<HashMap<String, String>> getAttendanceMonthlyManualReport() {

		ArrayList<HashMap<String, String>> attendanceList = new ArrayList<>();
		try {
			String s = "SELECT details.emp_name AS 'Emp Name',"
					+ "SUM(CASE WHEN att_mark IN ('A','L') THEN 1 ELSE 0 END) 'Absents',"
					+ "SUM(CASE WHEN att_mark = 'Lt' THEN 1 ELSE 0 END) AS 'Lates',"
					+ "SUM(CASE WHEN att_mark = 'HD' THEN 1 ELSE 0 END) AS 'Half Days',"
					+ "SUM(CASE WHEN att_mark IN ('P', 'WO') THEN 1 ELSE 0 END) 'PaidDays'"
					+ " FROM emp_daily emp LEFT JOIN employee_details details ON details.emp_id = emp.emp_id "
					+ " WHERE emp.work_date BETWEEN DATE_FORMAT(NOW() ,'%Y-%m-01') AND NOW() GROUP BY emp.emp_id ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("empName", rs.getString("Emp Name"));
				list.put("absents", rs.getString("Absents"));
				list.put("lates", rs.getString("Lates"));
				list.put("halfDays", rs.getString("Half Days"));
				list.put("paidDays", rs.getString("PaidDays"));

				attendanceList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return attendanceList;
	}

	@RequestMapping(value = "csrIndividualCallsReport")
	public ModelAndView getCSRIndividualCallsReport(ModelMap model) {

	
		
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		model.addAttribute("csrName", "");
		
		return new ModelAndView("redirect:csrIndividualCallsReports");
	}
	
	@RequestMapping(value = "csrIndividualCallsReports", method ={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView getCSRIndividualCallsReports(ModelMap model,String fromDate, String toDate, String csrName) {

		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> callsList = new ArrayList<>();
		try {
			String s = "SELECT * FROM CSR_Daywise_Calls WHERE call_date BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:59:59' AND csr LIKE '%"+csrName+"%'  ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("csrName", rs.getString("CSR"));
				list.put("callDate", rs.getString("call_date"));
				list.put("totalCalls", rs.getString("Total Calls"));
				list.put("presentations", rs.getString("Presentations"));
				callsList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("callsList", callsList);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("csrName", csrName);
		List<EmployeeDTO> csrList = adminService.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("csr", csrList);
		return new ModelAndView("Admin/customerCallRecords/csrIndividualCallsReport");
	}
		
	
	public void saveEmployeeLeaves(Integer empId, Date fromDate, Date toDate) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
	  //  Date firstDate = sdf.parse(fromDate);
	  //  Date secondDate = sdf.parse("07/04/2018");
	 
	    long diffInMillies = Math.abs(toDate.getTime() - fromDate.getTime());
	    long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
	
System.out.println(diff);

for(int i =0 ; i <= diff ; i++){
	SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
	Calendar c = Calendar.getInstance();
	c.setTime(fromDate); // Now use today date.
	c.add(Calendar.DATE, i); // Adding 5 days
	String leaveDate = sdf1.format(c.getTime());
	System.out.println(leaveDate);
	String query = "INSERT INTO emp_daily(emp_id, work_date, work_quantum, late_coming, att_mark)VALUES('"+empId+"', '"+leaveDate+"', 0, 0, 'L')";
	hrService.upDateQuery(query);
}
	
	}
	public HashMap<String, String> leavesCountByreportId(Integer userId) {
		HashMap<String, String> count = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) AS 'New Request' FROM leave_request req "
					+ " LEFT JOIN employee_roles roles ON roles.emp_id = req.emp_id " 
					+ "WHERE CURRENT_DATE BETWEEN roles.from_date AND roles.to_date "
					+ " AND (roles.report_to = (SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON "
					+ " emp.corporate_email = mast.user_mail WHERE user_id = '"+userId+"')) AND req.status = 'New'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				count.put("leaveCount", rs.getString("New Request"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return count;
	}

	public ArrayList<HashMap<String, String>> employeeLeavesList() {

		ArrayList<HashMap<String, String>> leaveList = new ArrayList<>();
		try {
			String s = "SELECT req.request_id,req.from_date,req.to_date,req.total_days,req.leave_type,req.status,req.description, emp.emp_name,emp1.emp_name AS 'report' FROM leave_request req"
					+ " LEFT JOIN employee_details emp ON emp.emp_id = req.emp_id LEFT JOIN employee_roles roles ON roles.emp_id = req.emp_id "
					+ " LEFT JOIN employee_details emp1 ON emp1.emp_id = report_to WHERE (CURRENT_DATE BETWEEN roles.from_date AND roles.to_date) "
					+ " AND (CURRENT_DATE BETWEEN req.from_date AND req.to_date)  ORDER BY req.from_date ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("requestId", rs.getString("request_id"));
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
				list.put("fromDate", sdf.format(rs.getDate("from_date")));
				list.put("toDate", sdf.format(rs.getDate("to_date")));
				list.put("totalDays", rs.getString("total_days"));
				list.put("leaveType", rs.getString("leave_type"));
				list.put("status", rs.getString("status"));
				list.put("description", rs.getString("description"));
				list.put("empName", rs.getString("emp_name"));
				list.put("reportName", rs.getString("report"));

				leaveList.add(list);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return leaveList;
	}
	
	public ArrayList<HashMap<String, String>> getVoucherList() {

		ArrayList<HashMap<String, String>> voucherList = new ArrayList<>();
		try {
			String s = "SELECT off.service_id,ser.service_name, COUNT(quantity) AS 'Voucher Count' FROM transaction_offers off "
					+ " LEFT JOIN services ser ON ser.service_id = off.service_id WHERE off.service_id NOT IN ('4','5','6','7','8','9','10','11','12') "
					+ " GROUP BY off.service_id UNION ALL  "
					+ "SELECT '','Total', COUNT(quantity)AS 'Voucher Count' FROM transaction_offers off "
					+ " LEFT JOIN services ser ON ser.service_id = off.service_id WHERE off.service_id NOT IN ('4','5','6','7','8','9','10','11','12')";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("serviceId", rs.getString("service_id"));
				list.put("serviceName", rs.getString("service_name"));
				list.put("voucherCount", rs.getString("Voucher Count"));
				voucherList.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return voucherList;
	}
	public ArrayList<HashMap<String, String>> getApplicationStatusReport() {

		ArrayList<HashMap<String, String>> applicationStatus = new ArrayList<>();
		try {
			String s = "SELECT STATUS, COUNT(1) AS 'Total' FROM application_stock GROUP BY STATUS "
					+ "UNION ALL SELECT 'TOTAL', COUNT(1) AS 'Total' FROM application_stock ";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("status", rs.getString("STATUS"));
				list.put("Total", rs.getString("Total"));
				applicationStatus.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return applicationStatus;
	}
	public ArrayList<HashMap<String, String>> getDispatchStatusReport() {

		ArrayList<HashMap<String, String>> applicationStatus = new ArrayList<>();
		try {
			String s = "SELECT IFNULL(delivery_status,'New') AS 'status' ,COUNT(1) AS 'Total' FROM dispatch_tracking GROUP BY delivery_status UNION ALL "
					+ " SELECT 'TOTAL' ,COUNT(1) AS 'Total' FROM dispatch_tracking ";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("status", rs.getString("status"));
				list.put("Total", rs.getString("Total"));
				applicationStatus.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return applicationStatus;
	}
	public HashMap<String, String> getApplicationTrackInTransaction(String applicationNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT transaction_id,customer_name,tx_status,product_name,approval_date FROM view_PayTrxCust WHERE application_No = '"+applicationNo+"' ";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				
				list.put("transactionId", rs.getString("transaction_id"));
				list.put("customerName", rs.getString("customer_name"));
				list.put("txStatus", rs.getString("tx_status"));
				list.put("productName", rs.getString("product_name"));
				list.put("approvalDate", rs.getString("approval_date"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public HashMap<String, String> getApplicationTrackInDispatch(String applicationNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT transaction_id,customer_name,tx_status,product_name,approval_date FROM view_PayTrxCust WHERE application_No = '"+applicationNo+"' ";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				
				list.put("transactionId", rs.getString("transaction_id"));
				list.put("customerName", rs.getString("customer_name"));
				list.put("txStatus", rs.getString("tx_status"));
				list.put("productName", rs.getString("product_name"));
				list.put("approvalDate", rs.getString("approval_date"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public HashMap<String, String> getRoleBaseAccessRoleId(String empId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT emp_name,business_unit,department,designation,section,role_id,emp_id FROM employment_history WHERE CURRENT_DATE BETWEEN from_date AND to_date AND emp_id ='"+empId+"'";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.put("empRoleId", rs.getString("role_id"));
				list.put("department", rs.getString("department"));
				list.put("designation", rs.getString("designation"));
				list.put("businessUnit", rs.getString("business_unit"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public HashMap<String, String> getTotalHealthAppointment() {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) AS 'Total' FROM health_appointment WHERE status_appointment NOT IN ('Missed','Cancelled','Rescheduled')";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.put("total", rs.getString("Total"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public HashMap<String, String> getNotification(String query) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(query);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.put("total", rs.getString("Total"));
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	@RequestMapping(value = "/inOutWard")
	public ModelAndView searchByitem1(ModelMap model) {
		ResultSet rs;
		
		PreparedStatement prepareStatement;
		Connection connection;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		List<String> categoryList= new ArrayList<String>();
		try {
			String s = "SELECT item_id AS 'Id',`item_category`AS category,item_name AS 'Iteam Name',unit_of_measure AS 'Unit Of Measure',current_stock AS 'Current Stock'"
					+ " FROM item_master ";
		
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			
			while (rs.next()) {
				
				HashMap<String, String>  item = new HashMap<String, String>();
				item.put("itemId", rs.getString("Id"));
				item.put("itemCategory", rs.getString("category"));
				item.put("itemName",rs.getString("Iteam Name") );
				item.put("unitOfMeasure",rs.getString("Unit Of Measure") );
				item.put("currentStock", rs.getString("Current Stock"));
				stkList.add(item);
				
			}
			String s2= "SELECT DISTINCT `item_category` FROM `item_master` WHERE `item_category`!='(NULL)'";
			prepareStatement= connection.prepareStatement(s2);
			ResultSet rs2 = prepareStatement.executeQuery();	
			
			while(rs2.next()){
			
				categoryList.add(rs2.getString("item_category"));
			
				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("stkList", stkList);
		model.addAttribute("categoryList", categoryList);

		VendorsTO vendors=new VendorsTO();
				
		return new ModelAndView("Admin/Inventory/inOutWard",
				"vendors", vendors);
	}

	@RequestMapping(value = "/inventoryReport" , method=RequestMethod.GET )
		public ModelAndView inventoryReport(ModelMap model) {	
		
		DateFormat dateFormat= new SimpleDateFormat("dd/MM/YYYY");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate",  dateFormat.format(date));
		model.addAttribute("entryPath","");
		
		
		return new ModelAndView("redirect:inventoryReports");	
	}
	
	
	@RequestMapping(value = "/inventoryReports", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView inventoryReport(ModelMap model,String fromDate,String toDate,String entryPath) {
		
		ArrayList<HashMap<String, String>> inOutWardList = new ArrayList<>();
		
		List<String> list = new ArrayList<String>();
		List<String> categoryList = new ArrayList<String>();
		
		String date = null;
		String date1=null;	
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date=formatter.format(sdf.parse(fromDate));
			date1=formatter.format(sdf.parse(toDate));
			} catch (Exception e) {
					e.printStackTrace();
			}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		
		try {
			String s= "SELECT DISTINCT inv.entry_type FROM inventory inv "
					+ " WHERE inv.entry_type!='(Auto)' ";
			
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement ;
			prepareStatement= connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();	
			
			while(rs.next()){
						list.add(rs.getString("entry_type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("entryItems",list);
		model.addAttribute("categoryList", categoryList);
		model.addAttribute("entryPath",entryPath);
		
			String s2 = "SELECT item.item_id,item.item_category, item.item_name,inve.quantity,ven.vendor_company, item.unit_of_measure,"
					+ " inve.entry_type,emp.emp_name,inve.action_date  FROM inventory inve LEFT JOIN item_master item ON item.item_id = inve.item_id "
					+ " LEFT JOIN vendors ven ON ven.vendor_id= inve.vendor_id   LEFT JOIN  employee_details emp ON emp.emp_id = inve.issued_to	"
					+ " WHERE inve.action_date BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:59:59' AND inve.entry_type LIKE '%"+entryPath+"%'";
		//	System.out.println(s2);
			try {
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s2);
			ResultSet rs = prepareStatement.executeQuery();
			
			while (rs.next()) {
				HashMap<String, String>  item = new HashMap<String, String>();
				item.put("itemId", rs.getString("item_id"));
				item.put("itemCategory", rs.getString("item_category"));
				item.put("itemName",rs.getString("item_name") );
				item.put("unitOfMeasure",rs.getString("unit_of_measure") );
				item.put("currentStock", rs.getString("quantity"));
				item.put("actionDate", rs.getString("action_date"));
				item.put("entryType", rs.getString("entry_type"));
				item.put("vendorCompany", rs.getString("vendor_company"));
				item.put("empName", rs.getString("emp_name"));
				inOutWardList.add(item);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("stkList", inOutWardList);
		return new ModelAndView("Admin/Inventory/inventoryReport");	
	}
	
	@RequestMapping(value = "itemReportOut")
	public ModelAndView itemReportOut(ModelMap model,@RequestParam String itemId,@RequestParam String entryType,@RequestParam String dateFrom,@RequestParam String dateTo) {
		List<Map<String,String>> list= new ArrayList<Map<String,String>>();
		
		try {			
			String s = "SELECT item.`item_id`,item.`item_name` AS 'ItemName',inve.`action_date` AS 'IssuedON',emp.`emp_name` AS 'IssuedTO' ,item.`description`, inve.`description` AS 'NOTES', uma.`user_name`AS 'IssuedBY',ven.`vendor_company`"
				+ " FROM `inventory` inve"
				+ " LEFT JOIN `item_master` item ON item.`item_id`= inve.`item_id` "
				+ " LEFT JOIN `vendors` ven ON ven.`vendor_id`= inve.`vendor_id`"
				+ " LEFT JOIN employee_details emp ON emp.`emp_id`=inve.`issued_to`"
				+ " LEFT JOIN `usermaster` uma ON uma.`user_id`=inve.`action_by` "
				+ " WHERE inve.`entry_type`='"
				+  entryType
				+ "' AND item.`item_id`='"
				+ itemId 
				+ "' AND inve.`action_date` BETWEEN '"				
				+ dateFrom
				+ "' AND '"
				+ dateTo
				+ "' ORDER BY inve.`action_date` DESC "; 
		
	
	
	SimpleDateFormat formatter  = new SimpleDateFormat("dd-MM-YYYY");
	
	
		Connection connection = sessionFactory.getCurrentSession()
				.connection();
		PreparedStatement prepareStatement = connection.prepareStatement(s);
		ResultSet rs = prepareStatement.executeQuery();
		
		 
		while(rs.next()){
			
			Map<String,String> map = new HashMap<String, String>();
			map.put("itemName", rs.getString("ItemName"));
			String dateStr = null;
			
			try {				
			
				dateStr = formatter.format(rs.getDate("IssuedON"));
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			
			map.put("issuedOn", dateStr);
			map.put("issuedTo",rs.getString("IssuedTO"));
			map.put("description", rs.getString("description"));
			map.put("notes", rs.getString("NOTES"));
			map.put("issuedBy", rs.getString("IssuedBY"));
			map.put("vendorCompany", rs.getString("vendor_company"));
			list.add(map);
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("itemReport", list);
		return new ModelAndView("Admin/Inventory/itemReportOut");
	}
	
	public List<VendorsTO> getAllVendors(Integer itemId) {
		List<VendorsTO> vendorList = new ArrayList<>();
		try {
			String s = "SELECT DISTINCT ven.vendor_name,inv.item_id,inv.vendor_id,ven.vendor_company FROM inventory inv"
					+ " LEFT JOIN vendors ven ON ven.vendor_id = inv.vendor_id WHERE inv.item_id ='"+itemId+"'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				VendorsTO vendor = new VendorsTO();
				vendor.setVendorId(rs.getInt("vendor_id"));
				vendor.setVendorName(rs.getString("vendor_name"));
				vendor.setVendorCompany(rs.getString("vendor_company"));
				vendorList.add(vendor);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vendorList;

	}
	public List<VendorsTO> getAllVendors() {
		List<VendorsTO> vendorList = new ArrayList<>();
		try {
			String s = "SELECT * FROM vendors ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				VendorsTO vendor = new VendorsTO();
				vendor.setVendorId(rs.getInt("vendor_id"));
				vendor.setVendorName(rs.getString("vendor_name"));
				vendor.setVendorCompany(rs.getString("vendor_company"));
				vendorList.add(vendor);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vendorList;

	}

	public void updateItemMaster(Integer iteamId, Float stock) {
		try {
			String query = "UPDATE item_master SET current_stock ='" + stock
					+ "' WHERE item_id='" + iteamId + "' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<HashMap<String, String>> getInventoryOutWardReport() {

		ArrayList<HashMap<String, String>> outWardList = new ArrayList<>();
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DATE, 1);
		Date todate1 = cal.getTime();
		//model.addAttribute("fromDate", dateFormat.format(todate1));
		//model.addAttribute("toDate", todate);
		
		try {
			String s = "SELECT item.item_id,inv.action_date,item.item_name,item.unit_of_measure,inv.quantity AS 'qty'FROM inventory inv"
					+ " LEFT JOIN item_master item ON item.item_id = inv.item_id "
					+ " WHERE inv.entry_type ='OutWard' AND inv.action_date BETWEEN '"+dateFormat.format(todate1)+" 00:00:00' AND '"+todate+" 23:59:59'"
					+ " GROUP BY inv.`price`,inv.`quantity` UNION ALL "
					+ " SELECT '','','','Total',SUM(inv.quantity) FROM inventory inv LEFT JOIN item_master item ON item.item_id = inv.item_id "
					+ " WHERE inv.entry_type ='OutWard' AND inv.action_date BETWEEN '"+dateFormat.format(todate1)+" 00:00:00' AND '"+todate+" 23:59:59'";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("actionDate", rs.getString("action_date"));
				list.put("itemId", rs.getString("item_id"));
				list.put("itemName", rs.getString("item_name"));
				list.put("unitMeasure", rs.getString("unit_of_measure"));
				list.put("quantity", rs.getString("qty"));
				//list.put("quantity", rs.getString("cost"));
				outWardList.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return outWardList;
	}
	public ArrayList<HashMap<String, String>> getInventoryInWardReport() {

		ArrayList<HashMap<String, String>> inWardList = new ArrayList<>();
		DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-dd");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DATE, 1);
		Date todate1 = cal.getTime();
		try {
			String s = "SELECT item.item_id,inv.action_date,item.item_name,item.unit_of_measure,inv.quantity AS 'qty',inv.price AS 'cost' FROM inventory inv"
					+ " LEFT JOIN item_master item ON item.item_id = inv.item_id "
					+ " WHERE inv.entry_type ='InWard' AND inv.action_date BETWEEN '"+dateFormat.format(todate1)+" 00:00:00' AND '"+todate+" 23:59:59' "
					+ " GROUP BY inv.`price`,inv.`quantity` UNION ALL "
					+ " SELECT '','','','Total',SUM(inv.quantity),SUM(inv.price) FROM inventory inv LEFT JOIN item_master item ON item.item_id = inv.item_id "
					+ "WHERE inv.entry_type ='InWard' AND inv.action_date BETWEEN '"+dateFormat.format(todate1)+" 00:00:00' AND '"+todate+" 23:59:59' ";
		
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("actionDate", rs.getString("action_date"));
				list.put("itemId", rs.getString("item_id"));
				list.put("itemName", rs.getString("item_name"));
				list.put("unitMeasure", rs.getString("unit_of_measure"));
				list.put("quantity", rs.getString("qty"));
				list.put("cost", rs.getString("cost"));
				inWardList.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return inWardList;
	}
	/* END OF INVENTORY REPORT*/
	
	
	
	
}