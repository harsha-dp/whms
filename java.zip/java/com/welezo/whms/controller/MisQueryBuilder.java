package com.welezo.whms.controller;

import java.util.ArrayList;

public class MisQueryBuilder {

	public String x_axis, y_axis;
	// public float aggr;
	public String valueType = "Count";
	public String columnDefn = "";
	public String tableSource = "view_PayTrxCust";
	public String dataColumn = "collected_date";
	public String whereClause;
	public ArrayList<String> yCols = new ArrayList<String>();

	public MisQueryBuilder(String x_axis, String y_axis, String dataColumn,String valueType, String tableSource, String whereClause) {
		super();
		this.x_axis = x_axis;
		this.y_axis = y_axis;
		this.valueType = valueType;
		this.tableSource = tableSource;
		this.dataColumn = dataColumn;
		this.whereClause = whereClause;
	}

	private String generateColumns() {
		String cols = "";
		if (y_axis.equalsIgnoreCase("Month")) {
			if (valueType.equalsIgnoreCase("count")) {
				cols = generateColumnDefn("SUM", "CONCAT(LEFT(MONTHNAME("
						+ dataColumn + "),3), ' ' , YEAR(" + dataColumn + "))",
						"1", "")
						+ "COUNT(1) AS 'Total'";
			} else if (valueType.equalsIgnoreCase("Revenue")) {
				cols = generateColumnDefn("SUM", "CONCAT(LEFT(MONTHNAME("
						+ dataColumn + "),3), ' ' , YEAR(" + dataColumn + "))",
						"amount", "")
						+ "SUM(amount) AS 'Revenue'," + "COUNT(1) AS 'Sales'";
			} else if (valueType.equalsIgnoreCase("TicketSize")) {
				cols = generateColumnDefn("AVG", "CONCAT(LEFT(MONTHNAME("
						+ dataColumn + "),3), ' ' , YEAR(" + dataColumn + "))",
						"amount", "")
						+ "ROUND(AVG(amount),2) AS 'Ticket Size',"
						+ "SUM(amount) AS 'Revenue'," + "COUNT(1) AS 'Sales'";
			} else if (valueType.equalsIgnoreCase("Prospects")) {
				cols = generateColumnDefn("SUM", "CONCAT(LEFT(MONTHNAME("
						+ dataColumn + "),3), ' ' , YEAR(" + dataColumn + "))",
						"1", "")
						+ "COUNT(1) AS 'Prospects'";
			} else if (valueType.equalsIgnoreCase("Appointments")) {
				cols = generateColumnDefn("SUM", "CONCAT(LEFT(MONTHNAME("
						+ dataColumn + "),3), ' ' , YEAR(" + dataColumn + "))",
						"1", "")
						+ "COUNT(1) AS 'Appointments',"
						+ "COUNT(DISTINCT aid) AS 'Prospects'";
			} else if (valueType.equalsIgnoreCase("Meetings")) {
				cols = generateColumnDefn("SUM", "CONCAT(LEFT(MONTHNAME("
						+ dataColumn + "),3), ' ' , YEAR(" + dataColumn + "))",
						"1", " AND meeting_status='Met'")
						+ "SUM(CASE WHEN meeting_status='Met' THEN 1 ELSE 0 END) AS 'Meetings',"
						+ "COUNT(1) AS 'Appointments',"
						+ "COUNT(DISTINCT aid) AS 'Prospects'";
			}
		} else if (y_axis.equalsIgnoreCase("ApptStatus")) {
			// cols = generateColumnDefn("SUM","status", "1" , "");
			// System.out.println(cols);
			cols = generateColumnDefn("SUM", "status", "1", "")
					+ "SUM(CASE WHEN meeting_status = 'Met'  THEN 1 ELSE 0 END) AS 'Meetings',"
					+ "COUNT(1) AS 'Appointments',"
					+ "COUNT(DISTINCT aid) AS 'Prospects'";
		}

		return cols;
	}

	private String generateColumnDefn(String aggregateType, String phrase,
			String thenPhrase, String internalWhere) {
		StringBuilder sb = new StringBuilder("");
		for (String col : this.yCols) {
			String casePhrase = "CASE WHEN " + phrase + " = '" + col + "' "
					+ internalWhere + " THEN " + thenPhrase + " ELSE NULL END";
			if (thenPhrase.equals("1"))
				sb.append("IFNULL(" + aggregateType + "(" + casePhrase
						+ "),'NA') AS '" + col + "',");
			else
				sb.append("IFNULL(ROUND(" + aggregateType + "(" + casePhrase
						+ "),2),'NA') AS '" + col + "',");
		}
		// System.out.println(sb.toString());
		return sb.toString();
	}

	public String generateQuery() {
		String qb = "";

		if (y_axis.equalsIgnoreCase("Month")) {
			qb = "Select DISTINCT CONCAT(LEFT(MONTHNAME(" + dataColumn
					+ "),3), ' ' , YEAR(" + dataColumn + "))  from "
					+ tableSource + " WHERE " + whereClause;
		} else if (y_axis.equalsIgnoreCase("ApptStatus")) {
			qb = "Select DISTINCT " + dataColumn + "  from " + tableSource
					+ " WHERE " + whereClause;
		}
		JDBCConnection jdbc = new JDBCConnection();
		this.yCols = jdbc.getDistinctValues(qb);

		// System.out.println("Successful " + this.yCols);
		this.columnDefn = generateColumns();
		String qry = "";

		qry = "SELECT " + x_axis + ", " + columnDefn + " from " + tableSource
				+ " WHERE " + whereClause + " GROUP BY 1" + " UNION "
				+ "SELECT 'Z-GRAND TOTAL', " + columnDefn + " from "
				+ tableSource + " WHERE " + whereClause;
		System.out.println(qry);
		return qry;
	}

	public String getX_axis() {
		return x_axis;
	}

	public void setX_axis(String x_axis) {
		this.x_axis = x_axis;
	}

	public String getY_axis() {
		return y_axis;
	}

	public void setY_axis(String y_axis) {
		this.y_axis = y_axis;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public String getTableSource() {
		return tableSource;
	}

	public void setTableSource(String tableSource) {
		this.tableSource = tableSource;
	}

	public String getWhereClause() {
		return whereClause;
	}

	public void setWhereClause(String whereClause) {
		this.whereClause = whereClause;
	}

}
