package com.welezo.whms.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.ReportService;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.ProjectsTO;
import com.welezo.whms.to.TeamsTO;

@Controller
public class StaticTablesController {

	HttpSession session = null;

	@Autowired
	ReportController report;

	@Autowired
	ReportService reportService;

	@Autowired
	AdminService adminService;
	@Autowired
	HRService hrService;

	@RequestMapping(value = "/manual_dashboard")
	public ModelAndView viewAllmanual(ModelMap model) {
		return new ModelAndView("Admin/PSF/staticTableDashboard");
	}

	@RequestMapping(value = "/viewProductServiceTeam")
	public ModelAndView viewproducts(ModelMap model) {
		List<HashMap<String, String>> allproducts = adminService.getAllProducts();
		model.addAttribute("allproducts", allproducts);

		List<HashMap<String, String>> allservice = adminService.getAllservice();
		model.addAttribute("allservice", allservice);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("channelss", allChannels);

		List<TeamsTO> allteams = adminService.getAllTeamName();
		model.addAttribute("allteams", allteams);
		ArrayList<HashMap<String, String>> allCategory = report
				.getAllCategory();
		model.addAttribute("category", allCategory);
		return new ModelAndView("Admin/PSF/allStatictablesViews");
	}

	@RequestMapping(value = "/saveProducts", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveproducts(ModelMap Model,	@RequestParam String productName, String price, String startDate,
			String validTill, String prodidCcavenue, String description,String offerPrice) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		String date = null;
		String date1 = null;
		try {
			date = formatter.format(sdf.parse(startDate));
			date1 = formatter.format(sdf.parse(validTill));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String s = "INSERT INTO welezohe_whms.product_master(product_name,product_price,start_date,valid_till,prodid_ccavenue,product_description,today_offers,is_active) "
				+ " VALUES('"
				+ productName
				+ "','"
				+ price
				+ "','"
				+ date
				+ "','"
				+ date1
				+ "','"
				+ prodidCcavenue
				+ "','"
				+ description
				+ "','" + offerPrice + "',1)";
		hrService.upDateQuery(s);
		return new ModelAndView("redirect:viewProductServiceTeam");
	}

	@RequestMapping(value = "/saveService", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveproducts(ModelMap Model,
			@RequestParam String category, String serviceName,
			String description) {

		String s = "INSERT INTO welezohe_whms.services(category,service_name,service_description,isActive) VALUES ('"
				+ category + "','" + serviceName + "','" + description + "',1)";
		hrService.upDateQuery(s);
		return new ModelAndView("redirect:viewProductServiceTeam");
	}
	@RequestMapping(value = "/addServices", method = RequestMethod.POST)
	public @ResponseBody ModelAndView addServicesIntoPackagee(ModelMap model,@RequestParam String productId, String[] serviceId,Integer[] quantity) {

		System.out.println("Length of the array " + serviceId.length +" quantity"+quantity.length);
		for(int i =0; i < serviceId.length ; i++){
			if(quantity[i] != null){
		String s = "INSERT INTO product_offers(product_id,service_id,quantity) VALUES ('"+ productId + "','" + serviceId[i] + "','" + quantity[i] + "')";
		//System.out.println(s);
		hrService.upDateQuery(s);
			}
		}
		model.addAttribute("productId", productId);
		return new ModelAndView("redirect:editproducts");
	}


	@RequestMapping(value = "/saveTeams", method = RequestMethod.POST)
	public ModelAndView saveTeams(ModelMap model,
			@RequestParam String teamName, String leaderName) {

		String s = "INSERT INTO welezohe_whms.teams(team_name,leader_name) VALUES('"
				+ teamName + "','" + leaderName + "')";
		hrService.upDateQuery(s);
		return new ModelAndView("redirect:viewProductServiceTeam");
	}

	@RequestMapping(value = "/saveChannels", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveChannels(ModelMap Model,
			@RequestParam String channelsName) {

		String s = "INSERT INTO welezohe_whms.channels(channels_name) VALUES('"
				+ channelsName + "')";
		hrService.upDateQuery(s);
		return new ModelAndView("redirect:viewProductServiceTeam");
	}

	@RequestMapping(value = "/editproducts")
	public ModelAndView editproducts(ModelMap model,
			@RequestParam Integer productId) {
		ProductMasterTO allproducts = adminService.getproductById(productId);
		model.addAttribute("allproducts", allproducts);
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		model.addAttribute("startDate",	dateFormat.format(allproducts.getStartDate()));
		model.addAttribute("validTill",	dateFormat.format(allproducts.getValidTill()));
		
		ArrayList<HashMap<String,String>> servicesBasedOnProductId = adminService.getServicesBasedOnProductId(productId);
		model.addAttribute("servicesBasedOnProductId", servicesBasedOnProductId);
		ArrayList<HashMap<String,String>> servicesNotInProducts = adminService.getServicesNotInProducts(productId);
		model.addAttribute("servicesNotInProducts", servicesNotInProducts);

		return new ModelAndView("Admin/PSF/editProducts");
	}

	@RequestMapping(value = "/editsaveProducts")
	public ModelAndView postEditExtension(ModelMap model,
			@RequestParam String productName,String productPrice,String startDate,String validTill,String prodidCcavenue,Integer isActive, Integer productId) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(startDate));
			date1 = formatter.format(sdf.parse(validTill));

		} catch (Exception e) {
			e.printStackTrace();
		}
		String s = "UPDATE product_master SET product_name='"
				+ productName + "',product_price='"
				+ productPrice + "',start_date='" + date
				+ "',valid_till='" + date1 + "',prodid_ccavenue='"
				+ prodidCcavenue + "',is_active='"
				+isActive + "'  "
				+ "	WHERE product_id = '" + productId+ "' ";
		System.out.println(s);
		hrService.upDateQuery(s);
		
		model.addAttribute("productId", productId);
		return new ModelAndView("redirect:editproducts");
	}

	@RequestMapping(value = "editChannels")
	public ModelAndView editchannels(ModelMap model,
			@RequestParam Integer channelId) {

		ChannelsTO channel = reportService.editchannelsById(channelId);
		model.addAttribute("channel", channel);
		return new ModelAndView("Admin/PSF/editChannels", "ChanelsTO",
				new ChannelsTO());
	}

	@RequestMapping(value = "/saveEditChannels", method = RequestMethod.POST)
	public @ResponseBody ModelAndView saveeditchannels(ModelMap model,
			@ModelAttribute ChannelsTO channelsDTO) {
		channelsDTO.setChannelId(channelsDTO.getChannelId());
		System.out.println(channelsDTO.getChannelsName());
		adminService.saveOrUpdate("channel");
		return new ModelAndView("redirect:channels");
	}

	@RequestMapping(value = "viewProjectById")
	public ModelAndView addnewprojects(ModelMap model) {
		ProjectsTO project = new ProjectsTO();
		List<ProjectsTO> allproject = reportService.getallprojects();
		model.addAttribute("allproject", allproject);
		return new ModelAndView("Admin/PSF/viewProjectById", "projects",
				project);
	}

	@RequestMapping(value = "/saveprojects", method = RequestMethod.POST)
	public ModelAndView saveprojects(ModelMap model,
			@ModelAttribute ProjectsTO projectsTO) {
		adminService.saveAdmin(projectsTO);
		return new ModelAndView("redirect:projects");
	}

	@RequestMapping(value = "/editProjects")
	public ModelAndView editprojects(@RequestParam Integer projectId,
			ModelMap model) {
		ProjectsTO projectTO = new ProjectsTO();
		ProjectsTO allprojects = reportService.getallprojectsById(projectId);
		model.addAttribute("allprojects", allprojects);
		return new ModelAndView("Admin/PSF/editProjects", "projectTO",
				projectTO);
	}

	@RequestMapping(value = "/editSaveprojects")
	public @ResponseBody ModelAndView upadate(ModelMap model,
			@ModelAttribute ProjectsTO projectsDTO) {

		projectsDTO.setProjectId(projectsDTO.getProjectId());
		adminService.saveOrUpdate(projectsDTO);
		return new ModelAndView("redirect:editProjects");

	}

	@RequestMapping(value = "/editTeams")
	public ModelAndView editteams(@RequestParam Integer teamId, ModelMap model) {
		TeamsTO allteam = reportService.getteamsById(teamId);
		model.addAttribute("allteam", allteam);
		return new ModelAndView("Admin/PSF/editTeams", "TeamsTO", new TeamsTO());
	}

	@RequestMapping(value = "/saveeditteams")
	public @ResponseBody ModelAndView save(ModelMap model, TeamsTO teamsTO) {
		teamsTO.setTeamId(teamsTO.getTeamId());
		teamsTO.setLeaderName(teamsTO.getLeaderName());
		teamsTO.setTeamName(teamsTO.getTeamName());
		return new ModelAndView("redirect:teams");
	}
	
	@RequestMapping(value = "/seoOnpage")
	public ModelAndView seoOnpage(ModelMap model)
	{
		ArrayList<HashMap<String, String>> onLineUserList = adminService.getSeoOnPageList("", "");
		model.addAttribute("onLineUserList", onLineUserList);
		return new ModelAndView("Admin/website/seoOnpage");
	}
	@RequestMapping(value = "/saveBannedIp")
	public ModelAndView saveBannedIp(ModelMap model,String ipAddress,String reason,Integer bannedBy)
	{
		String query ="INSERT INTO banned_ip(ip_address,reason,banned_by,date_time)VALUES('"+ipAddress+"','"+reason+"','"+bannedBy+"',CURRENT_TIMESTAMP)";
		hrService.upDateQuery(query);
		
		return new ModelAndView("redirect:bannedIpList");
	}
	
	@RequestMapping(value = "/websiteDashBoard")
	public ModelAndView websiteDashBoard(ModelMap model)
	{
		return new ModelAndView("Admin/website/websiteDashboard");
	}
	@RequestMapping(value = "/bannedIpList")
	public ModelAndView bannedIpAddress(ModelMap model)
	{
		ArrayList<HashMap<String, String>> bannedList = adminService.getBannedIpList("", "");
		model.addAttribute("bannedList", bannedList);
		return new ModelAndView("Admin/website/bannedIpAddressView");
	}
	@RequestMapping(value = "onLineUser")
	public ModelAndView onLineUserView(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		return new ModelAndView("redirect:onLineUser1x");
	}
	
	@RequestMapping(value = "/onLineUser1x", method = { RequestMethod.GET,RequestMethod.POST })
	public ModelAndView onLineUserData(ModelMap model,@RequestParam String fromDate, String toDate)
	{
		ArrayList<HashMap<String,String>> onlineUserList = adminService.getOnlineUserList(fromDate, toDate);
		model.addAttribute("onlineUserList", onlineUserList);
		
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		
		return new ModelAndView("Admin/website/onLineUser");
	}
	
	
	@RequestMapping(value = "/saveSeoOnPage")
	public @ResponseBody ModelAndView saveSeoOnPage(ModelMap model,@RequestParam String moduleName,String title,String description,
			String keyword,String robots,String imgUrl,String slug,Integer updatedBy) {
		String query ="INSERT  INTO seo_on_page(module_name,title,description,keyword,robots,last_updated,updated_by,img_url,slug) "
				+ " VALUES ('"+moduleName+"','"+title+"','"+description+"', '"+keyword+"', '"+robots+"' "
				+ " ,CURRENT_TIMESTAMP,'"+updatedBy+"','"+imgUrl+"','"+slug+"')";
		hrService.upDateQuery(query);
		
		return new ModelAndView("redirect:seoOnpage");
	}
	
	@RequestMapping(value = "/editSeoOnPage")
	public ModelAndView editSeoOnPage(ModelMap model,@RequestParam Integer id)
	{
	HashMap<String,String> seoOnPageById = adminService.getSeoOnPageById(id);
	model.addAttribute("seoOnPageById", seoOnPageById);
		return new ModelAndView("Admin/website/editSeoOnPage");
	}
	@RequestMapping(value = "/postEditSeoOnPage")
	public ModelAndView postEditSaveSeoOnPage(ModelMap model,@RequestParam Integer id,@RequestParam String moduleName,String title,String description,
			String keyword,String robots,String imgUrl,String slug,Integer updatedBy)
	{
	
		String query = "UPDATE seo_on_page SET module_name = '"+moduleName+"',title ='"+title+"',description ='"+description+"',keyword = '"+keyword+"',"
				+ " robots = '"+robots+"',img_url ='"+imgUrl+"',slug = '"+slug+"'   WHERE id = '"+id+"'";
		hrService.upDateQuery(query);
				
		return new ModelAndView("redirect:seoOnpage");
	}
	
	@RequestMapping(value = "/viewSubIpAddresDetails")
	public ModelAndView viewSubIpAddresDetails(ModelMap model,@RequestParam String ipAddress)
	{
		ArrayList<HashMap<String, String>> ipAddressThruUserDetails = adminService.getIpAddressThruUserDetails(ipAddress);
		model.addAttribute("onlineUserSubDetails", ipAddressThruUserDetails);
		
		model.addAttribute("ipAddress", ipAddress);
		
		return new ModelAndView("Admin/website/viewSubIpAddressDetails");
	}
}
