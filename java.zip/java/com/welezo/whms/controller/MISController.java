package com.welezo.whms.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dto.InteractionRegisterDTO;
import com.welezo.whms.dto.ResultsetColumnsDeatils;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;

@Controller
public class MISController extends CustomHibenateDaoSupport {

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	AdminService adminService;
	@Autowired
	HRService hrService;

	@Autowired
	ReportController report;

	@RequestMapping(value = "misWelcome")
	public ModelAndView welecomeReport(ModelMap model, HttpSession httpSession) {
		ArrayList<HashMap<String, String>> reportTitle = getReportTitle();
		model.addAttribute("reportTitle", reportTitle);
		httpSession.setAttribute("reportTitle", reportTitle);

		InteractionRegisterDTO customerCount = report.getCustomerCount();
		model.addAttribute("customerCount", customerCount);

		/*InteractionRegisterDTO transactionCount = report.getTransactionCount();
		model.addAttribute("transactionCount", transactionCount);*/

		HashMap<String, String> totalHealthAppt = report.getTotalHealthAppt();
		model.addAttribute("totalHealthAppt", totalHealthAppt);

		InteractionRegisterDTO hospitalCount = report.getHospitalCount();
		model.addAttribute("hospitalCount", hospitalCount);

		ArrayList<HashMap<String, String>> employeeAbsenties = report
				.getEmployeeAbsenties();
		model.addAttribute("employeeAbsenties", employeeAbsenties);

		ArrayList<HashMap<String, String>> csrSummary = report.getCSRSummary();
		model.addAttribute("csrSummary", csrSummary);

		/*
		 * HashMap<String,String> employeeIdFromUserId =
		 * hrService.getEmployeeIdFromUserId(19); EmployeeImagesTO employeeImage
		 * =
		 * report.getEmployeeImage(Integer.parseInt(employeeIdFromUserId.get("empId"
		 * ))); String encode =
		 * Base64.encodeBase64String(employeeImage.getEmpImg());
		 * model.addAttribute("empImge", encode);
		 * httpSession.setAttribute("empImge", encode);
		 */

		return new ModelAndView("MIS/report/notification");
	}

	@RequestMapping(value = "customizedMIS")
	public ModelAndView customizedReport(ModelMap model,
			@RequestParam Integer reportId) {

		HashMap<String, String> reportQueryByTitle = getReportQueryByTitle(reportId);
		model.addAttribute("reportQueryByTitle", reportQueryByTitle);

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, -2);
		cal.set(Calendar.DATE, 1);
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		model.addAttribute("x_axis", "csr_name");
		model.addAttribute("y_axis", "month");
		// model.addAttribute("value", "Revenue");
		model.addAttribute("reportId", reportId);
		return new ModelAndView("redirect:misCustomReport");
	}

	@RequestMapping(value = "/misReportCount", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView countsReport(ModelMap model,
			@RequestParam Integer reportId) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		HashMap<String, String> reportQueryByTitle = getReportQueryByTitle(reportId);
		model.addAttribute("reportQueryByTitle", reportQueryByTitle);
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = reportQueryByTitle.get("reportQuery");
			// System.out.println(s);
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();

			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);

			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return new ModelAndView("MIS/report/index");
	}

	@RequestMapping(value = "/misCustomReport", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView report(ModelMap model, @RequestParam String fromDate,
			@RequestParam String toDate, String x_axis, String y_axis,
			Integer reportId) {
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");

		HashMap<String, String> reportQueryByTitle = getReportQueryByTitle(reportId);

		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {

			MisQueryBuilder qb = null;
			String dateRange = " BETWEEN '" + date + "' AND '" + date1 + "' ";

			if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"Sales Count")) {
				// System.out.println("-- Sales Count");
				qb = new MisQueryBuilder(x_axis, y_axis, "collected_date",
						"count", "view_PayTrxCust", " collected_date "
								+ dateRange
								+ " AND `status` IN ('Payment Approved','New')");
			} else if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"Revenue")) {
				// System.out.println("-- Revenue");
				qb = new MisQueryBuilder(x_axis, y_axis, "collected_date",
						"Revenue", "view_PayTrxCust", " collected_date "
								+ dateRange
								+ " AND `status` IN ('Payment Approved','New')");
			} else if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"TicketSize")) {
				System.out.println("-- TicketSize");
				qb = new MisQueryBuilder(x_axis, "month", "collected_date",
						"TicketSize", "view_PayTrxCust", " collected_date "
								+ dateRange
								+ " AND status IN ('Payment Approved','New')");
			} else if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"Prospects")) {
				// System.out.println("-- Prospects");
				qb = new MisQueryBuilder(x_axis, y_axis, "date_appointment",
						"Prospects", "presales_appts",
						"  appointment_type = 'Fresh' AND date_appointment "
								+ dateRange);
			} else if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"Appointments")) {
				// System.out.println("-- Appointments");
				qb = new MisQueryBuilder(x_axis, y_axis, "date_appointment",
						"Appointments", "presales_appts", "  date_appointment "
								+ dateRange);
			} else if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"Meetings")) {
				// System.out.println("-- Meetings");
				qb = new MisQueryBuilder(x_axis, y_axis, "date_appointment",
						"Meetings", "presales_appts", "  date_appointment "
								+ dateRange);
			} else if (reportQueryByTitle.get("reportType").equalsIgnoreCase(
					"Appt Status-wise")) {
				// System.out.println("-- Appt Status-wise");
				qb = new MisQueryBuilder(x_axis, y_axis, "status", "count",
						"presales_appts", "  date_appointment " + dateRange);
			}
			String generateQuery = qb.generateQuery();
			String s = generateQuery;
			// System.out.println(s);
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);
			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("x_axis", x_axis);
		model.addAttribute("y_axis", y_axis);
		// model.addAttribute("value", value);

		model.addAttribute("reportQueryByTitle", reportQueryByTitle);
		return new ModelAndView("MIS/report/customizedReport");
	}

	public ArrayList<HashMap<String, String>> getReportTitle() {
		ArrayList<HashMap<String, String>> reportList = new ArrayList<>();
		try {
			String s = "SELECT * FROM report_table WHERE isActive IS TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("reportId", rs.getString("report_id"));
				list.put("reportTitle", rs.getString("report_title"));
				list.put("reportLink", rs.getString("report_link"));
				reportList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return reportList;
	}

	public HashMap<String, String> getReportQueryByTitle(Integer reportId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM report_table WHERE report_id ='"
					+ reportId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("reportId", rs.getString("report_id"));
				list.put("reportTitle", rs.getString("report_title"));
				list.put("reportLink", rs.getString("report_link"));
				list.put("reportQuery", rs.getString("report_query"));
				list.put("x_axis", rs.getString("x_axis"));
				list.put("y_axis", rs.getString("y_axis"));
				list.put("value", rs.getString("value"));
				list.put("sourceDetails", rs.getString("source_details"));
				list.put("reportType", rs.getString("report_type"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<String> getDistinctValuesFromMIS(String query) {
		return adminService.getDistinctValues(query);
	}

	@RequestMapping(value = "/sales&marketing")
	public ModelAndView attendence(ModelMap model) {

		return new ModelAndView("MIS/report/salesAndMarketing");
	}

}
