package com.welezo.whms.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.MailData;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.CallRecordsService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.ExtensionDetailsTO;
import com.welezo.whms.to.RoleMasterTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Controller
public class CallRecordsController {

	@Autowired
	AdminService adminService;
	@Autowired
	CallRecordsService callrecordservice;
	@Autowired
	HRService hrService;
	@Autowired
	ReportController report;
	
	@Autowired
	private JavaMailSender mailSender;

	@RequestMapping(value = "/callsDashboards")
	public ModelAndView callsDashboard(ModelMap model) {
		
		CollectionTO callsCount = report.callsCount();
		model.addAttribute("callsCount", callsCount);
		

		return new ModelAndView("Admin/dashboards/callsDashboards");
	}

	@RequestMapping(value = "/viewVistorBook")
	public ModelAndView viewVistorBook(ModelMap model,@RequestParam String fromDate,String toDate, String purpose) {
		
		//IncomingCallRecordsTO callRecordsTO = new IncomingCallRecordsTO();

		List<HashMap<String, String>> allVisitorList = callrecordservice.getAllVisitorList(fromDate, toDate, purpose);
		model.addAttribute("visitorList", allVisitorList);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("purpose", purpose);
		
		return new ModelAndView("Admin/customerCallRecords/viewcalls");
	}
	
	@RequestMapping(value = "/viewcalls")
	public ModelAndView viewcalls(ModelMap model) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy",Locale.ENGLISH);
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		model.addAttribute("purpose", "");

		return new ModelAndView("redirect:viewVistorBook");
	}

	@RequestMapping(value = "/saveVisitorData")
	public ModelAndView saveCallrecords(ModelMap model,@RequestParam String visitorName,String visitorNumber,String source,
			String purpose,String visitDate,String inTime,String outTime,String remarks,Integer createdBy) {

		String date = null;
		try {
			Date visitDate1 = new SimpleDateFormat("dd/MM/yyyy").parse(visitDate);
			date = new SimpleDateFormat("yyyy-MM-dd").format(visitDate1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String query ="INSERT INTO visitor_book (visitor_number,visitor_name,source,purpose,STATUS,visit_date,in_time,out_time,remarks,creation_date,created_by)"
				+ " VALUES('"+visitorNumber+"','"+visitorName+"','"+source+"','"+purpose+"','New','"+date+"','"+inTime+"','"+outTime+"','"+remarks+"',CURRENT_TIMESTAMP,'"+createdBy+"')";
		
		hrService.upDateQuery(query);
		return new ModelAndView("redirect:viewcalls");
	}

	@RequestMapping(value = "/updateVisitorTime")
	public ModelAndView updateVisitorTime(ModelMap model,@RequestParam Integer callId,String outTime) {

		String  query ="UPDATE visitor_book SET out_time = '"+outTime+"' WHERE call_id = '"+callId+"'";
		hrService.upDateQuery(query);
		return new ModelAndView("redirect:viewcalls");
	}

	@RequestMapping(value = "/sentmail")
	public ModelAndView mailSender(ModelMap model) {
		MailData maildata = new MailData();
		return new ModelAndView("Admin/mail/sentmail", "mailDTO", maildata);
	}

	@RequestMapping(value = "/sendingMailtest")
	public ModelAndView mailSenders(ModelMap model, MailData mail) {
		MailData maildata1 = new MailData();

		String fromAddr1 = "care@welezohealth.com";
		MimeMessage message = mailSender.createMimeMessage();
		try {
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setFrom(fromAddr1);
			helper.setTo(mail.getTo());
			helper.setSubject(mail.getSubject());
			helper.setText(mail.getBody());
			helper.addAttachment("Test.docx", new File(mail.getFileData()));
			mailSender.send(message);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return new ModelAndView("Admin/mail/sentmail", "mailDTO", maildata1);
	}

	@RequestMapping(value = "/sendingMail")
	public ModelAndView mailTest(ModelMap model,
			@RequestParam String toAddress, @RequestParam String subject,
			@RequestParam String message) throws MessagingException {
		/* @RequestParam List<File> attachedFiles */
		MailData maildata = new MailData();
		String userName = "care@welezohealth.com";
		// Message msg = new MimeMessage(session);
		MimeMessage msg = mailSender.createMimeMessage();
		Multipart multipart = null;
		try {
			msg.setFrom(new InternetAddress(userName));
			InternetAddress[] toAddresses = { new InternetAddress(toAddress) };
			msg.setRecipients(Message.RecipientType.TO, toAddresses);
			msg.setSubject(subject);
			msg.setSentDate(new Date());
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setContent(message, "text/html");

			// creates multi-part
			multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		// adds attachments
		/*
		 * if (attachedFiles != null && attachedFiles.size() > 0) { for (File
		 * aFile : attachedFiles) { System.out.println(aFile); MimeBodyPart
		 * attachPart = new MimeBodyPart();
		 * 
		 * try { attachPart.attachFile(aFile); } catch (IOException ex) {
		 * ex.printStackTrace(); }
		 * 
		 * multipart.addBodyPart(attachPart); } }
		 */

		// sets the multi-part as e-mail's content
		msg.setContent(multipart);

		// sends the e-mail
		mailSender.send(msg);
		return new ModelAndView("Admin/mail/sentmail", "mailDTO", maildata);
	}

	@RequestMapping(value = "/callsFileUpdate")
	public ModelAndView callsFileUpdate(ModelMap model) {

		return new ModelAndView("Admin/customerCallRecords/callsFileUpdate");
	}

	@RequestMapping(value = "/callUpload", method = RequestMethod.POST)
	public ModelAndView uploadHealthDoc(ModelMap model,
			@RequestParam CommonsMultipartFile file) throws Exception {

		String path = "/home/welezohealth/whms/calls";
		//String path = "D:/Calls";
		String filename = file.getOriginalFilename();
		try {
			byte barr[] = file.getBytes();
			BufferedOutputStream bout = new BufferedOutputStream(
					new FileOutputStream(path + "/" + filename));
			bout.write(barr);
			bout.flush();
			bout.close();
		} catch (Exception e) {
		}
		File uploadedFile = new File(path + "/" + filename);
		uploadedFile.renameTo(new File(path + "/" + filename));
		return new ModelAndView("redirect:callUploadDB");
	}

	@RequestMapping(value = "customerTxInt")
	public ModelAndView customerTxInt(ModelMap model) {
		return new ModelAndView("Admin/customerCallRecords/customerTxIntegrate");
	}

	@RequestMapping(value = "callByDuration")
	public ModelAndView searchCallByDuration(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		model.addAttribute("fromDate", dateFormat.format(date));
		model.addAttribute("toDate", dateFormat.format(date));
		List<ExtensionDetailsTO> extensionDetails = adminService
				.geteExtensionDetails();
		model.addAttribute("extensionDetails", extensionDetails);
		return new ModelAndView(
				"Admin/customerCallRecords/searchCallsByDuration");
	}

	@RequestMapping(value = "viewExtension")
	public ModelAndView viewExtension(ModelMap model) {
		ArrayList<HashMap<String, String>> allExtensionDetails = callrecordservice
				.getAllExtensionDetails();
		model.addAttribute("extnDetails", allExtensionDetails);

		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);

		return new ModelAndView("Admin/customerCallRecords/viewExtensions",
				"updateextensions", new ExtensionDetailsTO());
	}

	@RequestMapping(value = "editExtension")
	public ModelAndView editExtension(ModelMap model, @RequestParam Integer id) {
		HashMap<String, String> extensionById = callrecordservice
				.getExtensionById(id);
		model.addAttribute("extension", extensionById);
		List<EmployeeDetailsDTO> allEmployees = hrService
				.getAllEmployees("STATUS = 'Joined'");
		model.addAttribute("allEmployees", allEmployees);

		List<TeamsTO> allTeamName = adminService.getAllTeamName();
		model.addAttribute("allTeamName", allTeamName);

		List<ChannelsTO> allChannels = adminService.getAllChannels();
		model.addAttribute("allChannels", allChannels);
		List<RoleMasterTO> allDepartment = hrService.getAllDepartment();
		model.addAttribute("allDepartment", allDepartment);

		return new ModelAndView("Admin/customerCallRecords/editExtension",
				"extensions", new ExtensionDetailsTO());
	}

	@RequestMapping(value = "/postEditExtension")
	public ModelAndView postEditExtension(
			@ModelAttribute ExtensionDetailsTO extensions) {
		String s = "UPDATE extension_details SET to_date = (CURRENT_TIMESTAMP) WHERE id = '"
				+ extensions.getId() + "' ";
		hrService.upDateQuery(s);
		return new ModelAndView("redirect:viewExtension");
	}

	@RequestMapping(value = "/saveExtensions")
	public ModelAndView saveNewExtension(
			@ModelAttribute ExtensionDetailsTO extensions) {
		String s = "INSERT INTO extension_details (extension_No,emp_id,team,channel,from_date,to_date,department)"
				+ " VALUES('"
				+ extensions.getExtensionNo()
				+ "', '"
				+ extensions.getEmpId()
				+ "','"
				+ extensions.getTeam()
				+ "','"
				+ extensions.getChannel()
				+ "', CURRENT_TIMESTAMP, ADDDATE(CURRENT_TIMESTAMP, 360),'"
				+ extensions.getDepartment() + "') ";
		hrService.upDateQuery(s);
		return new ModelAndView("redirect:viewExtension");
	}

	@RequestMapping(value = "/teleNumbers")
	public ModelAndView teleCallsContactNoUpdates(ModelMap model) {
		List<EmployeeDTO> allEmployeeDetails = adminService
				.getAllEmployeeDetails("IN ('CSR', 'Sr. CSR')");
		model.addAttribute("allEmployeeDetails", allEmployeeDetails);

		return new ModelAndView("Admin/customerCallRecords/teleNumberUpdate");
	}

	@RequestMapping(value = "/saveNumbers", method = RequestMethod.POST)
	public ModelAndView saveTeleNumbers(@RequestParam String date, String csr,
			String[] number, String[] name, String[] status) {
		String date1 = null;
		try {
			Date txDate1 = new SimpleDateFormat("dd/MM/yyyy").parse(date);
			date1 = new SimpleDateFormat("yyyy-MM-dd").format(txDate1);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < number.length; i++) {
			if (!number[i].isEmpty()) {
				String s = " INSERT INTO daily_telecalls_details (contact_name,Phone_number,DATE,csr,STATUS) "
						+ " VALUES('"
						+ name[i]
						+ "','"
						+ number[i]
						+ "','"
						+ date1 + "','" + csr + "','" + status[i] + "')";
				hrService.upDateQuery(s);
			}
		}
		return new ModelAndView("redirect:teleNumbers");
	}
	@RequestMapping(value = "/incomingCalls")
	public @ResponseBody ModelAndView walkInCustomer(ModelMap model) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = new Date();
		String todate = dateFormat.format(date);
		Calendar cal = Calendar.getInstance();
		Date todate1 = cal.getTime();
		model.addAttribute("fromDate", dateFormat.format(todate1));
		model.addAttribute("toDate", todate);
		model.addAttribute("callsMode", "Missed");
		
		return new ModelAndView("redirect:incomingCalls1");
	}
	
	@RequestMapping(value = "/incomingCalls1")
	public ModelAndView inComingCallsView(ModelMap model,String fromDate, String toDate, String callsMode) {
		
		ArrayList<HashMap<String,String>> incomingCallsList = callrecordservice.getIncomingCallsList(fromDate, toDate, callsMode);
		model.addAttribute("incomingCallsList", incomingCallsList);
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("callsMode", callsMode);
		
		List<WelezoConstantsTO> welezoConstant = adminService.getWelezoConstant();
		model.addAttribute("welezoConstant", welezoConstant);
		return new ModelAndView("Admin/customerCallRecords/inComingCallsView");
					}

	@RequestMapping(value = "saveIncomingCallsStatus")
	public ModelAndView saveWalkInCustomer(ModelMap model,@RequestParam Integer id, @RequestParam String status,String purpose,String remarks,
			String fromDate, String toDate,Integer updatedBy,String callsMode) {

		String query = "UPDATE tele_call_incoming SET call_status= '"+status+"',purpose ='"+purpose+"', "
				+ "Remarks = '"+remarks+"' , updated_date = CURRENT_TIMESTAMP ,updated_by= '"+updatedBy+"' WHERE id = "+id+";";
		
		System.out.println(query);
		hrService.upDateQuery(query);
		
		model.addAttribute("fromDate", fromDate);
		model.addAttribute("toDate", toDate);
		model.addAttribute("callsMode", callsMode);
		return new ModelAndView("redirect:incomingCalls1");
	}

}
