package com.welezo.whms.controller;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.commons.VoucherGenerator;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.service.AdminService;
@Controller
public class HealthAppointmentController extends CustomHibenateDaoSupport {

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	AdminService adminService;
	
	
	public String addHealthAppt(long transaction_id, long service_id, long booking_id) {
		String result = "";
		
		try {
			String s = "SELECT * FROM transaction_offers WHERE transaction_id='"+ transaction_id +"' AND service_id = '"+service_id + "' and quantity=1 AND usage_id IS NULL";
			//System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession().connection();
			
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				int qtyOffered = rs.getInt("quantity");
				long trxOfferId = rs.getInt("txoffer_id");
				String updateQuery = "Update transaction_offers set usage_id ='"+ booking_id + "' where txoffer_id = '"+trxOfferId + "'";
				//System.out.println(updateQuery);
				PreparedStatement updPrepStmt = connection.prepareStatement(updateQuery);
				updPrepStmt.executeUpdate(updateQuery);
				result = "Updated the booking id";
				return result;
				}
			rs = null;

			// Split and update
			s = "SELECT * FROM transaction_offers WHERE transaction_id='"+ transaction_id +"' AND service_id = '"+service_id + "' and quantity > 1  AND usage_id IS NULL";
			//System.out.println(s);
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery(s);
			int qtyOffered = 100, trxOfferId = 0;
			if(rs.next()){
				qtyOffered = rs.getInt("quantity");
				trxOfferId = rs.getInt("txoffer_id");
				
				String updateQuery = "Update transaction_offers set usage_id ='"+ booking_id + "', quantity = 1 where txoffer_id = '"+trxOfferId + "'";
				//System.out.println(updateQuery);
				PreparedStatement updPrepStmt = connection.prepareStatement(updateQuery);
				updPrepStmt.executeUpdate(updateQuery);
				
				String insertQuery = "INSERT INTO transaction_offers(transaction_id, service_id, quantity, voucher_no, track_id)"
						+ " SELECT transaction_id, service_id, " + (qtyOffered -1) +" , voucher_no, track_id FROM transaction_offers "
								+ "WHERE txoffer_id = '"+trxOfferId+"'";
				updPrepStmt.execute(insertQuery);
				result = "Tx offers updated successfully";

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public String cancelHealthAppt(long booking_id) {
		String result = "";
		try {
				String updateQuery = "Update transaction_offers set usage_id = NULL where usage_id='"+booking_id+"' " ;
				Connection connection = sessionFactory.getCurrentSession().connection();
				PreparedStatement updPrepStmt = connection.prepareStatement(updateQuery);
				updPrepStmt.executeUpdate(updateQuery);
				result = "Canceled the booking Appointment";
				return result;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public String getVoucherNumber(int serviceId,Integer quantity){
		String result;
		String voucherSeries = "", startRange = "";
		try {
			String query = "SELECT voucher_no FROM transaction_offers  WHERE transaction_id=0 and service_id= '"+ serviceId+"'" ;
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			ResultSet rs = updPrepStmt.executeQuery(query);
			if(rs.next()){
				voucherSeries = rs.getString("voucher_no");
			//	System.out.println("Voucher series = "+voucherSeries);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//VoucherGenerator voucher = new VoucherGenerator();
		String voucherNumbers = VoucherGenerator.getVoucherNumbers(voucherSeries, quantity);
				//System.out.println(""+voucherNumbers);		
							return voucherNumbers;
	}
	public void clearVoucherNumber(String voucherNumber, Integer serviceId){
		String[] vNos = voucherNumber.split(" ");
		//System.out.println("Final Number " + vNos[vNos.length -1]);
		try {
			String query = "Update transaction_offers set voucher_no = '"+vNos[vNos.length -1]+"' where transaction_id=0 and service_id='"+serviceId+"'" ;
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			 updPrepStmt.executeUpdate(query);
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	/*public String getNextVoucher(String series, String currentVoucher){
		String res = "";
		String originalSeries = series;
		String numericSeries = currentVoucher.replaceAll("T-", "");
		int number=0;
		try{
			number = Integer.parseInt(numericSeries);
		}catch(NumberFormatException e){
			
		}
		String newNumber = "T-"+ (++number);
		System.out.println(newNumber);
		return res;
	}*/
	public List<HealthAppointmentDTO> getServiceUtilizationByTxOffer(Integer txId) {
		List<HealthAppointmentDTO> serviceList = new ArrayList<>();
		try {
			String s = "SELECT tx.service_id, ser.service_name, SUM(tx.quantity) AS 'Offered', SUM(CASE WHEN tx.usage_id > 0 THEN tx.quantity ELSE 0 END) 'Utilized',"
					+ " SUM( CASE WHEN tx.usage_id IS NULL THEN tx.quantity ELSE 0 END) 'Available' "
					+ "FROM transaction_offers tx LEFT JOIN services ser ON tx.service_id = ser.service_id WHERE tx.transaction_id = '"+txId+"' GROUP BY service_id";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HealthAppointmentDTO appointment = new HealthAppointmentDTO();
				appointment.setServiceId(rs.getInt("service_id"));
				appointment.setServiceName(rs.getString("service_name"));
				appointment.setAppointmentId(rs.getInt("Offered"));
				appointment.setAppointmnetFor(rs.getString("Utilized"));
				appointment.setReportStatus(rs.getString("Available"));
				serviceList.add(appointment);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return serviceList;
	}
	public ArrayList<HashMap<String, String>> getCustomerReports(
			String fileHolder) {
		ArrayList<HashMap<String, String>> accList = new ArrayList<>();

		String path = "/home/welezohealth/whms/apptReports";
		//String path = "D:\\files\\doc";
		try {
			File folder = new File(path);
			File[] listOfFiles = folder.listFiles();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					if (listOfFiles[i].getName().startsWith(fileHolder)) {
						// System.out.println("File=" +
						// listOfFiles[i].getName());
						HashMap<String, String> list = new HashMap<String, String>();
						list.put("docName", listOfFiles[i].getName());
						list.put("path", "/home/welezohealth/whms/apptReports/"+ listOfFiles[i].getName());
						//list.put("path", "D:\\files\\doc\\"+ listOfFiles[i].getName());
						accList.add(list);
					}
				} else if (listOfFiles[i].isDirectory()) {
					// System.out.println("Directory=" +
					// listOfFiles[i].getName());
					String name = listOfFiles[i].getName();
					HashMap<String, String> list = new HashMap<String, String>();
					list.put("docName", listOfFiles[i].getName());
					accList.add(list);
				}
			}
		} catch (Exception e) {
			// System.out.println(e);
		}
		return accList;
	}
}
