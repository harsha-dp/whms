package com.welezo.whms.commons;

public class Utilities {

	public String getNumberFromExponentialFormat(String number) {
		// System.out.println("before " + number);
		String value = number.replaceFirst("\\.", "").replaceAll("E9", "");
		if (number.endsWith("E9")) {
			switch (value.length()) {
			case 9:
				value = value + "0";
				break;
			case 8:
				value = value + "00";
				break;
			case 7:
				value = value + "000";
				break;
			case 6:
				value = value + "0000";
				break;
			default:
				break;
			}

			// System.out.println(value);
		}
		return value;
	}

}
