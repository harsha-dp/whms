package com.welezo.whms.commons;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.controller.AdminController;
import com.welezo.whms.controller.HealthAppointmentController;
import com.welezo.whms.controller.ReportController;
import com.welezo.whms.daoImpl.CorporateDaoImpl;
import com.welezo.whms.dto.ProductOffersDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.to.AddressCatagoriesTO;
import com.welezo.whms.to.AddressTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.CustomerFamilyTO;
import com.welezo.whms.to.PaymentDetailsTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.ServicesTO;
import com.welezo.whms.to.TransactionMasterTO;
import com.welezo.whms.to.TransactionOffersTO;

@Controller
public class CorporatePreEmployment {
	private Logger LOG = Logger.getLogger(AdminController.class);
	@Autowired
	AdminService adminService;
	@Autowired
	CorporateDaoImpl corporate;
	@Autowired
	ReportController report;
	@Autowired
	HealthAppointmentController healthAppt;

	@Autowired
	HRService hrService;

	@RequestMapping(value = "/preEmployee")
	public ModelAndView viewPreEmpQuery(ModelMap model) {

		ArrayList<HashMap<String, String>> allPreEmployeeList = corporate
				.getAllPreEmployeeList();
		model.addAttribute("allPreEmployeeList", allPreEmployeeList);

		return new ModelAndView("Admin/corporate/viewPreEmployeeList");
	}

	@RequestMapping(value = "/viewPreEmpQuery")
	public ModelAndView savePreEmployeeDetails(ModelMap model,
			@RequestParam Integer id, Integer userId) {
		HashMap<String, String> preEmployeeDetails = corporate
				.getPreEmployeeDetails(id);
		LOG.info("++++++++++++++++++++++ Enter into saveAdmin(save customer Details from application) ");
		CustomerDeatilsTO custDetailTO = new CustomerDeatilsTO();
		custDetailTO.setCustomerName(preEmployeeDetails.get("empName"));
		custDetailTO.setGender(preEmployeeDetails.get("gender"));
		custDetailTO.setCorrespondence("Residence");
		custDetailTO.setCommuniation("mail");

		custDetailTO.setCreatedBy(userId);
		Calendar cal = Calendar.getInstance();
		custDetailTO.setCreatedDate(cal.getTime());
		adminService.saveAdmin(custDetailTO);
		LOG.info("************ Inserting customer address details(save customer Details from application) ");
		AddressTO custAddressTO = new AddressTO();
		AddressCatagoriesTO addressCatagoriesTO = new AddressCatagoriesTO();
		addressCatagoriesTO.setAddressTypeId((2));
		custAddressTO.setAddressCatagories(addressCatagoriesTO);
		custAddressTO.setResidenceAddresss(preEmployeeDetails.get("address"));
		custAddressTO.setCity(preEmployeeDetails.get("city"));
		custAddressTO.setPincode(preEmployeeDetails.get("pincode"));
		custAddressTO.setLandmark("");
		custAddressTO.setLandline("");
		custAddressTO.setEmail(preEmployeeDetails.get("email"));
		custAddressTO.setPrimaryMob(preEmployeeDetails.get("contactNo"));
		// custAddressTO.setAltMob("");
		custAddressTO.setEntityId(custDetailTO.getCustomerId());
		adminService.saveAdmin(custAddressTO);

		CustomerFamilyTO cusFamilyTO = new CustomerFamilyTO();
		cusFamilyTO.setFName(preEmployeeDetails.get("empName"));
		cusFamilyTO.setGender(preEmployeeDetails.get("gender"));
		cusFamilyTO.setRelationship("Self");
		cusFamilyTO.setAge(Integer.parseInt(preEmployeeDetails.get("age")));
		cusFamilyTO.setIsactive(true);
		cusFamilyTO.setCustomerDeatils(custDetailTO);
		adminService.saveAdmin(cusFamilyTO);

		LOG.info("----------- End of customer details insertion(save customer Details from application) ");
		ProductMasterTO productMasterTO = new ProductMasterTO();
		productMasterTO.setProductId(Integer.parseInt(preEmployeeDetails
				.get("productId")));
		TransactionMasterTO txMasterTO = new TransactionMasterTO();
		txMasterTO.setApplicationNo("CORP" + id);
		txMasterTO.setProductMaster(productMasterTO);
		txMasterTO.setPaymentStatus("-");
		txMasterTO.setAmount((float) (00));
		txMasterTO.setCsr(0);
		txMasterTO.setExecutive(0);
		txMasterTO.setChannel(6);
		txMasterTO.setTeam(1);
		txMasterTO.setTxStatus("Payment Approved");
		txMasterTO.setRemarks("For corporate customer Pre-Employment");
		txMasterTO.setCreatedBy(userId);
		Calendar cal1 = Calendar.getInstance();
		txMasterTO.setCreatedDate((cal1.getTime()));
		SimpleDateFormat formatter1 = new SimpleDateFormat("dd/MM/yyyy");
		String colletdate1 = "21/10/2017";
		Date date1 = null;
		try {
			date1 = formatter1.parse(colletdate1);
			txMasterTO.setCollectedDate(date1);
			Date now = formatter1.parse(colletdate1);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(now);
			calendar.add(Calendar.YEAR, 1);
			Date expDate = calendar.getTime();
			txMasterTO.setExpriryDate(expDate);
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e);
		}
		txMasterTO.setCustomerDeatils(custDetailTO);
		adminService.saveAdmin(txMasterTO);
		LOG.info("************ Inserting transaction master where Tx Id is : "
				+ txMasterTO.getTransactionId());
		// report.insertAccountTransaction("");
		LOG.info("************ Inserting account Transaction that application No. is ");
		// adminService.getUpdateApplnStatus(collectionDTO.getApplicationNo(),
		// "For Data Entry");

		PaymentDetailsTO payDetailsTO = new PaymentDetailsTO();
		payDetailsTO.setModeOfPayment("");
		payDetailsTO.setAmount(00);
		payDetailsTO.setChequeAuthCode("");

		payDetailsTO.setTerminalNumber("");
		payDetailsTO.setBank("");
		payDetailsTO.setStatus("Payment Approved");

		payDetailsTO.setCreatedBy(userId);
		payDetailsTO.setCreatedDate((cal.getTime()));

		payDetailsTO.setTransactionMaster(txMasterTO);
		adminService.saveAdmin(payDetailsTO);
		// System.out.println("end pre emp " + custDetailTO.getCustomerId());

		List<ProductOffersDTO> allProductSevice = adminService
				.getAllProductSevice(Integer.parseInt(preEmployeeDetails
						.get("productId")));

		for (ProductOffersDTO dto : allProductSevice) {
			ServicesTO servicesTO = new ServicesTO();
			servicesTO.setServiceId(dto.getServicesId());
			TransactionOffersTO offersTO = new TransactionOffersTO();
			offersTO.setQuantity(dto.getQuantity());
			offersTO.setServices(servicesTO);
			offersTO.setTransactionMaster(txMasterTO);

			adminService.saveAdmin(offersTO);
			LOG.info("************ Transaction Offers Voucher entry : no- where Service Id is "
					+ dto.getServicesId());

		}
		String query = "UPDATE welezohe_corp.pre_employment SET STATUS = 'Confirmed' WHERE id = '"
				+ id + "'";
		hrService.upDateQuery(query);

		String query1 = "INSERT INTO corporate_customer(corporate_id,customer_id,pre_emp_id)"
				+ " VALUES('"
				+ preEmployeeDetails.get("corporateId")
				+ "','"
				+ custDetailTO.getCustomerId() + "','" + id + "')";
		hrService.upDateQuery(query1);
		model.addAttribute("transactionId", txMasterTO.getTransactionId());
		return new ModelAndView("redirect:serviceBaseAppointment");
	}
}
