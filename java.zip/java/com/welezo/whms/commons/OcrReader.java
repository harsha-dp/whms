package com.welezo.whms.commons;


import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

import java.io.File;
import java.io.IOException;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import net.sourceforge.tess4j.util.LoadLibs;

public class OcrReader {

	public void ocrTest() throws TesseractException {

		/*System.out.println("inside ocr");
	//	String inputPath = "D:/Calls/tessract/SACN.pdf";
		try {
			File fr = new File("D:/Calls/tessract/images.PNG");
		
		System.out.println(fr.getAbsolutePath());
		Tesseract tess = new Tesseract();
		String fullText = tess.doOCR(fr);
		tess.setDatapath("D:/Calls/tessract/");
		tess.setLanguage("eng");
		System.out.println(fullText);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		try {
			crackImage();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		File tessDataFolder = LoadLibs.extractTessResources("tessdata");
		
		 File imageFile = new File("D:/Calls/tessract/images.PNG");  
		    ITesseract instance = new Tesseract();  
		    try {  
		        String result = instance.doOCR(imageFile);
		        instance.setDatapath(tessDataFolder.getAbsolutePath());
		        System.out.println(result);
		       // return result;  
		    } catch (TesseractException e) {  
		        System.err.println(e.getMessage());  
		        System.out.println( "Error while reading image");  
		    } 
	}
	 public static String crackImage() throws InvalidPasswordException, IOException {
		
		 try (PDDocument document = PDDocument.load(new File("D:\\Calls\\tessract\\HRMSDoc.pdf"))) {

	           document.getClass();

	           if (!document.isEncrypted()) {
				
	               PDFTextStripperByArea stripper = new PDFTextStripperByArea();
	               stripper.setSortByPosition(true);

	               PDFTextStripper tStripper = new PDFTextStripper();

	               String pdfFileInText = tStripper.getText(document);
	               //System.out.println("Text:" + st);

					// split by whitespace
	               String lines[] = pdfFileInText.split("\\r?\\n");
	               for (String line : lines) {
	                   System.out.println(line);
	               }
	           
	         }
		 }
		return null;
	 }
}

	    

