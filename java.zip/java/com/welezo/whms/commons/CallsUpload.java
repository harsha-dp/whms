package com.welezo.whms.commons;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.service.HRService;

@Controller
public class CallsUpload extends CustomHibenateDaoSupport {

	private Logger LOG = Logger.getLogger(CallsUpload.class);

	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired
	HRService hrservice;

	@RequestMapping(value = "callUploadDB")
	public ModelAndView updateCalls(ModelMap model) throws Exception {
		File dir = new File("/home/welezohealth/whms/calls");
		// File dir = new File("D:\\Calls");
		LOG.info("calls file path " + dir.getPath());
		String[] fileNames = null;
		if (dir.isDirectory()) {
			fileNames = dir.list();
		}
		try {
			FileWriter fw = new FileWriter("outgoingCalls.txt");
			BufferedWriter bf = new BufferedWriter(fw);

			FileWriter rw = new FileWriter("incomingCalls.txt");
			BufferedWriter rbf = new BufferedWriter(rw);

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			int recCount = 0;

			LOG.info("file name For loop");
			for (String fName : fileNames) {
			FileReader fr = new FileReader("/home/welezohealth/whms/calls/"	+ fName);
			//FileReader fr = new FileReader("D:\\Calls\\"	+ fName);
				BufferedReader br = new BufferedReader(fr);
				String line;
				while ((line = br.readLine()) != null) {
					line = line.trim().replaceAll("( )+", ",");
					line += "\n";
					if (!(line.startsWith("0") || line.startsWith("1")
							|| line.startsWith("2") || line.startsWith("3")
							|| line.startsWith("4") || line.startsWith("5")
							|| line.startsWith("6") || line.startsWith("7")
							|| line.startsWith("8") || line.startsWith("9"))) { // Lines
																				// starting
																				// with
																				// number
																				// 0.
						continue;
					}
					 if (line.contains("R")) {
						 try {
						String ele[] = line.split(",");
					//	System.out.println(ele.length);
						String dt = ele[5], tm = ele[6];
						String dttm = getDateTime(dt, tm);
						String lineOut = ele[0] + ",'" + ele[1] + "','"
								+ ele[3] + "','" + ele[4] + "','" + dttm
								+ "','" + ele[7] + "'";
						String query = "Insert into tele_call_incoming(id,extension_no,miss_calls,phone_no,call_date,duration) values ("+ lineOut + ")";
						
						System.out.println("Incoming "+line);
						
							PreparedStatement pstmt = connection.prepareStatement(query);
							pstmt.executeUpdate();
						} catch (Exception e) {
							// LOG.error(e.getMessage());
							// System.out.println(e.getMessage());
						}
					} 
					 else if (line.contains("U")) {
							try{
							String ele[] = line.split(",");
							//System.out.println(ele.length);
						
							String dt = ele[4], tm = ele[5];
							String dttm = getDateTime(dt, tm);
							String lineOut = ele[0] + ",'" + ele[1] + "','"
									+ ele[2] + "','" + ele[3] + "','" + dttm
									+ "','" + ele[6] + "'";
							String query = "Insert into tele_call_incoming (id,extension_no,miss_calls,phone_no,call_date,duration) values ("+ lineOut + ") ";
							
						//	System.out.println("missed "+line);
						
								PreparedStatement pstmt = connection.prepareStatement(query);
								pstmt.executeUpdate();
							} catch (Exception e) {
								// LOG.error(e.getMessage());
								// System.out.println(e.getMessage());
							}
						} 
					else {

						// 5th column and 6th column
						String ele[] = line.split(",");
						String dt = ele[4], tm = ele[5];
						String dttm = getDateTime(dt, tm);

						// System.out.println(dt + " " + tm + " ---->> " +
						// dttm);
						String lineOut = ele[0] + ",'" + ele[1] + "','"
								+ ele[2] + "','" + ele[3] + "','" + dttm
								+ "','" + ele[6] + "'";
						String query = "Insert into tele_call_record values ("+ lineOut + ")";
						
					//	System.out.println("Outgoing "+lineOut);
						try {
							PreparedStatement pstmt = connection.prepareStatement(query);
							pstmt.executeUpdate();
						} catch (Exception e) {
							// LOG.error(e.getMessage());
							// System.out.println(e.getMessage());
						}
					}
				}
				fr.close();
			}
			// System.out.println("Total rows " + recCount);
			fw.close();
			rw.close();
		} catch (IOException e) {
			e.printStackTrace();
			LOG.error(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			// LOG.error(e.getMessage());
		} finally {
		}
		LOG.info("Calls Uploaded successfully");
		// System.out.println("Completed");
		
		String query1 ="INSERT IGNORE  INTO call_status (phone, calltime, duration, extn_no, emp_id ) "
				+ " SELECT DISTINCT cd.phone_no, cd.call_date, cd.duration, cd.extension_no, emps.emp_id "
				+ " FROM call_details cd LEFT JOIN employee_details emps ON cd.emp_id = emps.emp_id "
				+ " WHERE cd.call_date >= ADDDATE( NOW(), -3) "
				+ " AND cd.extension_no NOT IN ('222', '223', '224','201', '202','203','204','205','206','215','216','217', '218', '219','244', '245')";
		hrservice.upDateQuery(query1);
		
		
		String query2 ="UPDATE call_status SET call_status='Active' WHERE duration < 30 AND call_status='Called' AND calltime > (CURRENT_DATE - 2)";
		hrservice.upDateQuery(query2);
		return new ModelAndView("redirect:welezouser_dashboard");
	}

	public static String getDateTime(String dt, String tm) {
		String dtParts[] = dt.split("/");
		String dateS = "2018-" + dtParts[1] + "-" + dtParts[0] + " " + tm+ ":00";
		return dateS;
	}

	public ArrayList<HashMap<String, String>> getEmployeeDocuments(String fileHolder,String path) {
		ArrayList<HashMap<String, String>> accList = new ArrayList<>();
	//	String path = "/home/welezohealth/whms/hr/";
	//	String path = "D:\\files\\WH10021\\";
		try {
			File folder = new File(path);
			File[] listOfFiles = folder.listFiles();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					if (listOfFiles[i].getName().startsWith(fileHolder + "_")) {
						//System.out.println("File=" + listOfFiles[i].getName());
						HashMap<String, String> list = new HashMap<String, String>();
						list.put("docName", listOfFiles[i].getName());
						//list.put("path", path+ listOfFiles[i].getName());
						list.put("path", path+ listOfFiles[i].getName());
						accList.add(list);
					}
				} else if (listOfFiles[i].isDirectory()) {
					HashMap<String, String> list = new HashMap<String, String>();
					list.put("docName", listOfFiles[i].getName());
					accList.add(list);
				}
			}
		} catch (Exception e) {
			// System.out.println(e);
		}
		return accList;
	}
	@RequestMapping(value = "bio")
	public ModelAndView readBiometricFile() {
		//File dir = new File("K:\\attendance");
		File dir = new File("/home/welezohealth/whms/attendance");
		String[] fileNames = null;
		if (dir.isDirectory()) {
			fileNames = dir.list();
		}
		try {
			Connection connection = sessionFactory.getCurrentSession().connection();
			for (String fName : fileNames) {
				FileReader fr = new FileReader("/home/welezohealth/whms/attendance/" + fName);
				BufferedReader br = new BufferedReader(fr);
				String strLine = "";
				while ((strLine = br.readLine()) != null) {
					String dateStr = strLine.substring(10, 20);
					String timeStr = strLine.substring(21, 30).trim();
					String idStr = (strLine.substring(0, 9)).trim();
					// System.out.println(idStr + "$" + dateStr + "$" +
					// timeStr);
					String sql = "insert into attendence (biometric_id, date, log_time)"
							+ " values ( "
							+ idStr
							+ ", '"
							+ dateStr
							+ "', '"
							+ timeStr + "');";
					try {
						PreparedStatement pstmt = connection.prepareStatement(sql);
						pstmt.executeUpdate();
					} catch (Exception e) {
					//	System.out.println(e.getMessage());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("redirect:homeHr");
	}
	
	
}
