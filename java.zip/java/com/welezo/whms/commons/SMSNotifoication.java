package com.welezo.whms.commons;

import static com.rosaloves.bitlyj.Bitly.as;
import static com.rosaloves.bitlyj.Bitly.shorten;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.rosaloves.bitlyj.Url;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;

@Controller
public class SMSNotifoication {

	HttpSession session = null;
	@Autowired
	UserService userService;
	@Autowired
	AdminService adminService;
	@Autowired
	HRService hrService;

private static final String tinyUrl = "http://tinyurl.com/api-create.php?url=";
	
	public String shorter(String url) throws IOException {
		String tinyUrlLookup = tinyUrl + url;
		BufferedReader reader = new BufferedReader(new InputStreamReader(new URL(tinyUrlLookup).openStream()));
		String tinyUrl = reader.readLine();
		//System.out.println(tinyUrl);
		return tinyUrl;
	}
	public String sendTextMessage(String customerNo, String customerName,HashMap<String, String> smsTemplates, String urlLink,String encode) {
		//Test test = new Test();
		try {
			Url ul = as("lohithvn245", "R_ce40f3b2154d4268a8462c6d3f5493e1").call(shorten(urlLink));
			String tinyUrl = ul.getShortUrl();
			//System.out.println("art bitfly:" + ul);
			//System.out.println(ul);

			//String tinyUrl = shorter(urlLink);
			//System.out.println(tinyUrl);
			tinyUrl = tinyUrl.replace("http://", "");
			
			String requestUrl = null;
		//	String encode = smsTemplates.get("body");

			encode = encode.replaceAll("#customerName", customerName);
			// System.out.println(encode);
			encode = encode.replaceAll("#tinyUrl", tinyUrl);
			 
		//	System.out.println(encode);
			
			 if(smsTemplates.get("messageType").equalsIgnoreCase("Transactional")){ 
				 requestUrl = smsTemplates.get("url")+ "&msisdn=+91"+customerNo+"&msg="+URLEncoder.encode(encode, "UTF-8");
			 }else{ 
				 requestUrl = smsTemplates.get("url")+ "&msisdn=+91"+customerNo+"&msg="+URLEncoder.encode(encode,"UTF-8");
			  } 
			// System.out.println(requestUrl);
			 URL url = new URL(requestUrl);
			//  System.out.println(url);
			  HttpURLConnection uc = (HttpURLConnection) url.openConnection(); 
			  System.out.println("response msg"+uc.getResponseMessage());
			

			 
		} catch (Exception ex) {
			//System.out.println(ex.getMessage());
		}

		String query1 = "INSERT INTO sms_datacollection(phone_number,msg_template_id,sent_date,message_date,message_status,message_sent_thru,vendor_id)"
				+ " VALUES('"+ customerNo+ "','"+ smsTemplates.get("templateId")+ "',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,'Sent','CRM','"+ smsTemplates.get("vendorId") + "')";
		//System.out.println(query1);
		
		return query1;
	}

	
	public void smsCampign() throws IOException {
		String	msgBody ="Best Diabetes Health check @home. Buy @599 Hb1AC, RBS TSH CBC BUN Cholesterol Urine Test +dental check @Apollo White Call 1800 102 8364-welezo";
		String phoneNo ="9164074183";
		String requestUrl = "http://103.16.101.52:8080/sendsms/bulksms?username=kpsd-welezohlth&password=wele321&type=0&dlr=1&destination=91"+phoneNo+"&source=022751&message="+msgBody;
		URL url = new URL(requestUrl);
		  HttpURLConnection uc = (HttpURLConnection) url.openConnection(); 
		  System.out.println(requestUrl);
		  System.out.println("response msg"+uc.getResponseMessage());

		
	}
}
