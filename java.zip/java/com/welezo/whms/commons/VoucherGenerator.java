package com.welezo.whms.commons;

public class VoucherGenerator {
	/*static String currentNumber;
	static String latestNumber;
	static String voucherNumbers;*/
	
	
	 public static String getVoucherNumbers(String currentNumber, int quantity){
		String res = "";
		String voucherNumber="";
		String toUpdate = "";

		String numericSeries = currentNumber.substring(4, currentNumber.length());
		int length = numericSeries.length();

		int number=0;
		try{
			number = Integer.parseInt(numericSeries.substring(4, numericSeries.length()));
		}catch(NumberFormatException e){

		}
		for(int i = 0; i < quantity; i++){
			++number;
			res = String.valueOf(number);
			for(int start = res.length(); start < length ; start++){
				res = "0"+res; // Padding
			}
			
			voucherNumber = currentNumber.substring(0,4) + "" +  res;
			//System.out.println(voucherNumber);
			toUpdate = toUpdate + voucherNumber + " ";
		}
		
	
	//	System.out.println("Voucher Numbers " + toUpdate);
	//	System.out.println("Final Number " + voucherNumber);
		
		/*String[] vNos = toUpdate.split(" ");
		System.out.println("Final Number " + vNos[vNos.length -1]);*/
	//	String updateSeriesQuery = "Update transaction_offers set voucher_no = '"+voucherNumber+"' where transaction_id=0 and service_id="+serviceId;
		return toUpdate.trim();
	}

}
