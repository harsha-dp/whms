package com.welezo.whms.commons;

import java.util.ArrayList;
import java.util.HashMap;

public class CardGenerator {
	
	
	public ArrayList<String> generateCardNumber(String dob, String pinCode, String name) {
		ArrayList<String> newMap = new ArrayList<String>();
		int len = name.length();

		newMap.add(generateCardNumber(dob, pinCode, name, (len / 2 - 1)));
		newMap.add(generateCardNumber(dob, pinCode, name, 3));
		newMap.add(generateCardNumber(dob, pinCode, name, 1));
		return newMap;
	}

	public String generateCardNumber(String dob, String pinCode, String name,int pos) {
		// dob is in the form of YYYY-MM-DD
		HashMap<String, String> charMap = new HashMap<String, String>();
		charMap.put("A", "82");
		charMap.put("B", "91");
		charMap.put("C", "77");
		charMap.put("D", "74");
		charMap.put("E", "48");
		charMap.put("F", "95");
		charMap.put("G", "64");
		charMap.put("H", "36");
		charMap.put("I", "23");
		charMap.put("J", "91");
		charMap.put("K", "23");
		charMap.put("L", "32");
		charMap.put("M", "58");
		charMap.put("N", "27");
		charMap.put("O", "78");
		charMap.put("P", "66");
		charMap.put("Q", "96");
		charMap.put("R", "14");
		charMap.put("S", "96");
		charMap.put("T", "34");
		charMap.put("U", "44");
		charMap.put("V", "92");
		charMap.put("W", "50");
		charMap.put("X", "31");
		charMap.put("Y", "42");
		charMap.put("Z", "38");
		charMap.put(" ", "71");
		charMap.put("Others", "71");

		pinCode = pinCode.replaceAll("-", "").replaceAll(" ", "").trim();
		int pin = 9999, yr = 1970, mn = 1, dy = 1;
		String cardNumber = "WBNG ";
		try {
			pin = Integer.parseInt(pinCode);
			String dtParts[] = dob.split("-");
			yr = Integer.parseInt(dtParts[0]);
			mn = Integer.parseInt(dtParts[1]);
			dy = Integer.parseInt(dtParts[2]);

			pin = (pin - 559000) % 10000;
			if (pin < 0) {
				pin = pin * -1;
			}
			cardNumber = cardNumber + String.valueOf((yr + dy * 100 + mn))
					+ " " + String.valueOf(pin);

			String fi = (name.substring(pos, pos + 1)).toUpperCase();
			String li = (name.substring(name.length() - pos, name.length()
					- (pos - 1))).toUpperCase();
			if (charMap.get(li) == null)
				li = "Others";
			String lastPart = charMap.get(fi) + charMap.get(li);
			// System.out.println(name + " --> " + fi + " " + li + " --- > "
			// +lastPart);
			cardNumber = cardNumber + " " + lastPart;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		// System.out.println(pin + "  " + yr + " " +mn + " " + dy + " " + (yr +
		// dy*100 +mn));
		System.out.println(dob + "  -" + pinCode + "  -" + name + " ---> "
				+ cardNumber);
		return cardNumber;
	}

	
}
