package com.welezo.whms.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.welezo.whms.dao.AdminDao;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.CustomerDeatilsAllDTO;
import com.welezo.whms.dto.CustomerFamilyDTO;
import com.welezo.whms.dto.CustomerReferencesDTO;
import com.welezo.whms.dto.DaywiseCallsIdDTO;
import com.welezo.whms.dto.DispatchTrackingDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.ExternalIdDTO;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.dto.HospitalServiceDTO;
import com.welezo.whms.dto.PresalesDTO;
import com.welezo.whms.dto.ProductOffersDTO;
import com.welezo.whms.dto.TransactionMasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.to.AddressCatagoriesTO;
import com.welezo.whms.to.AddressTO;
import com.welezo.whms.to.ApplicationStockTO;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.CustomerFamilyTO;
import com.welezo.whms.to.CustomerHealthanalysisTO;
import com.welezo.whms.to.DispatchTrackingTO;
import com.welezo.whms.to.EmpanellmentTO;
import com.welezo.whms.to.ExtensionDetailsTO;
import com.welezo.whms.to.HealthAppointmentTO;
import com.welezo.whms.to.HospitalServiceTO;
import com.welezo.whms.to.InventoryTO;
import com.welezo.whms.to.ItemMasterTO;
import com.welezo.whms.to.PaymentDetailsTO;
import com.welezo.whms.to.PresalesTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.ServicesTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.to.TransactionMasterTO;
import com.welezo.whms.to.VendorsTO;
import com.welezo.whms.to.WelezoConstantsTO;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminDao adminDao;

	public <T> void saveAdmin(T entity) {
		adminDao.saveAdmin(entity);
	}

	@Override
	public List<CustomerDeatilsAllDTO> getAllCustomer() {

		return adminDao.getAllCustomer();
	}

	@Override
	public void deleteCustomer(Integer id) {
		adminDao.deleteCustomer(id);
	}

	@Override
	public CustomerDeatilsTO getCustomerDetail(Integer id) {

		return adminDao.getCustomerDetail(id);
	}

	@Override
	public AddressTO getAddress(Integer id) {
		return adminDao.getAddress(id);
	}

	@Override
	public CustomerHealthanalysisTO getCustomerHealth(int id) {
		return adminDao.getCustomerHealth(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getCustomerPayment(int id) {
		return adminDao.getCustomerPayment(id);
	}

	@Override
	public List<CustomerFamilyDTO> getFamily(Integer id) {
		return adminDao.getFamily(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllHospital(String city) {

		return adminDao.getAllHospital(city);
	}

	@Override
	public List<AddressTO> getAll(Integer addressId) {
		return adminDao.getAll(addressId);
	}

	public EmpanellmentTO getHospitalById(Integer id) {
		return adminDao.getHospitalById(id);
	}

	@Override
	public HospitalServiceTO getHospitalServicelById(Integer id) {
		return adminDao.getHospitalServicelById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllServiceForHospital(
			Integer hospitalId) {
		return adminDao.getAllServiceForHospital(hospitalId);
	}

	@Override
	public List<HealthAppointmentDTO> getAllAppointments(
			HealthAppointmentDTO healthAppointmentDTO) {
		return adminDao.getAllAppointments(healthAppointmentDTO);
	}

	@Override
	public ServicesTO getAllServices(Integer serviceId) {
		return adminDao.getAllServices(serviceId);
	}

	@Override
	public HealthAppointmentTO getAppointmentById(Integer id) {
		return adminDao.getAppointmentById(id);
	}

	@Override
	public List<CustomerReferencesDTO> getCustRefrence(Integer id) {
		return adminDao.getCustRefrence(id);
	}

	@Override
	public List<HospitalServiceDTO> getAllServiceByHid(Integer Hid) {
		return adminDao.getAllServiceByHid(Hid);
	}

	/*
	 * @Override public <T> void saveOrUpdate(T entity) {
	 * adminDao.saveOrUpdate(entity); }
	 */

	@Override
	public List<TransactionMasterDTO> getAlltransaction(
			TransactionMasterTO masterTO) {
		return adminDao.getAlltransaction(masterTO);
	}

	public ProductMasterTO getproductById(Integer id) {
		return adminDao.getproductById(id);
	}

	@Override
	public List<TransactionMasterDTO> getAllPayments(
			TransactionMasterTO masterTO) {
		return adminDao.getAllPayments(masterTO);
	}

	@Override
	public TransactionMasterTO getTxById(Integer id) {
		return adminDao.getTxById(id);
	}

	@Override
	public PaymentDetailsTO getPaymentById(Integer id) {
		return adminDao.getPaymentById(id);
	}

	@Override
	public List<DispatchTrackingDTO> getAllDispatchTracks(
			DispatchTrackingDTO dispatchDTO) {
		return adminDao.getAllDispatchTracks(dispatchDTO);
	}

	@Override
	public DispatchTrackingTO getDispatchTrackById(Integer id) {
		return adminDao.getDispatchTrackById(id);
	}

	@Override
	public List<PresalesTO> getAllpresales() {
		return adminDao.getAllpresales();
	}

	@Override
	public HashMap<String, String> getPresalesThrId(Integer id) {
		return adminDao.getPresalesThrId(id);
	}

	public PresalesTO getPresalesById(Integer id) {
		return adminDao.getPresalesById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllProducts() {
		return adminDao.getAllProducts();
	}

	@Override
	public List<ChannelsTO> getAllChannels() {
		return adminDao.getAllChannels();
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllCollections() {
		return adminDao.getAllCollections();
	}

	@Override
	public CollectionTO getCollectionById(Integer id) {
		return adminDao.getCollectionById(id);
	}

	@Override
	public List<EmployeeDTO> getAllEmployeeDetails(String designation) {
		return adminDao.getAllEmployeeDetails(designation);
	}

	@Override
	public List<TeamsTO> getAllTeamName() {
		return adminDao.getAllTeamName();
	}

	@Override
	public <T> void upDateAdmin(T entity) {
		adminDao.upDateAdmin(entity);

	}

	@Override
	public <T> void saveOrUpdate(T entity) {
		adminDao.saveOrUpdate(entity);

	}

	@Override
	public EmployeeDTO getEmployeeId(String empId) {
		return adminDao.getEmployeeId(empId);
	}

	@Override
	public ChannelsTO getChannelName(Integer id) {
		return adminDao.getChannelName(id);
	}

	@Override
	public TeamsTO getTeamName(Integer id) {
		return adminDao.getTeamName(id);
	}

	@Override
	public List<AddressCatagoriesTO> getAllAddressCatagories() {
		return adminDao.getAllAddressCatagories();
	}

	@Override
	public AddressDTO getAllAddress(Integer entityId, String addressType) {
		return adminDao.getAllAddress(entityId, addressType);
	}

	@Override
	public List<AddressDTO> getAddressEntityId(Integer entityId) {
		return adminDao.getAddressEntityId(entityId);
	}

	@Override
	public List<ExternalIdDTO> getProofId(Integer id) {
		return adminDao.getProofId(id);
	}

	@Override
	public AddressCatagoriesTO getAddressTypeId(Integer id) {
		return adminDao.getAddressTypeId(id);
	}

	@Override
	public HashMap<String, String> getApplicationNoTx(String applicationNo) {
		return adminDao.getApplicationNoTx(applicationNo);
	}

	@Override
	public List<ProductOffersDTO> getAllProductSevice(Integer id) {
		return adminDao.getAllProductSevice(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllTxOffers(Integer id) {
		return adminDao.getAllTxOffers(id);
	}

	@Override
	public List<DaywiseCallsIdDTO> getAllDailyCalls() {
		return adminDao.getAllDailyCalls();
	}

	@Override
	public List<ApplicationStockTO> getAllApplicationNo(String status) {
		return adminDao.getAllApplicationNo(status);
	}

	@Override
	public void getUpdateApplnStatus(String applicationNo, String status) {
		adminDao.getUpdateApplnStatus(applicationNo, status);
	}

	@Override
	public List<ExtensionDetailsTO> geteExtensionDetails() {
		return adminDao.geteExtensionDetails();
	}

	@Override
	public HashMap<String, String> getHospitalServices(Integer id) {
		return adminDao.getHospitalServices(id);
	}

	@Override
	public CustomerFamilyTO getFamilyId(Integer id) {
		return adminDao.getFamilyId(id);
	}

	@Override
	public List<PresalesTO> SearchPresales(Integer Aid) {
		return adminDao.SearchPresales(Aid);
	}

	@Override
	public ArrayList<HashMap<String, String>> FilterAPresales(
			PresalesDTO presalesTO) {
		return adminDao.FilterAPresales(presalesTO);
	}

	@Override
	public List<WelezoConstantsTO> getWelezoConstant() {
		return adminDao.getWelezoConstant();
	}

	@Override
	public DispatchTrackingTO getDispatchDetails(Integer txId) {
		return adminDao.getDispatchDetails(txId);
	}

	@Override
	public List<TransactionMasterDTO> getPaymentsBulkOperation() {
		return adminDao.getPaymentsBulkOperation();
	}

	@Override
	public List<TransactionMasterDTO> getPaymentsBulkOperationForOthers() {
		return adminDao.getPaymentsBulkOperationForOthers();
	}

	@Override
	public List<VendorsTO> getVendors() {
		return adminDao.getVendors();
	}

	@Override
	public List<ItemMasterTO> getItemMaster() {
		return adminDao.getItemMaster();
	}

	@Override
	public VendorsTO getVendorByid(Integer vendorId) {

		return adminDao.getVendorByid(vendorId);
	}

	@Override
	public ItemMasterTO getItemmasterByid(Integer itemId) {

		return adminDao.getItemmasterByid(itemId);
	}

	@Override
	public List<InventoryTO> getinventry() {
		return adminDao.getinventry();
	}

	@Override
	public List<WelezoConstantsTO> getconstants() {
		return adminDao.getconstants();
	}

	@Override
	public WelezoConstantsTO getconstantbyid(Integer id) {
		return adminDao.getconstantbyid(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllCollectionOffers(
			Integer collectionId) {
		return adminDao.getAllCollectionOffers(collectionId);
	}

	@Override
	public ArrayList<HashMap<String, String>> geteExtensionNoAndCsr() {
		return adminDao.geteExtensionNoAndCsr();
	}

	@Override
	public ArrayList<HashMap<String, String>> getCustomerList(
			String cardRPhnNumber) {
		return adminDao.getCustomerList(cardRPhnNumber);
	}

	@Override
	public ArrayList<HashMap<String, String>> getWalkinCustomer(
			String fromDate, String toDate) {
		return adminDao.getWalkinCustomer(fromDate, toDate);
	}

	@Override
	public HashMap<String, String> getWalkinCustomerById(Integer id) {
		return adminDao.getWalkinCustomerById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getDispatchList(
			Integer transactionId) {
		return adminDao.getDispatchList(transactionId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getHealthAppointmnetFBRating() {
		return adminDao.getHealthAppointmnetFBRating();
	}

	@Override
	public HashMap<String, String> getCustomerFBById(Integer id) {
		return adminDao.getCustomerFBById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllservice() {
		return adminDao.getAllservice();
	}

	@Override
	public ArrayList<HashMap<String, String>> getDetailsCustomer() {
		return adminDao.getDetailsCustomer();
	}

	@Override
	public ArrayList<String> getDistinctValues(String query) {
		return adminDao.getDistinctValues(query);
	}

	@Override
	public ArrayList<HashMap<String, String>> getWelezoBankList() {
		return adminDao.getWelezoBankList();
	}

	@Override
	public ArrayList<HashMap<String, String>> getServicesBasedOnProductId(
			Integer productId) {
		return adminDao.getServicesBasedOnProductId(productId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getServicesNotInProducts(
			Integer productId) {
		return adminDao.getServicesNotInProducts(productId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getSeoOnPageList(String fromDate,String toDate) {
		return adminDao.getSeoOnPageList(fromDate, toDate);
	}

	@Override
	public ArrayList<HashMap<String, String>> getOnlineUserList(
			String fromDate, String toDate) {
		return adminDao.getOnlineUserList(fromDate, toDate);
	}

	@Override
	public ArrayList<HashMap<String, String>> getBannedIpList(String fromDate,
			String toDate) {
		return adminDao.getBannedIpList(fromDate, toDate);
	}

	@Override
	public ArrayList<HashMap<String, String>> getIpAddressThruUserDetails(
			String ipAddress) {
		return adminDao.getIpAddressThruUserDetails(ipAddress);
	}

	@Override
	public HashMap<String, String> getSeoOnPageById(Integer id) {
		return adminDao.getSeoOnPageById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getCSatListforEdit(
			Integer appointmentId) {
		return adminDao.getCSatListforEdit(appointmentId);
	}

	@Override
	public HashMap<String, String> getApplicationStatusTx(String applicationNo) {
		return adminDao.getApplicationStatusTx(applicationNo);
	}

	@Override
	public HashMap<String, String> getApplicationStatusDispatch(
			String applicationNo) {
		return adminDao.getApplicationStatusDispatch(applicationNo);
	}

	@Override
	public HashMap<String, String> getInvoiceTransactionDetails(
			Integer transactionId) {
		return adminDao.getInvoiceTransactionDetails(transactionId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getCustomerReportList() {
		return adminDao.getCustomerReportList();
	}

}
