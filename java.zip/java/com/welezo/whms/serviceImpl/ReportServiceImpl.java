package com.welezo.whms.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.welezo.whms.dao.ReportDao;
import com.welezo.whms.service.ReportService;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.ProjectsTO;
import com.welezo.whms.to.TeamsTO;
@Service
public class ReportServiceImpl implements ReportService {

	@Autowired
	ReportDao reportDao;
	
	

	
	@Override
	public List<ProjectsTO> getallprojects() {
		return reportDao.getallprojects();
	}

	@Override
	public ProjectsTO getallprojectsById(Integer projectId) {
		return reportDao.getallprojectsById(projectId);
	}

	

	@Override
	public TeamsTO getteamsById(Integer teamId) {
		return reportDao.getteamsById(teamId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllChannelss() {
		return reportDao.getAllChannelss();
	}

	@Override
	public ChannelsTO editchannelsById(Integer channelId) {
		return reportDao.editchannelsById(channelId);
	}

	
}
