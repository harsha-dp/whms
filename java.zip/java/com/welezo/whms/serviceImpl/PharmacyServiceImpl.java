package com.welezo.whms.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.welezo.whms.dao.PharmacyDao;
import com.welezo.whms.service.PharmacyService;

@Service
public class PharmacyServiceImpl implements PharmacyService {

	@Autowired
	PharmacyDao pharmacyDao;

	@Override
	public ArrayList<HashMap<String, String>> getPharmacyList(
			String fromDate, String toDate, String status) {
		return pharmacyDao.getPharmacyList(fromDate, toDate, status);
	}

	@Override
	public HashMap<String, String> getPharmacyDeatilsById(Integer pharmacyId) {
		return pharmacyDao.getPharmacyDeatilsById(pharmacyId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getDoctorsList() {
		return pharmacyDao.getDoctorsList();
	}

	@Override
	public ArrayList<HashMap<String, String>> getPharmacyNameList() {
		return pharmacyDao.getPharmacyNameList();
	}

	@Override
	public ArrayList<HashMap<String, String>> getPharmacyLeadList(
			String fromDate, String toDate, String status) {
		return pharmacyDao.getPharmacyLeadList(fromDate, toDate, status);
	}
}
