package com.welezo.whms.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.welezo.whms.dao.HRDao;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.EmployeeQualificationDTO;
import com.welezo.whms.dto.PerformanceMetricsDTO;
import com.welezo.whms.service.HRService;
import com.welezo.whms.to.ExperienceDetailsTO;
import com.welezo.whms.to.HireCompanyTO;
import com.welezo.whms.to.RoleMasterTO;

@Service
public class HRServiceImpl implements HRService {

	@Autowired
	HRDao hrDao;

	@Override
	public EmployeeDetailsDTO getEmployeeById(int id) {
		return hrDao.getEmployeeById(id);
	}

	@Override
	public List<EmployeeQualificationDTO> getEmpQualifiaction(Integer empId) {
		return hrDao.getEmpQualifiaction(empId);
	}

	@Override
	public List<ExperienceDetailsTO> getEmpExperience(Integer empId) {
		return hrDao.getEmpExperience(empId);
	}

	@Override
	public List<EmployeeDetailsDTO> getAllEmployees(String status) {
		return hrDao.getAllEmployees(status);
	}

	@Override
	public void saveInterviewRemarks(EmployeeQualificationDTO employeeDetails) {
		hrDao.saveInterviewRemarks(employeeDetails);
	}

	@Override
	public List<RoleMasterTO> getAllRoles() {
		return hrDao.getAllRoles();
	}

	@Override
	public List<EmployeeQualificationDTO> getEmpRoleDesignation(Integer empId) {
		return hrDao.getEmpRoleDesignation(empId);
	}

	@Override
	public List<RoleMasterTO> getAllDepartment() {
		return hrDao.getAllDepartment();
	}

	@Override
	public List<EmployeeQualificationDTO> getEmpDeptWise(String departmentName) {
		return hrDao.getEmpDeptWise(departmentName);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllLeaves(String fromdate, String toDate) {
		return hrDao.getAllLeaves(fromdate, toDate);
	}

	public EmployeeQualificationDTO getEmpRoleById(Integer roleId) {
		return hrDao.getEmpRoleById(roleId);
	}


	@Override
	public ArrayList<HashMap<String, String>> getAllSalSlab() {
		return hrDao.getAllSalSlab();
	}

	@Override
	public HashMap<String, String> getSalarySlabDetails(Integer slabId) {
		return hrDao.getSalarySlabDetails(slabId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllGoals(String fromDate,String toDate, String status) {
		return hrDao.getAllGoals(fromDate,toDate, status);
	}

	@Override
	public List<HireCompanyTO> getAllHireCompany() {
		return hrDao.getAllHireCompany();
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllJobOpenings() {
		return hrDao.getAllJobOpenings();
	}

	@Override
	public HashMap<String, String> getJobOpeninsById(Integer jobOpenId) {
		return hrDao.getJobOpeninsById(jobOpenId);
	}

	@Override
	public HashMap<String, String> getEmployeeGoalById(Integer goalId) {
		return hrDao.getEmployeeGoalById(goalId);
	}

	@Override
	public HashMap<String, String> getQualificationById(Integer empQufnId) {
		return hrDao.getQualificationById(empQufnId);
	}

	@Override
	public HashMap<String, String> getExperienceById(Integer expId) {
		return hrDao.getExperienceById(expId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllMetrics(String supervisor) {
		return hrDao.getAllMetrics(supervisor);
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmpEvaluation(PerformanceMetricsDTO performanceDTO) {
		return hrDao.getEmpEvaluation(performanceDTO);
	}

	@Override
	public void updateHRemployeeperformance(PerformanceMetricsDTO performanceDTO) {
		hrDao.updateHRemployeeperformance(performanceDTO);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllEmpSalrSlab(String month) {
		return hrDao.getAllEmpSalrSlab(month);
	}

	@Override
	public HashMap<String, String> setEmpSalComponent(Integer empId) {
		return hrDao.setEmpSalComponent(empId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllPayType() {
		return hrDao.getAllPayType();
	}

	@Override
	public ArrayList<HashMap<String, String>> getQuestionBank(String qCategory) {
		return hrDao.getQuestionBank(qCategory);
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmployeeACCDetails(
			String attrType, Integer empId) {
		return hrDao.getEmployeeACCDetails(attrType, empId);
	}

	@Override
	public void upDateQuery(String query) {
		hrDao.upDateQuery(query);
	}

	@Override
	public HashMap<String, String> getLeavesById(Integer reqId) {
		return hrDao.getLeavesById(reqId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getMonthlyEmpSalary(
			String salMonth) {
		return hrDao.getMonthlyEmpSalary(salMonth);
	}

	@Override
	public HashMap<String, String> getEmpMonthlySalSlip(Integer empId,
			String month) {
		return hrDao.getEmpMonthlySalSlip(empId, month);
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmpAttenance(
			Integer bioMetricId,String fromDate,String toDate) {
		return hrDao.getEmpAttenance(bioMetricId, fromDate, toDate);
	}

	@Override
	public ArrayList<HashMap<String, String>> getemployeeListThruRole(String query) {
		return hrDao.getemployeeListThruRole(query);
	}

	@Override
	public HashMap<String, String> getDesignation(Integer empId) {
		return hrDao.getDesignation(empId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllLeavesAdmin(String query) {
		return hrDao.getAllLeavesAdmin(query);
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmployeesListByReportId(
			Integer userId) {
		return hrDao.getEmployeesListByReportId(userId);
	}

	@Override
	public HashMap<String, String> getEmployeeIdFromUserId(Integer userId) {
		return hrDao.getEmployeeIdFromUserId(userId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getGoalsAdmin(String query) {
		return hrDao.getGoalsAdmin(query);
	}

	@Override
	public ArrayList<HashMap<String, String>> getSalPayMonthsList(Integer empId) {
		return hrDao.getSalPayMonthsList(empId);
	}

	@Override
	public HashMap<String, String> getEmployeeDesignation(
			Integer empId, String date) {
		return hrDao.getEmployeeDesignation(empId, date);
	}

	@Override
	public HashMap<String, String> getReportIdthruUserId(Integer userId) {
		return hrDao.getReportIdthruUserId(userId);
	}

	@Override
	public HashMap<String, String> getCandidateDetails(Integer candidateId) {
		return hrDao.getCandidateDetails(candidateId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getInterviewerFeedback(
			Integer candidateId) {
		return hrDao.getInterviewerFeedback(candidateId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getInterviewCandidatesList(String fromDate, String todate,String status) {
		return hrDao.getInterviewCandidatesList(fromDate, todate, status);
	}

	@Override
	public boolean updateEmployeeImage(Integer empId) {
		return hrDao.updateEmployeeImage(empId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getMonthsList() {
		return hrDao.getMonthsList();
	}

	@Override
	public ArrayList<HashMap<String, String>> getMetricsList() {
		return hrDao.getMetricsList();
		
	}

	@Override
	public ArrayList<HashMap<String, String>> getMeetingDetails(String query,Integer userId) {
		return hrDao.getMeetingDetails(query,userId);
	}

	@Override
	public HashMap<String, String> getMeetingById(Integer userId) {
		return hrDao.getMeetingById(userId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getMOMList(Integer meetingId) {
		return hrDao.getMOMList(meetingId);
	}

	@Override
	public HashMap<String, String> getMeetingAssignedById(Integer meetingId) {
		return hrDao.getMeetingAssignedById(meetingId);
	}

	@Override
	public List<HashMap<String, String>> getEmployeesListOnEmpType(
			String empType) {
		return hrDao.getEmployeesListOnEmpType(empType);
	}
	@Override
	public ArrayList<HashMap<String, String>> getallholidaylist() {
		return hrDao.getallholidaylist();
	}


}
