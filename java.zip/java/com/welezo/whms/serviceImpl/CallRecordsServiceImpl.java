package com.welezo.whms.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.welezo.whms.dao.CallRecordsDao;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.TeleCallRecordIdDTO;
import com.welezo.whms.service.CallRecordsService;

@Service
public class CallRecordsServiceImpl implements CallRecordsService {

	@Autowired
	CallRecordsDao callRecordDao;

	@Override
	public ArrayList<HashMap<String, String>> getAllVisitorList(
			String fromDate, String toDate, String purpose) {
		return callRecordDao.getAllVisitorList(fromDate, toDate, purpose);
	}

	@Override
	public List<AddressDTO> searchCustomer(String phoneNumber) {
		return callRecordDao.searchCustomer(phoneNumber);
	}

	@Override
	public List<TeleCallRecordIdDTO> teleCallsByPhoneNo(String phoneNumber) {
		return callRecordDao.teleCallsByPhoneNo(phoneNumber);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllExtensionDetails() {
		return callRecordDao.getAllExtensionDetails();
	}

	@Override
	public HashMap<String, String> getExtensionById(Integer id) {
		return callRecordDao.getExtensionById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getIncomingCallsList(
			String fromDate, String toDate, String callsMode) {
		return callRecordDao.getIncomingCallsList(fromDate, toDate, callsMode);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllBTlLeads(String fromDate,
			String toDate, String status, String parkId) {
		return callRecordDao.getAllBTlLeads(fromDate, toDate, status, parkId);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllParkDetails() {
		return callRecordDao.getAllParkDetails();
	}

}
