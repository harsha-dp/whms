package com.welezo.whms.serviceImpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.stereotype.Service;

import com.welezo.whms.dao.UserDao;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;

	@Autowired
	private MailSender sendMail;

	@Override
	public <T> void save(T entity) {
		userDao.save(entity);
	}

	@Override
	public UsermasterDTO login(String userName, String password) {
		return userDao.login(userName, password);
	}

	@Override
	public List<UsermasterDTO> getAllUser() {
		return userDao.getAllUser();
	}

	@Override
	public UsermasterDTO getUserById(int id) {
		return userDao.getUserById(id);
	}

	@Override
	public ArrayList<HashMap<String, String>> getUserAccessModule(String query) {
		return userDao.getUserAccessModule(query);
	}

	@Override
	public void UpDateUserAccess(Integer userId, String mailId) {
		userDao.UpDateUserAccess(userId, mailId);		
	}

	@Override
	public Boolean checkCredentials(String mobileNumber, String mailId) {
		return userDao.checkCredentials(mobileNumber, mailId);
	}

	@Override
	public HashMap<String, String> getEmailBody(String templateName) {
		return userDao.getEmailBody(templateName);
	}

	@Override
	public HashMap<String, String> getSMSTemplates(String purpose) {
		return userDao.getSMSTemplates(purpose);
	}

}
