package com.welezo.whms.to;

import java.util.List;

public class Person {

	private String validation;
	

	private String proName;
	private Integer empCount;
	private String healthMode;
	private Integer companyId;
	private List<Integer> serviceList;
	
	public Person() {

	}

	public Person(String proName, Integer empCount, String healthMode,
			Integer companyId, List<Integer> serviceList) {
		super();
		this.proName = proName;
		this.empCount = empCount;
		this.healthMode = healthMode;
		this.companyId = companyId;
		this.serviceList = serviceList;
	}

	
	

	public List<Integer> getServiceList() {
		return serviceList;
	}

	public void setServiceList(List<Integer> serviceList) {
		this.serviceList = serviceList;
	}

	public String getValidation() {
		return validation;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}

	

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public Integer getEmpCount() {
		return empCount;
	}

	public void setEmpCount(Integer empCount) {
		this.empCount = empCount;
	}

	public String getHealthMode() {
		return healthMode;
	}

	public void setHealthMode(String healthMode) {
		this.healthMode = healthMode;
	}

	public Integer getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}







	
}
