package com.welezo.whms.to;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.persistence.Id;

@Entity
@Table(name = "corporate_service_offers", catalog = "welezohe_whms")
public class CorporateServiceOffersTO implements Serializable {

	private static final long serialVersionUID = 4511114529026869912L;
	private Integer corpId;
	private String healthCheckId;
	private Integer productId;
	private Integer serviceHeadCount;
	private Integer isActive;
	private String proName;

	public CorporateServiceOffersTO() {

	}

	

	public CorporateServiceOffersTO(Integer corpId, String healthCheckId,
			Integer productId, Integer serviceHeadCount, Integer isActive,
			String proName) {
		this.corpId = corpId;
		this.healthCheckId = healthCheckId;
		this.productId = productId;
		this.serviceHeadCount = serviceHeadCount;
		this.isActive = isActive;
		this.proName = proName;
	}



	@Column(name = "corporate_id", length = 11)
	public Integer getCorpId() {
		return corpId;
	}

	public void setCorpId(Integer corpId) {
		this.corpId = corpId;
	}

	@Column(name = "health_check_id", length = 30)
	public String getHealthCheckId() {
		return healthCheckId;
	}

	public void setHealthCheckId(String healthCheckId) {
		this.healthCheckId = healthCheckId;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "product_id", length = 11,  unique = true, nullable = false)
	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	@Column(name = "service_head_count", length = 11)
	public Integer getServiceHeadCount() {
		return serviceHeadCount;
	}

	public void setServiceHeadCount(Integer serviceHeadCount) {
		this.serviceHeadCount = serviceHeadCount;
	}

	@Column(name = "is_active", length = 11)
	public Integer getIsActive() {
		return isActive;
	}

	public void setIsActive(Integer isActive) {
		this.isActive = isActive;
	}


@Column(name = "product_name", length = 50,nullable = false)
	public String getProName() {
		return proName;
	}



	public void setProName(String proName) {
		this.proName = proName;
	}

	
	
}
