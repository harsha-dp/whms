package com.welezo.whms.to;

import static javax.persistence.GenerationType.IDENTITY;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "data_allocation", catalog = "welezohe_whms")
public class DataAllocationTO {

	private Integer allocationId;
	private Integer  sourceId;
	private Date allocationDate;
	private Integer allocatedBy;
	private String remarks;
	
	public DataAllocationTO() {
	}

	public DataAllocationTO(Integer allocationId, Integer sourceId,
			Date allocationDate, Integer allocatedBy,String remarks) {
		super();
		this.allocationId = allocationId;
		this.sourceId = sourceId;
		this.allocationDate = allocationDate;
		this.allocatedBy = allocatedBy;
		this.remarks = remarks;
	}
	@Id
	@GeneratedValue(strategy = IDENTITY)
	@Column(name = "allocation_id", unique = true, nullable = false)
	public Integer getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(Integer allocationId) {
		this.allocationId = allocationId;
	}
	@Column(name = "source_id")
	public Integer getSourceId() {
		return sourceId;
	}

	public void setSourceId(Integer sourceId) {
		this.sourceId = sourceId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "allocation_date", length = 19)
	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}
	@Column(name = "allocated_by")
	public Integer getAllocatedBy() {
		return allocatedBy;
	}

	public void setAllocatedBy(Integer allocatedBy) {
		this.allocatedBy = allocatedBy;
	}
	@Column(name = "remarks", length = 500)
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
