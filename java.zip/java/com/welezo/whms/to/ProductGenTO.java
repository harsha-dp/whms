package com.welezo.whms.to;

import static javax.persistence.GenerationType.IDENTITY;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.persistence.Id;;


@Entity
@Table(name = "product_gen", catalog = "welezohe_whms")
public class ProductGenTO {


private int productId;
private Integer serviceList;


public ProductGenTO() {
	}


public ProductGenTO(int productId, Integer serviceList) {
	this.productId = productId;
	this.serviceList = serviceList;
}

@Id
@Column(name = "product_id", unique = true, nullable = false,length=11)
public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}

@Column(name = "service_list", length=11)
public Integer getServiceList() {
	return serviceList;
}


public void setServiceList(Integer serviceList) {
	this.serviceList = serviceList;
}








}
