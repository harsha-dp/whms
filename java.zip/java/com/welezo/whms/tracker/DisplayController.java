package com.welezo.whms.tracker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dto.ResultsetColumnsDeatils;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.UserService;

@Controller
public class DisplayController extends CustomHibenateDaoSupport {
	@Autowired
	AdminService adminService;
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	UserService userService;
	@RequestMapping(value = "/viewDetails3")
	public ModelAndView viewcustomers(ModelMap model,@RequestParam Integer userId) {
		UsermasterDTO userById = userService.getUserById(userId);
		model.addAttribute("userById", userById);
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT task_id,project_name,module,task_title,task_description,priority,created_by,assignee,task_status,task_activity,task_type,due_date,estimated_time "
					+ "FROM tasks_list WHERE  task_status NOT IN ('Completed','Cancelled','Deployed','Ready for Release')";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);

			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		List<UsermasterDTO> allUser = userService.getAllUser();
		model.addAttribute("allUser", allUser);
		return new ModelAndView("Admin/tracker/ViewTask", "rest",
				new ResultsetColumnsDeatils());
	}
	@RequestMapping(value = "/searchTask")
	public ModelAndView searchTask(ModelMap model,String name,String status,@RequestParam Integer userId) {
	//	System.out.println(name);
		//System.out.println(status);
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT `task_id`,`project_name`,`module`,`task_title`,`task_description`,`priority`,`created_by`,`assignee`,`task_status`,`task_activity`,`task_type`,`due_date`,`estimated_time` "
					+ "FROM tasks_list WHERE  task_status LIKE '%"+status+"%' AND assignee LIKE '%"+name+"%'";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);

			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		List<UsermasterDTO> allUser = userService.getAllUser();
		model.addAttribute("allUser", allUser);
		
		UsermasterDTO userById = userService.getUserById(userId);
		model.addAttribute("userById", userById);
		return new ModelAndView("Admin/tracker/ViewTask", "rest",
				new ResultsetColumnsDeatils());
	}
	@RequestMapping(value = "/viewTaskById")
	public ModelAndView viewTaskByUserId(ModelMap model,@RequestParam Integer userId) {
		UsermasterDTO userById = userService.getUserById(userId);
		model.addAttribute("userById", userById);
		ResultSet rs = null;
		PreparedStatement prepareStatement = null;
		Connection connection = null;
		ArrayList<HashMap<String, String>> stkList = new ArrayList<>();
		try {
			String s = "SELECT task_id,project_name,module,task_title,task_description,priority,created_by,assignee,task_status,task_activity,task_type,due_date,estimated_time "
					+ "FROM tasks_list WHERE  task_status NOT IN ('Completed','Cancelled','Deployed','Ready for Release') AND (author = '"+userId+"' OR assigned_to = '"+userId+"')";
			connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			ResultSetMetaData rdms = rs.getMetaData();
			int columnCount = rdms.getColumnCount();
			List<ResultsetColumnsDeatils> columnList = new ArrayList<>();
			for (int j = 1; j <= columnCount; j++) {
				ResultsetColumnsDeatils rest = new ResultsetColumnsDeatils();
				rest.setColumnName(rdms.getColumnName(j));
				columnList.add(rest);
			}
			model.addAttribute("columnName", columnList);

			while (rs.next()) {
				int i = 1;
				HashMap<String, String> stkMap = new HashMap<String, String>();
				for (i = 1; i <= columnCount; i++) {
					stkMap.put("attr" + i, rs.getString(i));
				}
				stkList.add(stkMap);
			}
			model.addAttribute("stkList", stkList);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		List<UsermasterDTO> allUser = userService.getAllUser();
		model.addAttribute("allUser", allUser);
		return new ModelAndView("Admin/tracker/ViewTaskThruId", "rest",
				new ResultsetColumnsDeatils());
	}
}
