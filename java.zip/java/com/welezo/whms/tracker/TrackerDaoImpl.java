package com.welezo.whms.tracker;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dto.TasksDTO;
import com.welezo.whms.to.FilesUploadTO;
import com.welezo.whms.to.ProjectsTO;
import com.welezo.whms.to.ReleaseDetailsTO;
import com.welezo.whms.to.UsermasterTO;
import com.welezo.whms.to.WelezoConstantsTO;
import com.welezo.whms.to.WelezoWorkflowTO;
import com.welezo.whms.util.HibernateUtil;

@Controller
public class TrackerDaoImpl extends CustomHibenateDaoSupport {

	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	private HibernateUtil hibernateUtil;

	@Transactional
	public <T> void save(T entity) {
		getSession().save(entity);
	}
	public <T> void saveOrUpdate(T entity) {
		hibernateUtil.saveOrUpdate(entity);
	}
	public ArrayList<HashMap<String, String>> getAllProjects() {
		ArrayList<HashMap<String, String>> projectList = new ArrayList<>();
		try {
			String s = "SELECT project_id, project_name FROM projects WHERE isActive > 0 ORDER BY parent_project, project_id ";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("projectId", rs.getString("project_id"));
					list.put("projectName", rs.getString("project_name"));
					projectList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return projectList;
	}
	public List<FilesUploadTO> getAllFiles() {
		List<FilesUploadTO> projectTO = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(FilesUploadTO.class,"project");
		@SuppressWarnings("unchecked")
		Collection<? extends FilesUploadTO> theUserList = (Collection<? extends FilesUploadTO>) theCriteria
				.list();

		projectTO.addAll(theUserList);
		return projectTO;
	}
	public FilesUploadTO getFileById(Integer id) {
		return hibernateUtil.fetchById(id, FilesUploadTO.class);

	}
	public List<UsermasterTO> getAllUsers() {
		List<UsermasterTO> userTO = new ArrayList<>();
		try {
			String s = "SELECT * FROM usermaster WHERE role_type = 'Admin' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				UsermasterTO userMaster = new UsermasterTO();
				userMaster.setUserId(rs.getInt("user_id"));
				userMaster.setUserName(rs.getString("user_name"));
				userTO.add(userMaster);
			}
		} catch (SQLException e) {
		//	e.printStackTrace();
		}
		return userTO;
	}

	public List<WelezoConstantsTO> getAllConstant() {
		List<WelezoConstantsTO> projectTO = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(WelezoConstantsTO.class,
				"project");
		@SuppressWarnings("unchecked")
		Collection<? extends WelezoConstantsTO> theUserList = (Collection<? extends WelezoConstantsTO>) theCriteria
				.list();

		projectTO.addAll(theUserList);
		
		return projectTO;
	}

	public ArrayList<HashMap<String, String>> getAllRelease() {
		ArrayList<HashMap<String, String>> releaseList = new ArrayList<>();
		try {
			String s = "SELECT * FROM release_details WHERE isCompleted IS NULL";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("releaseId", rs.getString("release_id"));
					list.put("releaseName", rs.getString("release_name"));
					releaseList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return releaseList;
	}

	public HashMap<String, String> getTaskById(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT task.*,proj.project_name,usermas.user_name AS 'Authors',usermas1.user_name AS 'Assignee',releas.release_name FROM tasks task "
					+ "LEFT JOIN projects proj ON proj.project_id = task.project_id "
					+ "LEFT JOIN usermaster usermas ON usermas.user_id = task.author  "
					+ "LEFT JOIN release_details releas ON releas.release_id = task.release_id  "
					+ "LEFT JOIN usermaster usermas1 ON usermas1.user_id = task.assigned_to  WHERE task.task_id = '"+id+"'";
			//System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("taskId", rs.getString("task_id"));
				list.put("taskTitle", rs.getString("task_title"));
				list.put("taskDescription", rs.getString("task_description"));
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					list.put("startDate",sdf.format(rs.getDate("start_date")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					list.put("dueDate",sdf.format(rs.getDate("due_date")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				list.put("taskActivity", rs.getString("task_activity"));
				list.put("taskStatus", rs.getString("task_status"));
				list.put("taskType", rs.getString("task_type"));
				list.put("module", rs.getString("module"));
				list.put("priority", rs.getString("priority"));
				list.put("estimatedTime", rs.getString("estimated_time"));
				list.put("releaseId", rs.getString("release_id"));
				list.put("releaseName", rs.getString("release_name"));
				list.put("projectId", rs.getString("project_id"));
				list.put("projectName", rs.getString("project_name"));
				list.put("author", rs.getString("author"));
				list.put("assignedTo", rs.getString("assigned_to"));
				list.put("Authors", rs.getString("Authors"));
				list.put("Assignee", rs.getString("Assignee"));
				list.put("percentComplete", rs.getString("percent_complete"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;

	}

	public ProjectsTO getProjectById(Integer id) {
		return hibernateUtil.fetchById(id, ProjectsTO.class);
	}

	public UsermasterTO getUserMasterById(Integer id) {
		return hibernateUtil.fetchById(id, UsermasterTO.class);
	}

	public ReleaseDetailsTO getReleaseById(Integer id) {
		return hibernateUtil.fetchById(id, ReleaseDetailsTO.class);
	}

	public WelezoConstantsTO getWelezoConstantById(Integer id) {
		return hibernateUtil.fetchById(id, WelezoConstantsTO.class);
	}

	public List<WelezoWorkflowTO> getAllWorkFlow() {
		List<WelezoWorkflowTO> projectTO = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(WelezoWorkflowTO.class,
				"project");
		@SuppressWarnings("unchecked")
		Collection<? extends WelezoWorkflowTO> theUserList = (Collection<? extends WelezoWorkflowTO>) theCriteria
				.list();

		projectTO.addAll(theUserList);
		return projectTO;
	}
	public void updateTask(TasksDTO task){
		String date = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy",Locale.ENGLISH);
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd" ,Locale.ENGLISH);
		try {
			date = formatter.format(sdf.parse(task.getDueDate()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String query = "UPDATE tasks SET task_status = '"+task.getTaskStatus()+"' , due_date='"+date+"' ,`percent_complete` = '"+task.getPercentComplete()+"' "
					+ "WHERE task_id = '"+task.getTaskId()+"'" ;
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			 updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public ArrayList<HashMap<String, String>> getTimeSpentDetails(Integer taskId) {
		ArrayList<HashMap<String, String>> timeList = new ArrayList<>();
		try {
			String s = "SELECT tspent.time_spent,tspent.date_spent_on,updates.user_notes FROM task_timespent tspent "
					+ "LEFT JOIN task_updates updates ON updates.id = tspent.update_id WHERE engg_id = '"+taskId+"' ";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("timeSpent", rs.getString("time_spent"));
					list.put("dateSpentOn", rs.getString("date_spent_on"));
					list.put("userNotes", rs.getString("user_notes"));
					timeList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return timeList;
	}
}
