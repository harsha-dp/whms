package com.welezo.whms.tracker;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.dto.TasksDTO;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.service.HRService;
import com.welezo.whms.service.UserService;
import com.welezo.whms.to.FilesUploadTO;
import com.welezo.whms.to.TaskTimespentTO;
import com.welezo.whms.to.TaskUpdatesTO;
import com.welezo.whms.to.TasksTO;
import com.welezo.whms.to.UsermasterTO;
import com.welezo.whms.to.WelezoConstantsTO;
import com.welezo.whms.to.WelezoWorkflowTO;

@Controller
public class TrackerController {
	@Autowired
	TrackerDaoImpl service;
	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	UserService userService;
	
	@Autowired
	HRService hrService;

	@RequestMapping(value = "/AddTask")
	public ModelAndView AddTask(ModelMap model,@RequestParam Integer userId) {
		UsermasterDTO userById = userService.getUserById(userId);
		model.addAttribute("userById", userById);
		TasksTO task = new TasksTO();
		 ArrayList<HashMap<String, String>> allProjects = service.getAllProjects();
		 model.addAttribute("projects", allProjects);

		List<UsermasterTO> allUsers = service.getAllUsers();
		model.addAttribute("user", allUsers);

		List<WelezoConstantsTO> allConstant = service.getAllConstant();
		model.addAttribute("constant", allConstant);

		 ArrayList<HashMap<String,String>> allRelease = service.getAllRelease();
		model.addAttribute("release", allRelease);

		return new ModelAndView("Admin/tracker/AddTask", "AddTaskTO", task);
	}

	@RequestMapping(value = "/saveTask")
	public ModelAndView saveTask(ModelMap model,TasksTO task) {
		task.setTaskStatus("New");
		Calendar cal = Calendar.getInstance();
		task.setCreatedOn(cal.getTime());

		service.save(task);

		UsermasterDTO assignee = userService.getUserById(task.getAssignedTo());
		UsermasterDTO author = userService.getUserById(task.getAuthor());

		final String toAddr = assignee.getUserMail();
		final String fromAddr = "tracker@welezohealth.com";
		final String subject = "Tracker Task Upadates";
		final String body = "Dear " + assignee.getUserName() + ",\n"
				+ " Your Task Assigned By -" + author.getUserName() + ".\n"
				+ " Task Title :  " + task.getTaskTitle() + "\n"
				+ " Task Description :  \n" + task.getTaskDescription() + "\n"
				+ "\n" + "Thanks " + "\n" + "Team Welezo IT \n" +"www.whms.welezohealth.com";

		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(toAddr);
		email.setSubject(subject);
		email.setText(body);
		email.setFrom(fromAddr);
		mailSender.send(email);
		final String toAddr1 = author.getUserMail();
		final String fromAddr1 = "tracker@welezohealth.com";
		final String subject1 = "Tracker Task Upadates";
		final String body1 = "Dear " + author.getUserName() + ",\n"
				+ " You  Assigned Task to - " + assignee.getUserName() + "\n"
				+ "Task Title :  " + task.getTaskTitle() + "\n"+ "\n"
				+ "Task Description :  \n" + task.getTaskDescription() + "\n"
				+ "\n" + "Thanks \n" + "Team Welezo IT \n"+"www.whms.welezohealth.com";

		SimpleMailMessage email1 = new SimpleMailMessage();
		email1.setTo(toAddr1);
		email1.setSubject(subject1);
		email1.setText(body1);
		email1.setFrom(fromAddr1);
		mailSender.send(email1);
		
		model.addAttribute("userId", task.getAuthor());
		return new ModelAndView("redirect:AddTask");
	}

	@RequestMapping(value = "/editTask")
	public ModelAndView editTask(@RequestParam Integer taskId, ModelMap model,@RequestParam Integer userId) {
		
		UsermasterDTO userById = userService.getUserById(userId);
		model.addAttribute("userById", userById);
		
		TasksDTO task = new TasksDTO();
		
		HashMap<String, String> taskById = service.getTaskById(taskId);
		model.addAttribute("taskById", taskById);
		
		// service.getWelezoConstantById(taskById.getPriority());
	/*	 ArrayList<HashMap<String, String>> allProjects = service.getAllProjects();
		model.addAttribute("projects", allProjects);*/

		List<UsermasterTO> allUsers = service.getAllUsers();
		model.addAttribute("user", allUsers);

		List<WelezoConstantsTO> allConstant = service.getAllConstant();
		model.addAttribute("constant", allConstant);
/*
		List<ReleaseDetailsTO> allRelease = service.getAllRelease();
		model.addAttribute("release", allRelease);*/
		List<WelezoWorkflowTO> allWorkFlow = service.getAllWorkFlow();
		model.addAttribute("allWorkFlow", allWorkFlow);
		return new ModelAndView("Admin/tracker/editTask", "task", task);
	}
	@RequestMapping(value = "/taskApproval")
	public ModelAndView saveTaskApproval(ModelMap model,@RequestParam Integer taskId,@RequestParam Integer userId,@RequestParam String remarks,@RequestParam Integer approvalBy) {
		TaskUpdatesTO taskUpdate = new TaskUpdatesTO();
		taskUpdate.setTaskId(taskId);
		taskUpdate.setUserNotes("Approved(Suggestions): "+remarks);
		taskUpdate.setUserId(userId);
		Calendar cal = Calendar.getInstance();
		taskUpdate.setUpdateDate(cal.getTime());
		service.save(taskUpdate);

		TaskTimespentTO timeSpent = new TaskTimespentTO();
		timeSpent.setEnggId(taskId);
		timeSpent.setUserId(userId);
		timeSpent.setUpdateId(taskUpdate.getId());
		service.save(timeSpent);
		
		String query = "UPDATE tasks SET task_status = 'Approved', approved_by = '"+approvalBy+"', approved_date = CURRENT_DATE WHERE task_id ='"+taskId+"'";
		hrService.upDateQuery(query);
		
		model.addAttribute("taskId", taskId);
		model.addAttribute("userId", userId);
		return new ModelAndView("redirect:viewTaskthruId");
	}

	@RequestMapping(value = "/saveEditTask")
	public ModelAndView postEditTask(ModelMap model,@ModelAttribute TasksDTO task) {

		service.updateTask(task);
		TaskUpdatesTO taskUpdate = new TaskUpdatesTO();
		taskUpdate.setTaskId(task.getTaskId());
		taskUpdate.setUserNotes(task.getUserNotes());
		taskUpdate.setUserId(task.getUserId());
		Calendar cal = Calendar.getInstance();
		taskUpdate.setUpdateDate(cal.getTime());
		service.save(taskUpdate);

		TaskTimespentTO timeSpent = new TaskTimespentTO();
		timeSpent.setEnggId(task.getTaskId());
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String spentDate = task.getDateSpentOn();
		try {

			Date date = formatter.parse(spentDate);
			timeSpent.setDateSpentOn(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		timeSpent.setUserId(task.getUserId());
		timeSpent.setTimeSpent(task.getTimeSpent());
		timeSpent.setUpdateId(taskUpdate.getId());
		service.save(timeSpent);
		
		UsermasterDTO assignee = userService.getUserById(task.getAssignedTo());
		UsermasterDTO author = userService.getUserById(task.getAuthor());

		final String toAddr = assignee.getUserMail();
		final String fromAddr = "tracker@welezohealth.com";
		final String subject = "Task Upadated...(Details Check In CRM)";
		final String body = "Dear " + assignee.getUserName() + ",\n"
				+ author.getUserName() +" - Assigned Task is Updated." +  "\n"
				+ "Task Title :  " + task.getTaskTitle() + ".\n" 
				+ "Task percentage Completed :" + task.getPercentComplete() + "% \n"
				+ "Task Status :  " + task.getTaskStatus()+ "\n"+ "\n"
				+ "Task Description :  \n" + task.getTaskDescription() + "\n"+ "\n"
				+ "User Note :  \n" + task.getUserNotes() + "\n"
				+ "\n" + "Thanks " + "\n" + "Team Welezo IT \n" +"www.whms.welezohealth.com";

		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(toAddr);
		email.setSubject(subject);
		email.setText(body);
		email.setFrom(fromAddr);
		mailSender.send(email);
		final String toAddr1 = author.getUserMail();
		final String fromAddr1 = "tracker@welezohealth.com";
		final String subject1 = "Task Updated....(View Details In CRM)";
		final String body1 = "Dear " + author.getUserName() + ",\n"
				+ " Your  Assigned Task Updated By - " + assignee.getUserName() + "\n"+ "\n"
				+ "Task Title :  " + task.getTaskTitle() + ".\n" 
				+ "Task percentage Completed :" + task.getPercentComplete() + "% \n"
				+ "Task Status :  " + task.getTaskStatus()+ "\n"+ "\n"
				+ "Task Description :  \n" + task.getTaskDescription() + "\n"+ "\n"
				+ "User Note :  \n" + task.getUserNotes() + "\n"
				+ "\n" + "Thanks " + "\n" + "Team Welezo IT \n" +"www.whms.welezohealth.com";


		SimpleMailMessage email1 = new SimpleMailMessage();
		email1.setTo(toAddr1);
		email1.setSubject(subject1);
		email1.setText(body1);
		email1.setFrom(fromAddr1);
		mailSender.send(email1);
		
		
		model.addAttribute("userId", task.getUserId());
		return new ModelAndView("redirect:viewDetails3");
	}

	@RequestMapping(value = "/viewTaskthruId")
	public ModelAndView viewTaskById(ModelMap model, @RequestParam Integer taskId,@RequestParam Integer userId) {
		
		HashMap<String,String> taskById = service.getTaskById(taskId);
		model.addAttribute("taskById", taskById);
		ArrayList<HashMap<String,String>> timeSpentDetails = service.getTimeSpentDetails(taskId);
		model.addAttribute("timeSpentDetails", timeSpentDetails);
		UsermasterDTO userById = userService.getUserById(userId);
		model.addAttribute("userById", userById);
		List<UsermasterTO> allUsers = service.getAllUsers();
		model.addAttribute("user", allUsers);
		
		return new ModelAndView("Admin/tracker/ViewTaskById");
	}
	@RequestMapping(value = "/upload1", method = RequestMethod.GET)
	public ModelAndView showUploadForm() {
		return new ModelAndView("Admin/fileupload/upload");
	}

	@RequestMapping(value = "/doUpload", method = RequestMethod.POST)
	public ModelAndView handleFileUpload(ModelMap model,@RequestParam("name") String name,
			@RequestParam CommonsMultipartFile file, HttpSession session)
			throws Exception {

		//System.out.println("Enter into upload file");
		//System.out.println(file);

		// String path=session.getServletContext().getRealPath("/");
		// String path=("D:\\k\\download");
		String path = "D:\\Workspace4\\WHMS\\src\\main\\webapp\\WEB-INF\\files";
		String filename = file.getOriginalFilename();

		System.out.println(path + " " + filename);
		try {
			byte barr[] = file.getBytes();

			BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(path + "/" + filename));
			// multipartFile.transferTo(new File(saveDirectory + fileName));
			// fileNames.add(fileName);
			bout.write(barr);

			bout.flush();
			bout.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		List<FilesUploadTO> allFiles = service.getAllFiles();
		model.addAttribute("allFiles", allFiles);

		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				System.out.println(bytes);
				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();
				// Create the file on server
			//	File serverFile = new File(dir.getAbsolutePath()+ File.separator + name);
			//	BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(serverFile));
			//	stream.write(bytes);
			//	stream.close();
				FilesUploadTO uploadFile = new FilesUploadTO();
				uploadFile.setFileName(name);
				uploadFile.setFileData(bytes);
				//System.out.println(bytes);
				service.save(uploadFile);
				//System.out.println("uploaded successfully " + bytes);
				List<FilesUploadTO> allFiles1 = service.getAllFiles();
				model.addAttribute("allFiles", allFiles1);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		return new ModelAndView("Admin/fileupload/upload");
	}

	@RequestMapping(value = { "/download-document-{userId}" }, method = RequestMethod.GET)
	public @ResponseBody String downloadDocument(@PathVariable Integer userId,
			HttpServletResponse response) throws IOException {
		FilesUploadTO fileById = service.getFileById(userId);
		try {
			response.setHeader("Content-Disposition", "inline;filename=\""+ fileById.getFileData() + "\"");
			OutputStream out = response.getOutputStream();
			response.setContentType(fileById.getFileName());
			// IOUtils.copy(fileById.getFileName().getClass(), out);
			out.flush();
			out.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		Path path = Paths.get("");
		byte[] data = Files.readAllBytes(path);
		return "redirect:/add-document-" + userId;
	}

	@RequestMapping(value = ("/documentList"))
	public ModelAndView documentList(ModelMap model) throws IOException {
		File dir = new File(
				"D:\\Workspace4\\WHMS\\src\\main\\webapp\\WEB-INF\\files");
		File[] files = dir.listFiles();
		
		  ArrayList filPaths = new ArrayList(); 
		  for (File file : files) {
		  filPaths.add(file.getAbsolutePath());
		  }
		  model.addAttribute("documentList", filPaths);
		  List<FilesUploadTO> allFiles = service.getAllFiles();
		  List<FilesUploadTO> list = new  ArrayList<>();
		 
		
		 for (FilesUploadTO file : allFiles) {
			 FilesUploadTO file1 = new  FilesUploadTO(); 
			 file1.setUploadId(file.getUploadId());
			 String encodeBase64 = Base64.encodeBase64String(file.getFileData());
		  file1.setFileName(encodeBase64); 
		  encodeBase64.getBytes();
		  list.add(file1); } 
		 model.addAttribute("allFiles", list);
		 
		return new ModelAndView("Admin/fileupload/upload");
	}

}
