package com.welezo.whms.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dao.UserDao;
import com.welezo.whms.dto.UsermasterDTO;
import com.welezo.whms.to.UsermasterTO;

@Repository
public class UserDaoImpl extends CustomHibenateDaoSupport implements UserDao {

	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	public <T> void save(T entity) {

		getSession().save(entity);

	}

	@Override
	public UsermasterDTO login(String userName, String password) {

		UsermasterDTO usermasterDTO = new UsermasterDTO();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(UsermasterTO.class,
				"login").add(
				Restrictions.and(Restrictions.eq("login.userMail", userName)
						.ignoreCase(), Restrictions.eq("login.password",
						password)));
		final List<UsermasterTO> theUserList = (List<UsermasterTO>) theCriteria.list();
		if (!theUserList.isEmpty()) {
			for (UsermasterTO login : theUserList) {
				usermasterDTO.setUserId(login.getUserId());
				usermasterDTO.setUserName(login.getUserName());
				usermasterDTO.setUserMail(login.getUserMail());
				usermasterDTO.setPassword(login.getPassword());
				usermasterDTO.setRoleType(login.getRoleType());
				usermasterDTO.setMobileNumber(login.getMobileNumber());
			}
		}
		return usermasterDTO;
	}

	@Override
	public List<UsermasterDTO> getAllUser() {

		List<UsermasterDTO> userDeatils = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(UsermasterTO.class,
				"userDeatils");
		@SuppressWarnings("unchecked")
		Collection<? extends UsermasterDTO> theUserList = (Collection<? extends UsermasterDTO>) theCriteria
				.list();

		userDeatils.addAll(theUserList);
		return userDeatils;
	}

	@Override
	public UsermasterDTO getUserById(int id) {
		UsermasterDTO usermasterDTO = new UsermasterDTO();
		try {
			String s = "SELECT * FROM usermaster WHERE user_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				usermasterDTO.setUserId(rs.getInt("user_id"));
				usermasterDTO.setUserName(rs.getString("user_name"));
				usermasterDTO.setUserMail(rs.getString("user_mail"));
				usermasterDTO.setMobileNumber(rs.getString("mobile_number"));
				usermasterDTO.setUserLoginName(rs.getString("user_login_name"));
				usermasterDTO.setPassword(rs.getString("password"));
				usermasterDTO.setCreatedBy(rs.getString("created_by"));
				usermasterDTO.setCreatedDate(rs.getDate("created_date"));
				usermasterDTO.setRoleType(rs.getString("role_type"));
				usermasterDTO.setAlterLoginName(rs
						.getString("alter_login_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return usermasterDTO;
	}

	@Override
	public ArrayList<HashMap<String, String>> getUserAccessModule(String query) {
		ArrayList<HashMap<String, String>> moduleList = new ArrayList<>();
		try {
			// String s =
			// "SELECT * FROM user_access ua LEFT JOIN modules mods ON mods.module_id = ua.module_id WHERE ua.user_id = '"+userId+"'  ORDER BY ua.module_id"
			// ;
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection
					.prepareStatement(query);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("canRead", rs.getString("can_read"));
				list.put("canWrite", rs.getString("can_write"));
				list.put("canUpdate", rs.getString("can_update"));
				list.put("report", rs.getString("report"));
				list.put("moduleName", rs.getString("module_name"));
				list.put("category", rs.getString("category"));
				list.put("moduleId", rs.getString("module_id"));
				list.put("userId", rs.getString("role_id"));
				list.put("moduleLink", rs.getString("module_link"));
				list.put("accessId", rs.getString("accessId"));
				list.put("modulePriority", rs.getString("module_priority"));
				list.put("icon", rs.getString("icons"));
				moduleList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return moduleList;
	}

	@Override
	public void UpDateUserAccess(Integer userId, String mailId) {
		try {
			String query = "INSERT INTO user_access (role_id,module_id) "
					+ " SELECT '" + userId
					+ "',module_id FROM role_access WHERE role_id = 1 ";
			// System.out.println(query);

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			updPrepStmt.executeUpdate(query);
			connection.close();
			updPrepStmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			// System.out.println(e);
		}
	}

	@Override
	public Boolean checkCredentials(String mobileNumber, String mailId) {
		Boolean check = null;
		try {
			String s = "SELECT * FROM usermaster WHERE user_mail = '" + mailId
					+ "' OR `mobile_number` = '" + mobileNumber + "' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				check = true;
			} else {
				check = false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return check;
	}

	@Override
	public HashMap<String, String> getEmailBody(String templateName) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM email_templates WHERE template_name = 'Health'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.put("templateId", rs.getString("template_id"));
				list.put("templateName", rs.getString("template_name"));
				list.put("description", rs.getString("description"));
				list.put("recipients", rs.getString("recipients"));
				list.put("subject", rs.getString("subject"));
				list.put("body", rs.getString("body"));
				list.put("attachmentQuery", rs.getString("attachment_query"));
				list.put("mailBodyQuery", rs.getString("mail_body_query"));

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getSMSTemplates(String purpose) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM sms_templates temp "
					+ "LEFT JOIN sms_vendor ven ON ven.message_type= temp.message_type"
					+ " WHERE temp.purpose='"+purpose+"' AND ven.isActive = 1 AND temp.isActive =1";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.put("templateId", rs.getString("template_id"));
				list.put("body", rs.getString("body"));
				list.put("url", rs.getString("url"));
				list.put("vendorId", rs.getString("vendor_id"));
				list.put("messageType", rs.getString("message_type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
