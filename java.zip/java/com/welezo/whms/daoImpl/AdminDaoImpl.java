package com.welezo.whms.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dao.AdminDao;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.CustomerDeatilsAllDTO;
import com.welezo.whms.dto.CustomerFamilyDTO;
import com.welezo.whms.dto.CustomerReferencesDTO;
import com.welezo.whms.dto.DaywiseCallsIdDTO;
import com.welezo.whms.dto.DispatchTrackingDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.ExternalIdDTO;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.dto.HospitalServiceDTO;
import com.welezo.whms.dto.PresalesDTO;
import com.welezo.whms.dto.ProductOffersDTO;
import com.welezo.whms.dto.TransactionMasterDTO;
import com.welezo.whms.to.AddressCatagoriesTO;
import com.welezo.whms.to.AddressTO;
import com.welezo.whms.to.ApplicationStockTO;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.CustomerFamilyTO;
import com.welezo.whms.to.CustomerHealthanalysisTO;
import com.welezo.whms.to.DispatchTrackingTO;
import com.welezo.whms.to.EmpanellmentTO;
import com.welezo.whms.to.ExtensionDetailsTO;
import com.welezo.whms.to.HealthAppointmentTO;
import com.welezo.whms.to.HospitalServiceTO;
import com.welezo.whms.to.InventoryTO;
import com.welezo.whms.to.ItemMasterTO;
import com.welezo.whms.to.PaymentDetailsTO;
import com.welezo.whms.to.PresalesTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.ServicesTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.to.TransactionMasterTO;
import com.welezo.whms.to.VendorsTO;
import com.welezo.whms.to.WelezoConstantsTO;
import com.welezo.whms.util.HibernateUtil;

@Repository
public class AdminDaoImpl extends CustomHibenateDaoSupport implements AdminDao {

	@Autowired
	SessionFactory sessionFactory;
	
	@Autowired
	private HibernateUtil hibernateUtil;

	@Override
	public <T> void saveAdmin(T entity) {
		hibernateUtil.create(entity);
	}

	public <T> void saveOrUpdate(T entity) {
		hibernateUtil.saveOrUpdate(entity);
	}

	@Override
	public List<CustomerDeatilsAllDTO> getAllCustomer() {
		List<CustomerDeatilsAllDTO> custDeatils = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(CustomerDeatilsTO.class,
				"custDetail");
		@SuppressWarnings("unchecked")
		Collection<? extends CustomerDeatilsAllDTO> theUserList = (Collection<? extends CustomerDeatilsAllDTO>) theCriteria
				.list();

		custDeatils.addAll(theUserList);
		return custDeatils;
	}

	@Override
	public void deleteCustomer(Integer id) {
		CustomerDeatilsTO cust = new CustomerDeatilsTO();
		cust.setCustomerId(id);
		hibernateUtil.delete(cust);
	}

	@Override
	public CustomerDeatilsTO getCustomerDetail(Integer id) {
		return hibernateUtil.fetchById(id, CustomerDeatilsTO.class);

	}

	public CustomerFamilyTO getFamilyId(Integer id) {
		return hibernateUtil.fetchById(id, CustomerFamilyTO.class);
	}

	@SuppressWarnings("deprecation")
	@Override
	public AddressTO getAddress(Integer id) {
		ResultSet rs = null;
		AddressTO AddressTO = new AddressTO();

		try {

			String s = "SELECT * FROM address WHERE aid = ?";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			rs = prepareStatement.executeQuery();

			if (rs.next()) {
				AddressTO.setAid(rs.getInt("aid"));
				AddressTO.setResidenceAddresss(rs.getString("Residence_addresss"));
				AddressTO.setCity(rs.getString("city"));
				AddressTO.setLandmark(rs.getString("landmark"));
				AddressTO.setLandline(rs.getString("landline"));
				AddressTO.setEmail(rs.getString("email"));
				AddressTO.setPrimaryMob(rs.getString("primary_mob"));
				AddressTO.setAltMob(rs.getString("alt_mob"));
				AddressTO.setPincode(rs.getString("pincode"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return AddressTO;
	}

	@SuppressWarnings("deprecation")
	@Override
	public CustomerHealthanalysisTO getCustomerHealth(int id) {
		CustomerHealthanalysisTO customerHealthanalysisTO = new CustomerHealthanalysisTO();
		try {
			String s = "SELECT * FROM customer_healthanalysis WHERE customer_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				customerHealthanalysisTO.setId(rs.getInt("id"));
				customerHealthanalysisTO.setM5(rs.getString("m5"));
				customerHealthanalysisTO.setM618(rs.getString("m6_18"));
				customerHealthanalysisTO.setM1935(rs.getString("m19_35"));
				customerHealthanalysisTO.setM3650(rs.getString("m36_50"));
				customerHealthanalysisTO.setM5165(rs.getString("m51_65"));
				customerHealthanalysisTO.setM65(rs.getString("m_65"));
				customerHealthanalysisTO.setConsultSpecialist(rs
						.getString("consult_specialist"));
				customerHealthanalysisTO.setDiagnostic(rs
						.getString("diagnostic"));
				customerHealthanalysisTO.setPharmacy(rs.getString("pharmacy"));
				customerHealthanalysisTO.setHospitalization(rs
						.getString("hospitalization"));
				customerHealthanalysisTO.setConsultation(rs
						.getString("consultation"));
				customerHealthanalysisTO.setCustHeight(rs
						.getString("cust_height"));
				customerHealthanalysisTO.setCustWeight(rs
						.getString("cust_weight"));
				customerHealthanalysisTO
						.setInsurance(rs.getString("insurance"));
				customerHealthanalysisTO.setPremium(rs.getString("premium"));
				customerHealthanalysisTO.setSick(rs.getString("sick"));
				customerHealthanalysisTO.setHealthCheck(rs
						.getString("health_check"));
				customerHealthanalysisTO.setVisitDentist(rs
						.getString("visit_dentist"));
				customerHealthanalysisTO.setMedicinFollow(rs
						.getString("medicin_follow"));
				customerHealthanalysisTO.setSmoke(rs.getString("smoke"));
				customerHealthanalysisTO.setFoodHabits(rs
						.getString("food_habits"));
				customerHealthanalysisTO.setCustSuffer(rs
						.getString("cust_suffer"));
				customerHealthanalysisTO.setParentsSuffer(rs
						.getString("parents_suffer"));
				customerHealthanalysisTO.setExercise(rs.getString("exercise"));
				customerHealthanalysisTO.setAlcohol(rs.getString("alcohol"));
				customerHealthanalysisTO.setStressfull(rs
						.getString("stressfull"));
				customerHealthanalysisTO.setSleep(rs.getString("sleep"));
				customerHealthanalysisTO.setMedicalHistory(rs
						.getString("medical_history"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return customerHealthanalysisTO;
	}

	public ArrayList<HashMap<String, String>> getCustomerPayment(int id) {
		ArrayList<HashMap<String, String>> custPayList = new ArrayList<>();

		try {
			String s = "SELECT * FROM payment_details WHERE transaction_id = '"
					+ id + "' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("paymentId", rs.getString("payment_id"));
				list.put("amount", rs.getString("amount"));
				list.put("prensentedDate", rs.getString("prensented_date"));
				list.put("approvalDate", rs.getString("approval_date"));
				list.put("bank", rs.getString("bank"));
				list.put("chequeDate", rs.getString("cheque_date"));
				list.put("chequeAuthCode", rs.getString("cheque_auth_code"));
				list.put("modeOfPayment", rs.getString("mode_of_payment"));
				list.put("terminalNumber", rs.getString("terminal_number"));
				list.put("status", rs.getString("status"));
				custPayList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custPayList;
	}

	@Override
	public List<CustomerFamilyDTO> getFamily(Integer id) {
		List<CustomerFamilyDTO> custFamily = new ArrayList<>();

		try {
			String s = "SELECT * FROM customer_family WHERE customer_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				CustomerFamilyDTO customerFamilyDTO = new CustomerFamilyDTO();
				customerFamilyDTO.setFamilyId(rs.getInt("family_id"));
				customerFamilyDTO.setFName(rs.getString("f_name"));
				customerFamilyDTO.setGender(rs.getString("gender"));
				customerFamilyDTO.setRelationship(rs.getString("relationship"));
				customerFamilyDTO.setAge(rs.getString("age"));
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					customerFamilyDTO.setDob(sdf.format(rs.getDate("dob")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				custFamily.add(customerFamilyDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custFamily;
	}

	public <T> void upDateAdmin(T entity) {
		hibernateUtil.update(entity);
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllHospital(String city) {
		ArrayList<HashMap<String, String>> hospitalDeatils = new ArrayList<>();
		try {
			String s = "SELECT * FROM empanellment hosp WHERE hosp.city = '"
					+ city + "' AND hosp.isActive = TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("hospitalId", rs.getString("hospital_id"));
				list.put("nameHcc", rs.getString("name_hcc"));
				list.put("empanelledDate", rs.getString("empanelled_date"));
				list.put("address", rs.getString("address"));
				list.put("city", rs.getString("city"));
				list.put("location", rs.getString("location"));
				hospitalDeatils.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return hospitalDeatils;
	}

	@Override
	public List<AddressTO> getAll(Integer addressId) {
		List<AddressTO> address = new ArrayList<>();

		try {
			String s = "SELECT * FROM address WHERE aid = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, addressId);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				AddressTO AddressTO = new AddressTO();
				AddressTO.setResidenceAddresss(rs
						.getString("Residence_addresss"));
				AddressTO.setCity(rs.getString("city"));
				AddressTO.setPrimaryMob(rs.getString("primary_mob"));
				AddressTO.setLandline(rs.getString("landline"));
				AddressTO.setEmail(rs.getString("email"));
				AddressTO.setPincode(rs.getString("pincode"));
				address.add(AddressTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return address;
	}

	public List<AddressDTO> getAddressEntityId(Integer entityId) {
		List<AddressDTO> address = new ArrayList<>();

		// System.out.println("inside Dao impl"+entityId);
		try {
			String s = "SELECT * FROM address WHERE entity_id = '" + entityId
					+ "' AND address_type_id IN (1,2,3) ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			// prepareStatement.setInt(1, entityId);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				AddressDTO AddressTO = new AddressDTO();
				AddressTO.setAid(rs.getInt("aid"));
				AddressTO.setResidenceAddresss(rs
						.getString("Residence_addresss"));
				AddressTO.setCity(rs.getString("city"));
				AddressTO.setLandmark(rs.getString("landmark"));
				AddressTO.setLandline(rs.getString("landline"));
				AddressTO.setEmail(rs.getString("email"));
				AddressTO.setPrimaryMob(rs.getString("primary_mob"));
				AddressTO.setAltMob(rs.getString("alt_mob"));
				AddressTO.setPincode(rs.getString("pincode"));
				AddressTO.setEntityId(rs.getInt("entity_id"));
				AddressTO.setAddressCategory(rs.getInt("address_type_id"));
				address.add(AddressTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return address;
	}

	@Override
	public EmpanellmentTO getHospitalById(Integer id) {
		return hibernateUtil.fetchById(id, EmpanellmentTO.class);
	}

	@Override
	public HospitalServiceTO getHospitalServicelById(Integer id) {
		HospitalServiceTO hospitalServiceTO = new HospitalServiceTO();
		try {
			String s = "SELECT * FROM hospital_service WHERE hospital_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				hospitalServiceTO.setAmount(rs.getDouble("amount"));
				// hospitalServiceTO.setServices((ServicesTO)rs.getObject("service_id"));
				hospitalServiceTO.setId(rs.getInt("id"));
				hospitalServiceTO.setServiceCategory(rs
						.getString("service_category"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return hospitalServiceTO;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllServiceForHospital(Integer hospitalId) {
		ArrayList<HashMap<String, String>> services = new ArrayList<>();
		try {
			String s = "SELECT service_id ,category, service_name,service_description FROM services WHERE isActive IS TRUE AND service_id NOT IN "
					+ " (SELECT service_id FROM hospital_service WHERE hospital_id = "+hospitalId+") ORDER BY category";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("serviceId", rs.getString("service_id"));
				list.put("category", rs.getString("category"));
				list.put("serviceName", rs.getString("service_name"));
				list.put("serviceDescription",
						rs.getString("service_description"));

				services.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return services;
	}

	@Override
	public List<HealthAppointmentDTO> getAllAppointments(
			HealthAppointmentDTO healthAppointmentDTO) {
		List<HealthAppointmentDTO> appointment = new ArrayList<>();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		String date = null;
		String date1 = null;
		try {
			date = formatter.format(sdf.parse(healthAppointmentDTO
					.getAppointmentDate()));
			date1 = formatter.format(sdf.parse(healthAppointmentDTO
					.getAppointmentTime()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT * FROM service_utilization "
					+ "WHERE Appt_Date BETWEEN '" + date + "' AND '" + date1
					+ "' AND Appt_Status LIKE '%"
					+ healthAppointmentDTO.getStatusAppointment()
					+ "%' AND Service LIKE '%"
					+ healthAppointmentDTO.getServiceName() + "%'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HealthAppointmentDTO health = new HealthAppointmentDTO();
				health.setAppointmentId(rs.getInt("appointment_id"));
				health.setTransactionId(rs.getInt("transaction_id"));
				health.setCustomerId(rs.getInt("customer_id"));
				health.setAppointmentDate(rs.getString("Appt_Date"));
				health.setAppointmentTime(rs.getString("Appt_Time"));
				health.setCustomerName(rs.getString("Customer_Name"));
				health.setStatusAppointment(rs.getString("Appt_Status"));
				health.setNameHcc(rs.getString("ServiceCentre"));
				health.setServiceName(rs.getString("Service"));
				health.setAppointmnetFor(rs.getString("Appt_For"));
				health.setProductName(rs.getString("ProductName"));
				health.setSource(rs.getString("source"));

				appointment.add(health);
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return appointment;
	}

	@Override
	public ServicesTO getAllServices(Integer serviceId) {
		ServicesTO serviceTO = new ServicesTO();
		try {
			String s = "SELECT * FROM services WHERE service_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, serviceId);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				serviceTO.setServiceId(rs.getInt("service_id"));
				serviceTO.setServiceName(rs.getString("service_name"));
				serviceTO.setCategory(rs.getString("category"));
				serviceTO.setIsActive(rs.getInt("isActive"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return serviceTO;
	}

	@Override
	public HealthAppointmentTO getAppointmentById(Integer id) {
		return hibernateUtil.fetchById(id, HealthAppointmentTO.class);
	}

	@Override
	public List<CustomerReferencesDTO> getCustRefrence(Integer id) {
		List<CustomerReferencesDTO> custRefrence = new ArrayList<>();

		try {
			String s = "SELECT * FROM customer_references WHERE customer_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				CustomerReferencesDTO customerReferencesDTO = new CustomerReferencesDTO();
				customerReferencesDTO.setSl(rs.getInt("reference_id"));
				customerReferencesDTO.setName(rs.getString("name"));
				customerReferencesDTO.setRelationship(rs
						.getString("relationship"));
				customerReferencesDTO.setContactNumber(rs
						.getString("contact_number"));
				custRefrence.add(customerReferencesDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custRefrence;
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<HospitalServiceDTO> getAllServiceByHid(Integer Hid) {
		List<HospitalServiceDTO> serviceList = new ArrayList<>();

		try {
			String s = "SELECT hos.id,hos.service_id,ser.service_name,ser.category,hos.service_start_date,hos.service_end_date FROM hospital_service hos "
					+ " LEFT JOIN services ser ON ser.service_id = hos.service_id  WHERE hos.hospital_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, Hid);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HospitalServiceDTO hospitalTo = new HospitalServiceDTO();
				hospitalTo.setId(rs.getInt("id"));
				hospitalTo.setServiceCategory(rs.getString("category"));
				hospitalTo.setServiceName(rs.getString("service_name"));
				hospitalTo.setServiceId(rs.getInt("service_id"));
				hospitalTo.setServiceStartDate(rs.getDate("service_start_date"));
				hospitalTo.setServiceEndDate(rs.getDate("service_end_date"));
				serviceList.add(hospitalTo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return serviceList;
	}

	@Override
	public List<TransactionMasterDTO> getAlltransaction(
			TransactionMasterTO masterTO) {
		List<TransactionMasterDTO> transctionDetails = new ArrayList<>();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		String date = null;
		String date1 = null;
		try {
			date = formatter.format(sdf.parse(masterTO.getPaymentStatus()));
			date1 = formatter.format(sdf.parse(masterTO.getCardNumber()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT tm.transaction_id, tm.application_No AS 'App. No', cust.customer_name AS 'Customer Name', pm.product_name AS 'Product',"
					+ "tm.amount AS 'Amount', tm.tx_status AS 'App. Status', tm.collected_date AS 'Collected Date',"
					+ "tm.card_number AS 'Card No.', csrs.emp_name AS 'CSR Name', exe.emp_name AS 'Executive Name', team.team_name AS 'Team Name',"
					+ "chn.channels_name AS 'Channel Name', pay.`mode_of_payment` AS 'Payment Mode', pay.cheque_auth_code AS 'Cheque No.',"
					+ "pay.terminal_number AS 'Swipe Terminal', pay.approval_date AS 'Approved On',"
					+ "tm.customer_id, tm.csr, tm.executive, tm.channel, tm.team, tm.product_id FROM transaction_master tm "
					+ "LEFT JOIN payment_details pay ON tm.transaction_id = pay.transaction_id LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN product_master pm ON tm.product_id = pm.product_id "
					+ "LEFT JOIN employee_details csrs ON tm.csr = csrs.emp_id "
					+ "LEFT JOIN employee_details exe ON tm.executive = exe.emp_id "
					+ "LEFT JOIN channels chn ON tm.channel = chn.channel_id "
					+ "LEFT JOIN teams team ON tm.team = team.team_id WHERE `collected_date` BETWEEN '"
					+ date
					+ "' AND '"
					+ date1
					+ "' "
					+ "AND `tx_status`LIKE '%" + masterTO.getTxStatus() + "%' ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				TransactionMasterDTO txDTO = new TransactionMasterDTO();
				txDTO.setTransactionId(rs.getInt("transaction_id"));
				txDTO.setApplicationNo(rs.getString("App. No"));
				txDTO.setCardNumber(rs.getString("Card No."));
				txDTO.setCsr(rs.getString("CSR Name"));
				txDTO.setAmount(rs.getFloat("Amount"));
				txDTO.setCollectedDate(rs.getString("Collected Date"));
				txDTO.setPaymentStatus(rs.getString("Payment Mode"));
				txDTO.setExecutive(rs.getString("Executive Name"));
				txDTO.setCsr(rs.getString("CSR Name"));
				// txDTO.setRemarks(rs.getString("Customer Name"));
				txDTO.setTerminalNumber(rs.getString("Team Name"));
				txDTO.setTxStatus(rs.getString("App. Status"));
				txDTO.setProductName(rs.getString("Product"));
				txDTO.setCustomerName(rs.getString("Customer Name"));
				transctionDetails.add(txDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transctionDetails;
	}

	@Override
	public ProductMasterTO getproductById(Integer id) {
		return hibernateUtil.fetchById(id, ProductMasterTO.class);
	}

	@Override
	public List<TransactionMasterDTO> getAllPayments(
			TransactionMasterTO masterTO) {
		List<TransactionMasterDTO> transctionDetails = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		String date = null;
		String date1 = null;
		try {
			date = formatter.format(sdf.parse(masterTO.getPaymentStatus()));
			date1 = formatter.format(sdf.parse(masterTO.getCardNumber()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT  tm.application_No AS 'App. No', cust.customer_name AS 'Customer Name', pm.product_name AS 'Product',"
					+ "pay.amount AS 'Amount', pay.`mode_of_payment` AS 'Payment Mode',  pay.approval_date AS 'Approved On',pay.`payment_id` "
					+ "AS 'Payment Id', pay.`status`AS 'App Sttaus',pay.`bank`AS 'Bank Details',pay.`cheque_auth_code`AS 'Cheque/Auth.No',pay.`prensented_date` AS 'Present Date' "
					+ "FROM  payment_details pay LEFT JOIN transaction_master tm ON tm.transaction_id = pay.transaction_id "
					+ "LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN product_master pm ON tm.product_id = pm.product_id "
					+ "WHERE pay.created_date BETWEEN CONCAT('"
					+ date
					+ "', ' 00:00:00') AND CONCAT('"
					+ date1
					+ "', ' 23:59:59') AND STATUS LIKE '%"
					+ masterTO.getTxStatus() + "%'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				TransactionMasterDTO txDTO = new TransactionMasterDTO();
				txDTO.setTransactionId(rs.getInt("Payment Id"));
				txDTO.setApplicationNo(rs.getString("App. No"));
				txDTO.setCardNumber(rs.getString("Cheque/Auth.No"));
				txDTO.setCsr(rs.getString("Bank Details"));
				txDTO.setAmount(rs.getFloat("Amount"));
				txDTO.setCollectedDate(rs.getString("Present Date"));
				txDTO.setPaymentStatus(rs.getString("Payment Mode"));
				// txDTO.setExecutive(rs.getString("Executive Name"));
				// txDTO.setCsr(rs.getString("CSR Name"));
				txDTO.setTxStatus(rs.getString("App Sttaus"));
				txDTO.setProductName(rs.getString("Product"));
				txDTO.setCustomerName(rs.getString("Customer Name"));
				transctionDetails.add(txDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transctionDetails;
	}

	public List<TransactionMasterDTO> getPaymentsBulkOperation() {
		// List<PaymentDetailsTO> paymentDetails = new ArrayList<>();
		List<TransactionMasterDTO> transctionDetails = new ArrayList<>();
		try {
			String s = "SELECT pay.payment_id,tm.transaction_id, tm.application_No AS 'App. No', cust.customer_name AS 'Customer Name', pm.product_name AS "
					+ " 'Product', pay.`mode_of_payment` AS 'Payment Mode', tm.amount AS 'Amount', pay.`status` AS 'Payment Status', pay.`bank` AS 'Bank',pay.cheque_auth_code,"
					+ "tm.tx_status AS 'App. Status', tm.collected_date AS 'Collected Date', pay.cheque_date, pay.cheque_auth_code AS 'Cheque No.',"
					+ "pay.terminal_number AS 'Swipe Terminal', pay.approval_date AS 'Approved On', tm.card_number AS 'Card No.', tm.customer_id "
					+ "FROM transaction_master tm "
					+ "LEFT JOIN payment_details pay ON tm.transaction_id = pay.transaction_id "
					+ "LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN product_master pm ON tm.product_id = pm.product_id "
					+ "WHERE pay.mode_of_payment IN ('Cheque') AND pay.status IN ('Not Approved', 'New') AND pay.cheque_date <= CURRENT_DATE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				TransactionMasterDTO txDTO = new TransactionMasterDTO();
				txDTO.setPaymentId(rs.getInt("payment_id"));
				txDTO.setApplicationNo(rs.getString("App. No"));
				txDTO.setBank(rs.getString("Bank"));
				txDTO.setAmount(rs.getFloat("Amount"));
				txDTO.setPaymentStatus(rs.getString("Payment Mode"));
				txDTO.setProductName(rs.getString("Product"));
				txDTO.setCustomerName(rs.getString("Customer Name"));
				txDTO.setModeOfPayment(rs.getString("Payment Mode"));
				txDTO.setCollectedDate(rs.getString("Collected Date"));
				txDTO.setCardNumber(rs.getString("cheque_auth_code"));
				txDTO.setStatus(rs.getString("Payment Status"));
				transctionDetails.add(txDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transctionDetails;
	}

	public List<TransactionMasterDTO> getPaymentsBulkOperationForOthers() {
		List<TransactionMasterDTO> transctionDetails = new ArrayList<>();
		try {
			String s = "SELECT pay.payment_id,tm.transaction_id, tm.application_No AS 'App. No', cust.customer_name AS 'Customer Name', pm.product_name AS "
					+ " 'Product', pay.`mode_of_payment` AS 'Payment Mode', tm.amount AS 'Amount', pay.`status` AS 'Payment Status', pay.`bank` AS 'Bank',pay.cheque_auth_code,"
					+ "tm.tx_status AS 'App. Status', tm.collected_date AS 'Collected Date', pay.cheque_date, pay.cheque_auth_code AS 'Cheque No.',"
					+ "pay.terminal_number AS 'Swipe Terminal', pay.approval_date AS 'Approved On', tm.card_number AS 'Card No.', tm.customer_id "
					+ "FROM transaction_master tm "
					+ "LEFT JOIN payment_details pay ON tm.transaction_id = pay.transaction_id "
					+ "LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN product_master pm ON tm.product_id = pm.product_id "
					+ "WHERE  ( (pay.mode_of_payment IN ('Cheque') AND pay.status IN ('Cheque Presented', 'Not Approved', 'In Bank', 'New')) OR "
					+ " (pay.mode_of_payment NOT IN ('Cheque') AND pay.status NOT IN ('Payment Approved', 'Cancelled', 'Not Approved','Cheque Returned','Payment Resubmitted')))";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				TransactionMasterDTO txDTO = new TransactionMasterDTO();
				txDTO.setPaymentId(rs.getInt("payment_id"));
				txDTO.setApplicationNo(rs.getString("App. No"));
				txDTO.setBank(rs.getString("Bank"));
				txDTO.setAmount(rs.getFloat("Amount"));
				txDTO.setPaymentStatus(rs.getString("Payment Mode"));
				txDTO.setProductName(rs.getString("Product"));
				txDTO.setCustomerName(rs.getString("Customer Name"));
				txDTO.setModeOfPayment(rs.getString("Payment Mode"));
				txDTO.setCollectedDate(rs.getString("Collected Date"));
				txDTO.setCardNumber(rs.getString("cheque_auth_code"));
				txDTO.setStatus(rs.getString("Payment Status"));
				transctionDetails.add(txDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return transctionDetails;
	}

	@Override
	public TransactionMasterTO getTxById(Integer id) {
		return hibernateUtil.fetchById(id, TransactionMasterTO.class);
	}

	@Override
	public PaymentDetailsTO getPaymentById(Integer id) {
		return hibernateUtil.fetchById(id, PaymentDetailsTO.class);
	}

	@Override
	public List<DispatchTrackingDTO> getAllDispatchTracks(
			DispatchTrackingDTO dispatchDTO1) {
		List<DispatchTrackingDTO> dispatchTrack = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		String date = null;
		String date1 = null;
		try {
			date = formatter.format(sdf.parse(dispatchDTO1.getCreatedBy()));
			date1 = formatter.format(sdf.parse(dispatchDTO1.getDispatchDate()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT dis.track_id, tm.application_No AS 'App. No', cust.customer_name AS 'Customer Name', tm.card_number AS 'Card No.', "
					+ "dis.dispatch_date AS 'Dispatched On', dis.dispatch_through 'Sent thru', dis.consignment_reference "
					+ "'Consignment No.', dis.delivery_status AS 'Delivery Status', dis.recevied_by 'Received By', dis.dispatch_status,dis.`created_date`,prod.`product_name` AS 'Product Name' "
					+ "FROM dispatch_tracking dis "
					+ "LEFT JOIN transaction_master tm ON dis.transaction_id = tm.transaction_id "
					+ "LEFT JOIN customer_deatils cust ON tm.customer_id = cust.customer_id "
					+ "LEFT JOIN `product_master` prod ON tm.`product_id` = prod.`product_id`"
					+ "WHERE dis.`created_date` BETWEEN CONCAT('"
					+ date
					+ "', ' 00:00:00') AND CONCAT('"
					+ date1
					+ "', ' 23:59:59') AND (dis.`delivery_status` IS NULL OR dis.`delivery_status` LIKE '%"
					+ dispatchDTO1.getDispatchStatus() + "%')";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				DispatchTrackingDTO dispatchDTO = new DispatchTrackingDTO();
				dispatchDTO.setTrackId(rs.getInt("track_id"));
				dispatchDTO.setApplicationNo(rs.getString("App. No"));
				dispatchDTO.setCardNumber(rs.getString("Card No."));
				dispatchDTO.setCustomerName(rs.getString("Customer Name"));
				dispatchDTO.setDispatchDate(rs.getString("Dispatched On"));
				dispatchDTO.setDispatchThrough(rs.getString("Sent thru"));
				dispatchDTO.setConsignmentReference(rs
						.getString("Consignment No."));
				dispatchDTO.setDeliveryStatus(rs.getString("Delivery Status"));
				dispatchDTO.setDispatchStatus(rs.getString("dispatch_status"));
				dispatchDTO.setCreatedBy(rs.getString("Product Name"));
				dispatchTrack.add(dispatchDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dispatchTrack;
	}

	@Override
	public DispatchTrackingTO getDispatchTrackById(Integer id) {
		return hibernateUtil.fetchById(id, DispatchTrackingTO.class);
	}

	@Override
	public List<PresalesTO> getAllpresales() {
		List<PresalesTO> presales = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(PresalesTO.class,
				"presales");
		@SuppressWarnings("unchecked")
		Collection<? extends PresalesTO> theUserList = (Collection<? extends PresalesTO>) theCriteria
				.list();

		presales.addAll(theUserList);
		return presales;
	}

	public PresalesTO getPresalesById(Integer id) {
		return hibernateUtil.fetchById(id, PresalesTO.class);
	}

	@Override
	public HashMap<String, String> getPresalesThrId(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT pre.*,prod.product_name,addr.Residence_addresss, addr.city,addr.pincode , addr.primary_mob,emp.emp_name AS 'CSR Name',"
					+ "emp1.emp_name AS 'Executive Name',team.team_name AS 'Team',chanl.channels_name FROM presales pre "
					+ "LEFT JOIN product_master prod ON prod.product_id = pre.product_intrested  LEFT JOIN address addr ON addr.aid = pre.aid "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = pre.csr  LEFT JOIN employee_details emp1 ON emp1.emp_id = pre.executive "
					+ "LEFT JOIN teams team ON team.team_id = pre.team_name LEFT JOIN channels chanl ON chanl.channel_id = pre.channel"
					+ "  WHERE pre.leads_id = '" + id + "' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("leadsId", rs.getString("leads_id"));
				list.put("customerName", rs.getString("customer_name"));
				try {
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					list.put("dateAppointment",
							sdf.format(rs.getDate("date_appointment")));
				} catch (NullPointerException e) {
					e.printStackTrace();
				}
				list.put("productIntrested", rs.getString("product_intrested"));
				list.put("csr", rs.getString("csr"));
				list.put("teamName", rs.getString("team_name"));
				list.put("channel", rs.getString("channel"));
				list.put("timeAppointment", rs.getString("time_appointment"));
				list.put("executive", rs.getString("executive"));
				list.put("appointmentType", rs.getString("appointment_type"));
				list.put("status", rs.getString("status"));
				list.put("meetingStatus", rs.getString("meeting_status"));
				list.put("reasons", rs.getString("reasons"));
				list.put("remark", rs.getString("remark"));
				list.put("aid", rs.getString("aid"));
				list.put("createdDate", rs.getString("created_date"));
				list.put("productName", rs.getString("product_name"));
				list.put("residenceAddresss",
						rs.getString("Residence_addresss"));
				list.put("city", rs.getString("city"));
				list.put("pincode", rs.getString("pincode"));
				list.put("primaryMob", rs.getString("primary_mob"));
				list.put("CSRName", rs.getString("CSR Name"));
				list.put("executiveName", rs.getString("Executive Name"));
				list.put("teamNames", rs.getString("Team"));
				list.put("channelsName", rs.getString("channels_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllProducts() {
		ArrayList<HashMap<String, String>> productList = new ArrayList<>();

		try {
			String s = "SELECT * FROM product_master WHERE CURRENT_DATE BETWEEN start_date AND valid_till ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("productId", rs.getString("product_id"));
				list.put("productName", rs.getString("product_name"));
				list.put("productPrice", rs.getString("product_price"));
				list.put("startDate", rs.getString("start_date"));
				list.put("validTill", rs.getString("valid_till"));
				list.put("prodidCcavenue", rs.getString("prodid_ccavenue"));
				list.put("isActive", rs.getString("is_active"));

				productList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return productList;
	}

	@Override
	public List<ChannelsTO> getAllChannels() {
		List<ChannelsTO> channelList = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(ChannelsTO.class,
				"channelList");
		@SuppressWarnings("unchecked")
		Collection<? extends ChannelsTO> theUserList = (Collection<? extends ChannelsTO>) theCriteria
				.list();

		channelList.addAll(theUserList);
		return channelList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllCollections() {
		ArrayList<HashMap<String, String>> collectionList = new ArrayList<>();
		try {
			String s = "SELECT coll.*,prod.product_name,pre.customer_name,emp.emp_name AS 'Executive Name',emp1.emp_name AS 'CSR Name',"
					+ "team.team_name,chan.channels_name FROM collection coll  LEFT JOIN product_master prod ON prod.product_id = coll.product_id "
					+ " LEFT JOIN presales pre ON pre.leads_id = coll.leads_id LEFT JOIN employee_details emp ON emp.emp_id = coll.executive "
					+ "LEFT JOIN employee_details emp1 ON emp1.emp_id = coll.csr  LEFT JOIN teams team ON team.team_id = coll.team "
					+ "LEFT JOIN channels chan ON chan.channel_id = coll.channel  WHERE coll.`transaction_id` IS NULL";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("collectionId", rs.getString("collection_id"));
				list.put("customerName", rs.getString("customer_name"));
				list.put("productName", rs.getString("product_name"));
				list.put("productPrice", rs.getString("price"));
				list.put("paymentMode", rs.getString("payment_mode"));
				list.put("csr", rs.getString("CSR Name"));
				list.put("channelName", rs.getString("channels_name"));
				list.put("executive", rs.getString("Executive Name"));
				list.put("colectedDate", rs.getString("colected_date"));
				collectionList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return collectionList;
	}

	@Override
	public CollectionTO getCollectionById(Integer id) {
		return hibernateUtil.fetchById(id, CollectionTO.class);
	}

	@Override
	public List<EmployeeDTO> getAllEmployeeDetails(String designation) {
		List<EmployeeDTO> employeeList = new ArrayList<>();
		try {
			String s = "SELECT emp_id, emp_name, business_unit, department, section, designation  "
					+ " FROM employment_history WHERE CURRENT_DATE < to_date AND designation "
					+ designation + " ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				EmployeeDTO EmployeeDTO = new EmployeeDTO();
				EmployeeDTO.setEmpId(rs.getString("emp_id"));
				EmployeeDTO.setEmpName(rs.getString("emp_name"));
				EmployeeDTO.setExtensionNumber(rs.getString("designation"));
				employeeList.add(EmployeeDTO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeList;
	}

	@Override
	public List<TeamsTO> getAllTeamName() {
		List<TeamsTO> teamList = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session
				.createCriteria(TeamsTO.class, "teamList");
		@SuppressWarnings("unchecked")
		Collection<? extends TeamsTO> theUserList = (Collection<? extends TeamsTO>) theCriteria
				.list();

		teamList.addAll(theUserList);
		return teamList;
	}

	@Override
	public EmployeeDTO getEmployeeId(String empId) {
		EmployeeDTO EmployeeDTO = new EmployeeDTO();
		try {
			String s = "SELECT * FROM employee WHERE emp_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setString(1, empId);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				EmployeeDTO.setSlEmp(rs.getInt("team_id"));
				EmployeeDTO.setEmpId(rs.getString("emp_id"));
				EmployeeDTO.setEmpName(rs.getString("emp_name"));
				EmployeeDTO
						.setExtensionNumber(rs.getString("extension_number"));
				EmployeeDTO.setRoleType(rs.getString("role_type"));
				EmployeeDTO.setEmpMobile(rs.getString("emp_mobile"));
				EmployeeDTO.setEmpEmail(rs.getString("emp_email"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return EmployeeDTO;
	}

	@Override
	public ChannelsTO getChannelName(Integer id) {
		return hibernateUtil.fetchById(id, ChannelsTO.class);
	}

	@Override
	public TeamsTO getTeamName(Integer id) {
		return hibernateUtil.fetchById(id, TeamsTO.class);
	}

	@Override
	public List<AddressCatagoriesTO> getAllAddressCatagories() {
		List<AddressCatagoriesTO> addressTypeList = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(
				AddressCatagoriesTO.class, "addressTypeList");
		@SuppressWarnings("unchecked")
		Collection<? extends AddressCatagoriesTO> theUserList = (Collection<? extends AddressCatagoriesTO>) theCriteria
				.list();

		addressTypeList.addAll(theUserList);
		return addressTypeList;
	}

	@Override
	public AddressDTO getAllAddress(Integer entityId, String addressType) {
		AddressDTO AddressDTO = new AddressDTO();

		AddressCatagoriesTO addrsCatag = new AddressCatagoriesTO();
		try {
			String s1 = "SELECT * FROM address_catagories WHERE  address_type = ?";
			Connection connection1 = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement1;
			prepareStatement1 = connection1.prepareStatement(s1);
			prepareStatement1.setString(1, addressType);
			ResultSet rs1 = prepareStatement1.executeQuery();
			while (rs1.next()) {
				addrsCatag.setAddressTypeId(rs1.getInt("address_type_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		Integer addressTypeId = addrsCatag.getAddressTypeId();
		try {
			String s = "SELECT * FROM address WHERE entity_id = ? AND address_type_id = ?";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, entityId);
			prepareStatement.setInt(2, addressTypeId);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				AddressDTO.setAid(rs.getInt("aid"));
				AddressDTO.setResidenceAddresss(rs
						.getString("Residence_addresss"));
				AddressDTO.setCity(rs.getString("city"));
				AddressDTO.setPrimaryMob(rs.getString("primary_mob"));
				AddressDTO.setAltMob(rs.getString("alt_mob"));
				AddressDTO.setLandline(rs.getString("landline"));
				AddressDTO.setEmail(rs.getString("email"));
				AddressDTO.setPincode(rs.getString("pincode"));
				AddressDTO.setLandmark(rs.getString("landmark"));
				AddressDTO.setAddressCategory(rs.getInt("address_type_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return AddressDTO;
	}

	@Override
	public List<ExternalIdDTO> getProofId(Integer id) {

		List<ExternalIdDTO> idProof = new ArrayList<>();

		try {
			String s = "SELECT * FROM external_id WHERE customer_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				ExternalIdDTO idProofDto = new ExternalIdDTO();
				idProofDto.setProofId(rs.getInt("proof_id"));
				idProofDto.setIdType(rs.getString("id_type"));
				idProofDto.setIdNumber(rs.getString("id_number"));
				idProof.add(idProofDto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return idProof;

	}

	@Override
	public AddressCatagoriesTO getAddressTypeId(Integer id) {
		return hibernateUtil.fetchById(id, AddressCatagoriesTO.class);
	}

	@Override
	public HashMap<String, String> getApplicationNoTx(String applicationNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM transaction_master WHERE application_No = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setString(1, applicationNo);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("transactionId", rs.getString("transaction_id"));
				list.put("applicationNo", rs.getString("application_No"));
				list.put("cardNumber", rs.getString("card_number"));
				list.put("customerId", rs.getString("customer_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<ProductOffersDTO> getAllProductSevice(Integer id) {
		List<ProductOffersDTO> offersList = new ArrayList<>();

		try {
			String s = "SELECT * FROM product_offers WHERE product_id = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, id);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				ProductOffersDTO productOffres = new ProductOffersDTO();
				productOffres.setOfferId(rs.getInt("offer_id"));
				productOffres.setServicesId(rs.getInt("service_id"));
				productOffres.setProductId(rs.getInt("product_id"));
				productOffres.setQuantity(rs.getInt("quantity"));
				offersList.add(productOffres);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return offersList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllTxOffers(Integer id) {
		ArrayList<HashMap<String, String>> allTxOffers = new ArrayList<>();

		try {
			String s = "SELECT DISTINCT track.transaction_id,offers.txoffer_id,offers.service_id,offers.quantity,offers.voucher_no,"
					+ " ser.category,ser.service_name,offers.usage_id FROM dispatch_tracking track "
					+ " LEFT JOIN transaction_offers offers ON offers.transaction_id = track.transaction_id "
					+ " LEFT JOIN services ser ON ser.service_id = offers.service_id  WHERE track.transaction_id ='"
					+ id + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> txOffres = new HashMap<String, String>();
				txOffres.put("txofferId", rs.getString("txoffer_id"));
				txOffres.put("transactionId", rs.getString("transaction_id"));
				txOffres.put("serviceId", rs.getString("service_id"));
				txOffres.put("category", rs.getString("category"));
				txOffres.put("serviceName", rs.getString("service_name"));
				txOffres.put("usageId", rs.getString("usage_id"));
				txOffres.put("quantity", rs.getString("quantity"));
				txOffres.put("voucherNo", rs.getString("voucher_no"));
				allTxOffers.add(txOffres);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return allTxOffers;
	}

	@Override
	public List<DaywiseCallsIdDTO> getAllDailyCalls() {
		List<DaywiseCallsIdDTO> dailyCallsDeatils = new ArrayList<>();
		try {
			String s = "SELECT * FROM daywise_calls ORDER BY 1 DESC";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				DaywiseCallsIdDTO calls = new DaywiseCallsIdDTO();
				calls.setCallDate(rs.getString("Call_Date"));
				calls.setTotalCalls(rs.getLong("Total_Calls"));
				calls.setTotalDuration(rs.getString("Total_Duration"));
				calls.setPresentations(rs.getBigDecimal("Presentations"));
				dailyCallsDeatils.add(calls);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dailyCallsDeatils;
	}

	@Override
	public List<ApplicationStockTO> getAllApplicationNo(String status) {
		List<ApplicationStockTO> applicationNo = new ArrayList<>();
		try {
			String s = "SELECT * FROM application_stock WHERE STATUS = '"
					+ status + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				ApplicationStockTO appls = new ApplicationStockTO();
				appls.setApplicationNo((rs.getString("application_no")));
				appls.setStatus(rs.getString("status"));
				// appls.setTotalCalls(rs.getLong("phone_no"));
				// appls.setTotalDuration(rs.getString("duration"));
				applicationNo.add(appls);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return applicationNo;
	}

	@Override
	public void getUpdateApplnStatus(String applicationNo, String status) {
		try {
			String s = "UPDATE application_stock SET STATUS =  '" + status
					+ "' WHERE application_no ='" + applicationNo + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			int executeUpdate = prepareStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public HashMap<String, String> getHospitalServices(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT hos.id, hos.service_id,hos.hospital_id,ser.service_name,ser.category,hos.service_start_date,hos.service_end_date FROM hospital_service hos "
					+ " LEFT JOIN services ser ON ser.service_id = hos.service_id  WHERE hos.id  = '"+id+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("id", rs.getString("id"));
				list.put("serviceId", rs.getString("service_id"));
				list.put("category", rs.getString("category"));
				list.put("serviceStartDate", rs.getString("service_start_date"));
				list.put("serviceEndDate", rs.getString("service_end_date"));
				list.put("serviceName", rs.getString("service_name"));
				list.put("hospitalId", rs.getString("hospital_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<ExtensionDetailsTO> geteExtensionDetails() {
		List<ExtensionDetailsTO> extensionList = new ArrayList<>();
		try {
			String s = "SELECT * FROM extension_details WHERE CURRENT_DATE BETWEEN from_date AND to_date ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				ExtensionDetailsTO extension = new ExtensionDetailsTO();
				extension.setId(rs.getInt("id"));
				extension.setEmpId(rs.getString("emp_id"));
				extension.setChannel(rs.getInt("channel"));
				extension.setExtensionNo(rs.getInt("extension_No"));
				extension.setTeam(rs.getInt("team"));
				extensionList.add(extension);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return extensionList;
	}

	@Override
	public List<PresalesTO> SearchPresales(Integer Aid) {
		List<PresalesTO> presalesTO = new ArrayList<>();
		try {
			String s = "SELECT * FROM presales_appts WHERE aid = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			prepareStatement.setInt(1, Aid);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				PresalesTO presalesTO2 = new PresalesTO();
				presalesTO2.setLeadsId(rs.getInt("leads_id"));
				presalesTO2.setCustomerName(rs.getString("customer_name"));
				presalesTO2.setDateAppointment(rs.getDate("date_appointment"));
				presalesTO2
						.setTimeAppointment(rs.getString("time_appointment"));
				presalesTO2.setProductIntrested(rs.getString("product_name"));
				presalesTO2.setRemark(rs.getString("channels_name"));
				// presalesTO2.setCsr(rs.getString("csr_name"));
				presalesTO2.setStatus(rs.getString("status"));
				presalesTO2
						.setAppointmentType(rs.getString("appointment_type"));
				// presalesTO2.setExecutive(rs.getString("executive_name"));
				presalesTO.add(presalesTO2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return presalesTO;
	}

	@Override
	public ArrayList<HashMap<String, String>> FilterAPresales(
			PresalesDTO presalesTO) {
		ArrayList<HashMap<String, String>> presalesTO1 = new ArrayList<>();
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(presalesTO.getDateAppointment()));
			date1 = formatter
					.format(sdf.parse(presalesTO.getTimeAppointment()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT * FROM presales_appts P WHERE date_appointment BETWEEN '"
					+ date
					+ " 00:00:00' AND '"
					+ date1
					+ " 23:59:59' AND STATUS LIKE '%"
					+ presalesTO.getStatus()
					+ "%'"
					+ " AND (meeting_status IS NULL OR meeting_status LIKE '%%') AND appointment_type LIKE '%"
					+ presalesTO.getMeetingStatus()
					+ "%'"
					+ "AND csr LIKE '%"
					+ presalesTO.getApplicationNo()	+ "' AND executive LIKE '%" + presalesTO.getCity() + "%' ";
			System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("leadsId", rs.getString("leads_id"));
				list.put("customerName", rs.getString("customer_name"));
				list.put("dateAppointment", rs.getString("date_appointment"));
				list.put("timeAppointment", rs.getString("time_appointment"));
				list.put("productName", rs.getString("product_name"));
				list.put("appointmentType", rs.getString("appointment_type"));
				list.put("channelsName", rs.getString("channels_name"));
				list.put("csrName", rs.getString("csr_name"));
				list.put("status", rs.getString("status"));
				list.put("executiveName", rs.getString("executive_name"));
				list.put("primaryMob", rs.getString("primary_mob"));
				presalesTO1.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return presalesTO1;
	}

	public List<WelezoConstantsTO> getWelezoConstant() {
		List<WelezoConstantsTO> custDeatils = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(WelezoConstantsTO.class,
				"custDetail");
		@SuppressWarnings("unchecked")
		Collection<? extends WelezoConstantsTO> theUserList = (Collection<? extends WelezoConstantsTO>) theCriteria
				.list();

		custDeatils.addAll(theUserList);
		return custDeatils;
	}

	@Override
	public DispatchTrackingTO getDispatchDetails(Integer txId) {
		DispatchTrackingTO dispatch = new DispatchTrackingTO();

		try {
			String s = "SELECT * FROM `dispatch_tracking` WHERE `transaction_id` = '"
					+ txId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				dispatch.setTrackId(rs.getInt("track_id"));
				dispatch.setDispatchDate(rs.getDate("dispatch_date"));
				dispatch.setDeliveryStatus(rs.getString("delivery_status"));
				dispatch.setConsignmentReference(rs
						.getString("consignment_reference"));
				dispatch.setDispatchThrough(rs.getString("dispatch_through"));
				dispatch.setReceviedBy(rs.getString("recevied_by"));
				dispatch.setUpdatedDate(rs.getDate("updated_date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dispatch;
	}

	@Override
	public List<VendorsTO> getVendors() {

		List<VendorsTO> list = new ArrayList<>();
		try {
			String s = "SELECT * FROM vendors";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery(s);
			while (rs.next()) {
				VendorsTO vendorsTO = new VendorsTO();
				vendorsTO.setVendorId(rs.getInt("vendor_id"));
				vendorsTO.setVendorCategory(rs.getString("vendor_category"));
				vendorsTO.setVendorName(rs.getString("vendor_name"));
				vendorsTO.setVendorCompany(rs.getString("vendor_company"));
				vendorsTO.setVendorAddress(rs.getString("vendor_address"));
				vendorsTO.setVendorBankDetails(rs
						.getString("vendor_bank_details"));
				vendorsTO.setVendorPhone(rs.getString("vendor_phone"));
				vendorsTO.setVendorEmail(rs.getString("vendor_email"));
				list.add(vendorsTO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public List<ItemMasterTO> getItemMaster() {
		List<ItemMasterTO> list = new ArrayList<>();

		try {
			String s = "SELECT * FROM item_master";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				ItemMasterTO itemMaster = new ItemMasterTO();
				itemMaster.setItemId(rs.getInt("item_id"));
				itemMaster.setItemName(rs.getString("item_name"));
				itemMaster.setAssetType(rs.getByte("asset_type"));
				itemMaster.setUnitOfMeasure(rs.getString("unit_of_measure"));
				itemMaster.setItemCategory(rs.getString("item_category"));
				itemMaster.setDept(rs.getString("dept"));
				itemMaster.setCurrentStock(rs.getFloat("current_stock"));
				itemMaster.setReorderTrigger(rs.getFloat("reorder_trigger"));
				itemMaster.setDescription(rs.getString("description"));
				itemMaster.setItemGroup(rs.getString("item_group"));
				itemMaster.setPricePerUnit(rs.getFloat("price_per_unit"));
				list.add(itemMaster);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public VendorsTO getVendorByid(Integer vendorId) {
		VendorsTO vendorsTO1 = new VendorsTO();
		try {
			String s = "SELECT * FROM vendors WHERE vendor_id = '" + vendorId
					+ "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery(s);
			if (rs.next()) {
				vendorsTO1.setVendorId(rs.getInt("vendor_id"));
				vendorsTO1.setVendorCategory(rs.getString("vendor_category"));
				vendorsTO1.setVendorName(rs.getString("vendor_name"));
				vendorsTO1.setVendorCompany(rs.getString("vendor_company"));
				vendorsTO1.setVendorAddress(rs.getString("vendor_address"));
				vendorsTO1.setVendorBankDetails(rs
						.getString("vendor_bank_details"));
				vendorsTO1.setVendorPhone(rs.getString("vendor_phone"));
				vendorsTO1.setVendorEmail(rs.getString("vendor_email"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vendorsTO1;

	}

	@Override
	public ItemMasterTO getItemmasterByid(Integer itemId) {
		ItemMasterTO itemMaster = new ItemMasterTO();
		try {
			String s = "SELECT * FROM item_master WHERE item_id = '" + itemId
					+ "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				itemMaster.setItemId(rs.getInt("item_id"));
				itemMaster.setItemName(rs.getString("item_name"));
				itemMaster.setAssetType(rs.getByte("asset_type"));
				itemMaster.setUnitOfMeasure(rs.getString("unit_of_measure"));
				itemMaster.setItemCategory(rs.getString("item_category"));
				itemMaster.setDept(rs.getString("dept"));
				itemMaster.setCurrentStock(rs.getFloat("current_stock"));
				itemMaster.setReorderTrigger(rs.getFloat("reorder_trigger"));
				itemMaster.setDescription(rs.getString("description"));
				itemMaster.setItemGroup(rs.getString("item_group"));
				itemMaster.setPricePerUnit(rs.getFloat("price_per_unit"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return itemMaster;
	}

	@Override
	public List<InventoryTO> getinventry() {
		List<InventoryTO> list = new ArrayList<>();
		try {
			String c = "SELECT * FROM inventory";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(c);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				InventoryTO invent = new InventoryTO();
				invent.setActionBy(rs.getInt("action_by"));
				invent.setActionDate(rs.getDate("action_date"));
				invent.setCreatedDate(rs.getDate("created_date"));
				invent.setDescription(rs.getString("description"));
				invent.setEntryId(rs.getInt("entry_id"));
				invent.setEntryType(rs.getString("entry_type"));
				invent.setIssuedTo(rs.getInt("issued_to"));
				invent.setItemId(rs.getInt("item_id"));
				invent.setPrice(rs.getFloat("price"));
				invent.setQuantity(rs.getFloat("quantity"));
				invent.setRemarks(rs.getString("remarks"));
				invent.setVendorId(rs.getInt("vendor_id"));
				list.add(invent);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public List<WelezoConstantsTO> getconstants() {
		List<WelezoConstantsTO> list = new ArrayList<>();
		try {
			String c = "SELECT * FROM welezo_constants";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(c);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				WelezoConstantsTO welezo = new WelezoConstantsTO();
				welezo.setId(rs.getInt("id"));
				welezo.setConstType(rs.getString("const_type"));
				welezo.setCValue(rs.getString("c_value"));
				welezo.setCDisplay(rs.getString("c_display"));
				list.add(welezo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public WelezoConstantsTO getconstantbyid(Integer id) {
		WelezoConstantsTO welezo = new WelezoConstantsTO();
		try {
			String s = "SELECT * FROM welezo_constants WHERE id = '" + id + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				welezo.setId(rs.getInt("id"));
				welezo.setConstType(rs.getString("const_type"));
				welezo.setCValue(rs.getString("c_value"));
				welezo.setCDisplay(rs.getString("c_display"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return welezo;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllCollectionOffers(
			Integer collectionId) {

		ArrayList<HashMap<String, String>> accList = new ArrayList<>();
		try {
			String s = "SELECT * FROM collection_offers coll LEFT JOIN services ser ON ser.service_id = coll.service_id "
					+ " WHERE coll.collection_id = '" + collectionId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("serviceId", rs.getString("service_id"));
				list.put("quantity", rs.getString("quantity"));
				list.put("category", rs.getString("category"));
				list.put("serviceName", rs.getString("service_name"));
				accList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accList;
	}

	@Override
	public ArrayList<HashMap<String, String>> geteExtensionNoAndCsr() {
		ArrayList<HashMap<String, String>> extenstionList = new ArrayList<>();
		try {
			String s = "SELECT ext.extension_No,his.emp_id,his.emp_name  FROM extension_details ext "
					+ " LEFT JOIN employment_history his ON his.emp_id = ext.emp_id "
					+ " WHERE CURRENT_DATE < his.to_date AND his.designation IN ('CSR', 'Sr. CSR') "
					+ " AND CURRENT_DATE BETWEEN ext.from_date AND ext.to_date ORDER BY ext.extension_No";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("extensionNo", rs.getString("extension_No"));
				list.put("empId", rs.getString("emp_id"));
				list.put("empName", rs.getString("emp_name"));
				// list.put("roleType", rs.getString("role_type"));
				// list.put("welezoEmpId", rs.getString("welezo_emp_id"));
				extenstionList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return extenstionList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getCustomerList(
			String cardRPhnNumber) {
		ArrayList<HashMap<String, String>> customerList = new ArrayList<>();
		try {
			String s = "SELECT  DISTINCT cust.customer_id, cust.customer_name 'Customer Name', cust.card_number 'Card Number',adr.primary_mob,adr.`alt_mob`"
					+ " FROM customer_deatils cust LEFT JOIN address adr ON (cust.customer_id = adr.entity_id AND address_type_id IN (1,2,3)) "
					+ " WHERE adr.primary_mob = '"
					+ cardRPhnNumber
					+ "' OR adr.`alt_mob` = '"
					+ cardRPhnNumber
					+ "' OR cust.card_number LIKE '%"
					+ cardRPhnNumber
					+ "%' OR "
					+ " cust.dob = '"
					+ cardRPhnNumber
					+ "' OR cust.`customer_name` LIKE '%"
					+ cardRPhnNumber
					+ "%'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("customerId", rs.getString("customer_id"));
				list.put("CustomerName", rs.getString("Customer Name"));
				list.put("CardNumber", rs.getString("Card Number"));
				list.put("primaryMob", rs.getString("primary_mob"));
				customerList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return customerList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getWalkinCustomer(
			String fromDate, String toDate) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> walkInList = new ArrayList<>();
		try {
			String s = "SELECT * FROM walkin_customer WHERE datetime BETWEEN '"
					+ date + " 00:00:00' AND '" + date1 + " 23:59:59'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("email", rs.getString("email"));
				list.put("phone", rs.getString("phone"));
				list.put("datetime", rs.getString("datetime"));
				list.put("status", rs.getString("status"));
				list.put("remarks", rs.getString("remarks"));
				list.put("walkinCustomerName", rs.getString("walkin_customer_name"));
				list.put("walkinCustomerMsg", rs.getString("walkin_customer_msg"));
				walkInList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return walkInList;
	}

	@Override
	public HashMap<String, String> getWalkinCustomerById(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM walkin_customer WHERE id = 2";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("id", rs.getString("id"));
				list.put("email", rs.getString("email"));
				list.put("phone", rs.getString("phone"));
				list.put("datetime", rs.getString("datetime"));
				list.put("status", rs.getString("status"));
				list.put("remarks", rs.getString("remarks"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getDispatchList(
			Integer transactionId) {
		ArrayList<HashMap<String, String>> dispatchList = new ArrayList<>();
		try {
			String s = "SELECT * FROM dispatch_tracking WHERE `transaction_id` = '"
					+ transactionId + "' ORDER BY 2 DESC";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("trackId", rs.getString("track_id"));
				list.put("dispatchDate", rs.getString("dispatch_date"));
				list.put("dispatchThrough", rs.getString("dispatch_through"));
				list.put("consignmentReference",
						rs.getString("consignment_reference"));
				list.put("dispatchStatus", rs.getString("dispatch_status"));
				list.put("deliveryStatus", rs.getString("delivery_status"));
				list.put("receviedBy", rs.getString("recevied_by"));
				list.put("receivedDate", rs.getString("received_date"));
				dispatchList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dispatchList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getHealthAppointmnetFBRating() {
		ArrayList<HashMap<String, String>> custSatList = new ArrayList<>();
		try {
			String s = "SELECT ser.appointment_id, ser.Customer_Name,ser.Service,ser.ServiceCentre,cs.* FROM csat cs "
					+ " LEFT JOIN service_utilization ser ON cs.health_appt_id = ser.appointment_id";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("appointmentId", rs.getString("appointment_id"));
				list.put("Customer_Name", rs.getString("Customer_Name"));
				list.put("Service", rs.getString("Service"));
				list.put("ServiceCentre", rs.getString("ServiceCentre"));
				list.put("Q6", rs.getString("Q6"));
				list.put("Q7", rs.getString("Q7"));
				list.put("Q8", rs.getString("Q8"));
				list.put("Q9", rs.getString("Q9"));
				list.put("Q10", rs.getString("Q10"));
				list.put("Q11", rs.getString("Q11"));
				custSatList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custSatList;
	}

	@Override
	public HashMap<String, String> getCustomerFBById(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT ser.appointment_id, ser.Customer_Name,ser.Service,ser.ServiceCentre,cs.* FROM csat cs "
					+ " LEFT JOIN service_utilization ser ON cs.health_appt_id = ser.appointment_id WHERE health_appt_id = '"
					+ id + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("Customer_Name", rs.getString("Customer_Name"));
				list.put("Service", rs.getString("Service"));
				list.put("ServiceCentre", rs.getString("ServiceCentre"));
				list.put("Q6", rs.getString("Q6"));
				list.put("Q7", rs.getString("Q7"));
				list.put("Q8", rs.getString("Q8"));
				list.put("Q9", rs.getString("Q9"));
				list.put("Q10", rs.getString("Q10"));
				list.put("Q11", rs.getString("Q11"));
				list.put("Q12", rs.getString("Q12"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllservice() {
		ArrayList<HashMap<String, String>> serviceList = new ArrayList<>();
		try {
			String s = "SELECT * FROM services WHERE isActive IS TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("serviceId", rs.getString("service_id"));
				list.put("category", rs.getString("category"));
				list.put("serviceName", rs.getString("service_name"));
				list.put("serviceDescription", rs.getString("service_description"));
				list.put("isActive", rs.getString("isActive"));
				
				serviceList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return serviceList;
	}
	@Override
    public ArrayList<HashMap<String, String>> getDetailsCustomer() {
		ArrayList<HashMap<String, String>> list = new ArrayList<>();
           
           try {
                  String s = "SELECT cm.`customer_name`,adr.`Residence_addresss`,adr.`primary_mob` FROM dispatch_tracking disp, transaction_master tm, customer_deatils cm, address adr "
                               + " WHERE delivery_status IS NULL AND disp.`transaction_id` = tm.`transaction_id` "
                               + " AND tm.`customer_id` = cm.`customer_id` AND adr.`entity_id` = cm.`customer_id`";
                  Connection connection = sessionFactory.getCurrentSession()
                               .connection();
                  PreparedStatement prepareStatement = connection.prepareStatement(s);
                  ResultSet rs = prepareStatement.executeQuery();
                  while (rs.next()) {
                	  HashMap<String, String> welezo = new HashMap<String, String>();
                	  welezo.put("customerName", rs.getString("customer_name"));
                	  welezo.put("residenceAddresss", rs.getString("Residence_addresss"));
                	  welezo.put("primaryMob", rs.getString("primary_mob"));
                        /*welezo.setLeadsId(rs.getInt("leads_id"));*/
                     //   welezo.setCustomerName(rs.getString("customer_name"));
                     //   welezo.setResidenceAddresss(rs.getString("Residence_addresss"));
                     //   welezo.setPrimaryMob(rs.getString("primary_mob"));
                        list.add(welezo);
           } 
           }
                  catch (Exception e) {
                  e.printStackTrace();
    
                  }
           return list;
    
    }

	@Override
	public ArrayList<String> getDistinctValues(String query) {
		ArrayList<String> list = new ArrayList<String>();
		try {
			String s = query;
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				String value = rs.getString(1);
				list.add(value);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getWelezoBankList() {
		ArrayList<HashMap<String, String>> bankList = new ArrayList<>();
		try {
			String s = "SELECT acct_id,acc_name,acc_no FROM welezohe_accounts.bank_accounts WHERE `beneficiary_name` LIKE 'Welezo%'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("acctId", rs.getString("acct_id"));
				list.put("accName", rs.getString("acc_name"));
				bankList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bankList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getServicesBasedOnProductId(
			Integer productId) {
		ArrayList<HashMap<String, String>> serviceList = new ArrayList<>();
		try {
			String s = "SELECT * FROM product_offers off LEFT JOIN services ser ON ser.service_id = off.service_id WHERE off.product_id = '"+productId+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("serviceId", rs.getString("service_id"));
				list.put("category", rs.getString("category"));
				list.put("serviceName", rs.getString("service_name"));
				list.put("productd", rs.getString("product_id"));
				list.put("quantity", rs.getString("quantity"));
				serviceList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return serviceList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getServicesNotInProducts(Integer productId) {
		ArrayList<HashMap<String, String>> serviceList = new ArrayList<>();
		try {
			String s = "SELECT service_id ,category, service_name,service_description "
					+ " FROM services WHERE isActive IS TRUE AND service_id NOT IN "
					+ " (SELECT service_id FROM product_offers WHERE product_id = '"+productId+"') ORDER BY service_id";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("serviceId", rs.getString("service_id"));
				list.put("category", rs.getString("category"));
				list.put("serviceName", rs.getString("service_name"));
				//list.put("category", rs.getString("category"));
				serviceList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return serviceList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getSeoOnPageList(String fromDate,String toDate) {
		ArrayList<HashMap<String, String>> seoOnPageList = new ArrayList<>();
		try {
			String s = "SELECT * FROM seo_on_page  ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("moduleName", rs.getString("module_name"));
				list.put("title", rs.getString("title"));
				list.put("description", rs.getString("description"));
				list.put("keyword", rs.getString("keyword"));
				list.put("robots", rs.getString("robots"));
				list.put("lastUpdated", rs.getString("last_updated"));
				list.put("imgUrl", rs.getString("img_url"));
				list.put("slug", rs.getString("slug"));
				seoOnPageList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return seoOnPageList;
	}
	@Override
	public ArrayList<HashMap<String, String>> getOnlineUserList(String fromDate,String toDate) {
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> onLineUsereList = new ArrayList<>();
		try {
			String s = "SELECT website_user_id,ip_address,COUNT(ip_address) AS 'Total Click',city,region,country_name,url_link,visited_date_time "
					+ " FROM online_users WHERE visited_date_time BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:59:59'"
					+ "GROUP BY ip_address ORDER BY website_user_id ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("websiteUserId", rs.getString("website_user_id"));
				list.put("ipAddress", rs.getString("ip_address"));
				list.put("TotalClick", rs.getString("Total Click"));
				list.put("city", rs.getString("city"));
				list.put("region", rs.getString("region"));
				list.put("countryName", rs.getString("country_name"));
				list.put("urlLink", rs.getString("url_link"));
				list.put("visitedDateTime", rs.getString("visited_date_time"));				
				onLineUsereList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return onLineUsereList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getBannedIpList(String fromDate,
			String toDate) {
		ArrayList<HashMap<String, String>> bannedList = new ArrayList<>();
		try {
			String s = "SELECT * FROM banned_ip";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("ipAddress", rs.getString("ip_address"));
				list.put("reason", rs.getString("reason"));
				list.put("bannedBy", rs.getString("banned_by"));
				list.put("dateTime", rs.getString("date_time"));
				bannedList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bannedList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getIpAddressThruUserDetails(
			String ipAddress) {
		ArrayList<HashMap<String, String>> onLineUsereList = new ArrayList<>();
		try {
			String s = "SELECT website_user_id,ip_address,city,region,country_name,url_link,visited_date_time "
					+ "FROM online_users WHERE ip_address = '"+ipAddress+"'"
					+ " ORDER BY visited_date_time DESC ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("websiteUserId", rs.getString("website_user_id"));
				list.put("ipAddress", rs.getString("ip_address"));
				list.put("city", rs.getString("city"));
				list.put("region", rs.getString("region"));
				list.put("countryName", rs.getString("country_name"));
				list.put("urlLink", rs.getString("url_link"));
				list.put("visitedDateTime", rs.getString("visited_date_time"));				
				onLineUsereList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return onLineUsereList;
	}

	@Override
	public HashMap<String, String> getSeoOnPageById(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM seo_on_page WHERE id ='"+id+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("id", rs.getString("id"));
				list.put("moduleName", rs.getString("module_name"));
				list.put("title", rs.getString("title"));
				list.put("description", rs.getString("description"));
				list.put("keyword", rs.getString("keyword"));
				list.put("robots", rs.getString("robots"));
				list.put("lastUpdated", rs.getString("last_updated"));
				list.put("imgUrl", rs.getString("img_url"));
				list.put("slug", rs.getString("slug"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getCSatListforEdit(
			Integer appointmentId) {
		ArrayList<HashMap<String, String>> feedBackList = new ArrayList<>();
		try {
			String s = "SELECT qr.*,qb.question,qb.qn_type,qb.option_details,qb.options_type FROM qn_responses qr "
					+ " LEFT JOIN question_bank qb ON qb.qn_id = qr.qn_id "
					+ " WHERE attr_type ='Customer Feedback' AND  ref_id = '"+appointmentId+"'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("autoNum", rs.getString("autoNum"));
				list.put("answer", rs.getString("answer"));
				list.put("qnId", rs.getString("qn_id"));
				list.put("question", rs.getString("question"));
				list.put("qnType", rs.getString("qn_type"));				
				list.put("optionDetails", rs.getString("option_details"));
				list.put("optionsType", rs.getString("options_type"));
				feedBackList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return feedBackList;
	}

	@Override
	public HashMap<String, String> getApplicationStatusTx(String applicationNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT transaction_id,customer_name,tx_status,product_name,approval_date,collected_date FROM view_PayTrxCust WHERE application_No = '"+applicationNo+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("transactionId", rs.getString("transaction_id"));
				list.put("customerName", rs.getString("customer_name"));
				list.put("txStatus", rs.getString("tx_status"));
				list.put("productName", rs.getString("product_name"));
				list.put("approvalDate", rs.getString("approval_date"));
				list.put("collectedDate", rs.getString("collected_date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getApplicationStatusDispatch(
			String applicationNo) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT track_id,delivery_status,dispatch_date FROM dispatch_tracking "
					+ " WHERE transaction_id = (SELECT transaction_id FROM view_PayTrxCust WHERE application_No = '"+applicationNo+"')";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("trackId", rs.getString("track_id"));
				list.put("deliveryStatus", rs.getString("delivery_status"));
				list.put("dispatchDate", rs.getString("dispatch_date"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getInvoiceTransactionDetails(
			Integer transactionId) {

		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT transaction_id,mode_of_payment,amount,collected_date,application_No,product_name,customer_name,customer_id,correspondence,product_id"
					+ "  FROM view_paytrxcust WHERE transaction_id ='"+transactionId+"'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("transactionId", rs.getString("transaction_id"));
				list.put("modeOfPayment", rs.getString("mode_of_payment"));
				list.put("amount", rs.getString("amount"));
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
				list.put("collectedDate", sdf.format(rs.getDate("collected_date")));
				list.put("applicationNo", rs.getString("application_No"));
				list.put("productName", rs.getString("product_name"));
				list.put("customerName", rs.getString("customer_name"));
				list.put("customerId", rs.getString("customer_id"));
				list.put("correspondence", rs.getString("correspondence"));
				list.put("productId", rs.getString("product_id"));
				
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getCustomerReportList() {
		ArrayList<HashMap<String, String>> custList = new ArrayList<>();
		try {
			String s = "SELECT appointment_id,Customer_Name,Service,Appt_For,ServiceCentre,Appt_Date,ProductName"
					+ "  FROM service_utilization WHERE reportStatus IN ('Report Updated') ORDER BY Appt_Date DESC";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("appointmentId", rs.getString("appointment_id"));
				list.put("CustomerName", rs.getString("Customer_Name"));
				list.put("Service", rs.getString("Service"));
				list.put("ServiceCentre", rs.getString("ServiceCentre"));
				list.put("ApptDate", rs.getString("Appt_Date"));				
				list.put("ProductName", rs.getString("ProductName"));
				list.put("ApptFor", rs.getString("Appt_For"));
				custList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return custList;
	}

}
