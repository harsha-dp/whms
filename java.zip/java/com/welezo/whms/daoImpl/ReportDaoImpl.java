package com.welezo.whms.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dao.ReportDao;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.ProjectsTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.util.HibernateUtil;
@Repository
public class ReportDaoImpl extends CustomHibenateDaoSupport implements ReportDao {

	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	private HibernateUtil hibernateUtil;

	
	public <T> void saveOrUpdate(T entity) {
		hibernateUtil.saveOrUpdate(entity);
	}
	
	@Override
	public List<ProjectsTO> getallprojects() {
		List<ProjectsTO> projects=new ArrayList<>();
		try {
			String c = "SELECT * FROM projects";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(c);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				ProjectsTO proj=new ProjectsTO();
				proj.setProjectId(rs.getInt("project_id"));
				proj.setProjectName(rs.getString("project_name"));
				proj.setParentProject(rs.getInt("parent_project"));
				projects.add(proj);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return projects;
		}


	@Override
	public ProjectsTO getallprojectsById(Integer projectId) {
		ProjectsTO proj= new ProjectsTO();
		try {
			
			String s="SELECT * FROM projects WHERE project_id = '"+ projectId +"'"; 
			Connection connection=sessionFactory.getCurrentSession().connection();
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();
			while(rs.next())
			{
				proj.setProjectId(rs.getInt("project_id"));
				proj.setProjectName(rs.getString("project_name"));
				proj.setParentProject(rs.getInt("parent_project"));
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return proj;
	}

	

	@Override
	public TeamsTO getteamsById(Integer teamId) {
		
		TeamsTO team = new TeamsTO();
		try {
			
			String s = " SELECT * from teams where team_id = '" + teamId + "'";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement preparedStatement;
			preparedStatement=connection.prepareStatement(s);
			ResultSet rs= preparedStatement.executeQuery();
			while(rs.next()){
				
				team.setTeamId(rs.getInt("team_id"));
				team.setTeamName(rs.getString("team_name"));
				team.setLeaderName(rs.getString("leader_name"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return team;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllChannelss() {
		
	ArrayList<HashMap<String, String>> list = new ArrayList<>();
	try {
		String s = "SELECT * FROM channels";
		Connection connection=sessionFactory.getCurrentSession().connection();
		PreparedStatement preparedStatement;
		preparedStatement=connection.prepareStatement(s);
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next())
		{
			HashMap<String, String> channel = new HashMap<String,String>();
			channel.put("channelId", rs.getString("channel_id"));
			channel.put("channelsName", rs.getString("channels_name"));
			list.add(channel);
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	}
		return list;
	}

	@Override
	public ChannelsTO editchannelsById(Integer channelId) {
     
		ChannelsTO channels = new ChannelsTO();
		try {
			
		String s="SELECT * FROM channels WHERE channel_id='" + channelId + "'";
		
		Connection connection=sessionFactory.getCurrentSession().connection();
		PreparedStatement preparedStatement;
		preparedStatement=connection.prepareStatement(s);
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next())
		{
			
			channels.setChannelId(rs.getInt("channel_id"));
			channels.setChannelsName(rs.getString("channels_name"));
		}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return channels;
	}

}
