package com.welezo.whms.daoImpl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dao.CallRecordsDao;
import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.TeleCallRecordIdDTO;
import com.welezo.whms.util.HibernateUtil;

@Repository
public class CallRecordsDaoImpl extends CustomHibenateDaoSupport implements
		CallRecordsDao {

	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	private HibernateUtil hibernateUtil;

	@Override
	public ArrayList<HashMap<String, String>> getAllVisitorList(
			String fromDate, String toDate, String purpose) {
		
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		ArrayList<HashMap<String, String>> extensionList = new ArrayList<>();
		try {
			String query = "SELECT visit.*,usr.user_name FROM visitor_book visit "
					+ " LEFT JOIN usermaster usr ON usr.user_id = visit.created_by WHERE visit.visit_date  "
					+ " BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:12:32' AND visit.purpose LIKE '%"+purpose+"%' ORDER BY creation_date DESC ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection
					.prepareStatement(query);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("callId", rs.getString("call_id"));
				list.put("incomingNumber", rs.getString("visitor_number"));
				list.put("callerName", rs.getString("visitor_name"));
				list.put("source", rs.getString("source"));
				list.put("purpose", rs.getString("purpose"));
				list.put("status", rs.getString("status"));
				list.put("remarks", rs.getString("remarks"));
				list.put("visitDate", rs.getString("visit_date"));
				list.put("updatedBy", rs.getString("user_name"));
				list.put("inTime", rs.getString("in_time"));
				list.put("outTime", rs.getString("out_time"));
				extensionList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return extensionList;
	}

	@Override
	public List<AddressDTO> searchCustomer(String phoneNumber) {
		List<AddressDTO> searchDetails = new ArrayList<>();
		try {
			String s = "SELECT * FROM address WHERE  primary_mob = ? ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			prepareStatement.setString(1, phoneNumber);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				AddressDTO details = new AddressDTO();
				details.setAid(rs.getInt("aid"));
				details.setEntityId(rs.getInt("entity_id"));
				searchDetails.add(details);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return searchDetails;
	}

	public static String getDateTime(String dt, String tm) {
		String dtParts[] = dt.split("/");
		String dateS = "2016-" + dtParts[1] + "-" + dtParts[0] + " " + tm
				+ ":00";
		return dateS;
	}

	@RequestMapping(value = "/fileCalls")
	public ModelAndView upLoadCalls(ModelMap model) {

		File dir = new File("K:\\Calls");
		String[] fileNames = null;
		if (dir.isDirectory()) {
			fileNames = dir.list();
		}

		try {
			FileWriter fw = new FileWriter("outgoingCalls.txt");
			BufferedWriter bf = new BufferedWriter(fw);

			FileWriter rw = new FileWriter("incomingCalls.csv");
			BufferedWriter rbf = new BufferedWriter(rw);

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			int recCount = 0;

			for (String fName : fileNames) {
				FileReader fr = new FileReader("K:\\Calls\\" + fName);
				BufferedReader br = new BufferedReader(fr);
				String line;

				while ((line = br.readLine()) != null) {
					line = line.trim().replaceAll("( )+", ",");
					line += "\n";
					if (!(line.startsWith("0") || line.startsWith("1")
							|| line.startsWith("2") || line.startsWith("3")
							|| line.startsWith("4") || line.startsWith("5")
							|| line.startsWith("6") || line.startsWith("7")
							|| line.startsWith("8") || line.startsWith("9"))) { // Lines
																				// starting
																				// with
																				// number
																				// 0.
						continue;
					}
					if (line.contains("R") || line.contains("U")
							|| line.contains("F") || line.contains("T")) {
						// 6th and 7th column
						// rw.write(line, 0, line.length());
					} else {
						// 5th column and 6th column
						String ele[] = line.split(",");
						String dt = ele[4], tm = ele[5];
						String dttm = getDateTime(dt, tm);

						// System.out.println(dt + " " + tm + " ---->> " +
						// dttm);
						String lineOut = ele[0] + ",'" + ele[1] + "','"
								+ ele[2] + "','" + ele[3] + "','" + dttm
								+ "','" + ele[6] + "'";

						String query = "Insert into tele_call_record values ("
								+ lineOut + ");";
						try {
							PreparedStatement pstmt = connection
									.prepareStatement(query);
							// pstmt.addBatch(query);
							recCount++;
							// if(recCount%10 == 0){
							// pstmt.executeBatch();
							// System.out.println("Total rows " + recCount);
							// }
							pstmt.executeUpdate();
							if (recCount % 100 == 0) {
								System.out.println("Total rows " + recCount);
							}
						} catch (Exception e) {
							System.out.println(e.getMessage());
						}
						// System.out.println(query);
						// fw.write(query, 0, query.length());
					}
				}
				fr.close();
			}
			System.out.println("Total rows " + recCount);
			fw.close();
			rw.close();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}

		System.out.println("Completed");

		return null;
	}

	@Override
	public List<TeleCallRecordIdDTO> teleCallsByPhoneNo(String phoneNumber) {
		List<TeleCallRecordIdDTO> listPhnDetails = new ArrayList<>();
		try {
			String s = "SELECT * FROM call_details WHERE phone_no='"
					+ phoneNumber + "' ORDER BY call_date DESC ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				TeleCallRecordIdDTO calls = new TeleCallRecordIdDTO();
				calls.setExtensionNo(rs.getString("extension_no"));
				calls.setPhoneNo(rs.getString("phone_no"));
				calls.setCallDate(rs.getString("call_date"));
				calls.setEmplName(rs.getString("emp_name"));
				calls.setDuration(rs.getString("duration"));
				listPhnDetails.add(calls);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listPhnDetails;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllExtensionDetails() {
		ArrayList<HashMap<String, String>> extensionList = new ArrayList<>();
		try {
			String query = "SELECT extn.*, emp.emp_name,team.`team_name` FROM extension_details extn "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = extn.emp_id  LEFT JOIN teams team ON team.team_id = extn.team "
					+ " WHERE to_date >= CURRENT_DATE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection
					.prepareStatement(query);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("empId", rs.getString("emp_id"));
				list.put("extensionNo", rs.getString("extension_No"));
				list.put("team", rs.getString("team"));
				list.put("fromDate", rs.getString("from_date"));
				list.put("toDate", rs.getString("to_date"));
				list.put("teamName", rs.getString("team_name"));
				list.put("empName", rs.getString("emp_name"));
				extensionList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return extensionList;
	}

	@Override
	public HashMap<String, String> getExtensionById(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT extn.*,emp.emp_name,team.team_name,chan.channels_name FROM extension_details extn "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = extn.emp_id "
					+ " LEFT JOIN teams team ON team.team_id = extn.team "
					+ " LEFT JOIN channels chan ON chan.channel_id = extn.channel WHERE extn.id = '"
					+ id + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("id", rs.getString("id"));
				list.put("empId", rs.getString("emp_id"));
				list.put("extensionNo", rs.getString("extension_No"));
				list.put("team", rs.getString("team"));
				list.put("fromDate", rs.getString("from_date"));
				list.put("toDate", rs.getString("to_date"));
				list.put("teamName", rs.getString("team_name"));
				list.put("empName", rs.getString("emp_name"));
				list.put("channel", rs.getString("channel"));
				list.put("channelsName", rs.getString("channels_name"));
				list.put("department", rs.getString("department"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getIncomingCallsList(
			String fromDate, String toDate, String callsMode) {
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		String mode = null;
		if (callsMode.equalsIgnoreCase("Missed")) {
			mode = " ='00:00' ";
		} else {
			mode = " !='00:00' ";
		}
		ArrayList<HashMap<String, String>> callsList = new ArrayList<>();
		try {
			String s = "SELECT * FROM tele_call_incoming WHERE call_date BETWEEN '"
					+ date
					+ " 00:00:00' AND '"
					+ date1
					+ " 23:59:59' AND duration " + mode + " ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("extensionNo", rs.getString("extension_no"));
				list.put("phoneNo", rs.getString("phone_no"));
				list.put("callDate", rs.getString("call_date"));
				list.put("duration", rs.getString("duration"));
				list.put("status", rs.getString("call_status"));
				list.put("purpose", rs.getString("purpose"));
				list.put("remarks", rs.getString("Remarks"));

				callsList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return callsList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllBTlLeads(String fromDate,
			String toDate, String status, String parkId) {
		ArrayList<HashMap<String, String>> callsList = new ArrayList<>();
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT btl.*,park.park_name FROM channel_leads btl  "
					+ " LEFT JOIN park_details park ON park.park_id = btl.entity_id "
					+ " WHERE acitivity_date  BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:59:59' "
					+ " AND lead_status LIKE '%"+status+"%' AND btl.entity_id LIKE '"+parkId+"%' HAVING btl.Channel LIKE '13' ";

			System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("btlId", rs.getString("id"));
				list.put("leaName", rs.getString("lead_name"));
				list.put("contactNumber", rs.getString("contact_number"));
				list.put("age", rs.getString("age"));
				list.put("leadStatus", rs.getString("lead_status"));
				list.put("parkName", rs.getString("park_name"));
				list.put("bp", rs.getString("bp"));
				list.put("sugar", rs.getString("sugar"));
				list.put("gender", rs.getString("gender"));

				callsList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return callsList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllParkDetails() {
		ArrayList<HashMap<String, String>> parkList = new ArrayList<>();
		try {
			String s = "SELECT park_id,CONCAT(park_name,'-',location) AS 'ParkName' FROM park_details WHERE isActive IS TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("parkId", rs.getString("park_id"));
				list.put("ParkName", rs.getString("ParkName"));
				parkList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return parkList;
	}
}
