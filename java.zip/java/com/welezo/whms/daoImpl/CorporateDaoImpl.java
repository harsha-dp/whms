package com.welezo.whms.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dto.CorporateAppointmentsDTO;
import com.welezo.whms.dto.User;
import com.welezo.whms.service.AdminService;
import com.welezo.whms.service.HRService;
import com.welezo.whms.to.CorporateServiceOffersTO;
import com.welezo.whms.to.ServiceParametersTo;
@Path("/json/metallica")
@Controller
public class CorporateDaoImpl extends CustomHibenateDaoSupport {

	@Autowired
	SessionFactory sessionFactory;

	@Autowired
	AdminService adminService;

	@Autowired
	HRService hrService;

	public ArrayList<HashMap<String, String>> getAllCorporate(String condition) {

		ArrayList<HashMap<String, String>> corporateList = new ArrayList<>();

		try {
			String s = "SELECT corp.corporate_id,corp.corporate_name,wel.c_value,corp.head_count,adr.city,adr.pincode,adr.alt_no,emp.emp_name"
					+ " FROM corporate_details corp LEFT JOIN contact_address adr ON adr.entity_id = corp.corporate_id "
					+ " LEFT JOIN welezo_constants wel ON wel.id = corp.entity_type LEFT JOIN `employee_details` emp ON emp.`emp_id` = corp.executive  "
					+ condition;
			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("corporateId", rs.getString("corporate_id"));
				list.put("corporateName", rs.getString("corporate_name"));
				list.put("entityType", rs.getString("c_value"));
				list.put("headCount", rs.getString("head_count"));
				list.put("city", rs.getString("city"));
				list.put("pincode", rs.getString("pincode"));
				list.put("contactNo", rs.getString("alt_no"));
				list.put("executive", rs.getString("emp_name"));
				corporateList.add(list);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateList;
	}

	public HashMap<String, String> getCorporateById(Integer id) {
		HashMap<String, String> corporateDetails = new HashMap<String, String>();
		try {
			String s = "SELECT corp.corporate_id,corp.corporate_name,corp.head_count,corp.status,ad.address_line,ad.city ,ad.landmark,ad.alt_no,ad.pincode,"
					+ "ch.channels_name,corp.channel_id,ad.address_id,ad.email "
					+ "FROM corporate_details corp LEFT JOIN  contact_address ad ON corp.corporate_id = ad.entity_id "
					+ "LEFT JOIN channels ch ON corp.channel_id = ch.channel_id WHERE corp.corporate_id = '"
					+ id + "' AND ad.address_type= 11 ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				corporateDetails.put("corporateId",
						rs.getString("corporate_id"));
				corporateDetails.put("corporateName",
						rs.getString("corporate_name"));
				corporateDetails.put("address", rs.getString("address_line"));
				corporateDetails.put("headCount", rs.getString("head_count"));
				corporateDetails.put("city", rs.getString("city"));
				corporateDetails.put("pincode", rs.getString("pincode"));
				corporateDetails.put("contactNo", rs.getString("alt_no"));
				// corporateDetails.put("executive", rs.getString("emp_name"));
				corporateDetails.put("channelsName",
						rs.getString("channels_name"));
				corporateDetails.put("landmark", rs.getString("landmark"));
				corporateDetails.put("channelId", rs.getString("channel_id"));
				corporateDetails.put("addressId", rs.getString("address_id"));
				corporateDetails.put("email", rs.getString("email"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateDetails;
	}

	public List<CorporateAppointmentsDTO> getCorporateBranch(Integer id) {
		List<CorporateAppointmentsDTO> corporateDTO = new ArrayList<>();
		try {
			String s = "SELECT * FROM corporate_details corp, contact_address cadr "
					+ "WHERE cadr.address_type IN (11) AND cadr.entity_id=corp.corporate_id AND (corp.corporate_id = "
					+ id + " OR corp.parent_id = " + id + ")";
			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				CorporateAppointmentsDTO corporateDTO1 = new CorporateAppointmentsDTO();
				corporateDTO1.setCorporateId(rs.getInt("corporate_id"));
				corporateDTO1.setCorporateName(rs.getString("corporate_name"));
				;
				corporateDTO1.setTotalStrength(rs.getInt("head_count"));
				corporateDTO1
						.setResidenceAddresss(rs.getString("address_line"));
				corporateDTO1.setCity(rs.getString("city"));
				corporateDTO.add(corporateDTO1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateDTO;
	}

	public List<CorporateAppointmentsDTO> getCorporateContactList(Integer id) {
		List<CorporateAppointmentsDTO> corporateDTO = new ArrayList<>();
		try {
			String s = "SELECT cont.contact_id,cont.contact_name,cont.designation, corp.corporate_name, corp.corporate_id"
					+ " FROM contact cont, corporate_details corp WHERE cont.corporate_id IN ( SELECT corporate_id FROM corporate_details  "
					+ "WHERE parent_id IN (SELECT parent_id FROM corporate_details WHERE corporate_id= '"
					+ id + "') ) AND cont.corporate_id = corp.corporate_id";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				CorporateAppointmentsDTO corporateDTO1 = new CorporateAppointmentsDTO();
				corporateDTO1.setCorporateId(rs.getInt("corporate_id"));
				corporateDTO1.setCorporateName(rs.getString("corporate_name"));
				;
				// corporateDTO1.setTotalStrength(rs.getInt("head_count"));
				corporateDTO1.setContactId(rs.getInt("contact_id"));
				corporateDTO1.setName(rs.getString("contact_name"));
				corporateDTO1.setDesignation(rs.getString("designation"));
				corporateDTO.add(corporateDTO1);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateDTO;
	}

	public CorporateAppointmentsDTO getContactById(Integer id) {
		CorporateAppointmentsDTO corporateDTO = new CorporateAppointmentsDTO();
		try {
			String s = "SELECT * FROM contact cont WHERE contact_id = '" + id
					+ "' ";

			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				corporateDTO.setContactId(rs.getInt("contact_id"));
				corporateDTO.setName(rs.getString("contact_name"));
				;
				corporateDTO.setDesignation(rs.getString("designation"));
				corporateDTO.setDob(rs.getString("dob"));
				corporateDTO.setPrimaryMob(rs.getString("primary_contact"));
				corporateDTO.setEmail(rs.getString("primary_email"));
				corporateDTO.setCorporateId(rs.getInt("corporate_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateDTO;
	}

	public List<CorporateAppointmentsDTO> getViewCorporateAppointment(
			String fromDate, String toDate, String executive) {
		List<CorporateAppointmentsDTO> corporateDTO = new ArrayList<>();
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT apt.*,cont.contact_name,corp.corporate_name,emp.emp_name,cont.designation,corp.head_count FROM corporate_appointments apt "
					+ " LEFT JOIN contact cont ON apt.contact_id = cont.contact_id "
					+ " LEFT JOIN corporate_details corp ON cont.corporate_id = corp.corporate_id  "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = apt.executive  "
					+ " WHERE appointment_date BETWEEN '"
					+ date
					+ "' AND '"
					+ date1 + "' AND apt.executive LIKE '%" + executive + "%'";
			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				CorporateAppointmentsDTO corporateDTO1 = new CorporateAppointmentsDTO();
				corporateDTO1.setAppointmentId(rs.getInt("appointment_id"));
				corporateDTO1.setName(rs.getString("contact_name"));
				corporateDTO1.setDesignation(rs.getString("designation"));
				corporateDTO1.setAppointmentDate(rs
						.getString("appointment_date"));
				corporateDTO1.setTimeAppointment(rs
						.getString("time_appointment"));
				corporateDTO1.setCorporateName(rs.getString("corporate_name"));
				corporateDTO1.setContactId(rs.getInt("contact_id"));
				corporateDTO1.setExecutive(rs.getString("emp_name"));
				corporateDTO1.setStatus(rs.getString("status"));
				corporateDTO1.setTotalStrength(rs.getInt("head_count"));
				corporateDTO.add(corporateDTO1);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateDTO;
	}

	public CorporateAppointmentsDTO getCorptAppointmentById(String id) {
		CorporateAppointmentsDTO corporateDTO1 = new CorporateAppointmentsDTO();
		try {
			String s = "SELECT * FROM corporate_appointments apt LEFT JOIN contact cont ON apt.`contact_id` = cont.`contact_id` "
					+ "LEFT JOIN corporate_details corp ON cont.`corporate_id` = corp.`corporate_id` "
					+ "LEFT JOIN employee_details emp ON emp.`emp_id` = apt.`executive` WHERE apt.`appointment_id`='"
					+ id + "'";
			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				corporateDTO1.setAppointmentId(rs.getInt("appointment_id"));
				corporateDTO1.setName(rs.getString("contact_name"));
				corporateDTO1.setDesignation(rs.getString("designation"));
				String appt = new SimpleDateFormat("dd/MM/yyyy").format(rs
						.getDate("appointment_date"));
				corporateDTO1.setAppointmentDate(appt);
				corporateDTO1.setTimeAppointment(rs
						.getString("time_appointment"));
				corporateDTO1.setCorporateName(rs.getString("corporate_name"));
				corporateDTO1.setContactId(rs.getInt("contact_id"));
				corporateDTO1.setExecutive(rs.getString("emp_name"));
				corporateDTO1.setStatus(rs.getString("status"));
				corporateDTO1.setRemarks(rs.getString("remarks"));

				corporateDTO1.setPrimaryMob(rs.getString("primary_contact"));
				corporateDTO1.setEmail(rs.getString("primary_email"));
				corporateDTO1.setLandline(rs.getString("executive"));
				corporateDTO1.setCorporateId(rs.getInt("corporate_id"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateDTO1;
	}

	public ArrayList<HashMap<String, String>> getBranchEmpDetails() {
		ArrayList<HashMap<String, String>> branchList = new ArrayList<>();
		try {
			String s = "SELECT branch, COUNT(1) AS 'Total Employee', AVG(bmi) as 'avgBmi' FROM welezohe_corp.sample_data GROUP BY 1";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("branch", rs.getString("branch"));
				list.put("totalEmployee", rs.getString("Total Employee"));
				list.put("avgBmi", rs.getString("avgBmi"));
				branchList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return branchList;
	}

	public HashMap<String, String> getInterActionCount() {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT  COUNT(1) as 'Total' FROM corporate_interaction WHERE DATE(interaction_date) = (CURRENT_DATE )";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("interActionCount", rs.getString("Total"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@RequestMapping(value = "corporateDashBoard")
	public ModelAndView getBranchEmpDesignationDetails(ModelMap model,
			Integer userId) {

		HashMap<String, String> employee = hrService
				.getEmployeeIdFromUserId(userId);

		HashMap<String, String> totalCorporateVisited = totalCorporateVisited();
		model.addAttribute("totalCorporateVisited", totalCorporateVisited);

		HashMap<String, String> totalCorporateAppt = totalCorporateAppt("appointment_date = CURRENT_DATE");
		model.addAttribute("totalCorporateAppt", totalCorporateAppt);

		HashMap<String, String> totalExecutiveAppt = totalCorporateAppt("appointment_date = CURRENT_DATE  AND executive ='"
				+ employee.get("empId") + "'");
		model.addAttribute("totalExecutiveAppt", totalExecutiveAppt);

		HashMap<String, String> totalCorporatetContact = totalCorporatetContact();
		model.addAttribute("totalCorporatetContact", totalCorporatetContact);

		HashMap<String, String> interActionCounts = getInterActionCount();
		model.addAttribute("interActionCounts", interActionCounts);

		return new ModelAndView("Admin/corporate/corporateDashboards");
	}

	public HashMap<String, String> getPreEmployeeDetails(Integer id) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM welezohe_corp.pre_employment pre "
					+ " LEFT JOIN welezohe_whms.corporate_offers off ON off.`offers_id` = pre.corporate_offer_id WHERE pre.id = '"
					+ id + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("empName", rs.getString("emp_name"));
				list.put("contactNo", rs.getString("contact_no"));
				list.put("age", rs.getString("age"));
				list.put("email", rs.getString("email"));
				list.put("appointmentLocation",
						rs.getString("appointment_location"));
				list.put("doa", rs.getString("doa"));
				list.put("time", rs.getString("time"));
				list.put("healthCheckUp", rs.getString("health_check_up"));
				list.put("address", rs.getString("address"));
				list.put("corporateOfferId", rs.getString("corporate_offer_id"));
				list.put("serviceId", rs.getString("service_id"));
				list.put("productId", rs.getString("product_id"));
				list.put("city", rs.getString("city"));
				list.put("pincode", rs.getString("pincode"));
				list.put("gender", rs.getString("gender"));
				list.put("corporateId", rs.getString("corporate_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<HashMap<String, String>> getAllPreEmployeeList() {
		ArrayList<HashMap<String, String>> employeeList = new ArrayList<>();
		try {
			String s = "SELECT pre.*,corp.corporate_name,prod.product_name FROM welezohe_corp.pre_employment pre  "
					+ "LEFT JOIN corporate_details corp ON corp.corporate_id = pre.corporate_id "
					+ "LEFT JOIN corporate_offers off ON off.offers_id = pre.corporate_offer_id "
					+ "LEFT JOIN product_master prod ON prod.product_id = off.product_id";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("id", rs.getString("id"));
				list.put("empName", rs.getString("emp_name"));
				list.put("contactNo", rs.getString("contact_no"));
				list.put("age", rs.getString("age"));
				list.put("email", rs.getString("email"));
				list.put("appointmentLocation",
						rs.getString("appointment_location"));
				list.put("doa", rs.getString("doa"));
				list.put("time", rs.getString("time"));
				list.put("productName", rs.getString("product_name"));
				list.put("address", rs.getString("address"));
				list.put("corporateName", rs.getString("corporate_name"));
				list.put("status", rs.getString("status"));
				employeeList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeList;
	}

	public HashMap<String, String> totalCorporateVisited() {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(DISTINCT `corporate_name`) AS 'Total_Corporate_Visted' FROM corporate_details";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("totalCount", rs.getString("Total_Corporate_Visted"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public HashMap<String, String> totalCorporateAppt(String condition) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) AS 'Total_Appt' FROM corporate_appointments WHERE "
					+ condition;

			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("totalCount", rs.getString("Total_Appt"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public HashMap<String, String> totalCorporatetContact() {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT COUNT(1) as 'Total contact' FROM contact";

			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				list.put("totalContact", rs.getString("Total contact"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<HashMap<String, String>> getCorporateApptThruCorpId(
			Integer corporateId) {
		ArrayList<HashMap<String, String>> apptList = new ArrayList<>();
		try {
			String s = "SELECT appt.appointment_id,cont.contact_name,cont.primary_contact,cont.designation,cont.primary_email,"
					+ " CONCAT(appt.appointment_date,':',appt.time_appointment) AS 'DOA & Time',appt.status,meeting_status,emp.emp_name "
					+ "FROM corporate_appointments appt LEFT JOIN contact cont ON cont.contact_id = appt.contact_id "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = appt.executive WHERE cont.corporate_id ='"
					+ corporateId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("appointmentId", rs.getString("appointment_id"));
				list.put("contactName", rs.getString("contact_name"));
				list.put("contactNo", rs.getString("primary_contact"));
				list.put("designation", rs.getString("designation"));
				list.put("email", rs.getString("primary_email"));
				list.put("doa", rs.getString("DOA & Time"));
				list.put("status", rs.getString("status"));
				list.put("meetingStatus", rs.getString("meeting_status"));
				list.put("executive", rs.getString("emp_name"));
				apptList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return apptList;
	}

	public ArrayList<HashMap<String, String>> getCorporateContactListCorpId(
			Integer corporateId) {
		ArrayList<HashMap<String, String>> apptList = new ArrayList<>();
		try {
			String s = "SELECT  cont.contact_id,cont.contact_name,  cont.designation,cont.primary_contact,cont.primary_email,"
					+ " cd.corporate_name, cont.corporate_id, cd.parent_id, cd.corporate_id "
					+ " FROM contact cont LEFT JOIN  corporate_details cd ON cont.corporate_id = cd.corporate_id "
					+ " WHERE cont.corporate_id = '"
					+ corporateId
					+ "' OR cd.parent_id = '" + corporateId + "'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("contactId", rs.getString("contact_id"));
				list.put("contactName", rs.getString("contact_name"));
				list.put("contactNo", rs.getString("primary_contact"));
				list.put("designation", rs.getString("designation"));
				list.put("email", rs.getString("primary_email"));
				list.put("corporateName", rs.getString("corporate_name"));
				apptList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return apptList;
	}

	public ArrayList<HashMap<String, String>> getCorporatePreEmploymentList(
			Integer corporateId) {
		ArrayList<HashMap<String, String>> preApptList = new ArrayList<>();
		try {
			String s = "SELECT emp_name,contact_no,age,gender,doa,STATUS FROM welezohe_corp.pre_employment WHERE corporate_id = '"
					+ corporateId + "' ORDER BY doa";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("empName", rs.getString("emp_name"));
				list.put("contactNo", rs.getString("contact_no"));
				list.put("age", rs.getString("age"));
				list.put("gender", rs.getString("gender"));
				list.put("doa", rs.getString("doa"));
				list.put("status", rs.getString("STATUS"));
				preApptList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return preApptList;
	}

	public HashMap<String, String> getCorporateContactByID(Integer contactId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT  cont.contact_id,cont.contact_name,  cont.designation,cont.primary_contact,cont.primary_email,"
					+ " cd.corporate_name, cont.corporate_id, cd.parent_id, cd.corporate_id "
					+ " FROM contact cont LEFT JOIN  corporate_details cd ON cont.corporate_id = cd.corporate_id "
					+ " WHERE cont.contact_id = '" + contactId + "'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("contactId", rs.getString("contact_id"));
				list.put("contactName", rs.getString("contact_name"));
				list.put("contactNo", rs.getString("primary_contact"));
				list.put("designation", rs.getString("designation"));
				list.put("email", rs.getString("primary_email"));
				list.put("corporateName", rs.getString("corporate_name"));
				list.put("corporateId", rs.getString("corporate_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<HashMap<String, String>> getCorporatInterActionList(
			Integer corporateId) {
		ArrayList<HashMap<String, String>> preApptList = new ArrayList<>();
		try {
			String s = "SELECT inter.corp_interaction_id,con.contact_name,inter.interaction_mode,emp.emp_name,inter.purpose,inter.status,"
					+ " inter.remarks,inter.interaction_date FROM corporate_interaction inter "
					+ " LEFT JOIN contact con ON con.contact_id = inter.contact_id "
					+ " LEFT JOIN `employee_details` emp ON emp.emp_id = inter.interaction_by "
					+ " WHERE inter.corporate_id ='"
					+ corporateId
					+ "' ORDER BY inter.interaction_date DESC ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("corpInteractionId",
						rs.getString("corp_interaction_id"));
				list.put("contactName", rs.getString("contact_name"));
				list.put("interactionMode", rs.getString("interaction_mode"));
				list.put("interActedBy", rs.getString("emp_name"));
				list.put("purpose", rs.getString("purpose"));
				list.put("remarks", rs.getString("remarks"));
				list.put("status", rs.getString("status"));
				list.put("interactionDate", rs.getString("interaction_date"));

				preApptList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return preApptList;
	}

	public ArrayList<HashMap<String, String>> getCorporatInterActionList(
			String fromDate, String toDate, String executive) {
		ArrayList<HashMap<String, String>> preApptList = new ArrayList<>();
		String date = null;
		String date1 = null;

		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			String s = "SELECT inter.corp_interaction_id,con.contact_name,corp.corporate_name,inter.interaction_mode,emp.emp_name,inter.purpose,inter.status,"
					+ " inter.remarks,inter.interaction_date FROM corporate_interaction inter LEFT JOIN contact con ON con.contact_id = inter.contact_id  "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = inter.interaction_by "
					+ " LEFT JOIN corporate_details corp ON corp.corporate_id = inter.corporate_id  "
					+ " WHERE inter.interaction_date BETWEEN '"
					+ date
					+ " 00:00:00' AND '"
					+ date1
					+ " 23:59:59' AND inter.interaction_by LIKE '%"
					+ executive
					+ "%' " + " ORDER BY inter.interaction_date DESC";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("corpInteractionId",
						rs.getString("corp_interaction_id"));
				list.put("contactName", rs.getString("contact_name"));
				list.put("interactionMode", rs.getString("interaction_mode"));
				list.put("interActedBy", rs.getString("emp_name"));
				list.put("purpose", rs.getString("purpose"));
				list.put("remarks", rs.getString("remarks"));
				list.put("status", rs.getString("status"));
				list.put("interactionDate", rs.getString("interaction_date"));
				list.put("corporateName", rs.getString("corporate_name"));

				preApptList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return preApptList;
	}

	public boolean validateCorporateDetails(String corporateName) {

		boolean corporate = false;
		try {
			String s = "SELECT corporate_id FROM corporate_details WHERE corporate_name = '"
					+ corporateName + "' ";
			// System.out.println(s);
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement;
			prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				corporate = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporate;
	}

	public ArrayList<HashMap<String, String>> getAllCorporate() {

		ArrayList<HashMap<String, String>> corporateList = new ArrayList<>();

		try {
			String s = "SELECT corp.corporate_id,corp.corporate_name,wel.c_value,corp.head_count,adr.city,adr.pincode,adr.alt_no,emp.emp_name"
					+ " FROM corporate_details corp LEFT JOIN contact_address adr ON adr.entity_id = corp.corporate_id "
					+ " LEFT JOIN welezo_constants wel ON wel.id = corp.entity_type LEFT JOIN `employee_details` emp ON emp.`emp_id` = corp.executive "
					+ " WHERE adr.address_type = 11 ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("corporateId", rs.getString("corporate_id"));
				list.put("corporateName", rs.getString("corporate_name"));
				list.put("entityType", rs.getString("c_value"));
				list.put("headCount", rs.getString("head_count"));
				list.put("city", rs.getString("city"));
				list.put("pincode", rs.getString("pincode"));
				list.put("contactNo", rs.getString("alt_no"));
				list.put("executive", rs.getString("emp_name"));
				corporateList.add(list);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateList;
	}

	public CorporateServiceOffersTO getCorpServiceById(Integer id) {

		CorporateServiceOffersTO corporateServiceOffersTO = new CorporateServiceOffersTO();
		try {
			String s = "SELECT *  FROM corporate_service_offers WHERE `corporate_id`='"
					+ id + "' ";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				corporateServiceOffersTO.setProductId(rs.getInt("product_id"));
				corporateServiceOffersTO.setCorpId(rs.getInt("corporate_id"));
				corporateServiceOffersTO.setHealthCheckId(rs
						.getString("health_check_id"));
				corporateServiceOffersTO.setServiceHeadCount(rs
						.getInt("service_head_count"));
				corporateServiceOffersTO.setIsActive(rs.getInt("is_active"));
				corporateServiceOffersTO.setProName(rs
						.getString("product_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corporateServiceOffersTO;

	}

	public ArrayList<HashMap<String, String>> getAllCorpProd() {
		ArrayList<HashMap<String, String>> prodList = new ArrayList<HashMap<String, String>>();

		try {

			String s = " SELECT DISTINCT corp.`corporate_id`,corp.`corporate_name`,corp.`head_count`,adr.city,adr.pincode,adr.alt_no, emp.emp_name "
					+ " FROM `corporate_details` corp "
					+ " LEFT JOIN corporate_service_offers cso ON corp.`corporate_id`=cso.`corporate_id`"
					+ " LEFT JOIN contact_address adr ON adr.entity_id = corp.corporate_id "
					+ " LEFT JOIN `employee_details` emp ON emp.`emp_id`=corp.`executive` "
					+ " WHERE adr.address_type=11";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("corpId", rs.getString("corporate_id"));
				list.put("corpName", rs.getString("corporate_name"));
				list.put("headCount", rs.getString("head_count"));
				list.put("city", rs.getString("city"));
				list.put("pincode", rs.getString("pincode"));
				list.put("altNo", rs.getString("alt_no"));
				list.put("empName", rs.getString("emp_name"));
				prodList.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prodList;
	}

	public ArrayList<HashMap<String, String>> getCorpProdById(
			Integer corporateId) {

		ArrayList<HashMap<String, String>> prodList = new ArrayList<HashMap<String, String>>();

		try {
			String s = " SELECT DISTINCT cso.`corporate_id`,cso.`product_id`,corp.`corporate_name`,cso.`health_check_id`,cso.`service_head_count`,cso.`is_active`,cso.`product_name` "
					+ " FROM corporate_service_offers cso "
					+ " LEFT JOIN `corporate_details` corp ON corp.`corporate_id`=cso.`corporate_id` "
					+ " LEFT JOIN `product_gen` pro ON  cso.`product_id`=pro.`product_id` "
					+ " WHERE corp.`corporate_id`=" + corporateId;

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("corpId", rs.getString("corporate_id"));
				list.put("corpName", rs.getString("corporate_name"));
				list.put("prodId", rs.getString("product_id"));
				list.put("healthId", rs.getString("health_check_id"));
				list.put("headCount", rs.getString("service_head_count"));
				list.put("isActive", rs.getString("is_active"));
				list.put("proName", rs.getString("product_name"));

				prodList.add(list);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prodList;
	}

	public ArrayList<HashMap<String, String>> getCorpProducts(Integer prodId) {

		ArrayList<HashMap<String, String>> proList = new ArrayList<HashMap<String, String>>();
		String s = "SELECT pgen.`service_list`,spa.`screening`,ssub.`screening` AS health_parameter"
                +" FROM `product_gen`  pgen "
                +" LEFT JOIN  `service_parameters` ssub ON pgen.`service_list`=ssub.`health_parameter_id` " 
                +" LEFT JOIN `service_parameters` spa ON ssub.`parentId`=spa.`health_parameter_id` "
                +" WHERE `product_id`= '"
                +  prodId
                + "' ORDER BY spa.`screening`";


		try {

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> listServices = new HashMap<String, String>();
				listServices.put("serviceId", rs.getString("service_list"));
				listServices.put("serviceCategory", rs.getString("screening"));
				listServices.put("serviceParameters",
						rs.getString("health_parameter"));

				proList.add(listServices);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return proList;
	}

	public ArrayList<HashMap<String, String>> getCorpPrefHospital(String city) {
		ArrayList<HashMap<String, String>> hospitalDetails = new ArrayList<>();
		try {

			String s = "SELECT  hosp.`hospital_id`, hosp.`name_hcc`,hosp.`address`,hosp.`location`,hosp.`city` "
					+ " FROM empanellment hosp "
					+ " RIGHT JOIN prefempanellment_corp pcorp "
					+ " ON hosp.`hospital_id`= pcorp.`hospital_id` "
					+ " WHERE hosp.city ='"
					+ city
					+ "' AND hosp.isActive = TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("hospitalId", rs.getString("hospital_id"));
				list.put("nameHcc", rs.getString("name_hcc"));
				list.put("address", rs.getString("address"));
				list.put("city", rs.getString("city"));
				list.put("location", rs.getString("location"));
				hospitalDetails.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return hospitalDetails;

	}

	public ArrayList<HashMap<String, String>> getEmailByCorpId(
			Integer corporateId) {
		ArrayList<HashMap<String, String>> corpEmailDetails = new ArrayList<>();
		try {

			String s = " SELECT emp.`emp_name` AS executive_name, emp.corporate_email AS executive_email, emp1.`emp_name`AS reportingto_name, emp1.`corporate_email`AS reportto_email "
					+ " FROM employment_history emh "
					+ " LEFT JOIN `employee_details` emp ON emp.`emp_id`=emh.`emp_id`"
					+ " LEFT JOIN employee_details emp1 ON emp1.`emp_id`=emh.`reporting_mgr_id` "
					+ " LEFT JOIN `corporate_details` corp ON corp.`executive`= emp.`emp_id` "
					+ " WHERE CURRENT_DATE BETWEEN from_date AND to_date "
					+ " AND corp.`corporate_id`='" + corporateId + "'";

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("executiveName", rs.getString("executive_name"));
				list.put("executiveEmail", rs.getString("executive_email"));
				list.put("reporttoName", rs.getString("reportingto_name"));
				list.put("reporttoEmail", rs.getString("reportto_email"));
				corpEmailDetails.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return corpEmailDetails;
	}
	public List<ServiceParametersTo> getServiceParameters() {

		List<ServiceParametersTo> serviceList = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(
				ServiceParametersTo.class, "custDetail");
		@SuppressWarnings("unchecked")
		Collection<? extends ServiceParametersTo> theUserList = (Collection<? extends ServiceParametersTo>) theCriteria
				.list();

		serviceList.addAll(theUserList);
		return serviceList;

	}

	public ArrayList<HashMap<String, String>> getServiceList() {

		ArrayList<HashMap<String, String>> proList = new ArrayList<HashMap<String, String>>();
		String s = "SELECT * FROM `serviceParametersOld`";

		try {

			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(s);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> listServices = new HashMap<String, String>();
				listServices.put("serviceId",
						rs.getString("health_parameter_id"));
				listServices.put("serviceName", rs.getString("screening"));
				listServices.put("category", rs.getString("health_parameter"));

				proList.add(listServices);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return proList;
	}

public List<ServiceParametersTo> getServiceParametersList() {
		
		List<ServiceParametersTo> serviceList = new ArrayList<>();
		Session session = getSession();
		Criteria theCriteria = session.createCriteria(ServiceParametersTo.class,
				"custDetail");
		@SuppressWarnings("unchecked")
		Collection<? extends ServiceParametersTo> theUserList = (Collection<? extends ServiceParametersTo>) theCriteria
				.list();

		serviceList.addAll(theUserList);
		return serviceList;	
	
}

/*@RequestMapping(value = "charts1")
public ModelAndView searchCallDetails(ModelMap model) {
	String object = "";
	String object1 = "";
	try {
		String s = "SELECT emp_department AS Dept , COUNT(*) AS COUNT FROM employee "
				+ "GROUP BY emp_department";
		Connection connection = sessionFactory.getCurrentSession()
				.connection();
		PreparedStatement preparedStatement;
		preparedStatement = connection.prepareStatement(s);
		ResultSet rs = preparedStatement.executeQuery();
		
		JSONArray mArray = new JSONArray();
		
		ObjectMapper objectMapper = new ObjectMapper();  
		List<Integer> list = new ArrayList<Integer>();
		
		//ObjectMapper objectMapper1 = new ObjectMapper();  
		List<String> list2 = new ArrayList<String>();
		while (rs.next()) {
			
			JSONObject obj = new JSONObject();
			list.add(rs.getInt("COUNT"));
			list2.add(rs.getString("Dept"));
		}
		try {
			
	        object = objectMapper.writeValueAsString(list);
	        System.out.println("json Count= " + object);
	        
	        object1 = objectMapper.writeValueAsString(list2);
	        System.out.println("json Dept= " + object1);
	        
	    } catch (JsonProcessingException e) {
	        e.printStackTrace();
	        
	    }

String string = mArray.toString();
System.out.println("Array values : "+ object);
model.addAttribute("Count", object);
model.addAttribute("Dept", object1);

} catch (Exception e) {
e.printStackTrace();
}
	return new ModelAndView("Admin/graph");
}*/



@RequestMapping(value="/charts1")  //requesting a url
public  ModelAndView corpChart(ModelMap model) {
	String object = "";
	String object2 = "";
	String object3 = "";
	String object4 = "";
	String object5 = "";
	String object6 = "";
	
	try {
		String s = "SELECT LEFT(created_date,7) AS 'Date' ,COUNT(1) AS 'Total' FROM corporate_details "
				+ " GROUP BY  LEFT(created_date,7)";//query one
		
		
		String s1 = "SELECT department AS Dept,COUNT(1) AS COUNT FROM employment_history"
				+ " WHERE CURRENT_DATE BETWEEN from_date AND to_date GROUP BY department"; //query two
		
		String s2 = "SELECT product_name AS aname,product_price AS bname FROM product_master "
				+ "WHERE CURRENT_DATE BETWEEN start_date AND valid_till ";//query three
		
		String s3 = "SELECT prod.product_name AS NAME, COUNT(tx.product_id) AS 'y' FROM "
				+ "transaction_master tx LEFT JOIN product_master prod ON"
				+ " prod.product_id = tx.product_id GROUP BY tx.product_id";
				 //query four
		String s4 = "SELECT ser.service_name AS name, COUNT(toff.service_id) AS 'y',COUNT(toff.usage_id) AS 'x'"
				+ " FROM transaction_offers toff LEFT JOIN services ser ON "
				+ "ser.service_id = toff.service_id GROUP BY toff.service_id ";
		
		Connection connection = sessionFactory.getCurrentSession()
				.connection();
		
		PreparedStatement preparedStatement;//query one
		PreparedStatement preparedStatement1;//query two
		PreparedStatement preparedStatement2;//query three
		PreparedStatement preparedStatement3;//query four
		PreparedStatement preparedStatement4;//query four
		
		preparedStatement = connection.prepareStatement(s);
		preparedStatement1 = connection.prepareStatement(s1);
		preparedStatement2 = connection.prepareStatement(s2);
		preparedStatement3 = connection.prepareStatement(s3);
		preparedStatement4 = connection.prepareStatement(s4);
		
		ResultSet rs = preparedStatement.executeQuery();//query one
		ResultSet rs1 = preparedStatement1.executeQuery();//query two
		ResultSet rs2 = preparedStatement2.executeQuery();//query three
		ResultSet rs3 = preparedStatement3.executeQuery();//query three
		ResultSet rs4 = preparedStatement4.executeQuery();//query three
		
		JSONArray mArray = new JSONArray();//json object
		
		ObjectMapper objectMapper = new ObjectMapper(); //creating onject mapper
		List<Integer> list = new ArrayList<Integer>(); //query one
		
		//ObjectMapper objectMapper1 = new ObjectMapper();  
		List<String> list2 = new ArrayList<String>();//query two
		
		
		//ObjectMapper objectMapper3 = new ObjectMapper();  
		List list3 = new ArrayList();//query three
		
		List list4 = new ArrayList();//query four
		List list5 = new ArrayList();//query four
		List list6 = new ArrayList();//query four
		//ObjectMapper objectMapper1 = new ObjectMapper();  
		//List<String> list4 = new ArrayList<String>();
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm"); //query one date formate converting 
		SimpleDateFormat formatter = new SimpleDateFormat("mm/yyyy");
		String date = null;
		
		while (rs.next()) {
		
			JSONObject obj = new JSONObject();
			list.add(rs.getInt("Total"));
			
			
			//System.out.println(sdf.format(rs.getDate("Date")));
			try {

				date = formatter.format(sdf.parse(rs.getString("Date")));
			} catch (Exception e) {
				e.printStackTrace();
			}	
			list2.add(date);

			/*obj.put("date", rs.getString("Date"));*/
			//obj.put("calls", rs.getString("Total"));
			//mArray.put(obj);
		}
		
	
		while (rs1.next()) {
			
		//	JSONObject obj = new JSONObject();
			Map maps = new HashMap();
			maps.put("name", rs1.getString("Dept"));
			maps.put("y", rs1.getInt("COUNT"));
			
			list3.add(maps);
			/*list3.add(rs1.getInt("COUNT"));
			list4.add();*/
			
			

			/*obj.put("date", rs.getString("Date"));*/
			//obj.put("calls", rs.getString("Total"));
			//mArray.put(obj);
		}
		
		while (rs2.next()) {
				Map maps = new HashMap();
				maps.put("name", rs2.getString("aname"));
				maps.put("y", rs2.getFloat("bname"));
				list4.add(maps);
			}
		while (rs3.next()) {
			Map maps = new HashMap();
			maps.put("name", rs3.getString("name"));
			maps.put("y", rs3.getInt("y"));
			list5.add(maps);
		}
		while (rs4.next()) {
			Map maps = new HashMap();
			maps.put("name", rs4.getString("name"));
			maps.put("y", rs4.getInt("y"));
			maps.put("x", rs4.getInt("x"));
			//maps.put("x", rs4.getInt("y"));
			list6.add(maps);
		}
		
		try {
			
			        object = objectMapper.writeValueAsString(list);
			        System.out.println("json JSON= " + object);
			        
			        object2 = objectMapper.writeValueAsString(list2);
			        System.out.println("json DAte= " + object2);
			        
			       object3 = objectMapper.writeValueAsString(list3);
			       
			        //System.out.println("json JSON= " + object3);
			       object4 = objectMapper.writeValueAsString(list4); 
			       
			       object5 = objectMapper.writeValueAsString(list5); 
			       
			       object6 = objectMapper.writeValueAsString(list6); 
			        //object4 = objectMapper.writeValueAsString(object3);
			       // System.out.println("json DAte= " + object4);*/
			        
			        
			    } catch (JsonProcessingException e) {
			        e.printStackTrace();
			        
			    }
		
		/*String string = mArray.toString();*/
		System.out.println("Array values : "+ object);
		System.out.println("Array values : "+ object2);
		/*System.out.println("Array values : "+ object4);*/
		/*System.out.println("Array values dept and count : "+ object3);
		System.out.println("Array values packages and price : "+ object4);*/
		System.out.println("Array  packages and Total Customer : "+ object5);
		System.out.println("Array  service and Total service : "+ object6);
		
		model.addAttribute("object", object);
		model.addAttribute("dateobject", object2);
		model.addAttribute("deptcount", object3);//key pair value for pie chart
		model.addAttribute("packagePrice", object4);
		model.addAttribute("packageServive", object5);
		model.addAttribute("totalServive", object6);
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	return new ModelAndView("Admin/graph");
}

//@Path("/charts")

//@Produces(MediaType.APPLICATION_JSON_VALUE)
@GET
@Path("/get")
@Produces(MediaType.APPLICATION_JSON)
public User getjson(){
	User u = new User();
	u.setId(1);
	u.setName("metallica");
	//System.out.println("hello"+u);
	return u;
	
}

}
