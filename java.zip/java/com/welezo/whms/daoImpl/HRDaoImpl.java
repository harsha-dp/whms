package com.welezo.whms.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.welezo.whms.commons.CustomHibenateDaoSupport;
import com.welezo.whms.dao.HRDao;
import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.EmployeeQualificationDTO;
import com.welezo.whms.dto.PerformanceMetricsDTO;
import com.welezo.whms.to.ExperienceDetailsTO;
import com.welezo.whms.to.HireCompanyTO;
import com.welezo.whms.to.RoleMasterTO;
@SuppressWarnings("deprecation")
@Repository
public class HRDaoImpl extends CustomHibenateDaoSupport implements HRDao {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public EmployeeDetailsDTO getEmployeeById(int id) {
		ResultSet rs = null;
		EmployeeDetailsDTO employeeDetails = new EmployeeDetailsDTO();

		try {
			String s = "SELECT * FROM employee_details WHERE emp_id = '"+id+"'";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			rs = prepareStatement.executeQuery();
			if (rs.next()) {
				employeeDetails.setEmpId(rs.getInt("emp_id"));
				employeeDetails.setEmpName(rs.getString("emp_name"));
				employeeDetails.setFHName(rs.getString("f_h_name"));
				employeeDetails.setRelationship(rs.getString("relationship"));
				try{
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
				employeeDetails.setDob(sdf.format(rs.getDate("dob")));
				}catch(NullPointerException e){
					e.printStackTrace();
				}
				employeeDetails.setGender(rs.getString("gender"));
				employeeDetails.setMaritalStatus(rs.getString("marital_status"));
				employeeDetails.setPersonalContact(rs.getString("personal_contact"));
				employeeDetails.setBloodGroup(rs.getString("blood_group"));
				employeeDetails.setEmergencyContact(rs.getString("emergency_contact"));
				employeeDetails.setPermanentAddress(rs.getString("permanent_address"));
				employeeDetails.setCommunicationAddresss(rs.getString("communication_addresss"));
				employeeDetails.setEmployeeId(rs.getString("employee_id"));
				employeeDetails.setPersonalEmail(rs.getString("personal_email"));
				employeeDetails.setCorporateEmail(rs.getString("corporate_email"));
				employeeDetails.setStatus(rs.getString("status"));
				employeeDetails.setBiometricId(rs.getInt("biometric_id"));
				employeeDetails.setRemarks(rs.getString("remarks"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeDetails;
	}

	@Override
	public List<EmployeeQualificationDTO> getEmpQualifiaction(Integer empId) {
		List<EmployeeQualificationDTO> qualificationList = new ArrayList<>();
		try {
			String s = "SELECT * FROM employee_qualification quln "
					+ " LEFT JOIN qualification_master mast ON mast.qualification_id = quln.qualification_id WHERE emp_id= '"+empId+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				EmployeeQualificationDTO qualification = new EmployeeQualificationDTO();
				qualification.setEmpQufnId(rs.getInt("emp_qufn_id"));
				qualification.setInstitute(rs.getString("institute"));
				qualification.setUniversity(rs.getString("university"));
				qualification.setPercentage(rs.getFloat("percentage"));
				qualification.setQualifiedYear(rs.getInt("qualified_year"));
				qualification.setSpecialization(rs.getString("specialization"));
				qualification.setQualification(rs.getString("qualification"));
				qualificationList.add(qualification);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return qualificationList;
	}

	@Override
	public List<ExperienceDetailsTO> getEmpExperience(Integer empId) {
		List<ExperienceDetailsTO> experienceList = new ArrayList<>();

		try {
			String s = "SELECT * FROM experience_details WHERE emp_id = '"+empId+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				ExperienceDetailsTO experience = new ExperienceDetailsTO();
				experience.setExpId(rs.getInt("exp_id"));
				experience.setCompanyName(rs.getString("company_name"));
				experience.setDesignation(rs.getString("designation"));
				experience.setFromDate(rs.getDate("from_date"));
				experience.setToDate(rs.getDate("to_date"));
				experience.setCtcAnnum(rs.getFloat("ctc_annum"));
				experienceList.add(experience);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return experienceList;
	}

	@Override
	public List<EmployeeDetailsDTO> getAllEmployees(String status) {
		List<EmployeeDetailsDTO> empList = new ArrayList<>();

		try {
			String s = "SELECT emp.*,img.emp_img FROM employee_details emp "
					+ " LEFT JOIN employee_images img ON img.emp_id = emp.emp_id  WHERE "+status+" ORDER BY emp.emp_id ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				EmployeeDetailsDTO employeeDetails = new EmployeeDetailsDTO();
				employeeDetails.setEmpId(rs.getInt("emp_id"));
				employeeDetails.setEmpName(rs.getString("emp_name"));
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					employeeDetails.setDob(sdf.format(rs.getDate("dob")));
					}catch(Exception e){
						e.printStackTrace();
					}
				employeeDetails.setGender(rs.getString("gender"));
				employeeDetails.setPersonalContact(rs.getString("personal_contact"));
				employeeDetails.setBloodGroup(rs.getString("blood_group"));
				employeeDetails.setMaritalStatus(rs.getString("marital_status"));
				employeeDetails.setEmergencyContact(rs.getString("emergency_contact"));
				employeeDetails.setPermanentAddress(rs.getString("permanent_address"));
				employeeDetails.setCommunicationAddresss(rs.getString("communication_addresss"));
				String encode = Base64.encodeBase64String(rs.getBytes("emp_img"));
				employeeDetails.setEmployeeImage(encode);
				employeeDetails.setEmployeeId(rs.getString("employee_id"));
				employeeDetails.setPersonalEmail(rs.getString("personal_email"));
				employeeDetails.setCorporateEmail(rs.getString("corporate_email"));
				employeeDetails.setStatus(rs.getString("status"));
				empList.add(employeeDetails);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empList;
	}

	@Override
	public void saveInterviewRemarks(EmployeeQualificationDTO employeeDetails) {
		try {
			String query = "UPDATE employee_details SET remarks ='"+employeeDetails.getRemarks()+"', STATUS = '"+employeeDetails.getStatus()+"',update_date= CURRENT_TIMESTAMP WHERE emp_id ='"+employeeDetails.getEmpId()+"' ";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			 updPrepStmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<RoleMasterTO> getAllRoles() {
		List<RoleMasterTO> roleList = new ArrayList<>();

		try {
			String s = "SELECT role_id, CONCAT(designation, '(',  business_unit, '-', department, '-', section, ')' ) AS designation_display FROM role_master";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				RoleMasterTO roles = new RoleMasterTO();
				roles.setRoleId(rs.getInt("role_id"));
				roles.setDesignation(rs.getString("designation_display"));
				roleList.add(roles);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return roleList;
	}

	@Override
	public List<EmployeeQualificationDTO> getEmpRoleDesignation(Integer empId) {
		List<EmployeeQualificationDTO> roleList = new ArrayList<>();

		try {
			String s = "SELECT role.emp_role_id,emp.emp_name,role.from_date,role.to_date,role.emp_type, emp1.emp_name AS 'report to',emp.`emp_id`, "
					+ " CONCAT(roles.designation, '(', roles.grade, '-', roles.business_unit, '-', roles.department, '-', roles.section, ')' ) AS 'designation_display' ,"
					+ "sal.slab_id,sal.slab_name  FROM employee_roles role LEFT JOIN employee_details emp ON emp.emp_id = role.emp_id "
					+ "LEFT JOIN employee_details emp1 ON emp1.emp_id = role.report_to LEFT JOIN role_master roles ON roles.role_id = role.role_id "
					+ " LEFT JOIN salary_slab sal ON sal.slab_id = role.slab_id "
					+ " WHERE emp.emp_id = '"+empId+"'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				EmployeeQualificationDTO roles = new EmployeeQualificationDTO();
				roles.setExpId(rs.getInt("emp_role_id"));
				roles.setEmpName(rs.getString("emp_name"));
				try{
				roles.setFromDate(rs.getDate("from_date"));
				roles.setToDate(rs.getDate("to_date"));
				}catch(Exception e){
					e.printStackTrace();
				}
				roles.setCompanyName(rs.getString("report to"));
				roles.setDesignation(rs.getString("designation_display"));
				roles.setLevel(rs.getString("emp_type"));
				roles.setEmpQufnId(rs.getInt("slab_id"));
				roles.setSpecialization(rs.getString("slab_name"));
				roleList.add(roles);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return roleList;
	}

	@Override
	public List<RoleMasterTO> getAllDepartment() {
		List<RoleMasterTO> roleList = new ArrayList<>();

		try {
			String s = "SELECT DISTINCT department FROM role_master";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				RoleMasterTO roles = new RoleMasterTO();
				//roles.setRoleId(rs.getInt("role_id"));
				roles.setDepartment(rs.getString("department"));
				roleList.add(roles);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return roleList;
	}

	@Override
	public List<EmployeeQualificationDTO> getEmpDeptWise(String departmentName) {
		List<EmployeeQualificationDTO> empList = new ArrayList<>();

		try {
			String s = "SELECT  emp.emp_id,emp.emp_name,emp.corporate_email,role.role_id,mast.department,mast.designation ,img.emp_img "
					+ "FROM employee_details emp LEFT JOIN employee_roles role ON role.emp_id = emp.emp_id "
					+ "LEFT JOIN employee_images img ON img.emp_id = emp.emp_id "
					+ "LEFT JOIN role_master mast ON mast.role_id = role.role_id  WHERE CURRENT_DATE BETWEEN role.from_date AND role.to_date  "
					+ "AND  mast.department = '"+departmentName+"'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				EmployeeQualificationDTO dept = new EmployeeQualificationDTO();
				dept.setEmpId(rs.getInt("emp_id"));
				dept.setEmpName(rs.getString("emp_name"));
				dept.setDesignation(rs.getString("designation"));
				dept.setCompanyName(rs.getString("department"));
				dept.setCorporateEmail(rs.getString("corporate_email"));
				String encode = Base64.encodeBase64String(rs.getBytes("emp_img"));
				dept.setEmployeeImage(encode);
				empList.add(dept);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllLeaves(String fromdate, String toDate) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {

			date = formatter.format(sdf.parse(fromdate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> leavesList = new ArrayList<>();
		try {
			String s = "SELECT req.*,emp.emp_name FROM leave_request req "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = req.emp_id "
					+ " WHERE req.from_date AND req.to_date BETWEEN '"+date+"' AND '"+date1+"' ";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("requestId", rs.getString("request_id"));
					list.put("empId", rs.getString("emp_id"));
					SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/YYYY");
					try{
						list.put("fromDate",sdf1.format(rs.getDate("from_date")));
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					try{
						list.put("toDate",sdf1.format(rs.getDate("to_date")));
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					list.put("totalDays", rs.getString("total_days"));
					list.put("leaveType", rs.getString("leave_type"));
					list.put("description", rs.getString("description"));
					list.put("status", rs.getString("status"));
					list.put("empName", rs.getString("emp_name"));
				
					leavesList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return leavesList;
	}

	@Override
	public EmployeeQualificationDTO getEmpRoleById(Integer roleId) {
		EmployeeQualificationDTO roles = new EmployeeQualificationDTO();
		try {
			String s = "SELECT role.emp_role_id,role.branch_id,role.role_id,role.emp_id,role.from_date,role.to_date,role.report_to,"
					+ "role.emp_type,emp.emp_name,CONCAT(mast.designation, '(', mast.grade, '-', mast.business_unit, '-', mast.department, '-', mast.section, ')' ) "
					+ "AS 'designation_display', emp1.emp_name As 'report to' FROM employee_roles role LEFT JOIN employee_details emp ON emp.emp_id = role.emp_id "
					+ "LEFT JOIN role_master mast ON mast.role_id = role.role_id  LEFT JOIN employee_details emp1 ON emp1.emp_id = role.report_to "
					+ " WHERE role.`emp_role_id` = '"+roleId+"' ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			if (rs.next()) {
				roles.setExpId(rs.getInt("emp_role_id"));
				roles.setEmpName(rs.getString("emp_name"));
				roles.setEmpId(rs.getInt("emp_id"));
				roles.setEmpQufnId(rs.getInt("role_id"));
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					roles.setDob(sdf.format(rs.getDate("from_date")));
					}catch(Exception e){
						e.printStackTrace();
					}
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					roles.setFHName(sdf.format(rs.getDate("to_date")));
					}catch(Exception e){
						e.printStackTrace();
					}
				roles.setCompanyName(rs.getString("report to"));
				roles.setDesignation(rs.getString("designation_display"));
				roles.setLevel(rs.getString("emp_type"));
				roles.setBiometricId(rs.getInt("report_to"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return roles;
	}
	

	@Override
	public ArrayList<HashMap<String, String>> getAllSalSlab() {
		ArrayList<HashMap<String, String>> salList = new ArrayList<>();
		try {
			String s = "SELECT * FROM salary_slab WHERE isActive IS TRUE";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("slabId", rs.getString("slab_id"));
					list.put("slabName", rs.getString("slab_name"));
					list.put("description", rs.getString("slab_description"));
				
				salList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return salList;
	}
	@Override
	public HashMap<String, String> getSalarySlabDetails(Integer slabId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT slab_id, slab_name, gross, basic_percent, ROUND(gross*basic_percent/100,0) AS basic,"
					+ " ROUND((hra_perc/100)*(gross*basic_percent/100)) AS hra, "
					+ " ROUND(gross - (gross*basic_percent/100 + (hra_perc/100)*(gross*basic_percent/100))) AS others,"
					+ " ROUND(IF(gross >= 21000, 0 ,  1.75*gross/100), 0) AS esi, "
					+ " ROUND(gross*basic_percent/100*0.12, 0) AS epf, IF(gross>15000, 200, 0) AS pt, "
					+ " ROUND( gross - IF(gross >= 21000, 0 ,  1.75*gross/100) -  gross*basic_percent/100*0.12 - IF(gross>15000, 200, 0) ,0) AS nett,"
					+ " ROUND(gross*basic_percent/100*0.12) AS company_pf, "
					+ " ROUND(IF(gross >= 21000, 0 ,  4.75*gross/100), 0) AS company_esi, "
					+ " ROUND((gross + IF(gross >= 21000, 0 ,  4.75*gross/100) + gross*basic_percent/100*0.12), 0) AS ctc "
					+ "FROM salary_slab WHERE slab_id = '"+slabId+"'";
			
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
					list.put("slabId", rs.getString("slab_id"));
					list.put("slabName", rs.getString("slab_name"));
					list.put("gross", rs.getString("gross"));
					list.put("basicPercent", rs.getString("basic_percent"));
					list.put("basic", rs.getString("basic"));
					list.put("hra", rs.getString("hra"));
					list.put("others", rs.getString("others"));
					list.put("esi", rs.getString("esi"));
					list.put("epf", rs.getString("epf"));
					list.put("pt", rs.getString("pt"));
					list.put("nett", rs.getString("nett"));
					list.put("company_pf", rs.getString("company_pf"));
					list.put("company_esi", rs.getString("company_esi"));
					list.put("ctc", rs.getString("ctc"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllGoals(String fromDate,String toDate, String status) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		PreparedStatement prepareStatement = null;
		ArrayList<HashMap<String, String>> goalList = new ArrayList<>();
		try {
			String s = "SELECT goal.*,emp.emp_name AS 'Set For',emp1.emp_name AS 'Set By' FROM goal_setting goal "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = goal.goal_set_for "
					+ "LEFT JOIN employee_details emp1 ON emp1.emp_id = goal.goal_set_by "
					+ " WHERE (goal.goal_from AND goal.goal_to BETWEEN '"+date+"' AND '"+date1+"') AND goal.status = '"+status+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("goalId", rs.getString("goal_id"));
					list.put("goalName", rs.getString("goal_name"));
					list.put("goalSetFor", rs.getString("goal_set_for"));
					list.put("goalSetBy", rs.getString("goal_set_by"));
					list.put("goalFrom", rs.getString("goal_from"));
					list.put("goalTo", rs.getString("goal_to"));
					list.put("status", rs.getString("status"));
					list.put("goalInfo", rs.getString("goal_info"));
					list.put("remarks", rs.getString("remarks"));
					list.put("setFor", rs.getString("Set For"));
					list.put("setBy", rs.getString("Set By"));
					goalList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return goalList;
	
	}

	@Override
	public List<HireCompanyTO> getAllHireCompany() {
		List<HireCompanyTO> companyList = new ArrayList<>();

		try {
			String s = "SELECT * FROM hire_company WHERE isActive IS TRUE";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HireCompanyTO list = new HireCompanyTO();
				list.setCompanyId(rs.getInt("company_id"));
				list.setCompanyName(rs.getString("company_name"));
				list.setContactEmail(rs.getString("contact_email"));
				list.setContactNumber(rs.getString("contact_number"));
				list.setContactPerson(rs.getString("contact_person"));
				list.setContactAddress(rs.getString("contact_address"));
				list.setCompTerms(rs.getString("comp_terms"));
				companyList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return companyList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllJobOpenings() {
		ArrayList<HashMap<String, String>> jobList = new ArrayList<>();
		try {
			String s = "SELECT job.*,CONCAT(designation, '(', department,')' ) AS 'Department' "
					+ " FROM job_openings job LEFT JOIN role_master mast ON mast.role_id = job.role_id "
					+ " WHERE job.no_position != filled_position";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("jobOpenId", rs.getString("job_open_id"));
					list.put("roleId", rs.getString("role_id"));
					list.put("noPosition", rs.getString("no_position"));
					list.put("openDate", rs.getString("open_date"));
					list.put("targetDate", rs.getString("target_date"));
					list.put("filledPosition", rs.getString("filled_position"));
					list.put("Department", rs.getString("Department"));
					jobList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return jobList;
	
	}

	@Override
	public HashMap<String, String> getJobOpeninsById(Integer jobOpenId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT job.*,CONCAT(designation, '(', grade, '-', business_unit, '-', department, '-', section, ')' ) AS 'Department' "
					+ "FROM job_openings job LEFT JOIN role_master mast ON mast.role_id = job.role_id WHERE job.job_open_id = '"+jobOpenId+"' ";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
					list.put("jobOpenId", rs.getString("job_open_id"));
					list.put("roleId", rs.getString("role_id"));
					list.put("noPosition", rs.getString("no_position"));
					try{
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
						list.put("openDate",sdf.format(rs.getDate("open_date")));
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					try{
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
						list.put("targetDate",sdf.format(rs.getDate("target_date")) );
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					list.put("filledPosition", rs.getString("filled_position"));
					list.put("Department", rs.getString("Department"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getEmployeeGoalById(Integer goalId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT goal.*,emp.emp_name AS 'Set For',emp1.emp_name AS 'Set By' FROM goal_setting goal "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = goal.goal_set_for "
					+ "LEFT JOIN employee_details emp1 ON emp1.emp_id = goal.goal_set_by "
					+ "WHERE goal.goal_id = '"+goalId+"' ";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
					list.put("goalId", rs.getString("goal_id"));
					list.put("goalName", rs.getString("goal_name"));
					list.put("goalSetFor", rs.getString("goal_set_for"));
					list.put("goalSetBy", rs.getString("goal_set_by"));
					try{
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
						list.put("goalFrom",sdf.format(rs.getDate("goal_from")));
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					try{
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
						list.put("goalTo",sdf.format(rs.getDate("goal_to")) );
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					list.put("status", rs.getString("status"));
					list.put("goalInfo", rs.getString("goal_info"));
					list.put("remarks", rs.getString("remarks"));
					list.put("setFor", rs.getString("Set For"));
					list.put("setBy", rs.getString("Set By"));
					list.put("type", rs.getString("type"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public HashMap<String, String> getQualificationById(Integer empQufnId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT empQulfn.*, emp.emp_name,qufn.qualification,qufn.specialization FROM employee_qualification empQulfn "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = empQulfn.emp_id "
					+ "LEFT JOIN qualification_master qufn ON qufn.qualification_id = empQulfn.qualification_id WHERE empQulfn.emp_qufn_id = '"+empQufnId+"'";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
					list.put("empQufnId", rs.getString("emp_qufn_id"));
					list.put("empId", rs.getString("emp_id"));
					list.put("qualificationId", rs.getString("qualification_id"));
					list.put("qualifiedYear", rs.getString("qualified_year"));
					list.put("institute", rs.getString("institute"));
					list.put("university", rs.getString("university"));
					list.put("percentage", rs.getString("percentage"));
					list.put("empName", rs.getString("emp_name"));
					list.put("qualification", rs.getString("qualification"));
					list.put("specialization", rs.getString("specialization"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getExperienceById(Integer expId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT expn.*, emp.emp_name FROM experience_details expn LEFT JOIN employee_details emp ON emp.emp_id = expn.emp_id "
					+ " WHERE expn.exp_id = '"+expId+"' ";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
					list.put("expId", rs.getString("exp_id"));
					list.put("empId", rs.getString("emp_id"));
					try{
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
						list.put("fromDate",sdf.format(rs.getDate("from_date")));
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					try{
						SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
						list.put("toDate",sdf.format(rs.getDate("to_date")));
						}catch(NullPointerException e){
							e.printStackTrace();
						}
					list.put("companyName", rs.getString("company_name"));
					list.put("designation", rs.getString("designation"));
					list.put("ctcAnnum", rs.getString("ctc_annum"));
					list.put("empName", rs.getString("emp_name"));
					list.put("reasonLeaving", rs.getString("reason_leaving"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllMetrics(String supervisor) {
		ArrayList<HashMap<String, String>> metricList = new ArrayList<>();
		try {
			String s = "SELECT * FROM evaluation_metrics WHERE applicable_for = '"+supervisor+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("metricId", rs.getString("q_id"));
					list.put("mNname", rs.getString("attrbute"));
					list.put("ratingType", rs.getString("rating_type"));
					list.put("ratingOptions", rs.getString("rating_options"));
					metricList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return metricList;
	}
	@Override
	public ArrayList<HashMap<String, String>> getEmpEvaluation(PerformanceMetricsDTO performanceDTO) {
		ArrayList<HashMap<String, String>> metricList = new ArrayList<>();
		try {
			String s = "SELECT metric.attrbute,metric.rating_type,metric.rating_options,eval.*, emp.emp_name,metric.applicable_for FROM emp_evaluation eval LEFT JOIN employee_details emp ON emp.emp_id = eval.emp_id "
					+ " LEFT JOIN evaluation_metrics metric ON metric.q_id = eval.metric_id WHERE eval.emp_id = '"+performanceDTO.getEmpId()+"' AND eval_period= '"+performanceDTO.getEvaluatorPeriod()+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("id", rs.getString("id"));
					list.put("empId", rs.getString("emp_id"));
					list.put("evalPeriod", rs.getString("eval_period"));
					list.put("metricId", rs.getString("metric_id"));
					list.put("selfEval", rs.getString("self_eval"));
					list.put("mgrEval", rs.getString("mgr_eval"));
					list.put("hrEval", rs.getString("hr_eval"));
					list.put("empName", rs.getString("emp_name"));
					list.put("ratingType", rs.getString("rating_type"));
					list.put("attrbute", rs.getString("attrbute"));
					list.put("applicableFor", rs.getString("applicable_for"));
					list.put("ratingOptions", rs.getString("rating_options"));
					metricList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return metricList;
	}
	public void updateHRemployeeperformance(PerformanceMetricsDTO performanceDTO){
		Integer[] metricId = performanceDTO.getMetricId();
		String[] text = performanceDTO.getText();
			if(performanceDTO.getModule().equalsIgnoreCase("HR")){
				try {
			for(int i = 0 ; i < metricId.length ; i++){
			String query = "UPDATE emp_evaluation SET hr_eval = '"+text[i]+"', hr_eval_dt = CURRENT_TIMESTAMP WHERE id = '"+metricId[i]+"' ";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			 updPrepStmt.executeUpdate(query);
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
			}else{
				try {
				for(int i = 0 ; i < metricId.length ; i++){
					String query = "UPDATE emp_evaluation SET mgr_eval = '"+text[i]+"', mgr_eval_dt = CURRENT_TIMESTAMP WHERE id = '"+metricId[i]+"' ";
					Connection connection = sessionFactory.getCurrentSession().connection();
					PreparedStatement updPrepStmt = connection.prepareStatement(query);
					 updPrepStmt.executeUpdate(query);	
			}
		} catch (Exception e) {
			e.printStackTrace();
		}}		
		}
	@Override
	public ArrayList<HashMap<String, String>> getAllEmpSalrSlab(String month) {
		ArrayList<HashMap<String, String>> salSlabList = new ArrayList<>();
		try {
			String s = "SELECT * FROM salary_comp WHERE payfor_month = '"+month+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("id", rs.getString("id"));
					list.put("payforMonth", rs.getString("payfor_month"));
					list.put("empName", rs.getString("emp_name"));
					list.put("empId", rs.getString("emp_id"));
					list.put("hraPerc", rs.getString("hra_perc"));
					list.put("basicPerc", rs.getString("basic_perc"));
					list.put("gross", rs.getString("gross"));
					list.put("paidDays", rs.getString("paid_days"));
					list.put("lateDays", rs.getString("late_days"));
					
					salSlabList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return salSlabList;
	}

	@Override
	public HashMap<String, String> setEmpSalComponent(Integer empId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT emp.emp_id,emp.employee_id,emp.emp_name,mast.department,mast.designation,sal.basic_percent,sal.gross,sal.nett "
					+ "FROM employee_details emp LEFT JOIN employee_roles role ON role.emp_id = emp.emp_id "
					+ "LEFT JOIN role_master mast ON mast.role_id = role.role_id LEFT JOIN salary_slab sal ON sal.slab_id = role.slab_id "
					+ " WHERE emp.emp_id = '"+empId+"' AND CURRENT_DATE BETWEEN role.from_date AND role.to_date";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("empId", rs.getString("emp_id"));
				list.put("employeeId", rs.getString("employee_id"));
				list.put("empName", rs.getString("emp_name"));
				list.put("department", rs.getString("department"));
				list.put("designation", rs.getString("designation"));
				list.put("basicPercent", rs.getString("basic_percent"));
				list.put("gross", rs.getString("gross"));
				list.put("nett", rs.getString("nett"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	@Override
	public ArrayList<HashMap<String, String>> getAllPayType() {
		ArrayList<HashMap<String, String>> payList = new ArrayList<>();
		try {
			String s = "SELECT * FROM pay_types ";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("paytypeId", rs.getString("paytype_id"));
					list.put("payName", rs.getString("pay_name"));
					list.put("payDescriptions", rs.getString("pay_descriptions"));
					list.put("payFrequency", rs.getString("pay_frequency"));
					list.put("payComponent", rs.getString("pay_component"));
					list.put("allowanceDeduction", rs.getString("allowance_deduction"));
					list.put("dueDate", rs.getString("due_date"));
					payList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return payList;
	}
	@Override
	public ArrayList<HashMap<String, String>> getQuestionBank(String qCategory) {
		ArrayList<HashMap<String, String>> qnBankList = new ArrayList<>();
		try {
			String s = "SELECT * FROM questionnaire qn LEFT JOIN question_bank qnbank ON qn.qn_id =  qnbank.qn_id "
					+ "WHERE qn.q_category = '"+qCategory+"' AND isActive IS TRUE";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("qnId", rs.getString("qn_id"));
					list.put("question", rs.getString("question"));
					list.put("qnType", rs.getString("qn_type"));
					list.put("optionsType", rs.getString("options_type"));
					list.put("optionDetails", rs.getString("option_details"));
					list.put("qnRefId", rs.getString("qn_ref_id"));
					qnBankList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return qnBankList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmployeeACCDetails(String attrType , Integer empId) {
		ArrayList<HashMap<String, String>> accList = new ArrayList<>();
		try {
			String s = "SELECT qn.*,bank.question FROM qn_responses qn LEFT JOIN question_bank bank ON bank.qn_id =  qn.qn_id "
					+ "WHERE qn.attr_type = '"+attrType+"' AND qn.ref_id='"+empId+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("autoNum", rs.getString("autoNum"));
					list.put("attrType", rs.getString("attr_type"));
					list.put("qnId", rs.getString("qn_id"));
					list.put("answer", rs.getString("answer"));
					list.put("question", rs.getString("question"));
					accList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return accList;
	}

	@Override
	public void upDateQuery(String query) {
		try {
			//System.out.println("dao impl :"+query);
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement updPrepStmt = connection.prepareStatement(query);
			 updPrepStmt.executeUpdate(query);
			 connection.close();
			 updPrepStmt.close();
			} catch (Exception e) {
				e.printStackTrace();
				//System.out.println(e);
			}	
	}
	

	@Override
	public HashMap<String, String> getLeavesById(Integer reqId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT leavs.*,emp.emp_name AS 'Leave for',emps.emp_name AS 'Approved By' FROM leave_request leavs "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = leavs.emp_id "
					+ " LEFT JOIN employee_details emps ON emps.emp_id = leavs.approved_by WHERE leavs.request_id = '"+reqId+"'";
			
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("requestId", rs.getString("request_id"));
				list.put("empId", rs.getString("emp_id"));
				list.put("reqCreation", rs.getString("req_creation"));
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					list.put("fromDate",sdf.format(rs.getDate("from_date")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				try{
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					list.put("toDate",sdf.format(rs.getDate("to_date")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				list.put("totalDays", rs.getString("total_days"));
				list.put("leaveType", rs.getString("leave_type"));
				list.put("description", rs.getString("description"));
				list.put("status", rs.getString("status"));
				list.put("approvedBy", rs.getString("approved_by"));
				list.put("Leavefor", rs.getString("Leave for"));
				list.put("ApprovedBy", rs.getString("Approved By"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getMonthlyEmpSalary(
			String salMonth) {
		ArrayList<HashMap<String, String>> salList = new ArrayList<>();
		try {
			String s = "SELECT sal.*,  DAY(payfor_month) AS 'total_days', ROUND((basic_perc/100*gross) * (paid_days/DAY(payfor_month)),2) AS basic_earned, "
					+ "ROUND(0.4*(gross*basic_perc/100)* (paid_days/DAY(payfor_month)),2) AS hra_earned, "
					+ "ROUND(gross*(paid_days/DAY(payfor_month)) - gross*basic_perc/100*(paid_days/DAY(payfor_month)) - 0.4*gross*basic_perc/100*(paid_days/DAY(payfor_month)), 2) AS others,"
					+ "ROUND(gross*(paid_days/DAY(payfor_month)),2) AS gross_earned, "
					+ "ROUND(IF(gross >= 21000, 0 ,  1.75*gross/100*(paid_days/DAY(payfor_month))), 2) AS esi,"
					+ "ROUND(gross*basic_perc/100*0.12*(paid_days/DAY(payfor_month)), 0) AS epf, IF(gross>15000, 200, 0) AS pt, "
					+ "ROUND((gross*(paid_days/DAY(payfor_month)) - IF(gross >= 21000, 0 ,  1.75*gross/100*(paid_days/DAY(payfor_month))) - gross*basic_perc/100*0.12*(paid_days/DAY(payfor_month)) -  IF(gross>15000, 200, 0)),2) AS earned_salary,"
					+ "ROUND((IF(late_days>3, late_days/3- 1 , 0))*(gross/DAY(payfor_month)),2) AS late_penalty, "
					+ "ROUND((gross*(paid_days/DAY(payfor_month)) - IF(gross >= 21000, 0 ,  1.75*gross/100*(paid_days/DAY(payfor_month))) - gross*basic_perc/100*0.12*(paid_days/DAY(payfor_month)) - "
					+ " IF(gross>15000, 200, 0)- IF(late_days>3, late_days/3- 1 , 0)*(gross/DAY(payfor_month))),0) AS nett_salary FROM salary_comp sal "
					+ "WHERE payfor_month = '"+salMonth+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("autoNum", rs.getString("id"));
					list.put("payforMonth", rs.getString("payfor_month"));
					list.put("empName", rs.getString("emp_name"));
					list.put("basicPerc", rs.getString("basic_perc"));
					list.put("gross", rs.getString("gross"));
					list.put("paidDays", rs.getString("paid_days"));
					list.put("lateDays", rs.getString("late_days"));
					list.put("totalDays", rs.getString("total_days"));
					list.put("basicEarned", rs.getString("basic_earned"));
					list.put("hraEarned", rs.getString("hra_earned"));
					list.put("others", rs.getString("others"));
					list.put("grossEarned", rs.getString("gross_earned"));
					list.put("esi", rs.getString("esi"));
					list.put("pt", rs.getString("pt"));
					list.put("epf", rs.getString("epf"));
					list.put("earnedSalary", rs.getString("earned_salary"));
					list.put("latePenalty", rs.getString("late_penalty"));
					list.put("nettSalary", rs.getString("nett_salary"));
					salList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return salList;
	}

	@Override
	public HashMap<String, String> getEmpMonthlySalSlip(Integer empId,
			String month) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT sal.*,  DAY(payfor_month) AS 'total_days', ROUND((basic_perc/100*gross) * (paid_days/DAY(payfor_month)),2) AS basic_earned,"
					+ " ROUND((CASE WHEN payfor_month < '2017-08-01' THEN 0.4 ELSE hra_perc/100 END)*(gross*basic_perc/100)* (paid_days/DAY(payfor_month)),2) AS hra_earned, "
					+ " ROUND(gross*(paid_days/DAY(payfor_month)) - gross*basic_perc/100*(paid_days/DAY(payfor_month)) - (CASE WHEN payfor_month < '2017-08-01' THEN 0.4 ELSE hra_perc/100 END)*(gross*basic_perc/100)* (paid_days/DAY(payfor_month)), 2) AS others,"
					+ " ROUND(gross*(paid_days/DAY(payfor_month)),2) AS gross_earned, "
					+ "ROUND(IF(gross >= 21000, 0 ,  1.75*gross/100*(paid_days/DAY(payfor_month))), 2) AS esi,"
					+ "ROUND(gross*basic_perc/100*0.12*(paid_days/DAY(payfor_month)), 0) AS epf, IF(gross>15000, 200, 0) AS pt, "
					+ "ROUND((gross*(paid_days/DAY(payfor_month)) - IF(gross >= 21000, 0 ,  1.75*gross/100*(paid_days/DAY(payfor_month))) - gross*basic_perc/100*0.12*(paid_days/DAY(payfor_month)) -  IF(gross>15000, 200, 0)),2) AS earned_salary,"
					+ "ROUND((IF(late_days>3, late_days/3- 1 , 0))*(gross/DAY(payfor_month)),2) AS late_penalty, "
					+ "ROUND((gross*(paid_days/DAY(payfor_month)) - IF(gross >= 21000, 0 ,  1.75*gross/100*(paid_days/DAY(payfor_month))) - gross*basic_perc/100*0.12*(paid_days/DAY(payfor_month)) - "
					+ " IF(gross>15000, 200, 0)- IF(late_days>3, late_days/3- 1 , 0)*(gross/DAY(payfor_month))),0) AS nett_salary FROM salary_comp sal "
					+ "WHERE payfor_month = '"+month+"' AND emp_id = '"+empId+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
			
					list.put("autoNum", rs.getString("id"));
					list.put("payforMonth", rs.getString("payfor_month"));
					list.put("empName", rs.getString("emp_name"));
					list.put("basicPerc", rs.getString("basic_perc"));
					list.put("gross", rs.getString("gross"));
					list.put("paidDays", rs.getString("paid_days"));
					list.put("lateDays", rs.getString("late_days"));
					list.put("totalDays", rs.getString("total_days"));
					list.put("basicEarned", rs.getString("basic_earned"));
					list.put("hraEarned", rs.getString("hra_earned"));
					list.put("others", rs.getString("others"));
					list.put("grossEarned", rs.getString("gross_earned"));
					list.put("esi", rs.getString("esi"));
					list.put("pt", rs.getString("pt"));
					list.put("epf", rs.getString("epf"));
					list.put("earnedSalary", rs.getString("earned_salary"));
					list.put("latePenalty", rs.getString("late_penalty"));
					list.put("nettSalary", rs.getString("nett_salary"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmpAttenance(Integer bioMetricId,String fromDate,String toDate) {
		ArrayList<HashMap<String, String>> attendanceList = new ArrayList<>();
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(toDate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String s = "SELECT biometric_id, DATE, MIN(log_time) AS login, MAX(log_time) AS logout, TIMEDIFF(MAX(log_time), MIN(log_time)) AS workDuration FROM attendence "
					+ " WHERE  `date` BETWEEN '"+date+"' AND '"+date1+"' AND biometric_id = '"+bioMetricId+"'   GROUP BY biometric_id, DATE";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("biometricId", rs.getString("biometric_id"));
					list.put("DATE", rs.getString("DATE"));
					list.put("login", rs.getString("login"));
					list.put("logout", rs.getString("logout"));
					list.put("workDuration", rs.getString("workDuration"));
					attendanceList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return attendanceList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getemployeeListThruRole(String query) {
		ArrayList<HashMap<String, String>> empList = new ArrayList<>();
		try {
			//String s = query ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(query);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("department", rs.getString("department"));
					list.put("empId", rs.getString("emp_id"));
					list.put("empName", rs.getString("emp_name"));
					empList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empList;
	}

	@Override
	public HashMap<String, String> getDesignation(Integer empId) {
	
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT role.emp_id,role.from_date,mast.designation FROM employee_roles role "
					+ " LEFT JOIN role_master mast ON mast.role_id = role.role_id  WHERE role.emp_id = '"+empId+"'";
			Connection connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("empId", rs.getString("emp_id"));
				list.put("designation", rs.getString("designation"));
				list.put("fromDate", rs.getString("from_date"));
				//list.put("test", (rs.getDate("from_date")- 3));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getAllLeavesAdmin(String query) {
		ArrayList<HashMap<String, String>> leaveList = new ArrayList<>();
		try {
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(query);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("requestId", rs.getString("request_id"));
					list.put("fromDate", rs.getString("from_date"));
					list.put("toDate", rs.getString("to_date"));
					list.put("totalDays", rs.getString("total_days"));
					list.put("leaveType", rs.getString("leave_type"));
					list.put("description", rs.getString("description"));
					list.put("status", rs.getString("status"));
					list.put("report", rs.getString("report"));
					list.put("empName", rs.getString("emp_name"));
					leaveList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return leaveList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getEmployeesListByReportId(
			Integer userId) {
		ArrayList<HashMap<String, String>> employeeList = new ArrayList<>();
		try {
			String s = "SELECT emp.emp_name,emp.emp_id,emp1.emp_name AS 'report',roles.report_to  FROM employee_roles roles "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = roles.emp_id "
					+ " LEFT JOIN employee_details emp1 ON emp1.emp_id = roles.report_to WHERE CURRENT_DATE BETWEEN roles.from_date AND roles.to_date AND  "
					+ " (roles.report_to = (SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON "
					+ " emp.corporate_email = mast.user_mail WHERE user_id = '"+userId+"')) "
					+ " OR roles.emp_id = (SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON "
					+ " emp.corporate_email = mast.user_mail WHERE user_id = '"+userId+"') ORDER BY emp.emp_id " ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("empId", rs.getString("emp_id"));
					list.put("empName", rs.getString("emp_name"));
					list.put("reportTo", rs.getString("report_to"));
					employeeList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employeeList;
	}

	@Override
	public HashMap<String, String> getEmployeeIdFromUserId(Integer userId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON emp.corporate_email = mast.user_mail WHERE user_id ='"+userId+"' " ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
					list.put("empId", rs.getString("emp_id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getGoalsAdmin(String query) {
		
		PreparedStatement prepareStatement = null;
		ArrayList<HashMap<String, String>> goalList = new ArrayList<>();
		try {
			Connection	connection = sessionFactory.getCurrentSession().connection();
			prepareStatement = connection.prepareStatement(query);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("goalId", rs.getString("goal_id"));
					list.put("goalName", rs.getString("goal_name"));
					list.put("goalSetFor", rs.getString("goal_set_for"));
					list.put("goalFrom", rs.getString("goal_from"));
					list.put("goalTo", rs.getString("goal_to"));
					list.put("status", rs.getString("status"));
					list.put("goalInfo", rs.getString("goal_info"));
					list.put("setFor", rs.getString("Set For"));
					list.put("target", rs.getString("target"));
					goalList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return goalList;
	
	}

	@Override
	public ArrayList<HashMap<String, String>> getSalPayMonthsList(Integer empId) {
		ArrayList<HashMap<String, String>> monthList = new ArrayList<>();
		try {
			String s = "SELECT payfor_month, CONCAT(MONTHNAME(payfor_month), '-', YEAR(payfor_month)) AS months FROM salary_comp WHERE emp_id='"+empId+"'" ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("payforMonth", rs.getString("payfor_month"));
					list.put("months", rs.getString("months"));
					monthList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return monthList;
	}

	@Override
	public HashMap<String, String> getEmployeeDesignation(Integer empId, String date) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT * FROM employment_history WHERE emp_id='"+empId+"' AND CURRENT_DATE BETWEEN from_date AND to_date" ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			if (rs.next()) {
					list.put("department", rs.getString("department"));
					list.put("designation", rs.getString("designation"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getReportIdthruUserId(Integer userId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT emp.emp_name,emp.emp_id,emp1.emp_name AS 'report',roles.report_to  FROM employee_roles roles "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = roles.emp_id "
					+ " LEFT JOIN employee_details emp1 ON emp1.emp_id = roles.report_to WHERE CURRENT_DATE BETWEEN roles.from_date AND roles.to_date AND  "
					+ " (roles.report_to = (SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON "
					+ " emp.corporate_email = mast.user_mail WHERE user_id = '"+userId+"')) "
					+ " OR roles.emp_id = (SELECT  emp.emp_id FROM usermaster mast LEFT JOIN employee_details emp ON "
					+ " emp.corporate_email = mast.user_mail WHERE user_id = '"+userId+"') ORDER BY emp.emp_id " ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				
					list.put("empId", rs.getString("emp_id"));
					list.put("empName", rs.getString("emp_name"));
					list.put("reportTo", rs.getString("report_to"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public HashMap<String, String> getCandidateDetails(Integer candidateId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT recu.*, role.role_id,role.designation,role.department,hire.company_name,hire.company_id ,sal.slab_name,sal.gross,sal.nett "
					+ " FROM recruitment recu LEFT JOIN role_master role ON role.role_id = recu.role_id  "
					+ " LEFT JOIN hire_company hire ON hire.company_id = recu.reffered_by  LEFT JOIN salary_slab sal ON sal.slab_id = recu.slab_id "
					+ " WHERE recu.candidate_id = '"+candidateId+"' " ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
					list.put("candidateId", rs.getString("candidate_id"));
					list.put("Name", rs.getString("Name"));
					list.put("dob", rs.getString("dob"));
					list.put("gender", rs.getString("gender"));
					list.put("contactNumber", rs.getString("contact_number"));
					list.put("email", rs.getString("email"));
					list.put("address", rs.getString("address"));
					list.put("refference", rs.getString("refference"));
					list.put("totalExp", rs.getString("total_exp"));
					list.put("higestQualification", rs.getString("higest_qualification"));
					list.put("interviewStatus", rs.getString("interview_status"));
					list.put("createdDate", rs.getString("created_date"));
					list.put("designation", rs.getString("designation"));
					list.put("department", rs.getString("department"));
					list.put("companyName", rs.getString("company_name"));
					list.put("remarks", rs.getString("remarks"));
					list.put("relaventExp", rs.getString("relavent_exp"));
					list.put("prviousCmpyDesignation", rs.getString("prvious_cmpy_designation"));
					list.put("locationContrain", rs.getString("location_contrain"));
					list.put("currentSalary", rs.getString("current_salary"));
					list.put("expectedSalary", rs.getString("expected_salary"));
					list.put("joiningDate", rs.getString("joining_date"));
					list.put("slabName", rs.getString("slab_name"));
					list.put("gross", rs.getString("gross"));
					list.put("nett", rs.getString("nett"));
					list.put("slabId", rs.getString("slab_id"));
					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getInterviewerFeedback(
			Integer candidateId) {
		ArrayList<HashMap<String, String>> interViewFBList = new ArrayList<>();
		try {
			String s = "SELECT inter.*,emp.emp_name FROM interviews inter "
					+ " LEFT JOIN employee_details emp ON emp.emp_id= inter.interviewed_by WHERE inter.candidate_id = '"+candidateId+"' " ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("interviewDate", rs.getString("interview_date"));
					list.put("remarks", rs.getString("remarks"));
					list.put("interviewStatus", rs.getString("interview_status"));
					list.put("interviewRound", rs.getString("interview_round"));
					list.put("empName", rs.getString("emp_name"));
					
					interViewFBList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return interViewFBList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getInterviewCandidatesList(String fromDate, String todate,String status) {
		String date = null;
		String date1 = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		SimpleDateFormat formatter = new SimpleDateFormat("YYYY-mm-dd");
		try {
			date = formatter.format(sdf.parse(fromDate));
			date1 = formatter.format(sdf.parse(todate));
		} catch (Exception e) {
			e.printStackTrace();
		}
		ArrayList<HashMap<String, String>> interViewList = new ArrayList<>();
		try {
			String s = "SELECT recu.*, role.role_id,role.designation,role.department,hire.company_name,hire.company_id FROM recruitment recu "
					+ " LEFT JOIN role_master role ON role.role_id = recu.role_id LEFT JOIN hire_company hire ON hire.company_id = recu.reffered_by "
					+ " WHERE created_date BETWEEN '"+date+" 00:00:00' AND '"+date1+" 23:59:59' AND interview_status LIKE '%"+status+"%'" ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("candidateId", rs.getString("candidate_id"));
				list.put("Name", rs.getString("Name"));
				list.put("gender", rs.getString("gender"));
				list.put("contactNumber", rs.getString("contact_number"));
				list.put("email", rs.getString("email"));
				list.put("refference", rs.getString("refference"));
				list.put("totalExp", rs.getString("total_exp"));
				list.put("interviewStatus", rs.getString("interview_status"));
				list.put("designation", rs.getString("designation"));
				list.put("department", rs.getString("department"));
				list.put("companyName", rs.getString("company_name"));
				list.put("prviousCmpyDesignation", rs.getString("prvious_cmpy_designation"));
					interViewList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return interViewList;
	}

	@Override
	public boolean updateEmployeeImage(Integer empId) {
		Boolean img = false;
		try {
			String s = "SELECT * FROM `employee_images` WHERE emp_id = '"+empId+"'" ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				if(rs.getString("emp_id").equals(null)){
					img = false;
				}else{
					img = true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return img;
	}
	@Override
	public ArrayList<HashMap<String, String>> getMonthsList() {
		ArrayList<HashMap<String, String>> monthList = new ArrayList<>();
		try {
			String s = "SELECT DISTINCT payfor_month, CONCAT(MONTHNAME(payfor_month), '-', YEAR(payfor_month)) AS months FROM salary_comp " ;
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("payforMonth", rs.getString("payfor_month"));
					list.put("months", rs.getString("months"));
					monthList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return monthList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getMetricsList() {
		ArrayList<HashMap<String, String>> metricList = new ArrayList<>();
		try {
			String s = "SELECT metric_id,metric_name,m_description FROM metrics";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("metricId", rs.getString("metric_id"));
					list.put("metricName", rs.getString("metric_name"));
					list.put("mDescription", rs.getString("m_description"));
					metricList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return metricList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getMeetingDetails(String query,Integer userId) {
		ArrayList<HashMap<String, String>> meetingList = new ArrayList<>();
		try {
			String s;
			if(query.equalsIgnoreCase("Assigne")){
			s = "SELECT DISTINCT met.meeting_id, met.* FROM meetings met "
					+ "LEFT JOIN meeting_attendees att ON att.`meeting_id` = met.meeting_id "
					+ "WHERE  att.isHost = '"+userId+"'";
			}else{
				s="SELECT DISTINCT met.meeting_id, met.*,emp.emp_name,att.id FROM meetings met "
						+ "LEFT JOIN meeting_attendees att ON att.`meeting_id` = met.meeting_id "
						+ " LEFT JOIN employee_details emp ON emp.`emp_id` =  att.isHost "
						+ " WHERE att.attendee_id = '"+userId+"'";
			}
			System.out.println(s);
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("meetingId", rs.getString("meeting_id"));
					list.put("mName", rs.getString("m_name"));
					list.put("mDescription", rs.getString("m_description"));
					list.put("mType", rs.getString("m_type"));
					list.put("mDate", rs.getString("m_date"));
					if(query.equalsIgnoreCase("Attendee")){
					list.put("id", rs.getString("id"));
					list.put("empName", rs.getString("emp_name"));
					}
					list.put("mTime", rs.getString("m_time"));
					list.put("duration", rs.getString("duration"));
					list.put("place", rs.getString("place"));
					meetingList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return meetingList;
	}

	@Override
	public HashMap<String, String> getMeetingById(Integer userId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT meet.*,emp.emp_name AS 'host',attend.id FROM  meeting_attendees attend "
					+ "LEFT JOIN meetings meet ON meet.meeting_id = attend.meeting_id LEFT JOIN employee_details emp ON emp.`emp_id` = attend.isHost "
					+ " WHERE attend.id = '"+userId+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("meetingId", rs.getString("meeting_id"));
				list.put("mName", rs.getString("m_name"));
				list.put("mDescription", rs.getString("m_description"));
				list.put("mType", rs.getString("m_type"));
				list.put("mDate", rs.getString("m_date"));
				list.put("mTime", rs.getString("m_time"));
				list.put("duration", rs.getString("duration"));
				list.put("place", rs.getString("place"));
				list.put("host", rs.getString("host"));
				list.put("id", rs.getString("id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getMOMList(Integer meetingId) {
		ArrayList<HashMap<String, String>> momList = new ArrayList<>();
		try {
			String s = "SELECT meet.*, emp.emp_name FROM minutes_of_meeting meet "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = meet.createdBy "
					+ " WHERE meet.meeting_id = '"+meetingId+"'";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("meetingId", rs.getString("meeting_id"));
					list.put("minutesOfMeeting", rs.getString("minutesOfMeeting"));
					list.put("empName", rs.getString("emp_name"));
					list.put("actionItems", rs.getString("actionItems"));
					momList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return momList;
	}

	@Override
	public HashMap<String, String> getMeetingAssignedById(Integer meetingId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT DISTINCT met.meeting_id,att.isHost, met.*,emp.emp_name AS HOST "
					+ " FROM meetings met "
					+ " LEFT JOIN meeting_attendees att ON att.meeting_id = met.meeting_id "
					+ "LEFT JOIN employee_details emp ON emp.emp_id = att.isHost WHERE  met.meeting_id ='"+meetingId+"'";
			
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet	rs = prepareStatement.executeQuery();
			while (rs.next()) {
				list.put("meetingId", rs.getString("meeting_id"));
				list.put("mName", rs.getString("m_name"));
				list.put("mDescription", rs.getString("m_description"));
				list.put("mType", rs.getString("m_type"));
				list.put("mDate", rs.getString("m_date"));
				list.put("mTime", rs.getString("m_time"));
				list.put("duration", rs.getString("duration"));
				list.put("place", rs.getString("place"));
				list.put("host", rs.getString("host"));
				list.put("id", rs.getString("id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public List<HashMap<String, String>> getEmployeesListOnEmpType(String empType) {
		List<HashMap<String, String>> empList = new ArrayList<>();

		try {
			String s = "SELECT empd.*,emph.emp_type,emph.designation,emph.department FROM employment_history emph"
					+ " LEFT JOIN employee_details empd ON empd.emp_id = emph.emp_id "
					+ " WHERE emph.emp_type = '"+empType+"' AND emph.STATUS IN('Joined') "
					+ " AND CURRENT_DATE BETWEEN from_date AND to_date; ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();

			while (rs.next()) {
				HashMap<String, String> employeeDetails = new HashMap<String, String>();
				employeeDetails.put("empId",rs.getString("emp_id"));
				employeeDetails.put("empName",rs.getString("emp_name"));
				employeeDetails.put("gender",rs.getString("gender"));
				employeeDetails.put("personalContact",rs.getString("personal_contact"));
				employeeDetails.put("bloodGroup",rs.getString("blood_group"));
				employeeDetails.put("maritalStatus",rs.getString("marital_status"));
				employeeDetails.put("emergencyContact",rs.getString("emergency_contact"));
				employeeDetails.put("permanentAddress",rs.getString("permanent_address"));
				employeeDetails.put("communicationAddresss",rs.getString("communication_addresss"));
				employeeDetails.put("employeeId",rs.getString("employee_id"));
				employeeDetails.put("personalEmail",rs.getString("personal_email"));
				employeeDetails.put("corporateEmail",rs.getString("corporate_email"));
				employeeDetails.put("status",rs.getString("status"));
				employeeDetails.put("designation",rs.getString("designation"));
				employeeDetails.put("department",rs.getString("department"));
				employeeDetails.put("empType",rs.getString("emp_type"));
				empList.add(employeeDetails);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return empList;
	}
	@Override
	public ArrayList<HashMap<String, String>> getallholidaylist() {
		ArrayList<HashMap<String, String>> momList = new ArrayList<>();
		try {
			String s = "SELECT * FROM holiday_list";
			Connection	connection = sessionFactory.getCurrentSession().connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
					list.put("holidays_id", rs.getString("holidays_id"));
					list.put("holiday_name", rs.getString("holiday_name"));
					list.put("holiday_day", rs.getString("holiday_day"));
					SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
					list.put("datetime", sdf.format(rs.getDate("holiday_date")));
					momList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return momList;
	}

}
