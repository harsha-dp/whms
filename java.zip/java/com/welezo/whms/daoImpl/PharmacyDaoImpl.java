package com.welezo.whms.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.welezo.whms.dao.PharmacyDao;

@Repository
@Transactional
public class PharmacyDaoImpl  implements PharmacyDao {

	@Autowired
	 SessionFactory sessionFactory;
	
	@Override
	public ArrayList<HashMap<String, String>> getPharmacyList(
			String fromDate, String toDate, String status) {

		ArrayList<HashMap<String, String>> pharmacyList = new ArrayList<>();
		try {
			String s = "SELECT * FROM pharmacies";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("pharmacyId", rs.getString("pharmacy_id"));
				list.put("pharmacyName", rs.getString("pharmacy_name"));
				list.put("location", rs.getString("location"));
				list.put("city", rs.getString("city"));
				list.put("address", rs.getString("address"));
				list.put("status", rs.getString("status"));
				list.put("regnNo", rs.getString("regn_no"));
				list.put("empanelDate", rs.getString("empanel_date"));
				list.put("primaryContact", rs.getString("primary_contact"));
				list.put("primaryNumber", rs.getString("primary_number"));
				list.put("email", rs.getString("email"));
				list.put("welezoCode", rs.getString("welezo_code"));
				list.put("expiryDate", rs.getString("expiry_date"));
				pharmacyList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pharmacyList;
	}

	@Override
	public HashMap<String, String> getPharmacyDeatilsById(
			Integer pharmacyId) {
		HashMap<String, String> list = new HashMap<String, String>();
		try {
			String s = "SELECT pharm.*,emp.emp_name FROM pharmacies pharm "
					+ " LEFT JOIN employee_details emp ON emp.emp_id = pharm.executive  WHERE pharm.pharmacy_id = '"+pharmacyId+"'";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			if (rs.next()) {
				list.put("pharmacyId", rs.getString("pharmacy_id"));
				list.put("pharmacyName", rs.getString("pharmacy_name"));
				list.put("location", rs.getString("location"));
				list.put("city", rs.getString("city"));
				list.put("address", rs.getString("address"));
				list.put("status", rs.getString("status"));
				list.put("regnNo", rs.getString("regn_no"));
				list.put("primaryContact", rs.getString("primary_contact"));
				list.put("primaryNumber", rs.getString("primary_number"));
				list.put("alternateNumber", rs.getString("alternate_number"));
				list.put("email", rs.getString("email"));
				list.put("welezoCode", rs.getString("welezo_code"));
				list.put("executiveId", rs.getString("executive"));
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/YYYY");
				try{
					list.put("expiryDate", sdf.format(rs.getDate("expiry_date")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				try{
					list.put("empanelDate", sdf.format(rs.getDate("empanel_date")));
					}catch(NullPointerException e){
						e.printStackTrace();
					}
				list.put("executive", rs.getString("emp_name"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public ArrayList<HashMap<String, String>> getDoctorsList() {
		ArrayList<HashMap<String, String>> doctorList = new ArrayList<>();
		try {
			String s = "SELECT * FROM doctors_lounge ";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("doctorId", rs.getString("doctor_id"));
				list.put("doctorName", rs.getString("doctor_name"));
				list.put("specializations", rs.getString("specializations"));
				list.put("clinic", rs.getString("clinic"));
				list.put("address", rs.getString("address"));
				list.put("pincode", rs.getString("pincode"));
				list.put("city", rs.getString("city"));
				list.put("location", rs.getString("location"));
				list.put("doctorNumber", rs.getString("doctor_number"));
				list.put("clinicNumber", rs.getString("clinic_number"));
				list.put("timing", rs.getString("timing"));
				//list.put("welezoCode", rs.getString("welezo_code"));
				list.put("expiryDate", rs.getString("expiry_date"));
				doctorList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return doctorList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getPharmacyNameList() {
		ArrayList<HashMap<String, String>> pharmacyList = new ArrayList<>();
		try {
			String s = "SELECT pharmacy_id,pharmacy_name FROM pharmacies";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("pharmacyId", rs.getString("pharmacy_id"));
				list.put("pharmacyName", rs.getString("pharmacy_name"));
				
				pharmacyList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pharmacyList;
	}

	@Override
	public ArrayList<HashMap<String, String>> getPharmacyLeadList(
			String fromDate, String toDate, String status) {
		ArrayList<HashMap<String, String>> pharmacyList = new ArrayList<>();
		try {
			String s = "SELECT lead.id,lead.lead_name,lead.contact_number,lead.age,lead.age,lead.gender,lead.lead_status,lead.acitivity_date,pharm.pharmacy_name "
					+ " FROM channel_leads lead LEFT JOIN pharmacies pharm ON pharm.pharmacy_id = lead.entity_id WHERE lead.channel = 12";
			Connection connection = sessionFactory.getCurrentSession()
					.connection();
			PreparedStatement prepareStatement = connection.prepareStatement(s);
			ResultSet rs = prepareStatement.executeQuery();
			while (rs.next()) {
				HashMap<String, String> list = new HashMap<String, String>();
				list.put("leadId", rs.getString("id"));
				list.put("leadName", rs.getString("lead_name"));
				list.put("age", rs.getString("age"));
				list.put("contactNumber", rs.getString("contact_number"));
				list.put("gender", rs.getString("gender"));
				list.put("leadStatus", rs.getString("lead_status"));
				list.put("acitivityDate", rs.getString("acitivity_date"));
				list.put("pharmacyName", rs.getString("pharmacy_name"));
				
				pharmacyList.add(list);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return pharmacyList;
	}
}
