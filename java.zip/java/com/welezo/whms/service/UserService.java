package com.welezo.whms.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.welezo.whms.dto.UsermasterDTO;

public interface UserService {

	public UsermasterDTO login(String userName, String password);

	public <T> void save(T entity);

	public List<UsermasterDTO> getAllUser();

	public UsermasterDTO getUserById(int id);
	
	public ArrayList<HashMap<String, String>> getUserAccessModule(String query);
	
	public  void UpDateUserAccess(Integer userId,String mailId);
	
	public  Boolean checkCredentials(String mobileNumber,String mailId);
	
	public HashMap<String, String> getEmailBody(String templateName);
	
	public HashMap<String, String> getSMSTemplates(String purpose);
}
