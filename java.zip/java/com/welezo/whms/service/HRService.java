package com.welezo.whms.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.welezo.whms.dto.EmployeeDetailsDTO;
import com.welezo.whms.dto.EmployeeQualificationDTO;
import com.welezo.whms.dto.PerformanceMetricsDTO;
import com.welezo.whms.to.ExperienceDetailsTO;
import com.welezo.whms.to.HireCompanyTO;
import com.welezo.whms.to.RoleMasterTO;

public interface HRService {

	public EmployeeDetailsDTO getEmployeeById(int id);

	public List<EmployeeQualificationDTO> getEmpQualifiaction(Integer empId);

	public List<ExperienceDetailsTO> getEmpExperience(Integer empId);

	public List<EmployeeDetailsDTO> getAllEmployees(String status);

	public void saveInterviewRemarks(EmployeeQualificationDTO employeeDetails);

	public List<RoleMasterTO> getAllRoles();

	public List<EmployeeQualificationDTO> getEmpRoleDesignation(Integer empId);

	public List<RoleMasterTO> getAllDepartment();

	public List<EmployeeQualificationDTO> getEmpDeptWise(String departmentName);

	public ArrayList<HashMap<String, String>> getAllLeaves(String fromdate, String toDate);

	public EmployeeQualificationDTO getEmpRoleById(Integer roleId);

	public ArrayList<HashMap<String, String>> getAllSalSlab();

	public HashMap<String, String> getSalarySlabDetails(Integer slabId);

	public ArrayList<HashMap<String, String>> getAllGoals(String fromDate,String toDate,String status);

	public ArrayList<HashMap<String, String>> getAllJobOpenings();

	public HashMap<String, String> getJobOpeninsById(Integer jobOpenId);

	public List<HireCompanyTO> getAllHireCompany();

	public HashMap<String, String> getEmployeeGoalById(Integer goalId);

	public HashMap<String, String> getQualificationById(Integer empQufnId);

	public HashMap<String, String> getExperienceById(Integer expId);

	public ArrayList<HashMap<String, String>> getAllMetrics(String supervisor);

	public ArrayList<HashMap<String, String>> getEmpEvaluation(
			PerformanceMetricsDTO performanceDTO);

	public void updateHRemployeeperformance(PerformanceMetricsDTO performanceDTO);

	public ArrayList<HashMap<String, String>> getAllEmpSalrSlab(String month);

	public HashMap<String, String> setEmpSalComponent(Integer empId);

	public ArrayList<HashMap<String, String>> getAllPayType();

	public ArrayList<HashMap<String, String>> getQuestionBank(String qCategory);

	public ArrayList<HashMap<String, String>> getEmployeeACCDetails(
			String attrType, Integer empId);

	public void upDateQuery(String query);
	
	public HashMap<String, String> getLeavesById(Integer reqId);
	public ArrayList<HashMap<String, String>> getMonthlyEmpSalary(String salMonth);
	
	public HashMap<String, String> getEmpMonthlySalSlip(Integer empId, String month);
	
	public ArrayList<HashMap<String, String>> getEmpAttenance(Integer bioMetricId,String fromDate,String toDate);

	public ArrayList<HashMap<String, String>> getemployeeListThruRole(String query);
	
	public HashMap<String, String> getDesignation(Integer empId);
	
	public ArrayList<HashMap<String, String>> getAllLeavesAdmin(String query);
	
	public ArrayList<HashMap<String, String>> getEmployeesListByReportId(Integer userId);
	public HashMap<String, String> getReportIdthruUserId(Integer userId);
	
	public HashMap<String, String> getEmployeeIdFromUserId(Integer userId);
	
	public ArrayList<HashMap<String, String>> getGoalsAdmin(String query);
	
	public ArrayList<HashMap<String, String>> getSalPayMonthsList(Integer empId);
	
	public HashMap<String, String> getEmployeeDesignation(Integer empId, String date);
	
	public HashMap<String, String> getCandidateDetails(Integer candidateId);
	public ArrayList<HashMap<String, String>> getInterviewerFeedback(Integer candidateId);
	
	public ArrayList<HashMap<String, String>> getInterviewCandidatesList(String fromDate, String todate,String status);
	
	public boolean updateEmployeeImage(Integer empId);
	
	public ArrayList<HashMap<String, String>> getMonthsList();

	public ArrayList<HashMap<String, String>> getMetricsList();
	
	public ArrayList<HashMap<String, String>> getMeetingDetails(String query,Integer userId);
	
	public HashMap<String, String> getMeetingById(Integer userId);

	public ArrayList<HashMap<String, String>> getMOMList(Integer meetingId);
	
	public HashMap<String, String> getMeetingAssignedById(Integer meetingId);
	
	public List<HashMap<String, String>> getEmployeesListOnEmpType(String empType);
	
	public ArrayList<HashMap<String, String>> getallholidaylist();
	
}
