package com.welezo.whms.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.ProjectsTO;
import com.welezo.whms.to.TeamsTO;

public interface ReportService {

	



	
	public List<ProjectsTO> getallprojects();

	public ProjectsTO getallprojectsById(Integer projectId);


	public TeamsTO getteamsById(Integer teamId);

	public ArrayList<HashMap<String, String>> getAllChannelss();

	public ChannelsTO editchannelsById(Integer channelId);


}
