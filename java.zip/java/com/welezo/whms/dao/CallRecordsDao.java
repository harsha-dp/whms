package com.welezo.whms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.TeleCallRecordIdDTO;

public interface CallRecordsDao {

	public ArrayList<HashMap<String, String>> getAllVisitorList(String fromDate, String toDate, String purpose);
	
	public List<AddressDTO> searchCustomer(String phoneNumber);
	
	public List<TeleCallRecordIdDTO> teleCallsByPhoneNo(String phoneNumber);
	
	public ArrayList<HashMap<String, String>> getAllExtensionDetails();
	
	public HashMap<String, String> getExtensionById(Integer id);
	
	public ArrayList<HashMap<String, String>> getIncomingCallsList(String fromDate,String toDate,String callsMode);
	
	public ArrayList<HashMap<String, String>> getAllBTlLeads(String fromDate, String toDate,String status,String parkId);
	
	public ArrayList<HashMap<String, String>> getAllParkDetails();
}
