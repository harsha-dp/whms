package com.welezo.whms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.welezo.whms.dto.AddressDTO;
import com.welezo.whms.dto.CustomerDeatilsAllDTO;
import com.welezo.whms.dto.CustomerFamilyDTO;
import com.welezo.whms.dto.CustomerReferencesDTO;
import com.welezo.whms.dto.DaywiseCallsIdDTO;
import com.welezo.whms.dto.DispatchTrackingDTO;
import com.welezo.whms.dto.EmployeeDTO;
import com.welezo.whms.dto.ExternalIdDTO;
import com.welezo.whms.dto.HealthAppointmentDTO;
import com.welezo.whms.dto.HospitalServiceDTO;
import com.welezo.whms.dto.PresalesDTO;
import com.welezo.whms.dto.ProductOffersDTO;
import com.welezo.whms.dto.TransactionMasterDTO;
import com.welezo.whms.to.AddressCatagoriesTO;
import com.welezo.whms.to.AddressTO;
import com.welezo.whms.to.ApplicationStockTO;
import com.welezo.whms.to.ChannelsTO;
import com.welezo.whms.to.CollectionTO;
import com.welezo.whms.to.CustomerDeatilsTO;
import com.welezo.whms.to.CustomerFamilyTO;
import com.welezo.whms.to.CustomerHealthanalysisTO;
import com.welezo.whms.to.DispatchTrackingTO;
import com.welezo.whms.to.EmpanellmentTO;
import com.welezo.whms.to.ExtensionDetailsTO;
import com.welezo.whms.to.HealthAppointmentTO;
import com.welezo.whms.to.HospitalServiceTO;
import com.welezo.whms.to.InventoryTO;
import com.welezo.whms.to.ItemMasterTO;
import com.welezo.whms.to.PaymentDetailsTO;
import com.welezo.whms.to.PresalesTO;
import com.welezo.whms.to.ProductMasterTO;
import com.welezo.whms.to.ServicesTO;
import com.welezo.whms.to.TeamsTO;
import com.welezo.whms.to.TransactionMasterTO;
import com.welezo.whms.to.VendorsTO;
import com.welezo.whms.to.WelezoConstantsTO;

public interface AdminDao {

	// save update and delete customer data by Admin...
	public <T> void saveAdmin(T entity);

	public <T> void upDateAdmin(T entity);

	public <T> void saveOrUpdate(T entity);

	public void deleteCustomer(Integer id);

	// retrieve all customer data from data base for view and editing process...
	public List<CustomerDeatilsAllDTO> getAllCustomer();

	public List<CustomerFamilyDTO> getFamily(Integer id);

	public CustomerFamilyTO getFamilyId(Integer id);

	public List<CustomerReferencesDTO> getCustRefrence(Integer id);

	public CustomerDeatilsTO getCustomerDetail(Integer id);

	public CustomerHealthanalysisTO getCustomerHealth(int id);

	public ArrayList<HashMap<String, String>> getCustomerPayment(int id);

	public AddressTO getAddress(Integer id);

	public List<AddressTO> getAll(Integer addressId);

	public AddressDTO getAllAddress(Integer entityId, String addressType);

	public List<AddressDTO> getAddressEntityId(Integer entityId);

	public List<ExternalIdDTO> getProofId(Integer id);

	// saving details about hospital customer address from Admin....
	public ArrayList<HashMap<String, String>> getAllHospital(String city);

	public EmpanellmentTO getHospitalById(Integer id);

	public List<HospitalServiceDTO> getAllServiceByHid(Integer Hid);

	public HospitalServiceTO getHospitalServicelById(Integer id);
	public  ArrayList<HashMap<String, String>> getAllservice();
	public  ArrayList<HashMap<String, String>> getAllServiceForHospital(Integer hospitalId);

	// fetching all values from Appointment tables
	public List<HealthAppointmentDTO> getAllAppointments(
			HealthAppointmentDTO healthAppointmentDTO);

	public ServicesTO getAllServices(Integer serviceId);

	public List<PresalesTO> SearchPresales(Integer Aid);

	public HashMap<String, String> getHospitalServices(Integer id);

	public HealthAppointmentTO getAppointmentById(Integer id);

	// transaction all transaction value fetching from database
	public List<TransactionMasterDTO> getAlltransaction(
			TransactionMasterTO masterTO);

	public TransactionMasterTO getTxById(Integer id);

	public List<TransactionMasterDTO> getAllPayments(
			TransactionMasterTO masterTO);

	public PaymentDetailsTO getPaymentById(Integer id);

	public ArrayList<HashMap<String, String>> getAllProducts();

	public ProductMasterTO getproductById(Integer id);

	// dispatch details fetching from database
	public List<DispatchTrackingDTO> getAllDispatchTracks(
			DispatchTrackingDTO dispatchDTO);

	public DispatchTrackingTO getDispatchTrackById(Integer id);

	public DispatchTrackingTO getDispatchDetails(Integer txId);

	// save pre-sales

	public List<PresalesTO> getAllpresales();

	public ArrayList<HashMap<String, String>> FilterAPresales(
			PresalesDTO presalesTO);

	public HashMap<String, String> getPresalesThrId(Integer id);

	public PresalesTO getPresalesById(Integer id);

	// collection fetching, editing saving values
	public ArrayList<HashMap<String, String>> getAllCollections();

	public CollectionTO getCollectionById(Integer id);

	// fetching roletype from employee table
	public List<EmployeeDTO> getAllEmployeeDetails(String designation);

	public EmployeeDTO getEmployeeId(String empId);

	public List<TeamsTO> getAllTeamName();

	public TeamsTO getTeamName(Integer id);

	public List<ChannelsTO> getAllChannels();

	public ChannelsTO getChannelName(Integer id);

	public List<AddressCatagoriesTO> getAllAddressCatagories();

	public AddressCatagoriesTO getAddressTypeId(Integer id);

	public HashMap<String, String> getApplicationNoTx(String applicationNo);

	public List<ProductOffersDTO> getAllProductSevice(Integer id);

	public ArrayList<HashMap<String, String>> getAllTxOffers(Integer id);

	public List<DaywiseCallsIdDTO> getAllDailyCalls();

	public List<ApplicationStockTO> getAllApplicationNo(String status);

	public void getUpdateApplnStatus(String applicationNo, String status);

	public List<ExtensionDetailsTO> geteExtensionDetails();

	public List<WelezoConstantsTO> getWelezoConstant();

	public List<TransactionMasterDTO> getPaymentsBulkOperation();

	public List<TransactionMasterDTO> getPaymentsBulkOperationForOthers();

	public List<VendorsTO> getVendors();

	public List<ItemMasterTO> getItemMaster();

	public VendorsTO getVendorByid(Integer vendorId);

	public ItemMasterTO getItemmasterByid(Integer itemId);

	public List<InventoryTO> getinventry();

	public List<WelezoConstantsTO> getconstants();

	public WelezoConstantsTO getconstantbyid(Integer id);

	public ArrayList<HashMap<String, String>> getAllCollectionOffers(
			Integer collectionId);

	public ArrayList<HashMap<String, String>> geteExtensionNoAndCsr();

	public ArrayList<HashMap<String, String>> getCustomerList(
			String cardRPhnNumber);

	public ArrayList<HashMap<String, String>> getWalkinCustomer(
			String fromDate, String toDate);

	public HashMap<String, String> getWalkinCustomerById(Integer id);

	public ArrayList<HashMap<String, String>> getDispatchList(
			Integer transactionId);

	public ArrayList<HashMap<String, String>> getHealthAppointmnetFBRating();

	public HashMap<String, String> getCustomerFBById(Integer id);
	
	public ArrayList<HashMap<String, String>> getDetailsCustomer();
	
	public ArrayList<String> getDistinctValues(String query);
	
	public ArrayList<HashMap<String, String>> getWelezoBankList();
	
	public ArrayList<HashMap<String, String>> getServicesBasedOnProductId(Integer productId);
	
	public ArrayList<HashMap<String, String>> getServicesNotInProducts(Integer productId);
	
	public ArrayList<HashMap<String, String>> getSeoOnPageList(String fromDate,String toDate);
	public ArrayList<HashMap<String, String>> getOnlineUserList(String fromDate,String toDate) ;
	public ArrayList<HashMap<String, String>> getBannedIpList(String fromDate,String toDate);
	
	public ArrayList<HashMap<String, String>> getIpAddressThruUserDetails(String ipAddress);

	public HashMap<String, String> getSeoOnPageById(Integer id);
	
	public ArrayList<HashMap<String, String>> getCSatListforEdit(Integer appointmentId);

	public HashMap<String, String> getApplicationStatusTx(String applicationNo);
	
	public HashMap<String, String> getApplicationStatusDispatch(String applicationNo);
	
	public HashMap<String, String> getInvoiceTransactionDetails(Integer transactionId);
	
	public ArrayList<HashMap<String, String>> getCustomerReportList();
}
