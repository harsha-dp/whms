package com.welezo.whms.dao;

import java.util.ArrayList;
import java.util.HashMap;

public interface PharmacyDao {
	
	public ArrayList<HashMap<String, String>> getPharmacyList(String fromDate, String toDate,String status);
	
	public HashMap<String, String> getPharmacyDeatilsById(Integer pharmacyId);

	public ArrayList<HashMap<String, String>> getDoctorsList();
	
	public ArrayList<HashMap<String, String>> getPharmacyNameList();
	
	public ArrayList<HashMap<String, String>> getPharmacyLeadList(String fromDate,String toDate,String status);
}
