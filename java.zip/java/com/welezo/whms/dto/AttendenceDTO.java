package com.welezo.whms.dto;


public class AttendenceDTO {

	private Integer[] attendenceId;
	private String[] loginTime;
	private String[] logOutTime;
	private String[] workQuantum;
	private String[] attmark;
	public Integer[] getAttendenceId() {
		return attendenceId;
	}
	public void setAttendenceId(Integer[] attendenceId) {
		this.attendenceId = attendenceId;
	}
	public String[] getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(String[] loginTime) {
		this.loginTime = loginTime;
	}
	public String[] getLogOutTime() {
		return logOutTime;
	}
	public void setLogOutTime(String[] logOutTime) {
		this.logOutTime = logOutTime;
	}
	public String[] getWorkQuantum() {
		return workQuantum;
	}
	public void setWorkQuantum(String[] workQuantum) {
		this.workQuantum = workQuantum;
	}
	public String[] getAttmark() {
		return attmark;
	}
	public void setAttmark(String[] attmark) {
		this.attmark = attmark;
	}
	
}
