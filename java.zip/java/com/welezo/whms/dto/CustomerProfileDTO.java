package com.welezo.whms.dto;

public class CustomerProfileDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4925304160659553615L;
	private Integer id;
	private CustomerDeatilsAllDTO customerDeatils;
	private String salaried;
	private String occupation;
	private String annualIncome;

	public CustomerProfileDTO() {
	}

	public CustomerProfileDTO(CustomerDeatilsAllDTO customerDeatils,
			String salaried, String occupation, String annualIncome) {
		this.customerDeatils = customerDeatils;
		this.salaried = salaried;
		this.occupation = occupation;
		this.annualIncome = annualIncome;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CustomerDeatilsAllDTO getCustomerDeatils() {
		return this.customerDeatils;
	}

	public void setCustomerDeatils(CustomerDeatilsAllDTO customerDeatils) {
		this.customerDeatils = customerDeatils;
	}

	public String getSalaried() {
		return this.salaried;
	}

	public void setSalaried(String salaried) {
		this.salaried = salaried;
	}

	public String getOccupation() {
		return this.occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAnnualIncome() {
		return this.annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

}
