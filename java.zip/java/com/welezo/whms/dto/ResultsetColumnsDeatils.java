package com.welezo.whms.dto;

public class ResultsetColumnsDeatils {
	
	String columnName;
	Integer columnNumber;
	String displayName;
	String hyperLink;
	
	String checkBox[];
	
	
	public String[] getCheckBox() {
		return checkBox;
	}
	public void setCheckBox(String[] checkBox) {
		this.checkBox = checkBox;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public Integer getColumnNumber() {
		return columnNumber;
	}
	public void setColumnNumber(Integer columnNumber) {
		this.columnNumber = columnNumber;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getHyperLink() {
		return hyperLink;
	}
	public void setHyperLink(String hyperLink) {
		this.hyperLink = hyperLink;
	}
	

}
