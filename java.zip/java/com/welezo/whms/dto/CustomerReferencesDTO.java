package com.welezo.whms.dto;

import com.welezo.whms.to.CustomerDeatilsTO;

public class CustomerReferencesDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8133117798611681790L;
	private Integer sl;
	private String name;
	private String relationship;
	private String contactNumber;
	private CustomerDeatilsTO customerDeatils;

	public CustomerReferencesDTO() {
	}

	public CustomerReferencesDTO(CustomerDeatilsTO customerDeatils,
			String name, String relationship, String contactNumber) {
		this.customerDeatils = customerDeatils;
		this.name = name;
		this.relationship = relationship;
		this.contactNumber = contactNumber;
	}

	public Integer getSl() {
		return this.sl;
	}

	public void setSl(Integer sl) {
		this.sl = sl;
	}

	public CustomerDeatilsTO getCustomerDeatils() {
		return customerDeatils;
	}

	public void setCustomerDeatils(CustomerDeatilsTO customerDeatils) {
		this.customerDeatils = customerDeatils;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRelationship() {
		return this.relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getContactNumber() {
		return this.contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

}
