package com.welezo.whms.dto;

import java.util.ArrayList;
import java.util.List;

public class CustomerDeatilsAllDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1746230744564597610L;
	private Integer customerId;
	private String customerName;
	private String dob;
	private String gender;
	private String cardNumber;
	private String maritalStatus;
	private String anniversary;
	private String communiation;
	private String correspondence;

	private int[] proofId;
	private String[] idType;
	private String[] idNumber;

	/* customer address details properties */

	private Integer addressType1;
	private Integer addressType2;
	
	private Integer[] aid;
	private Integer[] entityId;
	private String[] residenceAddresss;
	private String[] locality;
	private String[] landmark;
	private String[] city;
	private String[] pincode;
	private String[] primaryMob;
	private String[] altMob;
	private String[] email;
	private String[] landline;

	/* customer family deatails */
	private int[] familyId;
	private String[] FamilyName;
	private String[] sex;
	private String[] relationship;
	private Integer[] age;
	private String[] memberDOB;

	/* customer payment details */
	private String applicationNumber;
	private String chequeNumber;
	private String bank;
	private String chequeDate;
	private String modOfPayment;
	private String creditDebit;
	private String plans;
	private String topups;
	private String others;
	private String collected;
	private String submittedOn;
	private String soDso;
	private String csr;
	private String team;
	private String channel;
	private String comment;

	/* customer profile properties */
	
	private String salaried;
	private String occupation;
	private String annualIncome;

	/* customer health analysis properties */
	private Integer id;
	private String m5;
	private String m618;
	private String m1935;
	private String m3650;
	private String m5165;
	private String m65;
	private String diagnostic;
	private String consultion;
	private String pharmacy;
	private String hospitalization;
	private String custHeigth;
	private String custWeigth;
	private String insurance;
	private String premium;
	private String sick;
	private String healthCheck;
	private String consultSpecialist;
	private String visitDentist;
	private String medicinFollow;
	private String smoke;
	private String alcohol;
	private String foodHabits;
	private String custSuffer;
	private String parentsSuffer;
	private String exercise;
	private String stressfull;
	private String sleep;
	private String medicalHistory;

	private int[] sl;
	private String[] name;
	private String[] relationshipRef;
	private String[] testNo;
	private String[] contactNumber;

	private Integer createdBy;
	private List<CustomerProfileDTO> customerProfiles = new ArrayList<CustomerProfileDTO>(
			0);
	private List<AddressDTO> customerAddresses = new ArrayList<AddressDTO>(0);
	private List<CustomerFamilyDTO> customerFamilies = new ArrayList<CustomerFamilyDTO>(
			0);
	private List<CustomerHealthanalysisDTO> customerHealthanalysises = new ArrayList<CustomerHealthanalysisDTO>(
			0);
	

	public CustomerDeatilsAllDTO() {
	}

	public CustomerDeatilsAllDTO(String customerName, String dob,
			String gender, String maritalStatus, String anniversary,
			String communiation, String correspondence, String aadharcardId,
			String electionId, String drivingLicense, String passportNumber,
			Integer[] entityId, String[] residenceAddresss, String[] locality,
			String[] landmark, String[] city, String[] pincode,
			String[] primaryMob, String[] altMob, String[] email,
			String[] landline, List<CustomerProfileDTO> customerProfiles,
			List<AddressDTO> customerAddresses,
			List<CustomerFamilyDTO> customerFamilies,
			List<CustomerHealthanalysisDTO> customerHealthanalysises,
			 String[] FamilyName,
			String[] sex, String[] relationship, Integer[] age,
			String applicationNumber, String chequeNumber, String bank,
			String chequeDate, String creditDebit, String plans, String topups,
			String others, String collected, String submittedOn, String soDso,
			String csr, String team, String channel, String comment,
			String salaried, String occupation, String annualIncome, String m5,
			String m618, String m1935, String m3650, String m65,
			String diagnostic, String consultion, String pharmacy,
			String hospitalization, String custHeigth, String custWeigth,
			String insurance, String premium, String sick, String healthCheck,
			String consultSpecialist, String visitDentist,
			String medicinFollow, String smoke, String alcohol,
			String foodHabits, String custSuffer, String parentsSuffer,
			String exercise, String stressfull, String sleep,
			String medicalHistory, String residenceAddresss1, String locality1,
			String landmark1, String city1, String pincode1,
			String primaryMob1, String altMob1, String email1,
			String landline1, String[] name, String[] relationshipRef,
			String[] contactNumber) {
		this.customerName = customerName;
		this.dob = dob;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
		this.anniversary = anniversary;
		this.communiation = communiation;
		this.correspondence = correspondence;
		this.residenceAddresss = residenceAddresss;
		this.locality = locality;
		this.landmark = landmark;
		this.city = city;
		this.pincode = pincode;
		this.primaryMob = primaryMob;
		this.altMob = altMob;
		this.email = email;
		this.landline = landline;

		this.entityId = entityId;

		this.customerProfiles = customerProfiles;
		this.customerAddresses = customerAddresses;
		this.customerFamilies = customerFamilies;
		this.customerHealthanalysises = customerHealthanalysises;

		this.FamilyName = FamilyName;
		this.sex = sex;
		this.relationship = relationship;
		this.age = age;

		this.applicationNumber = applicationNumber;
		this.chequeNumber = chequeNumber;
		this.bank = bank;
		this.chequeDate = chequeDate;
		this.creditDebit = creditDebit;
		this.plans = plans;
		this.topups = topups;
		this.others = others;
		this.collected = collected;
		this.submittedOn = submittedOn;
		this.soDso = soDso;
		this.csr = csr;
		this.team = team;
		this.channel = channel;
		this.comment = comment;

		this.salaried = salaried;
		this.occupation = occupation;
		this.annualIncome = annualIncome;

		this.m5 = m5;
		this.m618 = m618;
		this.m1935 = m1935;
		this.m3650 = m3650;

		this.m65 = m65;
		this.diagnostic = diagnostic;
		this.consultion = consultion;
		this.pharmacy = pharmacy;
		this.hospitalization = hospitalization;
		this.custHeigth = custHeigth;
		this.custWeigth = custWeigth;
		this.insurance = insurance;
		this.premium = premium;
		this.sick = sick;
		this.healthCheck = healthCheck;
		this.consultSpecialist = consultSpecialist;
		this.visitDentist = visitDentist;
		this.medicinFollow = medicinFollow;
		this.smoke = smoke;
		this.alcohol = alcohol;
		this.foodHabits = foodHabits;
		this.custSuffer = custSuffer;
		this.parentsSuffer = parentsSuffer;
		this.exercise = exercise;
		this.stressfull = stressfull;
		this.sleep = sleep;
		this.name = name;
		this.relationshipRef = relationshipRef;
		this.contactNumber = contactNumber;
		this.medicalHistory = medicalHistory;
	}

	
	
	
	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public Integer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}

	public String[] getTestNo() {
		return testNo;
	}

	public void setTestNo(String[] testNo) {
		this.testNo = testNo;
	}

	public Integer[] getAid() {
		return aid;
	}

	public void setAid(Integer[] aid) {
		this.aid = aid;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAddressType1() {
		return addressType1;
	}

	public void setAddressType1(Integer addressType1) {
		this.addressType1 = addressType1;
	}

	public Integer getAddressType2() {
		return addressType2;
	}

	public void setAddressType2(Integer addressType2) {
		this.addressType2 = addressType2;
	}

	public int[] getFamilyId() {
		return familyId;
	}

	public void setFamilyId(int[] familyID2) {
		this.familyId = familyID2;
	}

	public int[] getSl() {
		return sl;
	}

	public void setSl(int[] sl) {
		this.sl = sl;
	}

	public String[] getFamilyName() {
		return FamilyName;
	}

	public void setFamilyName(String[] familyName) {
		FamilyName = familyName;
	}

	public String[] getSex() {
		return sex;
	}

	public void setSex(String[] sex) {
		this.sex = sex;
	}

	public String[] getRelationship() {
		return relationship;
	}

	public void setRelationship(String[] relationship) {
		this.relationship = relationship;
	}

	public Integer[] getAge() {
		return age;
	}

	public void setAge(Integer[] age) {
		this.age = age;
	}

	public String[] getName() {
		return name;
	}

	public void setName(String[] name) {
		this.name = name;
	}

	public String[] getRelationshipRef() {
		return relationshipRef;
	}

	public void setRelationshipRef(String[] relationshipRef) {
		this.relationshipRef = relationshipRef;
	}

	public String[] getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String[] contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Integer getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return this.customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getDob() {
		return this.dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return this.maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getAnniversary() {
		return this.anniversary;
	}

	public void setAnniversary(String anniversary) {
		this.anniversary = anniversary;
	}

	public String getCommuniation() {
		return this.communiation;
	}

	public void setCommuniation(String communiation) {
		this.communiation = communiation;
	}

	public String getCorrespondence() {
		return this.correspondence;
	}

	public void setCorrespondence(String correspondence) {
		this.correspondence = correspondence;
	}

	public int[] getProofId() {
		return proofId;
	}

	public void setProofId(int[] proofId) {
		this.proofId = proofId;
	}

	public String[] getIdType() {
		return idType;
	}

	public void setIdType(String[] idType) {
		this.idType = idType;
	}

	public String[] getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String[] idNumber) {
		this.idNumber = idNumber;
	}

	public List<CustomerProfileDTO> getCustomerProfiles() {
		return this.customerProfiles;
	}

	public void setCustomerProfiles(List<CustomerProfileDTO> customerProfiles) {
		this.customerProfiles = customerProfiles;
	}

	public List<AddressDTO> getCustomerAddresses() {
		return this.customerAddresses;
	}

	public void setCustomerAddresses(List<AddressDTO> customerAddresses) {
		this.customerAddresses = customerAddresses;
	}

	public List<CustomerFamilyDTO> getCustomerFamilies() {
		return this.customerFamilies;
	}

	public void setCustomerFamilies(List<CustomerFamilyDTO> customerFamilies) {
		this.customerFamilies = customerFamilies;
	}

	public List<CustomerHealthanalysisDTO> getCustomerHealthanalysises() {
		return this.customerHealthanalysises;
	}

	public void setCustomerHealthanalysises(
			List<CustomerHealthanalysisDTO> customerHealthanalysises) {
		this.customerHealthanalysises = customerHealthanalysises;
	}



	/* customer address details setter getter methods */

	/* customer family deatils setter getter methods */

	/* customer payment details setter getter methods */
	public String getApplicationNumber() {
		return applicationNumber;
	}

	public Integer[] getEntityId() {
		return entityId;
	}

	public void setEntityId(Integer[] entityId) {
		this.entityId = entityId;
	}

	public String[] getResidenceAddresss() {
		return residenceAddresss;
	}

	public void setResidenceAddresss(String[] residenceAddresss) {
		this.residenceAddresss = residenceAddresss;
	}

	public String[] getLocality() {
		return locality;
	}

	public void setLocality(String[] locality) {
		this.locality = locality;
	}

	public String[] getLandmark() {
		return landmark;
	}

	public void setLandmark(String[] landmark) {
		this.landmark = landmark;
	}

	public String[] getCity() {
		return city;
	}

	public void setCity(String[] city) {
		this.city = city;
	}

	public String[] getPincode() {
		return pincode;
	}

	public void setPincode(String[] pincode) {
		this.pincode = pincode;
	}

	public String[] getPrimaryMob() {
		return primaryMob;
	}

	public void setPrimaryMob(String[] primaryMob) {
		this.primaryMob = primaryMob;
	}

	public String[] getAltMob() {
		return altMob;
	}

	public void setAltMob(String[] altMob) {
		this.altMob = altMob;
	}

	public String[] getEmail() {
		return email;
	}

	public void setEmail(String[] email) {
		this.email = email;
	}

	public String[] getLandline() {
		return landline;
	}

	public void setLandline(String[] landline) {
		this.landline = landline;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getChequeNumber() {
		return chequeNumber;
	}

	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}

	public String getModOfPayment() {
		return modOfPayment;
	}

	public void setModOfPayment(String modOfPayment) {
		this.modOfPayment = modOfPayment;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getChequeDate() {
		return chequeDate;
	}

	public void setChequeDate(String chequeDate) {
		this.chequeDate = chequeDate;
	}

	public String getCreditDebit() {
		return creditDebit;
	}

	public void setCreditDebit(String creditDebit) {
		this.creditDebit = creditDebit;
	}

	public String getPlans() {
		return plans;
	}

	public void setPlans(String plans) {
		this.plans = plans;
	}

	public String getTopups() {
		return topups;
	}

	public void setTopups(String topups) {
		this.topups = topups;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public String getCollected() {
		return collected;
	}

	public void setCollected(String collected) {
		this.collected = collected;
	}

	public String getSubmittedOn() {
		return submittedOn;
	}

	public void setSubmittedOn(String submittedOn) {
		this.submittedOn = submittedOn;
	}

	public String getSoDso() {
		return soDso;
	}

	public void setSoDso(String soDso) {
		this.soDso = soDso;
	}

	public String getCsr() {
		return csr;
	}

	public void setCsr(String csr) {
		this.csr = csr;
	}

	public String getTeam() {
		return team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	/* customer profile setter getter methods */
	public String getSalaried() {
		return salaried;
	}

	public void setSalaried(String salaried) {
		this.salaried = salaried;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	/* customer health analysis setter getter methods */

	public String getDiagnostic() {
		return diagnostic;
	}

	public String getM65() {
		return m65;
	}

	public void setM65(String m65) {
		this.m65 = m65;
	}

	public String getMedicalHistory() {
		return medicalHistory;
	}

	public void setMedicalHistory(String medicalHistory) {
		this.medicalHistory = medicalHistory;
	}

	public String getM5() {
		return m5;
	}

	public void setM5(String m5) {
		this.m5 = m5;
	}

	public String getM618() {
		return m618;
	}

	public void setM618(String m618) {
		this.m618 = m618;
	}

	public String getM1935() {
		return m1935;
	}

	public void setM1935(String m1935) {
		this.m1935 = m1935;
	}

	public String getM3650() {
		return m3650;
	}

	public void setM3650(String m3650) {
		this.m3650 = m3650;
	}

	public String getM5165() {
		return m5165;
	}

	public void setM5165(String m5165) {
		this.m5165 = m5165;
	}

	public void setDiagnostic(String diagnostic) {
		this.diagnostic = diagnostic;
	}

	public String getConsultion() {
		return consultion;
	}

	public void setConsultion(String consultion) {
		this.consultion = consultion;
	}

	public String getPharmacy() {
		return pharmacy;
	}

	public void setPharmacy(String pharmacy) {
		this.pharmacy = pharmacy;
	}

	public String getHospitalization() {
		return hospitalization;
	}

	public void setHospitalization(String hospitalization) {
		this.hospitalization = hospitalization;
	}

	public String getCustHeigth() {
		return custHeigth;
	}

	public void setCustHeigth(String custHeigth) {
		this.custHeigth = custHeigth;
	}

	public String getCustWeigth() {
		return custWeigth;
	}

	public void setCustWeigth(String custWeigth) {
		this.custWeigth = custWeigth;
	}

	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	public String getPremium() {
		return premium;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	public String getSick() {
		return sick;
	}

	public void setSick(String sick) {
		this.sick = sick;
	}

	public String getHealthCheck() {
		return healthCheck;
	}

	public void setHealthCheck(String healthCheck) {
		this.healthCheck = healthCheck;
	}

	public String getConsultSpecialist() {
		return consultSpecialist;
	}

	public void setConsultSpecialist(String consultSpecialist) {
		this.consultSpecialist = consultSpecialist;
	}

	public String getVisitDentist() {
		return visitDentist;
	}

	public void setVisitDentist(String visitDentist) {
		this.visitDentist = visitDentist;
	}

	public String getMedicinFollow() {
		return medicinFollow;
	}

	public void setMedicinFollow(String medicinFollow) {
		this.medicinFollow = medicinFollow;
	}

	public String getSmoke() {
		return smoke;
	}

	public void setSmoke(String smoke) {
		this.smoke = smoke;
	}

	public String getAlcohol() {
		return alcohol;
	}

	public void setAlcohol(String alcohol) {
		this.alcohol = alcohol;
	}

	public String getFoodHabits() {
		return foodHabits;
	}

	public void setFoodHabits(String foodHabits) {
		this.foodHabits = foodHabits;
	}

	public String getCustSuffer() {
		return custSuffer;
	}

	public void setCustSuffer(String custSuffer) {
		this.custSuffer = custSuffer;
	}

	public String getParentsSuffer() {
		return parentsSuffer;
	}

	public void setParentsSuffer(String parentsSuffer) {
		this.parentsSuffer = parentsSuffer;
	}

	public String getExercise() {
		return exercise;
	}

	public void setExercise(String exercise) {
		this.exercise = exercise;
	}

	public String getStressfull() {
		return stressfull;
	}

	public void setStressfull(String stressfull) {
		this.stressfull = stressfull;
	}

	public String getSleep() {
		return sleep;
	}

	public void setSleep(String sleep) {
		this.sleep = sleep;
	}

	public String[] getMemberDOB() {
		return memberDOB;
	}

	public void setMemberDOB(String[] memberDOB) {
		this.memberDOB = memberDOB;
	}

}
