package com.welezo.whms.dto;

import java.util.Date;

public class CustomerPaymentDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2857277645545732717L;
	private Integer paymentId;
	private CustomerDeatilsAllDTO customerDeatils;
	private String applicationNumber;
	private String chequeNumber;
	private String bank;
	private Date chequeDate;
	private String creditDebit;
	private String plans;
	private String topups;
	private String others;
	private String collected;
	private Date submittedOn;
	private String soDso;
	private String csr;
	private String team;
	private String channel;
	private String comment;

	public CustomerPaymentDTO() {
	}

	public CustomerPaymentDTO(CustomerDeatilsAllDTO customerDeatils,
			String applicationNumber, String chequeNumber, String bank,
			Date chequeDate, String creditDebit, String plans, String topups,
			String others, String collected, Date submittedOn, String soDso,
			String csr, String team, String channel, String comment) {
		this.customerDeatils = customerDeatils;
		this.applicationNumber = applicationNumber;
		this.chequeNumber = chequeNumber;
		this.bank = bank;
		this.chequeDate = chequeDate;
		this.creditDebit = creditDebit;
		this.plans = plans;
		this.topups = topups;
		this.others = others;
		this.collected = collected;
		this.submittedOn = submittedOn;
		this.soDso = soDso;
		this.csr = csr;
		this.team = team;
		this.channel = channel;
		this.comment = comment;
	}

	public Integer getPaymentId() {
		return this.paymentId;
	}

	public void setPaymentId(Integer paymentId) {
		this.paymentId = paymentId;
	}

	public CustomerDeatilsAllDTO getCustomerDeatils() {
		return this.customerDeatils;
	}

	public void setCustomerDeatils(CustomerDeatilsAllDTO customerDeatils) {
		this.customerDeatils = customerDeatils;
	}

	public String getApplicationNumber() {
		return this.applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getChequeNumber() {
		return this.chequeNumber;
	}

	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}

	public String getBank() {
		return this.bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public Date getChequeDate() {
		return this.chequeDate;
	}

	public void setChequeDate(Date chequeDate) {
		this.chequeDate = chequeDate;
	}

	public String getCreditDebit() {
		return this.creditDebit;
	}

	public void setCreditDebit(String creditDebit) {
		this.creditDebit = creditDebit;
	}

	public String getPlans() {
		return this.plans;
	}

	public void setPlans(String plans) {
		this.plans = plans;
	}

	public String getTopups() {
		return this.topups;
	}

	public void setTopups(String topups) {
		this.topups = topups;
	}

	public String getOthers() {
		return this.others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public String getCollected() {
		return this.collected;
	}

	public void setCollected(String collected) {
		this.collected = collected;
	}

	public Date getSubmittedOn() {
		return this.submittedOn;
	}

	public void setSubmittedOn(Date submittedOn) {
		this.submittedOn = submittedOn;
	}

	public String getSoDso() {
		return this.soDso;
	}

	public void setSoDso(String soDso) {
		this.soDso = soDso;
	}

	public String getCsr() {
		return this.csr;
	}

	public void setCsr(String csr) {
		this.csr = csr;
	}

	public String getTeam() {
		return this.team;
	}

	public void setTeam(String team) {
		this.team = team;
	}

	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

}
