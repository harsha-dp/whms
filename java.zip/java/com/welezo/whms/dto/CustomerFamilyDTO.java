package com.welezo.whms.dto;

public class CustomerFamilyDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7066746314639259084L;
	private Integer familyId;
	private CustomerDeatilsAllDTO customerDeatils;
	private String FName;
	private String gender;
	private String relationship;
	private String age;
	private String dob;

	public CustomerFamilyDTO() {
	}

	public CustomerFamilyDTO(CustomerDeatilsAllDTO customerDeatils, String FName,
			String gender, String relationship, String age,String dob) {
		this.customerDeatils = customerDeatils;
		this.FName = FName;
		this.gender = gender;
		this.relationship = relationship;
		this.age = age;
		this.dob = dob;
	}

	public Integer getFamilyId() {
		return this.familyId;
	}

	public void setFamilyId(Integer familyId) {
		this.familyId = familyId;
	}

	public CustomerDeatilsAllDTO getCustomerDeatils() {
		return this.customerDeatils;
	}

	public void setCustomerDeatils(CustomerDeatilsAllDTO customerDeatils) {
		this.customerDeatils = customerDeatils;
	}

	public String getFName() {
		return this.FName;
	}

	public void setFName(String FName) {
		this.FName = FName;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRelationship() {
		return this.relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getAge() {
		return this.age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

}
