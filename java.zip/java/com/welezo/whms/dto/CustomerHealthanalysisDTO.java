package com.welezo.whms.dto;

import javax.persistence.Column;

public class CustomerHealthanalysisDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8382251594007820422L;
	private Integer id;
	private CustomerDeatilsAllDTO customerDeatils;
	private String diagnostic;
	private String consultion;
	private String pharmacy;
	private String hospitalization;
	private String custHeigth;
	private String custWeigth;
	private String insurance;
	private String premium;
	private String sick;
	private String healthCheck;
	private String consultSpecialist;
	private String visitDentist;
	private String medicinFollow;
	private String smoke;
	private String alcohol;
	private String foodHabits;
	private String custSuffer;
	private String parentsSuffer;
	private String exercise;
	private String stressfull;
	private String sleep;

	public CustomerHealthanalysisDTO() {
	}

	public CustomerHealthanalysisDTO(CustomerDeatilsAllDTO customerDeatils,
			String diagnostic, String consultion, String pharmacy,
			String hospitalization, String custHeigth, String custWeigth,
			String insurance, String premium, String sick, String healthCheck,
			String consultSpecialist, String visitDentist,
			String medicinFollow, String smoke, String alcohol,
			String foodHabits, String custSuffer, String parentsSuffer,
			String exercise, String stressfull, String sleep) {
		this.customerDeatils = customerDeatils;
		this.diagnostic = diagnostic;
		this.consultion = consultion;
		this.pharmacy = pharmacy;
		this.hospitalization = hospitalization;
		this.custHeigth = custHeigth;
		this.custWeigth = custWeigth;
		this.insurance = insurance;
		this.premium = premium;
		this.sick = sick;
		this.healthCheck = healthCheck;
		this.consultSpecialist = consultSpecialist;
		this.visitDentist = visitDentist;
		this.medicinFollow = medicinFollow;
		this.smoke = smoke;
		this.alcohol = alcohol;
		this.foodHabits = foodHabits;
		this.custSuffer = custSuffer;
		this.parentsSuffer = parentsSuffer;
		this.exercise = exercise;
		this.stressfull = stressfull;
		this.sleep = sleep;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public CustomerDeatilsAllDTO getCustomerDeatils() {
		return this.customerDeatils;
	}

	public void setCustomerDeatils(CustomerDeatilsAllDTO customerDeatils) {
		this.customerDeatils = customerDeatils;
	}

	public String getDiagnostic() {
		return this.diagnostic;
	}

	public void setDiagnostic(String diagnostic) {
		this.diagnostic = diagnostic;
	}

	@Column(name = "consultion", length = 100)
	public String getConsultion() {
		return this.consultion;
	}

	public void setConsultion(String consultion) {
		this.consultion = consultion;
	}

	@Column(name = "pharmacy", length = 100)
	public String getPharmacy() {
		return this.pharmacy;
	}

	public void setPharmacy(String pharmacy) {
		this.pharmacy = pharmacy;
	}

	@Column(name = "hospitalization", length = 100)
	public String getHospitalization() {
		return this.hospitalization;
	}

	public void setHospitalization(String hospitalization) {
		this.hospitalization = hospitalization;
	}

	@Column(name = "cust_heigth", length = 100)
	public String getCustHeigth() {
		return this.custHeigth;
	}

	public void setCustHeigth(String custHeigth) {
		this.custHeigth = custHeigth;
	}

	@Column(name = "cust_weigth", length = 100)
	public String getCustWeigth() {
		return this.custWeigth;
	}

	public void setCustWeigth(String custWeigth) {
		this.custWeigth = custWeigth;
	}

	@Column(name = "insurance", length = 100)
	public String getInsurance() {
		return this.insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	@Column(name = "premium", length = 200)
	public String getPremium() {
		return this.premium;
	}

	public void setPremium(String premium) {
		this.premium = premium;
	}

	@Column(name = "sick", length = 100)
	public String getSick() {
		return this.sick;
	}

	public void setSick(String sick) {
		this.sick = sick;
	}

	@Column(name = "health_check", length = 200)
	public String getHealthCheck() {
		return this.healthCheck;
	}

	public void setHealthCheck(String healthCheck) {
		this.healthCheck = healthCheck;
	}

	public String getConsultSpecialist() {
		return this.consultSpecialist;
	}

	public void setConsultSpecialist(String consultSpecialist) {
		this.consultSpecialist = consultSpecialist;
	}

	public String getVisitDentist() {
		return this.visitDentist;
	}

	public void setVisitDentist(String visitDentist) {
		this.visitDentist = visitDentist;
	}

	public String getMedicinFollow() {
		return this.medicinFollow;
	}

	public void setMedicinFollow(String medicinFollow) {
		this.medicinFollow = medicinFollow;
	}

	public String getSmoke() {
		return this.smoke;
	}

	public void setSmoke(String smoke) {
		this.smoke = smoke;
	}

	public String getAlcohol() {
		return this.alcohol;
	}

	public void setAlcohol(String alcohol) {
		this.alcohol = alcohol;
	}

	public String getFoodHabits() {
		return this.foodHabits;
	}

	public void setFoodHabits(String foodHabits) {
		this.foodHabits = foodHabits;
	}

	public String getCustSuffer() {
		return this.custSuffer;
	}

	public void setCustSuffer(String custSuffer) {
		this.custSuffer = custSuffer;
	}

	public String getParentsSuffer() {
		return this.parentsSuffer;
	}

	public void setParentsSuffer(String parentsSuffer) {
		this.parentsSuffer = parentsSuffer;
	}

	public String getExercise() {
		return this.exercise;
	}

	public void setExercise(String exercise) {
		this.exercise = exercise;
	}

	public String getStressfull() {
		return this.stressfull;
	}

	public void setStressfull(String stressfull) {
		this.stressfull = stressfull;
	}

	public String getSleep() {
		return this.sleep;
	}

	public void setSleep(String sleep) {
		this.sleep = sleep;
	}

}
