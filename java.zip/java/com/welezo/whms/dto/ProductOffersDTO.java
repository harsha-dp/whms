package com.welezo.whms.dto;

// Generated Nov 11, 2016 7:43:34 AM by Hibernate Tools 4.0.0

/**
 * Author Mr.Lohith
 */
public class ProductOffersDTO implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 49216380973611597L;
	private int offerId;
	private Integer productId;
	private Integer servicesId;
	private Integer quantity;

	public ProductOffersDTO() {
	}

	public ProductOffersDTO(int offerId) {
		this.offerId = offerId;
	}

	public ProductOffersDTO(int offerId, Integer productId, Integer servicesId,
			Integer quantity) {
		this.offerId = offerId;
		this.productId = productId;
		this.servicesId = servicesId;
		this.quantity = quantity;
	}

	public int getOfferId() {
		return this.offerId;
	}

	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public Integer getServicesId() {
		return servicesId;
	}

	public void setServicesId(Integer servicesId) {
		this.servicesId = servicesId;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

}
